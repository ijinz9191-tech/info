# Workspace Documentation Generator AI Skill v3

React 화면, Spring Boot 및 Vert.x 백엔드가 함께 있는 Workspace를 전체 분석하여 **화면→API→백엔드→DB/메시징/관측 리소스** 연결을 자동 추적하고 공식 문서를 생성한다.

```text
사용자메뉴얼.pptx        React 화면 이미지·태그·절차·API 연결
운영자메뉴얼.pptx        Spring Boot·Vert.x·EventBus·운영 리소스
인터페이스명세서.xlsx    React/Spring/Vert.x 통합 인터페이스
프로그램목록.xlsx        화면·컴포넌트·클래스·Verticle·모듈
WorkBook.xlsx            분석 요약·구현 흐름·검토 항목
테이블정의서.xlsx        Oracle 정의와 Spring/Vert.x DB 사용처
아키텍쳐정의서.xlsx      프레임워크 공존·리소스·배포·관측 구조
```

## 1. 지원 범위

### Frontend

- React, TypeScript/JavaScript, TSX/JSX
- React Router JSX/객체형 Route
- Vite, Create React App, Next 기반 React 의존성 탐지
- Component, custom Hook, Redux/Zustand/Context/React Query
- Axios, fetch, WebSocket, SSE/EventSource
- Route·메뉴·역할 후보·화면 Component·API 호출 연결
- Playwright 화면 캡처, DOM 요소, 네트워크/콘솔 오류 수집

### Spring Boot

- MVC annotation API, WebFlux functional route
- Controller, Service, Repository, Configuration
- Interface/Implementation, Injection, Bean
- Spring Security, configuration properties, profile
- Scheduler, listener, Kafka listener, transaction, Actuator
- RestTemplate/WebClient/RestClient 및 내부·외부 호출
- JPA/JDBC/MyBatis, Redis, Elasticsearch, Kafka, Micrometer

### Vert.x

- Verticle/AbstractVerticle, deployVerticle, worker 후보
- HTTP server, Router, Route, Handler, subRouter
- EventBus send/publish/request/consumer, producer-consumer topology
- EventBus codec와 service proxy 후보
- WebClient/HttpClient
- Config, SharedData, timer
- Oracle SQL client, Redis client, Kafka client, Micrometer

### 공통·리소스

- Maven/Gradle 멀티모듈, 공통 모듈, NPM package
- Maven/Gradle repository, dependency, version catalog, local JAR
- JAR manifest/package/SPI/Spring AutoConfiguration와 import 연결
- Oracle, Redis, Elasticsearch, Kafka
- Grafana, Prometheus, Loki/Promtail
- Docker, Kubernetes, Helm, Kustomize, CI/CD 설정

## 2. 설치

Python 3.9 이상을 사용한다.

```bash
cd workspace-doc-ai-skill
python -m venv .venv
```

Windows:

```bat
.venv\Scripts\activate
pip install -r requirements.txt
playwright install chromium
```

Linux/macOS:

```bash
source .venv/bin/activate
pip install -r requirements.txt
playwright install chromium
```

Oracle·Redis·Kafka Runtime 점검까지 사용할 경우 추가 설치한다.

```bash
pip install -r requirements-runtime.txt
```

정적 분석과 Excel/PPT 생성은 Runtime 전용 패키지가 없어도 동작한다.

## 3. 최소 설정

`config.yaml`의 Workspace만 실제 경로로 수정한다.

```yaml
workspace:
  root: "C:/work/my-system"
  name: "MY_SYSTEM"
```

정적 분석만으로도 5개 Excel과 2개 PPT를 생성할 수 있다. 실제 화면 이미지를 넣으려면 React 앱을 실행하고 다음을 활성화한다.

```yaml
screenshots:
  enabled: true
  base_url: "http://localhost:3000"
  manual_pages_file: ""

react_spa:
  navigation_mode: "auto"
```

`manual_pages_file`이 비어 있으면 React Router를 분석해 화면 목록을 자동 생성한다. 화면별 업무 설명이나 클릭 동작을 추가하려면 다음처럼 파일을 지정한다.

```yaml
screenshots:
  manual_pages_file: "examples/manual_pages.example.yaml"
```

## 4. 전체 실행

```bash
python scripts/generate_all.py --config config.yaml
```

분석만:

```bash
python scripts/generate_all.py --config config.yaml --analysis-only
```

화면 캡처 제외:

```bash
python scripts/generate_all.py --config config.yaml --skip-screenshots
```

Runtime 점검 제외:

```bash
python scripts/generate_all.py --config config.yaml --skip-runtime-probe
```

## 5. React 화면 자동 분석 및 캡처

### Route 자동 생성

다음 형태를 탐지한다.

```tsx
<Route path="/users" element={<UsersPage />} />
```

```ts
const routes = [
  { path: "/events", element: <EventsPage /> }
]
```

화면 Route와 해당 Component 안의 API 호출을 연결한다.

```tsx
axios.get('/api/users')
fetch('/api/events')
```

그다음 `/api/users`, `/api/events`를 Spring Boot API 또는 Vert.x Route와 비교해 다음 흐름을 만든다.

```text
/users → UsersPage → GET /api/users → Spring Boot UserController.users
/events → EventsPage → GET /api/events → Vert.x MainVerticle::events
```

### SPA 이동 방식

```yaml
react_spa:
  navigation_mode: "auto" # auto | direct | hash | spa
  app_base_path: ""
  fallback_to_client_navigation: true
```

- `direct`: 각 Route URL로 직접 접속
- `hash`: HashRouter 방식
- `spa`: 루트 접속 후 History API로 이동
- `auto`: direct 실패 시 spa 방식으로 보완

### 화면별 사용자 동작

`examples/manual_pages.example.yaml`에서 화면마다 동작을 지정할 수 있다.

```yaml
actions:
  - type: "fill"
    selector: "input[name='keyword']"
    value: "테스트"
  - type: "click"
    selector: "button[data-testid='search']"
  - type: "wait"
    selector: "table tbody tr"
```

지원 동작은 `click`, `fill`, `select`, `press`, `wait`, `sleep`이다.

### 수집되는 화면 근거

- screenshot PNG
- 최종 URL과 Route
- 제목, heading, button, input, link, table, dialog
- XHR/fetch/document/WebSocket/EventSource 요청
- 실패한 network 요청
- browser console/page error
- 정적 API 호출과 backend 매핑

## 6. Spring Boot와 Vert.x 연결 분석

### 통합 Endpoint 목록

Spring Boot의 annotation/functional endpoint와 Vert.x route를 하나의 backend endpoint 목록으로 만든다.

```text
SPRING_BOOT  GET /api/users  UserController.users
VERTX        GET /api/events MainVerticle::events
```

### 내부 HTTP 흐름

Spring Boot RestTemplate/WebClient/RestClient 및 Vert.x WebClient/HttpClient 호출도 통합 endpoint와 비교한다.

```text
Spring UserController
  └─ GET http://vertx-service:8090/api/events
       └─ Vert.x MainVerticle::events
```

### Vert.x EventBus

동일 address의 producer와 consumer를 연결한다.

```text
MainVerticle --send audit.write--> AuditVerticle
MainVerticle --request user.lookup--> UserQueryVerticle
Publisher    --publish cache.changed--> 복수 consumer 후보
```

동적 address나 미연결 producer/consumer는 `확인필요`로 남긴다.

## 7. 공통 모듈 및 JAR 분석

다음 내용을 자동 추출한다.

- Maven/Gradle module 및 dependency
- NPM dependency와 React 빌드 script
- common/core/shared 모듈의 class와 소비 모듈
- Maven/Gradle repository와 실제 download coordinate
- local JAR와 선택적 `.m2`/Gradle cache 경로
- JAR manifest, Maven coordinate, package, SPI, auto configuration
- source import와 JAR package 연결

로컬 dependency cache까지 확인하려면 다음을 켠다.

```yaml
analysis:
  inspect_dependency_cache: true
```

## 8. Runtime 점검

기본값은 비활성이다.

```yaml
runtime_probe:
  enabled: true
  allow_discovered_endpoints: false
```

환경변수 예시는 `examples/runtime.env.example`에 있다.

```text
ORACLE_DSN / ORACLE_USER / ORACLE_PASSWORD
REDIS_URL / REDIS_USERNAME / REDIS_PASSWORD
ELASTICSEARCH_URL / ELASTICSEARCH_USERNAME / ELASTICSEARCH_PASSWORD
KAFKA_BOOTSTRAP_SERVERS / KAFKA_USERNAME / KAFKA_PASSWORD
GRAFANA_URL / GRAFANA_TOKEN
PROMETHEUS_URL / PROMETHEUS_TOKEN
LOKI_URL / LOKI_TOKEN
```

안전 기준:

- Oracle: SELECT와 metadata 조회만
- Redis: PING/INFO/DBSIZE, key scan 기본 비활성, value 미조회
- Elasticsearch/Grafana/Prometheus/Loki: GET만
- Kafka: metadata/topic/consumer group, payload 미소비
- Secret은 생성 JSON/Excel/PPT에서 마스킹
- 소스에서 자동 발견한 주소는 명시적 허용 전에는 실제 접속하지 않음

## 9. 운영 화면 캡처

Grafana dashboard와 Prometheus Targets/Alerts/Rules 화면을 자동 생성·캡처할 수 있다.

```yaml
resource_screenshots:
  enabled: true
  auto_generate: true
  allow_discovered_endpoints: false
  grafana_url: "https://grafana.example"
  prometheus_url: "https://prometheus.example"
```

인증 값은 `auth_profiles`에 지정된 환경변수에서 읽는다. Loki는 독립 UI가 없는 구성이 많으므로 정적·Runtime 정보가 기본이며, 필요한 URL을 수동 page로 추가할 수 있다.

## 10. 생성 문서 구조

### 인터페이스명세서.xlsx

React API, 화면-API-backend, Spring Boot API/Security/외부호출, Vert.x Route/EventBus/외부호출, 리소스 연계, JAR/NPM dependency를 포함한다.

### 프로그램목록.xlsx

모듈·기술스택·파일·React package/component/hook/route·Spring component·Verticle/Handler·class/method·배포 workload를 포함한다.

### WorkBook.xlsx

프로젝트 분석 요약, 프레임워크 역할, React-Spring-Vert.x 흐름, API 매핑 검토, EventBus topology, 실행·배포 구성, 공통 모듈/JAR, 영향도와 확인 항목을 포함한다.

### 테이블정의서.xlsx

Oracle object 정의와 함께 Spring JDBC/JPA/MyBatis 및 Vert.x SQL client의 DB 접근 근거를 포함한다.

### 아키텍쳐정의서.xlsx

Frontend/Spring Boot/Vert.x 구조, 프레임워크 공존, Frontend-Backend/API/EventBus 흐름, 리소스/배포/관측 구조, Mermaid 원문을 포함한다.

### 사용자메뉴얼.pptx

화면 이미지, Route, React Component, 대상 역할, 태그, 설명, 단계, DOM 요소, 정적 API-backend 연결, 실제 network 요청을 포함한다.

### 운영자메뉴얼.pptx

기술 스택, Spring Boot, Vert.x, EventBus, Oracle/Redis/Elasticsearch/Kafka, Grafana/Prometheus/Loki, Kubernetes, runtime 및 검토 항목을 포함한다.

## 11. 산출 디렉터리

```text
output/
  analysis/
    workspace_analysis.json
    workspace_summary.md
    runtime_probe.json
    validation_report.json
  screenshots/
    manual_pages.generated.json
    *.png
  resource-screenshots/
    resource_pages.generated.json
    *.png
  excel/
    인터페이스명세서.xlsx
    프로그램목록.xlsx
    WorkBook.xlsx
    테이블정의서.xlsx
    아키텍쳐정의서.xlsx
  ppt/
    사용자메뉴얼.pptx
    운영자메뉴얼.pptx
```

## 12. 자동 검증

마지막 단계에서 다음을 다시 확인한다.

- JSON parse와 schema
- 분석 파일 수
- 5개 Excel 파일 열림 및 필수 시트
- 2개 PPT 파일 열림 및 최소 슬라이드 수
- 오류와 경고를 `validation_report.json`에 기록

개별 검증:

```bash
python scripts/validate_outputs.py --config config.yaml
```

## 13. 내장 Self Test

설치 직후 프레임워크 매핑과 문서 생성 전체를 확인한다.

```bash
python scripts/self_test.py
```

결과를 보존하려면 `--keep`, 지정 디렉터리를 사용하려면 `--work-dir ./self-test-work`를 사용한다. 자세한 내용은 `SELF_TEST.md`에 있다.

## 14. 주요 파일

```text
scripts/analyze_workspace.py          Workspace 통합 분석
scripts/utils/react_parser.py         React/Router/API/상태 분석
scripts/utils/spring_parser.py        Spring Boot 전용 분석
scripts/utils/vertx_parser.py         Vert.x/Router/EventBus 분석
scripts/utils/framework_mapper.py     React-Spring-Vert.x 연결
scripts/probe_runtime_resources.py    7종 리소스 읽기 전용 점검
scripts/capture_manual_screens.py     React 화면·DOM·network 캡처
scripts/capture_resource_screens.py   운영 화면 캡처
scripts/generate_excel_documents.py   5개 Excel 생성
scripts/generate_manual_ppt.py        2개 PPT 생성
scripts/validate_outputs.py           산출물 검증
scripts/generate_all.py               전체 파이프라인
```

세부 분석 규칙은 `references/` 문서를 참고한다.
