# Runtime Probe 규칙

## 기본 정책

- 기본 비활성
- 환경변수 또는 명시 URL만 사용
- 발견 endpoint 자동 접속은 별도 허용 필요
- timeout 적용
- 실패해도 정적 문서 생성 지속

## 읽기 범위

- Oracle: schema metadata SELECT
- Redis: PING, INFO, DBSIZE; key scan은 opt-in, value 미조회
- Elasticsearch: cluster health, index/alias metadata GET
- Kafka: broker metadata, topic/group 정보; payload 미소비
- Grafana: health/dashboard metadata GET
- Prometheus: targets, alerts, rules, status GET
- Loki: ready/status/label metadata GET

## 결과 표현

- `OK`: 읽기 요청 성공
- `SKIPPED`: 비활성/환경변수 없음
- `FAILED`: 접속·인증·timeout 실패

`FAILED`는 실제 서비스 장애가 아니라 문서화 프로세스의 접속 실패다.
