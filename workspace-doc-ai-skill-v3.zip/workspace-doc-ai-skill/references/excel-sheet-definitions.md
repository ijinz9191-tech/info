# Excel 시트 정의 v3

모든 시트는 제목행, 헤더, AutoFilter, freeze pane, 줄바꿈, 적정 열 너비, 근거파일/Line을 적용한다. 행이 많으면 Excel 한계를 넘지 않도록 분할한다.

## 인터페이스명세서

통합 API, React API, 화면-API-backend, Spring Boot, Vert.x Route/EventBus, resource, JAR/NPM 연결을 제공한다.

## 프로그램목록

module/file/class/method 외에 React package/component/hook/route, Spring component, Verticle/Handler/deployment를 제공한다.

## WorkBook

요약과 품질 체크, framework role, cross-framework flow, API/EventBus 검토, 실행·배포·resource/JAR 흐름을 제공한다.

## 테이블정의서

Oracle object 정의와 Entity/MyBatis/SQL reference 및 Spring/Vert.x DB 접근 component를 제공한다.

## 아키텍쳐정의서

Frontend/Spring/Vert.x, 공존 구조, API/EventBus, resource/deployment/observability, Mermaid 원문과 검토 항목을 제공한다.
