# Package Manifest v3.0.0

## Entrypoint

- `SKILL.md` — AI agent 실행 규칙
- `config.yaml` — Workspace, React 캡처, Runtime probe, Excel/PPT 설정
- `scripts/generate_all.py` — 전체 파이프라인

## Framework analyzers

- `scripts/utils/react_parser.py`
- `scripts/utils/spring_parser.py`
- `scripts/utils/vertx_parser.py`
- `scripts/utils/framework_mapper.py`

## Resource/JAR analyzers

- `dependency_parser.py`, `jar_parser.py`, `db_parser.py`, `resource_parser.py`
- Oracle, Redis, Elasticsearch, Kafka, Grafana, Prometheus, Loki

## Output generators

- `generate_excel_documents.py` — 5개 Excel
- `generate_manual_ppt.py` — 사용자/운영자 PPT
- `capture_manual_screens.py` — React 화면·DOM·network
- `capture_resource_screens.py` — Grafana/Prometheus/Loki 화면
- `validate_outputs.py` — JSON/Excel/PPT 검증

## Rules and schemas

- `references/` — 프레임워크·연결·리소스·문서 규칙
- `schemas/` — analysis/runtime/manual JSON Schema
- `prompts/document_writer_prompt.md` — 근거 기반 문서 작성 프롬프트

## Test

- `scripts/self_test.py`
- `tests/fixtures/react-spring-vertx/`
- `SELF_TEST.md`
