# Self Test

패키지에는 React + Spring Boot + Vert.x + Oracle/Redis/Elasticsearch/Kafka/Grafana/Prometheus/Loki 예제 Workspace가 포함되어 있다.

```bash
python scripts/self_test.py
```

생성 결과를 유지하려면:

```bash
python scripts/self_test.py --keep
```

지정 경로에 생성하려면:

```bash
python scripts/self_test.py --work-dir ./self-test-work
```

Self test는 다음을 확인한다.

- React Route 2개 이상
- React API 호출 2개 이상
- React→Backend 매핑 2개 이상
- Spring Boot endpoint 2개 이상
- Vert.x route 2개 이상
- Verticle 2개 이상
- EventBus 연결 2개 이상
- 5개 Excel 및 필수 시트
- 사용자/운영자 PPT
- 분석/Runtime JSON Schema

화면과 Runtime 리소스는 실행 환경에 의존하므로 self test에서는 비활성화한다.
