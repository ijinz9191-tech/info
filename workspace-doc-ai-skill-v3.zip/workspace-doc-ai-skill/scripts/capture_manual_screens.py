from __future__ import annotations

import argparse
import json
import re
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.parse import urljoin, urlparse

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from utils.config_loader import ensure_dir, env_or_empty, load_config, resolve_path

try:
    import yaml
except Exception:
    yaml = None

TAG_RULES = [
    (("login", "sign", "auth"), ["인증"]),
    (("dashboard", "main", "home"), ["메인", "현황"]),
    (("admin", "operator", "ops", "manage"), ["운영"]),
    (("user", "member", "account"), ["사용자관리"]),
    (("search", "list", "grid", "table"), ["조회"]),
    (("create", "new", "register"), ["등록"]),
    (("edit", "update", "modify"), ["수정"]),
    (("delete", "remove"), ["삭제"]),
    (("report", "stat", "chart"), ["통계", "리포트"]),
    (("health", "monitor", "metric", "log"), ["모니터링", "운영"]),
]


def slugify(value: str) -> str:
    value = re.sub(r"[^0-9A-Za-z가-힣._-]+", "-", str(value or "").strip())
    return value.strip("-") or "screen"


def normalize_base_url(base_url: str) -> str:
    return str(base_url or "").rstrip("/") + "/"


def build_url(base_url: str, path_or_url: str) -> str:
    path_or_url = str(path_or_url or "/")
    if path_or_url.startswith(("http://", "https://")):
        return path_or_url
    return urljoin(normalize_base_url(base_url), path_or_url.lstrip("/"))


def build_spa_url(base_url: str, route: str, navigation_mode: str, app_base_path: str = "") -> str:
    route = str(route or "/")
    if route.startswith(("http://", "https://")):
        return route
    base = normalize_base_url(base_url)
    app_base = str(app_base_path or "").strip("/")
    prefix = f"{app_base}/" if app_base else ""
    if navigation_mode == "hash":
        clean = route.lstrip("#/")
        return f"{base}{prefix}#/{clean}" if clean else f"{base}{prefix}#/"
    return urljoin(base, prefix + route.lstrip("/"))


def derive_tags(title: str, path: str, text: str = "", roles: Optional[List[str]] = None) -> List[str]:
    source = f"{title} {path} {text[:500]}".lower()
    tags: List[str] = []
    for keys, values in TAG_RULES:
        if any(k in source for k in keys):
            tags.extend(values)
    if roles:
        tags.extend([f"권한:{role}" for role in roles[:10]])
    if not tags:
        tags.append("확인필요")
    return sorted(set(tags))


def load_analysis(analysis_path: Path) -> Dict[str, Any]:
    if not analysis_path.exists():
        return {}
    try:
        return json.loads(analysis_path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _route_key(value: Any) -> str:
    route = str(value or "").strip()
    if route == "(index)":
        return "/"
    route = re.sub(r"[?#].*$", "", route)
    return "/" + route.strip("/") if route.strip("/") else "/"


def enrich_from_analysis(page_def: Dict[str, Any], analysis: Dict[str, Any]) -> Dict[str, Any]:
    page = dict(page_def)
    target_path = _route_key(page.get("path") or page.get("url"))
    routes = analysis.get("frontend", {}).get("routes", []) or []
    route = next((row for row in routes if _route_key(row.get("path")) == target_path), None)
    if route:
        page.setdefault("title", route.get("title") or route.get("component") or target_path)
        page["react_component"] = route.get("component")
        page["route_type"] = route.get("route_type")
        page["router"] = route.get("router")
        page["roles"] = route.get("roles") or []
        page["protected"] = route.get("protected")
        page.setdefault("source_path", route.get("source_path"))
        page.setdefault("source_line", route.get("line"))
    links = [row for row in analysis.get("frontend", {}).get("route_api_links", []) or [] if _route_key(row.get("route_path")) == target_path]
    page["static_api_links"] = links
    page["static_api_calls"] = [
        {
            "method": row.get("api_method"), "path": row.get("api_path"),
            "backend_framework": row.get("backend_framework"),
            "backend_component": row.get("backend_component"),
            "backend_handler": row.get("backend_handler"), "backend_path": row.get("backend_path"),
            "status": row.get("status"), "confidence": row.get("confidence"),
        }
        for row in links if row.get("api_call_id")
    ]
    if not page.get("tags"):
        page["tags"] = derive_tags(page.get("title", ""), target_path, roles=page.get("roles") or [])
    return page


def load_pages(cfg: Dict[str, Any], base_dir: Path, analysis_path: Path) -> List[Dict[str, Any]]:
    ss = cfg.get("screenshots", {}) or {}
    analysis = load_analysis(analysis_path)
    page_file = ss.get("manual_pages_file", "")
    pages: List[Dict[str, Any]] = []
    if page_file:
        pf = resolve_path(base_dir, page_file)
        if pf.exists() and yaml is not None:
            data = yaml.safe_load(pf.read_text(encoding="utf-8")) or {}
            pages.extend(data.get("pages", []))
    if not pages:
        for idx, route in enumerate(analysis.get("frontend", {}).get("routes", [])[:500], start=1):
            route_path = route.get("path", "")
            title = route.get("title") or route.get("component") or str(route_path).strip("/").replace("/", " > ") or "메인"
            pages.append({
                "id": f"route-{idx}", "title": title, "audience": "user", "path": route_path,
                "tags": derive_tags(title, route_path, roles=route.get("roles") or []),
                "content": f"React Route와 Component({route.get('component') or '확인필요'})를 기준으로 자동 생성된 화면이다.",
                "steps": ["화면에 접속한다.", "주요 조회·입력·버튼 영역을 확인한다.", "연결된 Backend API 처리 결과를 확인한다."],
                "checks": ["권한별 화면 노출 여부를 확인한다.", "React API 호출과 Spring Boot/Vert.x 응답을 확인한다."],
                "requires_review": bool(route.get("requires_review", True)),
                "source_path": route.get("source_path", ""), "source_line": route.get("line", 0),
            })
    return [enrich_from_analysis(page, analysis) for page in pages]


def extract_dom_metadata(page: Any) -> Dict[str, Any]:
    metadata: Dict[str, Any] = {
        "document_title": "", "headings": [], "buttons": [], "inputs": [], "links": [],
        "tables": [], "dialogs": [], "text_sample": "", "current_url": "",
    }
    try:
        metadata["current_url"] = page.url
        metadata["document_title"] = page.title()
    except Exception:
        pass
    try:
        headings = page.locator("h1,h2,h3,[role='heading']").all_inner_texts()
        metadata["headings"] = [h.strip() for h in headings if h.strip()][:30]
    except Exception:
        pass
    try:
        buttons = page.locator("button,input[type='button'],input[type='submit'],[role='button']").all_inner_texts()
        metadata["buttons"] = [b.strip() for b in buttons if b.strip()][:80]
    except Exception:
        pass
    try:
        metadata["inputs"] = page.locator("input,select,textarea").evaluate_all("""
            els => els.slice(0, 120).map(e => ({
                name: e.getAttribute('name') || '', placeholder: e.getAttribute('placeholder') || '',
                type: e.getAttribute('type') || e.tagName.toLowerCase(),
                label: e.getAttribute('aria-label') || '', required: !!e.required,
                disabled: !!e.disabled
            }))
        """)
    except Exception:
        pass
    try:
        links = page.locator("a").evaluate_all("els => els.slice(0, 120).map(e => ({text: (e.innerText || '').trim(), href: e.getAttribute('href') || ''}))")
        metadata["links"] = [x for x in links if x.get("text") or x.get("href")]
    except Exception:
        pass
    try:
        metadata["tables"] = page.locator("table,[role='grid']").evaluate_all("els => els.slice(0, 30).map(e => ({headers: Array.from(e.querySelectorAll('th,[role=columnheader]')).map(x => (x.innerText||'').trim()).filter(Boolean).slice(0,30), rows: e.querySelectorAll('tbody tr,[role=row]').length}))")
    except Exception:
        pass
    try:
        metadata["dialogs"] = page.locator("[role='dialog'],dialog").all_inner_texts()
    except Exception:
        pass
    try:
        body_text = page.locator("body").inner_text(timeout=3000)
        metadata["text_sample"] = re.sub(r"\s+", " ", body_text).strip()[:4000]
    except Exception:
        pass
    return metadata


def enrich_page(page_def: Dict[str, Any], dom: Dict[str, Any]) -> Dict[str, Any]:
    page = dict(page_def)
    title = page.get("title") or (dom.get("headings") or [""])[0] or dom.get("document_title") or page.get("path") or page.get("id")
    page["title"] = title
    text_source = " ".join(dom.get("headings", [])) + " " + dom.get("text_sample", "")
    if not page.get("tags"):
        page["tags"] = derive_tags(title, page.get("path", ""), text_source, page.get("roles") or [])
        page["tags_auto_generated"] = True
    if not page.get("content"):
        headings = ", ".join(dom.get("headings", [])[:5])
        component = page.get("react_component") or "확인필요"
        page["content"] = f"React Component: {component}. 화면 주요 문구: {headings or dom.get('text_sample', '')[:300] or '확인필요'}"
        page["requires_review"] = True
    if not page.get("steps"):
        buttons = [b for b in dom.get("buttons", []) if b]
        page["steps"] = [f"'{button}' 버튼의 동작을 확인한다." for button in buttons[:5]] or ["화면에 접속한다.", "표시된 항목을 확인한다."]
        page["requires_review"] = True
    if not page.get("checks"):
        page["checks"] = ["화면 데이터와 권한별 노출 여부를 확인한다.", "네트워크 API의 성공/실패 응답을 확인한다."]
    page["dom_metadata"] = dom
    return page


def run_login(page: Any, cfg: Dict[str, Any], base_url: str) -> None:
    login = (cfg.get("screenshots", {}) or {}).get("login", {}) or {}
    if not login.get("enabled"):
        return
    username = env_or_empty(login.get("username_env", "DOC_LOGIN_USERNAME"))
    password = env_or_empty(login.get("password_env", "DOC_LOGIN_PASSWORD"))
    if not username or not password:
        print("login skipped: username/password env missing")
        return
    timeout = int((cfg.get("screenshots", {}) or {}).get("wait_timeout_ms", 20000))
    page.goto(build_url(base_url, login.get("url", "/login")), wait_until="domcontentloaded", timeout=timeout)
    page.fill(login.get("username_selector", "input[name='username']"), username)
    page.fill(login.get("password_selector", "input[name='password']"), password)
    page.click(login.get("submit_selector", "button[type='submit']"))
    page.wait_for_selector(login.get("success_selector", "body"), timeout=timeout)


def perform_actions(page: Any, actions: List[Dict[str, Any]], timeout: int) -> List[Dict[str, Any]]:
    results: List[Dict[str, Any]] = []
    for action in actions or []:
        action_type = str(action.get("type", "")).lower()
        selector = action.get("selector", "")
        try:
            if action_type == "click":
                page.click(selector, timeout=timeout)
            elif action_type == "fill":
                value = env_or_empty(action.get("value_env")) if action.get("value_env") else str(action.get("value", ""))
                page.fill(selector, value, timeout=timeout)
            elif action_type == "select":
                page.select_option(selector, str(action.get("value", "")), timeout=timeout)
            elif action_type == "press":
                page.press(selector, str(action.get("key", "Enter")), timeout=timeout)
            elif action_type == "wait":
                page.wait_for_selector(selector, timeout=timeout)
            elif action_type == "sleep":
                time.sleep(max(0, int(action.get("milliseconds", 500))) / 1000)
            else:
                raise ValueError(f"unsupported action: {action_type}")
            results.append({"type": action_type, "selector": selector, "status": "OK"})
        except Exception as exc:
            results.append({"type": action_type, "selector": selector, "status": "FAILED", "error": str(exc)})
            if bool(action.get("required", False)):
                raise
    return results


def navigate_react_spa(page: Any, base_url: str, route: str, ss: Dict[str, Any], timeout: int) -> str:
    spa = ss.get("react_spa", {}) or {}
    mode = str(spa.get("navigation_mode", "auto")).lower()
    if mode not in {"auto", "direct", "hash", "spa"}:
        mode = "auto"
    app_base_path = spa.get("app_base_path", "")
    effective = "hash" if mode == "hash" else "direct"
    target_url = build_spa_url(base_url, route, effective, app_base_path)
    if mode == "spa":
        root_url = build_spa_url(base_url, "/", "direct", app_base_path)
        page.goto(root_url, wait_until="domcontentloaded", timeout=timeout)
        clean_route = _route_key(route)
        page.evaluate("route => { history.pushState({}, '', route); window.dispatchEvent(new PopStateEvent('popstate')); }", clean_route)
        return page.url
    response = page.goto(target_url, wait_until="domcontentloaded", timeout=timeout)
    fallback = bool(spa.get("fallback_to_client_navigation", True))
    status = response.status if response else 0
    if mode == "auto" and fallback and status >= 400:
        root_url = build_spa_url(base_url, "/", "direct", app_base_path)
        page.goto(root_url, wait_until="domcontentloaded", timeout=timeout)
        clean_route = _route_key(route)
        page.evaluate("route => { history.pushState({}, '', route); window.dispatchEvent(new PopStateEvent('popstate')); }", clean_route)
    return page.url


def main() -> None:
    parser = argparse.ArgumentParser(description="Capture React SPA screenshots and build manual page metadata.")
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    cfg = load_config(args.config)
    base_dir = Path(cfg["_base_dir"])
    output_root = resolve_path(base_dir, cfg.get("output", {}).get("dir", "output"))
    analysis_path = output_root / "analysis" / "workspace_analysis.json"
    ss = cfg.get("screenshots", {}) or {}
    screenshot_dir = ensure_dir(resolve_path(base_dir, ss.get("output_dir", str(output_root / "screenshots"))))
    generated_path = screenshot_dir / "manual_pages.generated.json"

    pages = load_pages(cfg, base_dir, analysis_path)
    if not pages:
        generated_path.write_text(json.dumps({"generated_at": datetime.now().isoformat(), "pages": []}, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"no pages. metadata written: {generated_path}")
        return

    if not ss.get("enabled", False):
        normalized = []
        for page in pages:
            page = dict(page)
            title = page.get("title") or page.get("id") or page.get("path") or "화면"
            page.setdefault("tags", derive_tags(title, page.get("path", ""), roles=page.get("roles") or []))
            page["screenshot_status"] = "SKIPPED"
            page["screenshot_error"] = "screenshots.enabled=false"
            normalized.append(page)
        generated_path.write_text(json.dumps({"generated_at": datetime.now().isoformat(), "pages": normalized}, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"screenshot disabled. metadata written: {generated_path}")
        return

    try:
        from playwright.sync_api import sync_playwright
    except Exception as exc:
        for page in pages:
            page["screenshot_status"] = "FAILED"
            page["screenshot_error"] = f"playwright import failed: {exc}"
        generated_path.write_text(json.dumps({"generated_at": datetime.now().isoformat(), "pages": pages}, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"playwright unavailable. metadata written: {generated_path}")
        return

    base_url = ss.get("base_url", "http://localhost:3000")
    wait_until = ss.get("wait_until", "networkidle")
    timeout = int(ss.get("wait_timeout_ms", 20000))
    viewport = ss.get("viewport", {}) or {"width": 1440, "height": 1000}
    full_page = bool(ss.get("full_page", True))
    extract_dom = bool(ss.get("extract_dom_text", True))
    capture_network = bool(ss.get("capture_network", True))
    capture_console = bool(ss.get("capture_console", True))
    ignore_https_errors = bool(ss.get("ignore_https_errors", False))
    network_limit = int(ss.get("network_capture_limit", 300))

    captured: List[Dict[str, Any]] = []
    with sync_playwright() as pctx:
        browser = pctx.chromium.launch(headless=bool(ss.get("headless", True)))
        context = browser.new_context(
            viewport={"width": int(viewport.get("width", 1440)), "height": int(viewport.get("height", 1000))},
            ignore_https_errors=ignore_https_errors,
        )
        page = context.new_page()
        try:
            run_login(page, cfg, base_url)
        except Exception as exc:
            print(f"login failed: {exc}")

        for idx, page_def in enumerate(pages, start=1):
            current_network: List[Dict[str, Any]] = []
            current_console: List[Dict[str, Any]] = []
            current_errors: List[str] = []
            current_websockets: List[Dict[str, Any]] = []

            def on_response(response: Any) -> None:
                try:
                    req = response.request
                    if len(current_network) < network_limit and req.resource_type in {"xhr", "fetch", "document", "websocket", "eventsource"}:
                        current_network.append({"method": req.method, "url": response.url, "status": response.status, "resource_type": req.resource_type})
                except Exception:
                    pass

            def on_request_failed(request: Any) -> None:
                try:
                    if len(current_network) < network_limit:
                        current_network.append({"method": request.method, "url": request.url, "status": "FAILED", "resource_type": request.resource_type, "error": str(request.failure or "")})
                except Exception:
                    pass

            def on_console(message: Any) -> None:
                if len(current_console) < 200:
                    current_console.append({"type": message.type, "text": str(message.text)[:1000]})

            def on_page_error(error: Any) -> None:
                if len(current_errors) < 100:
                    current_errors.append(str(error)[:2000])

            def on_websocket(ws: Any) -> None:
                if len(current_websockets) < 100:
                    current_websockets.append({"url": ws.url})

            if capture_network:
                page.on("response", on_response)
                page.on("requestfailed", on_request_failed)
                page.on("websocket", on_websocket)
            if capture_console:
                page.on("console", on_console)
                page.on("pageerror", on_page_error)

            pd = dict(page_def)
            route = pd.get("url") or pd.get("path") or "/"
            screen_id = slugify(pd.get("id") or pd.get("title") or route or f"screen-{idx}")
            img_path = screenshot_dir / f"{idx:03d}-{screen_id}.png"
            try:
                actual_url = navigate_react_spa(page, base_url, route, ss, timeout)
                if wait_until and wait_until != "domcontentloaded":
                    try:
                        page.wait_for_load_state(wait_until, timeout=timeout)
                    except Exception:
                        pass
                wait_selector = pd.get("wait_selector") or ss.get("default_wait_selector")
                if wait_selector:
                    page.wait_for_selector(wait_selector, timeout=timeout)
                wait_after = int(pd.get("wait_after_ms", ss.get("wait_after_ms", 500)))
                if wait_after > 0:
                    page.wait_for_timeout(wait_after)
                pd["action_results"] = perform_actions(page, pd.get("actions", []) or [], timeout)
                dom = extract_dom_metadata(page) if extract_dom else {}
                pd = enrich_page(pd, dom)
                page.screenshot(path=str(img_path), full_page=full_page)
                pd["url"] = actual_url
                pd["screenshot_path"] = str(img_path)
                pd["screenshot_status"] = "OK"
            except Exception as exc:
                pd["url"] = page.url or build_url(base_url, route)
                pd["screenshot_status"] = "FAILED"
                pd["screenshot_error"] = str(exc)
                pd.setdefault("tags", derive_tags(pd.get("title", ""), str(route), roles=pd.get("roles") or []))
                pd.setdefault("content", "React 화면 캡처 실패로 실제 화면 내용 확인이 필요하다.")
                pd["requires_review"] = True
            finally:
                pd["network_requests"] = current_network
                pd["websockets"] = current_websockets
                pd["console_messages"] = current_console
                pd["page_errors"] = current_errors
                if capture_network:
                    page.remove_listener("response", on_response)
                    page.remove_listener("requestfailed", on_request_failed)
                    page.remove_listener("websocket", on_websocket)
                if capture_console:
                    page.remove_listener("console", on_console)
                    page.remove_listener("pageerror", on_page_error)
            captured.append(pd)
        browser.close()

    generated_path.write_text(json.dumps({"generated_at": datetime.now().isoformat(), "pages": captured}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"manual metadata written: {generated_path}")


if __name__ == "__main__":
    main()
