from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import yaml


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a React + Spring Boot + Vert.x documentation smoke test.")
    parser.add_argument("--work-dir", help="Directory for generated test output. A temporary directory is used by default.")
    parser.add_argument("--keep", action="store_true", help="Keep a temporary work directory after the test.")
    args = parser.parse_args()

    package_root = Path(__file__).resolve().parents[1]
    fixture = package_root / "tests" / "fixtures" / "react-spring-vertx"
    if not fixture.exists():
        raise FileNotFoundError(f"fixture not found: {fixture}")

    created_temp = not bool(args.work_dir)
    base = Path(args.work_dir).expanduser().resolve() if args.work_dir else Path(tempfile.mkdtemp(prefix="workspace-doc-v3-self-test-"))
    output = base / "output"
    config_path = base / "self-test-config.yaml"
    base.mkdir(parents=True, exist_ok=True)

    config = {
        "workspace": {"root": str(fixture), "name": "SELF_TEST_REACT_SPRING_VERTX"},
        "output": {"dir": str(output), "overwrite": True},
        "analysis": {
            "max_file_mb": 10,
            "max_binary_file_mb": 300,
            "inspect_jars": True,
            "max_jar_entries": 200000,
            "inspect_dependency_cache": False,
            "ignore_dirs": [".git", ".idea", ".vscode", "node_modules", "dist", "build", "target", "out", ".gradle", "coverage", ".next"],
            "ignore_file_globs": ["*.class", "*.png", "*.jpg", "*.jpeg", "*.gif", "*.ico", "*.pdf", "*.zip", "*.tar", "*.gz"],
            "common_path_keywords": ["common", "core", "shared", "base", "framework", "util", "utils", "config", "security"],
            "internal_package_roots": ["com.acme"],
        },
        "screenshots": {"enabled": False, "base_url": "http://localhost:3000", "manual_pages_file": "", "output_dir": str(output / "screenshots")},
        "resource_screenshots": {"enabled": False, "output_dir": str(output / "resource-screenshots")},
        "runtime_probe": {"enabled": False},
        "excel": {"output_dir": str(output / "excel"), "author": "Self Test"},
        "ppt": {"output_dir": str(output / "ppt"), "title_prefix": "SELF TEST", "company_name": "", "author": "Self Test"},
    }
    config_path.write_text(yaml.safe_dump(config, allow_unicode=True, sort_keys=False), encoding="utf-8")

    command = [sys.executable, str(package_root / "scripts" / "generate_all.py"), "--config", str(config_path)]
    print("$ " + " ".join(command))
    completed = subprocess.run(command, check=False)
    report_path = output / "analysis" / "validation_report.json"
    report = json.loads(report_path.read_text(encoding="utf-8")) if report_path.exists() else {}

    if completed.returncode != 0 or report.get("status") != "PASS":
        print(json.dumps(report, ensure_ascii=False, indent=2))
        raise SystemExit(completed.returncode or 1)

    analysis = json.loads((output / "analysis" / "workspace_analysis.json").read_text(encoding="utf-8"))
    summary = analysis.get("summary", {})
    expected_minimum = {
        "frontend_route_count": 2,
        "react_api_call_count": 2,
        "frontend_backend_match_count": 2,
        "spring_endpoint_count": 2,
        "vertx_route_count": 2,
        "vertx_verticle_count": 2,
        "event_bus_link_count": 2,
    }
    failures = [f"{key}: expected >= {minimum}, actual={summary.get(key, 0)}" for key, minimum in expected_minimum.items() if int(summary.get(key, 0) or 0) < minimum]
    if failures:
        print("self-test semantic checks failed:")
        for failure in failures:
            print("- " + failure)
        raise SystemExit(1)

    print("self-test PASS")
    print(json.dumps({key: summary.get(key) for key in expected_minimum}, ensure_ascii=False, indent=2))
    print(f"outputs: {output}")

    if created_temp and not args.keep:
        shutil.rmtree(base, ignore_errors=True)
    elif created_temp:
        print(f"kept work directory: {base}")


if __name__ == "__main__":
    main()
