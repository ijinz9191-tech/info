from __future__ import annotations

import argparse
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List
from urllib.parse import urljoin

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from utils.config_loader import ensure_dir, load_config, resolve_path


def slugify(value: str) -> str:
    value = re.sub(r"[^0-9A-Za-z가-힣._-]+", "-", str(value).strip())
    return value.strip("-") or "resource-screen"


def join_url(base: str, path: str) -> str:
    if path.startswith(("http://", "https://")):
        return path
    return urljoin(base.rstrip("/") + "/", path.lstrip("/"))


def runtime_result(analysis: Dict[str, Any], resource_type: str) -> Dict[str, Any]:
    results = (((analysis.get("resources") or {}).get("runtime_probe") or {}).get("results") or [])
    return next((row for row in results if row.get("resource_type") == resource_type), {})


def screen_target(screen_cfg: Dict[str, Any], explicit_key: str, result: Dict[str, Any]) -> str:
    """Use an explicitly configured UI URL first; static-discovered targets require an explicit opt-in."""
    explicit = str(screen_cfg.get(explicit_key) or "").strip()
    if explicit:
        return explicit
    target = str(result.get("target") or "").strip()
    if not target:
        return ""
    source = str(result.get("source") or "")
    if source in {"CONFIG_OR_ENV", "CONFIG"}:
        return target
    if bool(screen_cfg.get("allow_discovered_endpoints", False)):
        return target
    return ""


def auto_pages(analysis: Dict[str, Any], cfg: Dict[str, Any]) -> List[Dict[str, Any]]:
    pages: List[Dict[str, Any]] = []
    screen_cfg = cfg.get("resource_screenshots", {}) or {}

    grafana_result = runtime_result(analysis, "GRAFANA")
    grafana_url = screen_target(screen_cfg, "grafana_url", grafana_result)
    grafana_section = ((analysis.get("resources") or {}).get("grafana") or {})
    grafana_dashboards = grafana_section.get("runtime_dashboards") or grafana_section.get("dashboards") or []
    if grafana_url:
        pages.append({
            "id": "grafana-home", "title": "Grafana 운영 대시보드", "resource_type": "GRAFANA",
            "url": join_url(grafana_url, "/dashboards"), "audience": "operator", "auth_profile": "grafana",
            "tags": ["운영", "모니터링", "Grafana", "대시보드"],
            "content": "시스템 대시보드 목록과 폴더 구성을 확인하는 화면이다.",
            "steps": ["Grafana에 접속한다.", "대시보드 폴더와 주요 대시보드를 확인한다.", "경고 패널과 시간 범위를 확인한다."],
            "checks": ["데이터소스 연결 상태", "대시보드 최근 갱신", "권한별 조회 가능 여부"],
        })
        for index, dashboard in enumerate(grafana_dashboards[: int(screen_cfg.get("max_grafana_dashboards", 20))], start=1):
            if not isinstance(dashboard, dict):
                continue
            uri = dashboard.get("url") or dashboard.get("uri")
            uid = dashboard.get("uid")
            if not uri and uid:
                uri = f"/d/{uid}"
            if not uri:
                continue
            pages.append({
                "id": f"grafana-dashboard-{index}", "title": dashboard.get("title") or f"Grafana Dashboard {index}",
                "resource_type": "GRAFANA", "url": join_url(grafana_url, str(uri)), "audience": "operator",
                "auth_profile": "grafana", "tags": ["운영", "모니터링", "Grafana", "지표"],
                "content": "Grafana API에서 확인된 운영 대시보드 화면이다.",
                "steps": ["대시보드를 연다.", "시간 범위와 변수를 확인한다.", "이상 지표와 알림 패널을 확인한다."],
                "checks": ["패널 데이터 표시", "데이터소스 오류", "알림 임계치"],
            })

    prometheus_result = runtime_result(analysis, "PROMETHEUS")
    prometheus_url = screen_target(screen_cfg, "prometheus_url", prometheus_result)
    if prometheus_url:
        for page_id, title, path, tags, content, checks in (
            ("prometheus-targets", "Prometheus Target 상태", "/targets", ["운영", "Prometheus", "Target", "수집상태"], "Prometheus scrape target의 UP/DOWN 상태를 확인한다.", ["DOWN target", "Last Scrape", "Scrape Error"]),
            ("prometheus-alerts", "Prometheus Alert 상태", "/alerts", ["운영", "Prometheus", "Alert"], "활성·대기 중인 Prometheus 알림을 확인한다.", ["Firing 알림", "Pending 지속시간", "라벨과 Annotation"]),
            ("prometheus-rules", "Prometheus Rule 상태", "/rules", ["운영", "Prometheus", "Rule"], "Recording rule과 alert rule 평가 상태를 확인한다.", ["Rule evaluation error", "Last evaluation", "Group interval"]),
        ):
            pages.append({
                "id": page_id, "title": title, "resource_type": "PROMETHEUS", "url": join_url(prometheus_url, path),
                "audience": "operator", "auth_profile": "prometheus", "tags": tags, "content": content,
                "steps": ["Prometheus 화면에 접속한다.", "상태와 오류 메시지를 확인한다.", "문제 항목의 라벨과 대상을 기록한다."],
                "checks": checks,
            })

    # Loki normally has no rich UI. Capture readiness/build page only when explicitly requested.
    loki_result = runtime_result(analysis, "LOKI")
    loki_url = screen_target(screen_cfg, "loki_url", loki_result)
    if loki_url and bool(screen_cfg.get("capture_loki_status", False)):
        pages.append({
            "id": "loki-ready", "title": "Loki Readiness", "resource_type": "LOKI", "url": join_url(loki_url, "/ready"),
            "audience": "operator", "auth_profile": "loki", "tags": ["운영", "Loki", "로그", "상태점검"],
            "content": "Loki readiness endpoint 응답을 확인한다.",
            "steps": ["Loki readiness URL에 접속한다.", "HTTP 상태와 응답을 확인한다."],
            "checks": ["HTTP 200", "응답 지연", "게이트웨이 인증 오류"],
        })
    return pages


def load_pages(analysis: Dict[str, Any], cfg: Dict[str, Any]) -> List[Dict[str, Any]]:
    screen_cfg = cfg.get("resource_screenshots", {}) or {}
    pages = list(screen_cfg.get("pages", []) or [])
    if bool(screen_cfg.get("auto_generate", True)):
        pages.extend(auto_pages(analysis, cfg))
    unique: Dict[str, Dict[str, Any]] = {}
    for index, page in enumerate(pages, start=1):
        row = dict(page)
        row.setdefault("id", f"resource-{index}")
        row.setdefault("audience", "operator")
        row.setdefault("tags", [row.get("resource_type", "운영"), "운영"])
        row.setdefault("content", "운영 리소스 화면이다.")
        row.setdefault("steps", ["화면에 접속한다.", "상태와 오류를 확인한다."])
        row.setdefault("checks", ["접속 상태", "오류 메시지"])
        unique[row["id"]] = row
    return list(unique.values())


def profile_options(screen_cfg: Dict[str, Any], name: str) -> Dict[str, Any]:
    profiles = screen_cfg.get("auth_profiles", {}) or {}
    profile = profiles.get(name, {}) or {}
    options: Dict[str, Any] = {}
    username = os.environ.get(str(profile.get("username_env", "")), "") if profile.get("username_env") else ""
    password = os.environ.get(str(profile.get("password_env", "")), "") if profile.get("password_env") else ""
    if username:
        options["http_credentials"] = {"username": username, "password": password}
    headers = {}
    for key, env_name in (profile.get("header_envs") or {}).items():
        value = os.environ.get(str(env_name), "")
        if value:
            headers[str(key)] = value
    token_env = profile.get("bearer_token_env")
    if token_env and os.environ.get(str(token_env)):
        headers["Authorization"] = f"Bearer {os.environ[str(token_env)]}"
    if headers:
        options["extra_http_headers"] = headers
    options["ignore_https_errors"] = bool(profile.get("ignore_https_errors", False))
    return options


def extract_dom(page: Any) -> Dict[str, Any]:
    result: Dict[str, Any] = {"title": "", "headings": [], "text_sample": ""}
    try:
        result["title"] = page.title()
    except Exception:
        pass
    try:
        result["headings"] = [x.strip() for x in page.locator("h1,h2,h3,[role='heading']").all_inner_texts() if x.strip()][:30]
    except Exception:
        pass
    try:
        text = page.locator("body").inner_text(timeout=3000)
        result["text_sample"] = re.sub(r"\s+", " ", text).strip()[:2500]
    except Exception:
        pass
    return result


def form_login(page: Any, profile: Dict[str, Any], timeout_ms: int) -> None:
    login_url = profile.get("login_url")
    if not login_url:
        return
    username = os.environ.get(str(profile.get("username_env", "")), "") if profile.get("username_env") else ""
    password = os.environ.get(str(profile.get("password_env", "")), "") if profile.get("password_env") else ""
    if not username or not password:
        return
    page.goto(str(login_url), wait_until="domcontentloaded", timeout=timeout_ms)
    page.fill(profile.get("username_selector", "input[name='user'],input[name='username']"), username)
    page.fill(profile.get("password_selector", "input[name='password']"), password)
    page.click(profile.get("submit_selector", "button[type='submit']"))
    page.wait_for_selector(profile.get("success_selector", "body"), timeout=timeout_ms)


def main() -> None:
    parser = argparse.ArgumentParser(description="Capture Grafana/Prometheus/Loki and other operator resource screens.")
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    cfg = load_config(args.config)
    base_dir = Path(cfg["_base_dir"])
    output_root = resolve_path(base_dir, cfg.get("output", {}).get("dir", "output"))
    analysis_path = output_root / "analysis" / "workspace_analysis.json"
    if not analysis_path.exists():
        raise FileNotFoundError(f"analysis json not found: {analysis_path}")
    analysis = json.loads(analysis_path.read_text(encoding="utf-8"))
    screen_cfg = cfg.get("resource_screenshots", {}) or {}
    output_dir = ensure_dir(resolve_path(base_dir, screen_cfg.get("output_dir", str(output_root / "resource-screenshots"))))
    metadata_path = output_dir / "resource_pages.generated.json"
    pages = load_pages(analysis, cfg)

    if not bool(screen_cfg.get("enabled", False)):
        for page in pages:
            page["screenshot_status"] = "SKIPPED"
            page["screenshot_error"] = "resource_screenshots.enabled=false"
        metadata_path.write_text(json.dumps({"generated_at": datetime.now().isoformat(), "pages": pages}, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"resource screenshot disabled. metadata written: {metadata_path}")
        return

    try:
        from playwright.sync_api import sync_playwright
    except Exception as exc:
        for page in pages:
            page["screenshot_status"] = "FAILED"
            page["screenshot_error"] = f"playwright import failed: {exc}"
        metadata_path.write_text(json.dumps({"generated_at": datetime.now().isoformat(), "pages": pages}, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"resource screenshot unavailable. metadata written: {metadata_path}")
        return

    timeout_ms = int(screen_cfg.get("wait_timeout_ms", 25000))
    viewport = screen_cfg.get("viewport", {}) or {"width": 1600, "height": 1000}
    profiles = screen_cfg.get("auth_profiles", {}) or {}
    captured = []
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=bool(screen_cfg.get("headless", True)))
        for index, page_def in enumerate(pages, start=1):
            row = dict(page_def)
            context = None
            try:
                profile_name = str(row.get("auth_profile", ""))
                options = profile_options(screen_cfg, profile_name)
                options["viewport"] = {"width": int(viewport.get("width", 1600)), "height": int(viewport.get("height", 1000))}
                context = browser.new_context(**options)
                page = context.new_page()
                profile = profiles.get(profile_name, {}) or {}
                form_login(page, profile, timeout_ms)
                page.goto(str(row.get("url")), wait_until=screen_cfg.get("wait_until", "networkidle"), timeout=timeout_ms)
                if row.get("wait_selector"):
                    page.wait_for_selector(str(row.get("wait_selector")), timeout=timeout_ms)
                if row.get("delay_ms"):
                    page.wait_for_timeout(int(row.get("delay_ms")))
                screenshot_path = output_dir / f"{index:03d}-{slugify(row.get('id') or row.get('title'))}.png"
                page.screenshot(path=str(screenshot_path), full_page=bool(row.get("full_page", screen_cfg.get("full_page", True))))
                row["screenshot_path"] = str(screenshot_path.resolve())
                row["screenshot_status"] = "CAPTURED"
                row["dom_metadata"] = extract_dom(page)
            except Exception as exc:
                row["screenshot_status"] = "FAILED"
                row["screenshot_error"] = str(exc)
            finally:
                if context is not None:
                    context.close()
            captured.append(row)
        browser.close()

    metadata_path.write_text(json.dumps({"generated_at": datetime.now().isoformat(), "pages": captured}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"resource screenshot metadata written: {metadata_path}")


if __name__ == "__main__":
    main()
