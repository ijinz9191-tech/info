from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any, Dict, Iterable, Union

import yaml

SENSITIVE_KEYS = (
    "password", "passwd", "pwd", "secret", "token", "credential", "private", "apikey", "api_key",
    "access_key", "secret_key", "authorization", "bearer", "client_secret", "keystore_password", "truststore_password",
)

SENSITIVE_VALUE_PATTERNS = (
    re.compile(r"(?i)(password|passwd|pwd|secret|token|api[_-]?key|client[_-]?secret)\s*[:=]\s*([^\s,;]+)"),
    re.compile(r"(?i)(authorization\s*[:=]\s*bearer\s+)([^\s,;]+)"),
    re.compile(r"(?i)(https?://[^:/\s]+:)([^@/\s]+)(@)"),
)

ENV_PLACEHOLDER_RE = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::([^}]*))?}")


def load_config(config_path: Union[str, Path]) -> Dict[str, Any]:
    path = Path(config_path).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(f"config file not found: {path}")
    with path.open("r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}
    cfg["_config_path"] = str(path)
    cfg["_base_dir"] = str(path.parent)
    return cfg


def resolve_path(base_dir: Union[str, Path], maybe_path: Union[str, Path]) -> Path:
    p = Path(str(maybe_path)).expanduser()
    if p.is_absolute():
        return p
    return Path(base_dir).expanduser().resolve() / p


def ensure_dir(path: Union[str, Path]) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def is_sensitive_key(key: str) -> bool:
    key_lower = str(key).lower()
    return any(s in key_lower for s in SENSITIVE_KEYS)


def mask_value(key: str, value: Any) -> Any:
    if is_sensitive_key(key) and value not in (None, ""):
        return "***MASKED***"
    if isinstance(value, str):
        return mask_text(value)
    return value


def mask_text(value: str) -> str:
    text = str(value or "")
    for pattern in SENSITIVE_VALUE_PATTERNS:
        if pattern.groups == 2:
            text = pattern.sub(lambda m: f"{m.group(1)}=***MASKED***", text)
        else:
            text = pattern.sub(lambda m: f"{m.group(1)}***MASKED***{m.group(3)}", text)
    return text


def deep_mask(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: deep_mask(mask_value(k, v)) for k, v in obj.items()}
    if isinstance(obj, list):
        return [deep_mask(v) for v in obj]
    if isinstance(obj, tuple):
        return tuple(deep_mask(v) for v in obj)
    if isinstance(obj, str):
        return mask_text(obj)
    return obj


def env_or_empty(name: str) -> str:
    return os.environ.get(name, "") if name else ""


def env_first(names: Iterable[str]) -> str:
    for name in names:
        value = env_or_empty(name)
        if value:
            return value
    return ""


def resolve_env_placeholders(value: Any, allow_default: bool = True) -> Any:
    if not isinstance(value, str):
        return value

    def repl(match: re.Match[str]) -> str:
        env_name = match.group(1)
        default = match.group(2) or ""
        return os.environ.get(env_name, default if allow_default else "")

    return ENV_PLACEHOLDER_RE.sub(repl, value)


def enabled_value(value: Any, auto_condition: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    text = str(value).strip().lower()
    if text == "auto":
        return auto_condition
    return text in {"1", "true", "yes", "y", "on", "enabled"}
