from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from utils.config_loader import ensure_dir, load_config, resolve_path

EXCEL_REQUIREMENTS: Dict[str, List[str]] = {
    "인터페이스명세서.xlsx": [
        "API 인터페이스", "React API호출", "React-Backend매핑", "화면-API-Backend",
        "Spring API", "Spring 보안", "Spring 외부호출", "Vertx HTTP Route", "Vertx EventBus",
        "EventBus연결", "Vertx 외부호출", "외부연계", "Interface-Impl", "주입연결", "Bean연결",
        "리소스연계", "Oracle연계", "Redis연계", "Elasticsearch연계", "Kafka연계",
        "모니터링연계", "런타임점검", "JAR-Dependency", "NPM-Dependency", "JAR내부구조", "JAR사용연결",
    ],
    "프로그램목록.xlsx": [
        "모듈목록", "기술스택", "React 패키지", "React 컴포넌트", "React Hook-State",
        "화면-라우트", "화면-API연결", "Spring 컴포넌트", "Spring 스케줄-리스너",
        "Vertx Verticle", "Vertx Handler", "Vertx 배포-서버", "파일목록", "클래스목록",
        "메서드목록", "공통소스", "배포워크로드", "리소스자산",
    ],
    "WorkBook.xlsx": [
        "요약", "문서생성체크리스트", "분석범위", "기술스택", "프레임워크모듈",
        "React-Spring-Vertx흐름", "API매핑검토", "EventBus토폴로지", "리소스현황",
        "공통모듈분석", "JAR가져오기", "JAR서비스연결", "구현흐름", "리소스토폴로지",
        "실행-배포구성", "런타임점검", "변경영향도", "검토항목",
    ],
    "테이블정의서.xlsx": [
        "테이블목록", "컬럼정의", "PK-FK", "인덱스", "시퀀스", "View", "PLSQL오브젝트",
        "Synonym", "Entity매핑", "MyBatis매퍼", "SQL사용처", "DB접근컴포넌트",
    ],
    "아키텍쳐정의서.xlsx": [
        "시스템개요", "기술스택", "모듈구조", "Frontend구조", "SpringBoot구조", "Vertx구조",
        "Frontend-Backend", "EventBus토폴로지", "Framework공존", "Mermaid아키텍처",
        "컴포넌트", "공통모듈", "의존성흐름", "인터페이스연결", "리소스토폴로지",
        "운영리소스", "배포워크로드", "관측구성", "설정-런타임", "런타임점검",
        "JAR구조", "리스크-확인필요",
    ],
}

PPT_REQUIREMENTS = {
    "사용자메뉴얼.pptx": 4,
    "운영자메뉴얼.pptx": 8,
}


def check_json(path: Path, schema_path: Optional[Path] = None) -> Dict[str, Any]:
    result: Dict[str, Any] = {"path": str(path), "status": "FAIL", "errors": []}
    if not path.exists() or path.stat().st_size == 0:
        result["errors"].append("file missing or empty")
        return result
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        result["top_level_keys"] = sorted(data.keys()) if isinstance(data, dict) else []
    except Exception as exc:
        result["errors"].append(f"invalid json: {exc}")
        return result
    if schema_path and schema_path.exists():
        try:
            import jsonschema  # type: ignore
            schema = json.loads(schema_path.read_text(encoding="utf-8"))
            jsonschema.validate(data, schema)
            result["schema_validation"] = "PASS"
        except ModuleNotFoundError:
            result["schema_validation"] = "SKIPPED(jsonschema not installed)"
        except Exception as exc:
            result["errors"].append(f"schema validation failed: {exc}")
    result["status"] = "PASS" if not result["errors"] else "FAIL"
    return result


def check_excel(path: Path, required_sheets: List[str]) -> Dict[str, Any]:
    result: Dict[str, Any] = {"path": str(path), "status": "FAIL", "errors": [], "required_sheets": required_sheets}
    if not path.exists() or path.stat().st_size == 0:
        result["errors"].append("file missing or empty")
        return result
    try:
        from openpyxl import load_workbook
        workbook = load_workbook(path, read_only=True, data_only=False)
        result["sheets"] = list(workbook.sheetnames)
        missing = [name for name in required_sheets if name not in workbook.sheetnames]
        if missing:
            result["errors"].append("missing sheets: " + ", ".join(missing))
        for sheet_name in workbook.sheetnames:
            sheet = workbook[sheet_name]
            if sheet.max_row < 3 or sheet.max_column < 1:
                result["errors"].append(f"invalid table layout: {sheet_name}")
        workbook.close()
    except Exception as exc:
        result["errors"].append(f"cannot open workbook: {exc}")
    result["status"] = "PASS" if not result["errors"] else "FAIL"
    return result


def check_ppt(path: Path, min_slides: int) -> Dict[str, Any]:
    result: Dict[str, Any] = {"path": str(path), "status": "FAIL", "errors": [], "minimum_slides": min_slides}
    if not path.exists() or path.stat().st_size == 0:
        result["errors"].append("file missing or empty")
        return result
    try:
        from pptx import Presentation
        presentation = Presentation(path)
        result["slide_count"] = len(presentation.slides)
        if len(presentation.slides) < min_slides:
            result["errors"].append(f"slide count is below minimum: {len(presentation.slides)} < {min_slides}")
    except Exception as exc:
        result["errors"].append(f"cannot open presentation: {exc}")
    result["status"] = "PASS" if not result["errors"] else "FAIL"
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description="Validate the generated JSON, Excel and PowerPoint documentation outputs.")
    parser.add_argument("--config", required=True)
    args = parser.parse_args()

    cfg = load_config(args.config)
    base_dir = Path(cfg["_base_dir"])
    package_root = SCRIPT_DIR.parent
    output_root = resolve_path(base_dir, cfg.get("output", {}).get("dir", "output"))
    analysis_dir = ensure_dir(output_root / "analysis")
    excel_dir = resolve_path(base_dir, cfg.get("excel", {}).get("output_dir", str(output_root / "excel")))
    ppt_dir = resolve_path(base_dir, cfg.get("ppt", {}).get("output_dir", str(output_root / "ppt")))

    checks: List[Dict[str, Any]] = []
    checks.append(check_json(analysis_dir / "workspace_analysis.json", package_root / "schemas" / "analysis.schema.json"))
    runtime_path = analysis_dir / "runtime_probe.json"
    if runtime_path.exists():
        checks.append(check_json(runtime_path, package_root / "schemas" / "runtime_probe.schema.json"))
    for filename, sheets in EXCEL_REQUIREMENTS.items():
        checks.append(check_excel(excel_dir / filename, sheets))
    for filename, min_slides in PPT_REQUIREMENTS.items():
        checks.append(check_ppt(ppt_dir / filename, min_slides))

    failures = [row for row in checks if row.get("status") != "PASS"]
    report = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "status": "PASS" if not failures else "FAIL",
        "check_count": len(checks),
        "failure_count": len(failures),
        "checks": checks,
    }
    report_path = analysis_dir / "validation_report.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"validation report written: {report_path}")
    if failures:
        for failure in failures:
            print(f"validation failed: {failure.get('path')} -> {failure.get('errors')}", file=sys.stderr)
        raise SystemExit(2)
    print("all generated outputs passed validation")


if __name__ == "__main__":
    main()
