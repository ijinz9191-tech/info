from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path
from typing import List


def run_step(script: Path, config: str, optional: bool = False) -> bool:
    command = [sys.executable, str(script), "--config", config]
    print("\n$ " + " ".join(command))
    completed = subprocess.run(command, check=False)
    if completed.returncode != 0:
        if optional:
            print(f"optional step warning: {script.name} returned {completed.returncode}")
            return False
        raise subprocess.CalledProcessError(completed.returncode, command)
    return True


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate all workspace documentation outputs.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--analysis-only", action="store_true")
    parser.add_argument("--skip-runtime-probe", action="store_true")
    parser.add_argument("--skip-screenshots", action="store_true")
    args = parser.parse_args()

    scripts = Path(__file__).resolve().parent
    run_step(scripts / "analyze_workspace.py", args.config)
    if args.analysis_only:
        print("\nanalysis completed")
        return
    if not args.skip_runtime_probe:
        run_step(scripts / "probe_runtime_resources.py", args.config, optional=True)
    if not args.skip_screenshots:
        run_step(scripts / "capture_manual_screens.py", args.config, optional=True)
        run_step(scripts / "capture_resource_screens.py", args.config, optional=True)
    run_step(scripts / "generate_excel_documents.py", args.config)
    run_step(scripts / "generate_manual_ppt.py", args.config)
    run_step(scripts / "validate_outputs.py", args.config)
    print("\nall documents generated and validated")


if __name__ == "__main__":
    main()
