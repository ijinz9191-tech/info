# CHANGELOG

## 3.0.0

### React 분석 확장

- `package.json`, NPM dependency/script/workspace 분석
- React/Vite/CRA/Next React 기술 스택 탐지
- React Router JSX/객체형 Route, menu/link, component, hook, state library 분석
- Axios/fetch/WebSocket/SSE 호출과 환경변수 분석
- Route → Component → API 호출 연결
- React API → Spring Boot/Vert.x endpoint 자동 매핑
- SPA direct/hash/history 이동과 Route 자동 화면 목록 지원
- 화면 캡처 중 DOM, XHR/fetch, WebSocket/EventSource, console/page error 수집
- 화면별 click/fill/select/press/wait/sleep 자동 동작 지원

### Spring Boot 분석 확장

- annotation API 및 WebFlux functional route
- application/component/security/configuration property
- scheduled job, event/Kafka listener
- RestTemplate/WebClient/RestClient 외부·내부 호출
- profile, transaction, Actuator 후보
- Spring Boot ↔ Vert.x 내부 HTTP 매핑

### Vert.x 분석 추가

- Verticle/AbstractVerticle, deployment, HTTP server
- Router/Route/Handler/subRouter
- EventBus send/publish/request/consumer 및 producer-consumer topology
- codec/service proxy, WebClient/HttpClient
- Config/SharedData/timer
- Vert.x Oracle/Redis/Kafka/Micrometer client

### 문서 확장

- 인터페이스명세서에 React API, 화면-API-backend, Spring, Vert.x, EventBus 시트 추가
- 프로그램목록에 React package/component/hook 및 Spring/Vert.x 프로그램 시트 추가
- WorkBook에 기술 스택, 프레임워크 모듈, API 매핑, EventBus topology 추가
- 테이블정의서에 Spring/Vert.x DB 접근 컴포넌트 추가
- 아키텍쳐정의서에 Frontend/Spring Boot/Vert.x, 공존 구조, Mermaid 추가
- 사용자/운영자 PPT에 화면 API 연결, 기술 스택, Spring Boot, Vert.x, EventBus 설명 추가
- v3 필수 시트와 PPT 최소 슬라이드 검증 강화

## 2.0.0

- Oracle, Redis, Elasticsearch, Kafka, Grafana, Prometheus, Loki 탐지
- 선택적 읽기 전용 Runtime probe
- JAR 내부 구조 및 source import 연결
- 운영 화면 캡처와 5개 Excel/2개 PPT 자동 검증

## 1.0.0

- Workspace 기본 정적 분석
- PowerPoint 사용자/운영자 매뉴얼
- Excel 인터페이스/프로그램/Work Book/테이블/아키텍처 문서 생성
