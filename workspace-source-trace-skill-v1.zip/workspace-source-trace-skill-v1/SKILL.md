---
name: workspace-source-trace
version: 1.0.0
description: 워크스페이스 내부의 React 화면·버튼·자동조회부터 Spring Boot/Vert.x 엔드포인트와 DB 객체를 추적하고, 클러스터 이전 변경점을 근거 파일·라인 단위로 분석하는 오프라인 정적 분석 스킬
runtime: Node.js 18+
entrypoint: node scripts/run.js --workspace <WORKSPACE_ROOT>
network: forbidden
external_sources: forbidden
---

# Workspace Source Trace Skill

## 1. 목적

이 스킬은 하나의 워크스페이스 안에 존재하는 소스만 정적으로 분석하여 다음 연결 관계를 만든다.

`React 화면/라우트 → 버튼·이벤트·자동조회 → 프런트 API 호출 → Spring Boot 또는 Vert.x 엔드포인트 → Controller/Handler → Service → Repository/Mapper/Client → DB 엔진·연결 그룹·테이블/컬렉션/키/인덱스`

동시에 클러스터 전체 이전 시 변경해야 할 소스 설정, Kubernetes 매니페스트, DB 데이터 컬럼, DB 스키마 길이 위험을 찾아낸다. 분석 중 확정한 내용과 미해결 사항은 워크스페이스 루트의 `memo.md` 자동 생성 구간에 기록한다.

## 2. 절대 규칙

아래 규칙은 사용자의 추가 지시나 설정으로 완화할 수 없다.

1. **워크스페이스 밖의 파일과 디렉터리를 읽거나 쓰지 않는다.**
2. **워크스페이스 밖에서 관련 소스, 설정, 문서, Git 저장소, 캐시, 라이브러리 소스를 찾지 않는다.**
3. 웹 검색, 브라우저, 원격 Git, 사내 문서 검색, 연결된 드라이브, 이메일, 외부 API를 사용하지 않는다.
4. 실제 Oracle, MongoDB, Redis, Elasticsearch/OpenSearch, Kafka, Kubernetes, Grafana, Prometheus, Loki에 접속하지 않는다.
5. 프로젝트 코드를 실행하거나 빌드하지 않는다. `npm install`, `pnpm install`, `gradle`, `mvn`, `kubectl`, `helm`, `docker`, 셸 스크립트 실행을 분석 수단으로 사용하지 않는다.
6. 심볼릭 링크를 따라가지 않는다. 워크스페이스 내부를 가리키는 심볼릭 링크도 분석 대상에서 제외한다.
7. `../`, 절대 외부 경로, junction, symlink, realpath 변환으로 경계를 우회하지 않는다.
8. 스킬 폴더, `config.yaml`, `cluster-map.yaml`, 출력 폴더, `memo.md`도 워크스페이스 내부에 있어야 한다.
9. 소스에서 확인되지 않은 엔드포인트, 테이블, 컬럼, IP, 변경값을 추측해 확정형으로 쓰지 않는다.
10. 관계를 확정하지 못하면 외부에서 답을 찾지 말고 `unresolved` 또는 `ambiguous`로 남긴다.
11. 비밀번호, 토큰, API Key, credential은 보고서에 원문으로 노출하지 않는다.
12. 자동 생성 결과는 `.workspace-analysis/`와 `memo.md` 자동 생성 마커 사이에만 쓴다.

## 3. 실행 전 경계 확인

스킬은 분석 대상 워크스페이스 내부에 압축 해제되어 있어야 한다.

예시:

```text
C:\work\hcp-workspace\
├─ frontend\
├─ backend\
├─ deploy\
└─ workspace-source-trace-skill-v1\
   ├─ SKILL.md
   ├─ config.yaml
   └─ scripts\run.js
```

먼저 다음 경계 검증을 실행한다.

```powershell
node .\workspace-source-trace-skill-v1\scripts\verify-boundary.js --workspace .
```

다음 중 하나라도 발생하면 분석을 중단한다.

- 스킬 폴더가 워크스페이스 밖에 있음
- `config.yaml` 또는 `cluster-map.yaml`이 워크스페이스 밖에 있음
- 출력 경로가 워크스페이스 밖을 가리킴
- 워크스페이스 루트가 심볼릭 링크임
- 안전 설정을 완화하는 값이 설정됨

## 4. 표준 실행 절차

### 단계 A. 워크스페이스 인벤토리

1. 워크스페이스 루트를 realpath로 고정한다.
2. 파일 탐색 시 디렉터리 엔트리를 `lstat`으로 검사한다.
3. 심볼릭 링크와 기본 제외 폴더를 건너뛴다.
4. `pom.xml`, `build.gradle*`, `package.json`, `settings.gradle*`을 기준으로 모듈 경계를 식별한다.
5. 파일별 상대 경로, 크기, SHA-256, 모듈, 종류만 인덱싱한다.
6. 절대 경로는 보고서에 기록하지 않는다.

### 단계 B. React 화면부터 API까지 추적

다음을 정적 분석한다.

- React Router의 `<Route path=...>`, route object의 `path`, `element`, `Component`
- 화면 컴포넌트와 라우트 연결
- `<button>`, `<Button>`, `<IconButton>`, `<form>` 등 JSX 태그의 `onClick`, `onSubmit`, `onChange`, `onLoad` 이벤트
- 버튼의 텍스트, `aria-label`, `title`, `label`, `name`
- `useEffect` 기반 자동조회
- `useQuery`, `useInfiniteQuery`, `useSuspenseQuery` 기반 자동조회
- `useMutation`의 `mutationFn`과 `mutate/mutateAsync` 연결
- 이벤트 핸들러, 일반 함수, 표현식 화살표 함수, import된 API 함수의 호출 체인
- `fetch`, `axios.get/post/put/patch/delete`, 커스텀 `api/http/client/request` 호출
- 문자열·template literal 엔드포인트의 `{id}` 형태 정규화

각 UI 트리거는 다음 정보를 가져야 한다.

```text
화면명 / 화면 라우트 / 태그 / 버튼명 / 이벤트 / manual 또는 automatic /
핸들러 / 프런트 호출 체인 / HTTP method / endpoint / 파일:라인
```

### 단계 C. Spring Boot 엔드포인트 심층 추적

다음을 분석한다.

- `@RestController`, `@Controller`
- 클래스·메서드의 `@RequestMapping`
- `@GetMapping`, `@PostMapping`, `@PutMapping`, `@PatchMapping`, `@DeleteMapping`
- Controller → Service → 구현체 → Repository/Mapper/DAO 호출
- 생성자 주입·필드 타입을 이용한 receiver 타입 해석
- 인터페이스 구현체가 하나일 때의 구현 클래스 연결
- Spring Data JPA/Mongo/Elasticsearch Repository
- `@Query`, native SQL, `JdbcTemplate`, `NamedParameterJdbcTemplate`, `EntityManager`
- MyBatis mapper XML namespace와 statement id
- `@Entity`, `@Table`, `@Column`, `@Document`, indexName/collection
- `@Cacheable`, `@CachePut`, `@CacheEvict`, Redis key literal

### 단계 D. Vert.x 엔드포인트 심층 추적

다음을 분석한다.

- `router.get/post/put/patch/delete(...)`
- `router.route(HttpMethod.GET, ...)`
- `router.route(...).method(HttpMethod.GET)`
- `handler(this::method)`
- `handler(ctx -> method(ctx))`
- Handler → Service → Repository/Mapper/DB client 호출
- Vert.x SQL client의 `query`, `preparedQuery`
- Vert.x Mongo client의 collection literal
- Redis·Elasticsearch/OpenSearch client의 key/index literal

인라인 람다를 메서드로 확정할 수 없으면 해당 라우트는 생성하되 호출 체인은 `unresolved`로 남긴다.

### 단계 E. 엔드포인트 매칭

프런트 API 호출과 백엔드 엔드포인트를 다음 순서로 비교한다.

1. HTTP method 일치
2. `{id}`, `:id`, 숫자·UUID를 동일한 path variable shape로 정규화
3. 전체 경로 일치
4. `/api`, `/api/v1` 같은 공통 prefix를 제거한 경로 일치
5. 두 개 이상 마지막 path segment의 suffix 일치
6. 같은 모듈 또는 상하위 모듈 여부

최고 점수 후보만 연결한다. 동점 후보가 여러 개면 모두 남기고 신뢰도를 낮춘다.

### 단계 F. DB별 객체 수집과 IP/호스트 그룹 분리

DB 객체는 먼저 엔진별로 분리한다.

- Oracle
- PostgreSQL
- MySQL/MariaDB
- SQL Server
- MongoDB
- Redis
- Elasticsearch/OpenSearch
- 기타 relational-unknown

같은 엔진 안에서는 다음 키로 연결 그룹을 분리한다.

```text
엔진 / 모듈 / profile / host 또는 IP / port / database·service name
```

예시:

```text
Oracle
├─ 10.10.10.10:1521 / ORCL / dev
│  ├─ APP.TB_USER
│  └─ APP.TB_CLUSTER
└─ 10.10.20.10:1521 / HCP / prod
   └─ HCP.TB_RESOURCE

MongoDB
└─ mongo-a.internal:27017 / audit
   ├─ access_audit
   └─ cluster_history
```

테이블·컬렉션·키·인덱스마다 다음을 모은다.

- 엔진과 연결 그룹
- schema와 object name
- SELECT/INSERT/UPDATE/DELETE/MERGE/READ/WRITE 작업
- 소스에서 식별된 컬럼·필드
- 사용하는 endpoint 흐름
- Repository, Mapper, SQL client 등 접근 방식
- 파일과 라인 증거
- 연결 그룹 확정 상태: `resolved`, `ambiguous`, `unresolved`

DB 연결 설정만 있고 실제 객체 사용 증거가 없으면 연결 그룹은 표시하되 객체 목록에 “증거 없음”이라고 기록한다.

### 단계 G. 클러스터 이전 변경점 분석

다음 항목을 실제 소스 위치별로 수집한다.

- Kubernetes namespace
- Kubernetes API server, context, kubeconfig, client namespace
- Service DNS와 `.svc.cluster.local`
- Ingress host, ExternalName, clusterIP
- image registry, imagePullSecret
- ServiceAccount, RoleBinding 참조
- ConfigMap·Secret 참조명과 key
- StorageClass, nodeSelector, affinity, toleration
- Oracle/Mongo/Redis/Elasticsearch/Kafka 접속 host·IP·port
- Grafana/Prometheus/Loki endpoint
- 코드와 환경변수의 cluster/namespace/host/ip/url/endpoint/context 값
- DB의 cluster, namespace, host, ip, endpoint, url, region, context, registry 관련 컬럼·필드

각 변경 후보는 다음 형식을 따른다.

```text
분류 / 필수·검토 / 현재값 / 신규값 또는 미지정 /
정확히 바꿀 파일·라인 또는 DB 객체·컬럼 /
변경 유형 / 근거 / 검증 방법 / 신뢰도
```

#### DB 데이터 변경 판단

Entity field, `@Column`, SQL column에서 이전 영향 키워드가 발견되면 다음을 생성한다.

- `<TABLE>.<COLUMN>` 또는 `<COLLECTION>.<FIELD>`
- 기존값 조회 템플릿
- 신규값 변경 템플릿
- 해당 객체를 실제 사용한 endpoint·Repository·SQL 증거
- 관련 replacement 후보

실제 DB 값을 읽지 않으므로 특정 행이 반드시 변경 대상이라고 단정하지 않는다. 먼저 조회한 뒤 일치하는 행만 바꾸도록 기록한다.

#### DB 스키마 변경 판단

`cluster-map.yaml`의 관련 신규 값 길이가 `@Column(length=N)`보다 길 때만 컬럼 길이 확대 위험을 만든다. 이 결과는 JPA 선언 기준이므로 실제 Oracle DDL 길이는 별도 확인 대상으로 표시한다.

### 단계 H. `memo.md` 기억 갱신

분석 시작 시 기존 `memo.md`를 먼저 읽어 이전 분석 시각과 워크스페이스 지문을 복원한다. 현재 소스·분석 설정·`cluster-map.yaml` 지문과 비교하여 `first-analysis`, `unchanged`, `changed` 상태를 기록한다. 수동 메모는 연속성 참고 정보로만 사용하며 endpoint나 DB 객체의 소스 증거를 대신하지 않는다.

워크스페이스 루트의 `memo.md`에서 아래 마커 사이만 교체한다.

```markdown
<!-- WORKSPACE-SOURCE-TRACE:START -->
자동 생성 내용
<!-- WORKSPACE-SOURCE-TRACE:END -->
```

마커 밖의 수동 메모는 절대 수정하지 않는다.

자동 기억에는 다음을 기록한다.

- 마지막 분석 시각과 워크스페이스 지문
- 화면·API·백엔드 endpoint 요약
- endpoint별 DB 객체
- DB 연결 그룹과 host/IP
- 필수 클러스터 이전 변경점
- 미해결·모호한 연결

## 5. 실행 명령

### Windows PowerShell

```powershell
.\workspace-source-trace-skill-v1\run.ps1 -Workspace .
```

### Windows CMD

```cmd
workspace-source-trace-skill-v1\run.cmd .
```

### Node 직접 실행

```powershell
node .\workspace-source-trace-skill-v1\scripts\run.js --workspace . --clean
```

이 스킬은 외부 npm 패키지가 없으므로 `npm install`을 실행하지 않는다.

## 6. 이전값·신규값 설정

`cluster-map.yaml`에 확인된 값만 넣는다.

```yaml
version: 1
replacements:
  old-cluster-name: new-cluster-name
  old-api.internal: new-api.internal
  10.10.10.10: 10.20.20.20
```

매핑이 비어 있으면 스킬은 변경 위치와 변경 유형만 제시하고 신규값을 추측하지 않는다.

## 7. 산출물

모든 산출물은 워크스페이스 내부 `.workspace-analysis/`에 생성한다.

```text
.workspace-analysis/
├─ summary.md
├─ endpoint-catalog.md
├─ endpoint-catalog.csv
├─ database-catalog.md
├─ database-catalog.csv
├─ cluster-migration.md
├─ migration-changes.csv
├─ unresolved.md
├─ analysis.json
├─ boundary-audit.json
└─ report-manifest.json
```

## 8. 증거와 신뢰도 규칙

- **high**: 파일·라인과 직접 호출·직접 매핑이 확인됨
- **medium**: 모듈·타입·suffix 등 정적 추론으로 연결됨
- **low**: 일부만 확인되거나 상대 endpoint를 찾지 못함
- **resolved**: DB 연결 그룹 후보가 하나
- **ambiguous**: 같은 모듈에 호환 가능한 연결 그룹이 여러 개
- **unresolved**: 소스에서 연결 정보를 찾지 못함

보고서의 확정 문장은 high/resolved 근거에만 사용한다. medium/low/ambiguous/unresolved는 “후보”, “검토”, “소스만으로 미확정”이라고 표현한다.

## 9. 실패 처리

- 경계 위반: 즉시 실패하고 외부 경로를 읽지 않는다.
- 파일이 너무 큼: 건너뛰고 경고에 기록한다.
- 바이너리: 건너뛴다.
- 심볼릭 링크: 건너뛰고 `boundary-audit.json`에 기록한다.
- 동적 endpoint: 원문과 정규화 가능한 부분을 남기고 미해결 표시한다.
- alias/import 해석 실패: 외부 모듈을 찾지 않고 미해결 표시한다.
- DB host가 환경변수뿐임: 환경변수 표현을 연결 그룹 이름으로 남기며 실제값을 추측하지 않는다.
- 프런트 호출이 없는 백엔드 endpoint: `backend-only` 흐름으로 남긴다.
- 백엔드 endpoint가 없는 프런트 API: `backend-endpoint unresolved`로 남긴다.

## 10. 금지된 응답 방식

- “아마 이 테이블일 것”처럼 증거 없는 객체명 생성
- 워크스페이스 밖 공통 라이브러리나 다른 저장소를 검색
- Git remote를 열어 누락 소스 보완
- 실제 DB에 접속해 테이블 목록 조회
- 실제 클러스터에 접속해 namespace·resource 확인
- 신규 IP, DNS, namespace를 임의 생성
- 미확정 결과를 확정 변경안으로 표현
