# Analysis Contract

## Boundary contract

- Workspace root is canonicalized with `realpath` once.
- Every candidate path is checked lexically and by existing path segments.
- Any path segment that is a symbolic link is rejected.
- The skill root must be a descendant of the workspace root.
- The configuration, migration mapping, output, and memo paths must be descendants of the same root.
- No network library is imported by the runtime.
- No child process is spawned by the runtime.

## Evidence contract

Every significant finding should include:

- workspace-relative file path
- 1-based line number
- short source excerpt
- analyzer type
- confidence

An inferred relation must retain the evidence of each hop. Missing hops are not silently skipped.

## Endpoint flow contract

A complete flow may contain:

1. screen and route
2. UI trigger
3. JavaScript handler chain
4. frontend HTTP call
5. backend route
6. backend method call chain
7. database access object
8. connection group
9. migration candidates

A flow is still emitted when either frontend or backend evidence is absent.

## Data handling contract

- Password/token/secret values are redacted.
- Absolute workspace paths are excluded from reports.
- Source file content is not copied wholesale into reports.
- Only short evidence excerpts are retained.
- `memo.md` content outside generated markers is preserved.
