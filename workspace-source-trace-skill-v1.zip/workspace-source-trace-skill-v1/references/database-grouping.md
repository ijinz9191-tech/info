# Database Grouping

## Hierarchy

```text
engine
└─ connection group
   └─ database object
      └─ operations, columns, source evidence, endpoint flows
```

## Connection group identity

The identity is derived from:

- engine
- module
- profile
- source property key
- host/IP and port when present
- database/service name when present

## Oracle grouping example

```text
oracle
├─ 10.10.10.10:1521 / ORCL / dev
└─ 10.10.20.10:1521 / HCP / prod
```

A table is not assigned to an arbitrary Oracle group when two equal candidates exist. It is copied as an ambiguous candidate relation in structured output.

## Non-relational objects

- MongoDB: collection
- Redis: key-pattern or cache
- Elasticsearch/OpenSearch: index

A connection group may appear without an object when configuration exists but no workspace source shows object usage.
