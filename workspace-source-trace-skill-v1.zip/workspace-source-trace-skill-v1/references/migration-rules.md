# Cluster Migration Rules

## Change classes

### Source and configuration

- hard-coded URL, IP, service DNS
- datasource and message broker connection
- Kubernetes client master URL, context, namespace
- cluster-related environment variable

### Kubernetes manifests

- metadata namespace
- image registry and pull secret
- ServiceAccount
- Ingress host
- ConfigMap and Secret reference
- StorageClass
- node selector, affinity, toleration
- ExternalName and fixed clusterIP

### Database data

Potential fields are selected using configured keywords such as cluster, namespace, context, host, IP, endpoint, URL, region, registry, and broker.

A field match creates a review plan, not an executed change. The plan always requires reading matching rows/documents before update. When a source assignment key matches the entity field or column name, its mapped old/new value is treated as the strongest replacement evidence; unrelated mappings are not attached to that DB field.

### Database schema

A schema length risk is emitted only when:

1. a Java entity field has an explicit `@Column(length=N)`; and
2. a replacement considered relevant to that field has a target value longer than N.

The Java annotation may differ from actual database DDL, so the result is a DDL verification requirement.

## Replacement map

`cluster-map.yaml` is the only source of target values. No target is invented.

Exact matches are preferred. Substring replacement is allowed for values such as URLs and image references. Every mapped change retains its original and target values.

## Verification rules

Each candidate includes a verification action appropriate to its category, such as datasource connection, Kafka message flow, DNS/TLS response, Kubernetes readiness, or DB row-count comparison.
