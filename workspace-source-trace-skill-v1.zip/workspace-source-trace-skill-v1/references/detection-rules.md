# Detection Rules

## React

Supported evidence patterns include:

- JSX event props: onClick, onSubmit, onChange, onLoad, keyboard events
- React Router JSX and route objects
- useEffect automatic execution
- React Query useQuery family
- React Query useMutation aliases
- function declarations
- block and expression arrow functions
- named/default/namespace relative imports
- common `@/` and `~/` aliases from `config.yaml`
- fetch and axios/custom-client method calls

Endpoint templates are normalized:

- `/users/${id}` → `/users/{id}`
- `/users/:id` → `/users/{id}`
- absolute URL host portion is removed for route comparison

## Spring Boot

Supported route annotations:

- RequestMapping
- GetMapping
- PostMapping
- PutMapping
- PatchMapping
- DeleteMapping

Supported persistence evidence:

- Entity/Table/Column
- Mongo/Elasticsearch Document
- JpaRepository, CrudRepository, MongoRepository, ElasticsearchRepository
- Query annotation
- JdbcTemplate and related SQL clients
- MyBatis mapper XML
- Cache annotations

## Vert.x

Supported route forms:

- `router.get("/x").handler(this::handler)`
- `router.get("/x").handler(ctx -> handler(ctx))`
- `router.route(HttpMethod.GET, "/x")`
- `router.route("/x").method(HttpMethod.GET)`

Supported persistence evidence includes SQL client string queries, Mongo collection literals, Redis key literals, and Elasticsearch index literals.

## SQL objects

Recognized operations:

- SELECT FROM/JOIN
- INSERT INTO
- UPDATE
- DELETE FROM
- MERGE INTO
- CREATE/ALTER/DROP TABLE

Oracle hints include NVL, SYSDATE, ROWNUM, CONNECT BY, VARCHAR2, NEXTVAL, and DUAL. Connection-group evidence takes precedence over dialect hints.

## Connection groups

Detected from workspace configuration keys and values:

- JDBC URLs
- MongoDB URIs 및 분리형 host/port/database 설정
- Redis URI 및 분리형 host/port/database 설정
- Elasticsearch/OpenSearch URIs
- Kafka bootstrap servers
- Prometheus, Loki, and Grafana endpoints

Split properties with the same engine, module, profile, and configuration prefix are aggregated into one connection group. Credential properties are excluded and redacted.

Objects are assigned to compatible connections in the nearest matching module. Multiple equal candidates remain ambiguous.
