#!/usr/bin/env node
'use strict';

const path = require('path');
const { parseArgs } = require('../src/cli');
const { WorkspaceGuard } = require('../src/core/workspace-guard');

function main() {
  const args = parseArgs(process.argv.slice(2));
  const guard = new WorkspaceGuard(args.workspace, { strict: true, followSymlinks: false });
  guard.assertSkillInside(path.resolve(__dirname, '..'));
  guard.removeTree('.workspace-analysis');
  process.stdout.write('워크스페이스 내부의 .workspace-analysis만 삭제했습니다. memo.md는 유지됩니다.\n');
}

try { main(); } catch (error) {
  process.stderr.write(`${error.message}\n`);
  process.exitCode = 1;
}
