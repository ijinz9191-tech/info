#!/usr/bin/env node
'use strict';

const path = require('path');
const { parseArgs, helpText } = require('../src/cli');
const { runAnalysis, WorkspaceBoundaryError } = require('../src/main');

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) {
    process.stdout.write(helpText());
    return;
  }
  const skillRoot = path.resolve(__dirname, '..');
  const result = await runAnalysis({
    workspace: args.workspace,
    config: args.config,
    clean: args.clean,
    quiet: args.quiet,
    skillRoot,
  });
  if (!args.quiet) {
    const summary = result.analysis;
    process.stdout.write([
      'Workspace-only 분석 완료',
      `- 파일: ${summary.meta.fileCount}`,
      `- 화면/트리거/API: ${summary.frontend.screens.length}/${summary.frontend.triggers.length}/${summary.frontend.apiCalls.length}`,
      `- 백엔드 엔드포인트: ${summary.backend.endpoints.length}`,
      `- DB 객체/연결: ${summary.databases.objects.length}/${summary.databases.connections.length}`,
      `- 이전 후보: ${summary.migration.summary.total}`,
      `- 결과: ${result.reportResult.outputDir}`,
      `- 메모: ${result.memoPath || '미갱신'}`,
      '',
    ].join('\n'));
  }
}

main().catch((error) => {
  if (error instanceof WorkspaceBoundaryError || error?.name === 'WorkspaceBoundaryError') {
    process.stderr.write(`BOUNDARY_DENIED: ${error.message}\n`);
  } else {
    process.stderr.write(`${error.stack || error.message || String(error)}\n`);
  }
  process.exitCode = 1;
});
