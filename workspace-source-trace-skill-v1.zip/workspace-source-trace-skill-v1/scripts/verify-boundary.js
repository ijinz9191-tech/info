#!/usr/bin/env node
'use strict';

const path = require('path');
const { parseArgs } = require('../src/cli');
const { WorkspaceGuard, WorkspaceBoundaryError } = require('../src/core/workspace-guard');

function main() {
  const args = parseArgs(process.argv.slice(2));
  const guard = new WorkspaceGuard(args.workspace, { strict: true, followSymlinks: false });
  const skillRoot = path.resolve(__dirname, '..');
  guard.assertSkillInside(skillRoot);
  let blocked = false;
  try {
    guard.resolveInside(path.resolve(guard.root, '..', '__outside_probe__'), { mustExist: false });
  } catch (error) {
    if (error instanceof WorkspaceBoundaryError) blocked = true;
    else throw error;
  }
  if (!blocked) throw new Error('외부 경로 차단 자체검증에 실패했습니다.');
  process.stdout.write('OK: 스킬 위치가 워크스페이스 내부이며 외부 경로 접근이 차단됩니다.\n');
}

try { main(); } catch (error) {
  process.stderr.write(`${error.message}\n`);
  process.exitCode = 1;
}
