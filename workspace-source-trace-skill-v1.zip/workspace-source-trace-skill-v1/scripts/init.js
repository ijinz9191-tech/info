#!/usr/bin/env node
'use strict';

const path = require('path');
const fs = require('fs');
const { parseArgs } = require('../src/cli');
const { WorkspaceGuard } = require('../src/core/workspace-guard');

function main() {
  const args = parseArgs(process.argv.slice(2));
  const guard = new WorkspaceGuard(args.workspace, { strict: true, followSymlinks: false });
  const skillRoot = path.resolve(__dirname, '..');
  guard.assertSkillInside(skillRoot);
  const memo = guard.resolveInside('memo.md', { mustExist: false });
  if (!fs.existsSync(memo)) guard.writeText(memo, guard.readText(path.join(skillRoot, 'memo.template.md')));
  guard.ensureDirectory('.workspace-analysis');
  process.stdout.write('초기화 완료: memo.md 및 .workspace-analysis 경로가 워크스페이스 내부에 준비되었습니다.\n');
}

try { main(); } catch (error) {
  process.stderr.write(`${error.message}\n`);
  process.exitCode = 1;
}
