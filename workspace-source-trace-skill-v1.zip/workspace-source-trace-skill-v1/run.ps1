param(
    [string]$Workspace = (Get-Location).Path,
    [string]$Config = ""
)

$ErrorActionPreference = "Stop"
$SkillRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$WorkspacePath = (Resolve-Path $Workspace).Path
$SkillPath = (Resolve-Path $SkillRoot).Path

$prefix = $WorkspacePath.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
if (-not ($SkillPath + [IO.Path]::DirectorySeparatorChar).StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
    throw "스킬 폴더는 반드시 분석 대상 워크스페이스 내부에 있어야 합니다. Skill=$SkillPath Workspace=$WorkspacePath"
}

$argsList = @("$SkillRoot\scripts\run.js", "--workspace", $WorkspacePath)
if ($Config -ne "") {
    $argsList += @("--config", $Config)
}

& node @argsList
if ($LASTEXITCODE -ne 0) {
    exit $LASTEXITCODE
}
