# Sample Flow

```text
PATCH /api/users/{id}/cluster
confidence: high

UsersPage (/users)
└─ 클러스터 이동 button / onClick / manual
   └─ handleMove
      └─ userApi.moveCluster
         └─ axios.patch('/api/users/${id}/cluster')
            └─ UserController#move
               └─ UserService#move
                  └─ UserRepository#save
                     └─ Oracle 10.10.10.10:1521 / APP.TB_USER_CLUSTER
                        └─ CLUSTER_ENDPOINT
```

Possible migration findings:

```text
application-prod.yml: spring.datasource.url host replacement
User.java: APP.TB_USER_CLUSTER.CLUSTER_ENDPOINT data review
User.java: @Column(length=20) target length risk
Deployment YAML: namespace, ServiceAccount, image registry
Ingress YAML: host replacement
```
