# Workspace Analysis Memo

이 파일은 사람이 작성하는 메모와 자동 생성 메모를 함께 보관한다.
자동 생성 구간 밖의 내용은 스킬이 수정하지 않는다.

## 수동 메모

- 프로젝트별 예외, 담당자 확인사항, 분석에서 제외할 사유를 기록한다.

<!-- WORKSPACE-SOURCE-TRACE:START -->
자동 분석을 실행하면 이 구간이 갱신된다.
<!-- WORKSPACE-SOURCE-TRACE:END -->
