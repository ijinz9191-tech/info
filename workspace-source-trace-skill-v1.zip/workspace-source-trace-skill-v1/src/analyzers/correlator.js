'use strict';

const { endpointShape, normalizeEndpointPath, stableId, unique } = require('../core/text');

function pathSegments(value) {
  return endpointShape(value).split('/').filter(Boolean);
}

function suffixSimilarity(a, b) {
  const left = pathSegments(a);
  const right = pathSegments(b);
  let equal = 0;
  for (let i = 1; i <= Math.min(left.length, right.length); i += 1) {
    if (left[left.length - i] !== right[right.length - i]) break;
    equal += 1;
  }
  return { equal, max: Math.max(left.length, right.length), min: Math.min(left.length, right.length) };
}

function endpointMatchScore(apiCall, endpoint) {
  const apiMethod = String(apiCall.method || 'UNKNOWN').toUpperCase();
  const backendMethod = String(endpoint.method || 'ANY').toUpperCase();
  if (apiMethod !== 'UNKNOWN' && backendMethod !== 'ANY' && apiMethod !== backendMethod) return 0;
  let score = 0;
  if (apiMethod === backendMethod) score += 35;
  else if (apiMethod === 'UNKNOWN' || backendMethod === 'ANY') score += 10;

  const a = endpointShape(apiCall.path);
  const b = endpointShape(endpoint.path);
  if (a === b) score += 65;
  else {
    const suffix = suffixSimilarity(a, b);
    if (suffix.equal === suffix.min && suffix.equal >= 2) score += 50;
    else if (suffix.equal >= 2) score += 35;
    else if (suffix.equal === 1) score += 12;
    const aNoApi = a.replace(/^\/api(?:\/v\d+)?/, '');
    const bNoApi = b.replace(/^\/api(?:\/v\d+)?/, '');
    if (aNoApi === bNoApi) score += 35;
  }
  if (apiCall.module === endpoint.module) score += 8;
  else if (apiCall.module?.startsWith(`${endpoint.module}/`) || endpoint.module?.startsWith(`${apiCall.module}/`)) score += 4;
  if (apiCall.path.includes('{') || endpoint.path.includes('{')) score += 2;
  return Math.min(100, score);
}

function groupApiCalls(apiCalls) {
  const map = new Map();
  for (const call of apiCalls || []) {
    const key = `${call.module}|${call.method}|${endpointShape(call.path)}`;
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(call);
  }
  return [...map.entries()].map(([key, calls]) => ({ key, calls }));
}

function migrationForFlow(flow, migrationCandidates) {
  const evidencePoints = [];
  const connectionIds = new Set();
  const dbNames = new Set();
  const addPoint = (source, radius = 2) => {
    if (source?.file) evidencePoints.push({ file: source.file, line: Number(source.line || 1), radius });
  };
  for (const trigger of flow.frontendTriggers || []) addPoint(trigger.source, 2);
  for (const call of flow.frontendCalls || []) addPoint(call.source, 1);
  for (const endpoint of flow.backendEndpoints || []) {
    addPoint(endpoint.source, 4);
    for (const step of endpoint.callChain || []) addPoint(step.source, 4);
  }
  for (const object of flow.databaseObjects || []) {
    addPoint(object.source, 3);
    dbNames.add(String(object.fullName || '').toLowerCase());
    for (const group of object.connectionGroups || []) connectionIds.add(group.id);
  }
  return (migrationCandidates || []).filter((candidate) => {
    if (candidate.connectionGroupId && connectionIds.has(candidate.connectionGroupId)) return true;
    if (candidate.databaseObject?.name && dbNames.has(String(candidate.databaseObject.name).toLowerCase())) return true;
    if (candidate.source?.file) {
      const candidateLine = Number(candidate.source.line || 1);
      if (evidencePoints.some((point) => point.file === candidate.source.file && Math.abs(point.line - candidateLine) <= point.radius)) return true;
    }
    return false;
  });
}

function flowConfidence(flow, matchScore) {
  if (!flow.backendEndpoints.length) return 'low';
  const unresolved = flow.unresolved.length;
  const dbAmbiguous = flow.databaseObjects.some((object) => object.connectionResolution === 'ambiguous');
  if (matchScore >= 90 && unresolved === 0 && !dbAmbiguous) return 'high';
  if (matchScore >= 55) return 'medium';
  return 'low';
}

function uniqueDbObjects(objects) {
  const map = new Map();
  for (const object of objects || []) {
    const key = object.id || `${object.engine}|${object.fullName}|${object.ownerClass}|${object.ownerMethod}`;
    if (!map.has(key)) map.set(key, object);
  }
  return [...map.values()];
}

function correlate({ frontend, backend, migration, config }) {
  const flows = [];
  const apiGroups = groupApiCalls(frontend.apiCalls || []);
  const triggersByApi = new Map();
  for (const trigger of frontend.triggers || []) {
    for (const apiId of trigger.apiCallIds || []) {
      if (!triggersByApi.has(apiId)) triggersByApi.set(apiId, []);
      triggersByApi.get(apiId).push(trigger);
    }
  }
  const minimum = Number(config.analysis.endpointMatchMinimumScore || 45);
  const matchedBackendIds = new Set();

  for (const group of apiGroups) {
    const representative = group.calls[0];
    const scored = (backend.endpoints || [])
      .map((endpoint) => ({ endpoint, score: endpointMatchScore(representative, endpoint) }))
      .filter((item) => item.score >= minimum)
      .sort((a, b) => b.score - a.score);
    const bestScore = scored[0]?.score || 0;
    const bestEndpoints = scored.filter((item) => item.score === bestScore).map((item) => item.endpoint);
    for (const endpoint of bestEndpoints) matchedBackendIds.add(endpoint.id);
    const triggers = [];
    for (const call of group.calls) triggers.push(...(triggersByApi.get(call.id) || []));
    const databaseObjects = uniqueDbObjects(bestEndpoints.flatMap((endpoint) => endpoint.databaseObjects || []));
    const unresolved = [];
    if (!bestEndpoints.length) unresolved.push({ type: 'backend-endpoint', message: '프런트엔드 API 호출과 일치하는 Spring/Vert.x 엔드포인트를 찾지 못함' });
    for (const endpoint of bestEndpoints) {
      for (const item of endpoint.unresolvedCalls || []) unresolved.push({ type: 'backend-call', endpointId: endpoint.id, ...item });
    }
    for (const object of databaseObjects) {
      if (object.connectionResolution === 'unresolved') unresolved.push({ type: 'database-connection', objectId: object.id, message: `${object.engine} ${object.fullName}의 연결 그룹을 소스만으로 확정하지 못함` });
      if (object.connectionResolution === 'ambiguous') unresolved.push({ type: 'database-connection', objectId: object.id, message: `${object.engine} ${object.fullName}가 여러 연결 그룹 후보를 가짐` });
    }
    const flow = {
      id: stableId('flow', representative.module, representative.method, endpointShape(representative.path)),
      method: representative.method,
      path: normalizeEndpointPath(representative.path),
      sourceKind: 'frontend-api',
      matchScore: bestScore,
      frontendCalls: group.calls,
      frontendTriggers: [...new Map(triggers.map((trigger) => [trigger.id, trigger])).values()],
      backendEndpoints: bestEndpoints,
      databaseObjects,
      connectionGroups: uniqueDbObjects(databaseObjects.flatMap((object) => object.connectionGroups || []).map((groupItem) => ({ ...groupItem, fullName: groupItem.id }))),
      unresolved,
      confidence: 'low',
      migrationCandidates: [],
    };
    flow.migrationCandidates = migrationForFlow(flow, migration.candidates || []);
    flow.confidence = flowConfidence(flow, bestScore);
    flows.push(flow);
  }

  for (const endpoint of backend.endpoints || []) {
    if (matchedBackendIds.has(endpoint.id)) continue;
    const databaseObjects = uniqueDbObjects(endpoint.databaseObjects || []);
    const unresolved = [{ type: 'frontend-caller', message: '워크스페이스 내 React 코드에서 이 엔드포인트를 호출하는 증거를 찾지 못함' }];
    for (const item of endpoint.unresolvedCalls || []) unresolved.push({ type: 'backend-call', ...item });
    const flow = {
      id: stableId('flow', endpoint.id, 'backend-only'),
      method: endpoint.method,
      path: endpoint.path,
      sourceKind: 'backend-only',
      matchScore: 0,
      frontendCalls: [],
      frontendTriggers: [],
      backendEndpoints: [endpoint],
      databaseObjects,
      connectionGroups: uniqueDbObjects(databaseObjects.flatMap((object) => object.connectionGroups || []).map((groupItem) => ({ ...groupItem, fullName: groupItem.id }))),
      unresolved,
      confidence: databaseObjects.length ? 'medium' : 'low',
      migrationCandidates: [],
    };
    flow.migrationCandidates = migrationForFlow(flow, migration.candidates || []);
    flows.push(flow);
  }

  return flows.sort((a, b) => `${a.path}|${a.method}`.localeCompare(`${b.path}|${b.method}`));
}

module.exports = {
  correlate,
  endpointMatchScore,
  suffixSimilarity,
};
