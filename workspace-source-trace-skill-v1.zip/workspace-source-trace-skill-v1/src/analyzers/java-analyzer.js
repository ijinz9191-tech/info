'use strict';

const {
  lineNumberAt,
  excerptAt,
  findMatchingBrace,
  normalizeEndpointPath,
  joinEndpointPaths,
  stableId,
  unique,
} = require('../core/text');
const { extractSqlObjects, mergeDatabaseObjects } = require('./sql-analyzer');

const JAVA_CONTROL_NAMES = new Set(['if', 'for', 'while', 'switch', 'catch', 'synchronized', 'try', 'do']);

function annotationBlockBefore(text, index, maxLookback = 3000) {
  const start = Math.max(0, index - maxLookback);
  const slice = text.slice(start, index);
  const match = slice.match(/((?:\s*@[A-Za-z_$][\w.$]*(?:\s*\((?:[^()]|\([^()]*\))*\))?\s*)+)$/s);
  return match ? match[1] : '';
}

function annotationContent(block, annotationName) {
  const regex = new RegExp(`@(?:[A-Za-z_$][\\w$]*\\.)*${annotationName}\\s*(?:\\(((?:[^()]|\\([^()]*\\))*)\\))?`, 'i');
  const match = regex.exec(block || '');
  return match ? (match[1] || '') : null;
}

function hasAnnotation(block, annotationName) {
  return annotationContent(block, annotationName) !== null;
}

function annotationStrings(content) {
  if (content === null || content === undefined) return [];
  const strings = [];
  const regex = /"((?:\\.|[^"\\])*)"|'((?:\\.|[^'\\])*)'/g;
  let match;
  while ((match = regex.exec(content))) strings.push((match[1] ?? match[2]).replace(/\\"/g, '"'));
  return strings;
}

function mappingPaths(annotationBlock, annotationName) {
  const content = annotationContent(annotationBlock, annotationName);
  if (content === null) return [];
  const strings = annotationStrings(content);
  if (!strings.length) return [''];
  const namedMatch = content.match(/\b(?:value|path)\s*=\s*(\{[\s\S]*?\}|"(?:\\.|[^"])*"|'(?:\\.|[^'])*')/i);
  if (namedMatch) {
    const namedStrings = annotationStrings(namedMatch[1]);
    if (namedStrings.length) return namedStrings;
  }
  return strings.filter((value) => !/^(application|text)\//i.test(value));
}

function combineRoutePaths(basePaths, methodPaths) {
  const bases = basePaths?.length ? basePaths : [''];
  const methods = methodPaths?.length ? methodPaths : [''];
  const result = [];
  for (const base of bases) for (const method of methods) result.push(joinEndpointPaths(base, method));
  return unique(result);
}

function extractJavaStrings(expression) {
  const values = [];
  const regex = /"((?:\\.|[^"\\])*)"/g;
  let match;
  while ((match = regex.exec(expression || ''))) values.push(match[1].replace(/\\n/g, ' ').replace(/\\"/g, '"'));
  return values;
}

function simpleType(type) {
  return String(type || '')
    .replace(/@[A-Za-z_$][\w.$]*(?:\([^)]*\))?\s*/g, '')
    .replace(/<.*>/g, '')
    .replace(/\[\]/g, '')
    .replace(/\?/g, '')
    .trim()
    .split(/[.\s]/)
    .filter(Boolean)
    .pop() || '';
}

function extractJavaCalls(body) {
  const calls = [];
  let match;
  const objectRegex = /\b([A-Za-z_$][\w$]*)\s*\.\s*([A-Za-z_$][\w$]*)\s*\(/g;
  while ((match = objectRegex.exec(body))) calls.push({ receiver: match[1], method: match[2], name: `${match[1]}.${match[2]}`, index: match.index });
  const selfRegex = /(?<![.\w$])([A-Za-z_$][\w$]*)\s*\(/g;
  while ((match = selfRegex.exec(body))) {
    const prefix = body.slice(Math.max(0, match.index - 12), match.index);
    if (/\bnew\s*$/.test(prefix)) continue;
    if (JAVA_CONTROL_NAMES.has(match[1]) || ['new', 'return', 'throw', 'super', 'this'].includes(match[1])) continue;
    calls.push({ receiver: 'this', method: match[1], name: match[1], index: match.index });
  }
  const seen = new Set();
  return calls.filter((call) => {
    const key = `${call.name}|${call.index}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function parseClass(file) {
  const text = file.text;
  const packageMatch = text.match(/\bpackage\s+([A-Za-z_$][\w$.]*)\s*;/);
  const classRegex = /\b(?:public\s+|protected\s+|private\s+|abstract\s+|final\s+|static\s+)*(class|interface|enum|record)\s+([A-Za-z_$][\w$]*)([^\{]*)\{/g;
  const match = classRegex.exec(text);
  if (!match) return null;
  const open = text.indexOf('{', match.index + match[0].lastIndexOf('{'));
  const close = findMatchingBrace(text, open);
  const headerTail = match[3] || '';
  const extendsMatch = headerTail.match(/\bextends\s+([^\{]+?)(?=\bimplements\b|$)/);
  const implementsMatch = headerTail.match(/\bimplements\s+([^\{]+)$/);
  const annotations = annotationBlockBefore(text, match.index);
  return {
    packageName: packageMatch?.[1] || '',
    kind: match[1],
    name: match[2],
    fullName: packageMatch?.[1] ? `${packageMatch[1]}.${match[2]}` : match[2],
    file: file.relative,
    module: file.module,
    line: lineNumberAt(text, match.index),
    start: match.index,
    open,
    end: close >= 0 ? close : text.length - 1,
    annotations,
    extendsTypes: extendsMatch ? extendsMatch[1].split(',').map(simpleType).filter(Boolean) : [],
    implementsTypes: implementsMatch ? implementsMatch[1].split(',').map(simpleType).filter(Boolean) : [],
    imports: [...text.matchAll(/\bimport\s+(?:static\s+)?([A-Za-z_$][\w$.*]*)\s*;/g)].map((m) => m[1]),
    fieldTypes: {},
    fields: [],
    methods: [],
  };
}

function extractMethods(file, classInfo) {
  const methods = [];
  const text = file.text;
  const regex = /\b(public|protected|private)\s+(?:static\s+)?(?:final\s+)?(?:synchronized\s+)?(?:<[^>{}]+>\s*)?([A-Za-z_$][\w$<>?,.\[\] @]*(?:\s+[A-Za-z_$][\w$<>?,.\[\] @]*)*)\s+([A-Za-z_$][\w$]*)\s*\(([^;{}]*)\)\s*(?:throws\s+[^\{]+)?\{/g;
  let match;
  while ((match = regex.exec(text))) {
    const name = match[3];
    if (JAVA_CONTROL_NAMES.has(name) || name === classInfo.name) continue;
    const open = text.indexOf('{', match.index + match[0].lastIndexOf('{'));
    const close = findMatchingBrace(text, open);
    if (close < 0 || open < classInfo.open || close > classInfo.end) continue;
    const body = text.slice(open + 1, close);
    const annotations = annotationBlockBefore(text, match.index);
    methods.push({
      id: stableId('jmethod', file.relative, classInfo.name, name, match.index),
      className: classInfo.name,
      classFullName: classInfo.fullName,
      name,
      returnType: simpleType(match[2]),
      parameters: match[4].trim(),
      annotations,
      file: file.relative,
      module: file.module,
      line: lineNumberAt(text, match.index),
      start: match.index,
      bodyStart: open + 1,
      end: close,
      calls: extractJavaCalls(body),
      _body: body,
    });
  }
  return methods;
}

function positionInsideMethods(index, methods) {
  return methods.some((method) => index >= method.start && index <= method.end);
}

function extractFields(file, classInfo, methods) {
  const fields = [];
  const text = file.text;
  const regex = /\b(private|protected|public)\s+(?:static\s+)?(?:final\s+)?([A-Za-z_$][\w$<>?,.\[\] ]*)\s+([A-Za-z_$][\w$]*)\s*(?:=[^;]*)?;/g;
  let match;
  while ((match = regex.exec(text))) {
    if (match.index < classInfo.open || match.index > classInfo.end || positionInsideMethods(match.index, methods)) continue;
    const annotations = annotationBlockBefore(text, match.index, 1000);
    const columnContent = annotationContent(annotations, 'Column');
    const columnName = columnContent?.match(/\bname\s*=\s*"([^"]+)"/i)?.[1] || match[3];
    const length = Number(columnContent?.match(/\blength\s*=\s*(\d+)/i)?.[1] || 0) || null;
    const field = {
      name: match[3],
      type: simpleType(match[2]),
      column: columnName,
      length,
      annotations,
      line: lineNumberAt(text, match.index),
      source: { file: file.relative, line: lineNumberAt(text, match.index), excerpt: excerptAt(text, match.index) },
    };
    fields.push(field);
  }
  return fields;
}

function extractEntity(classInfo, file) {
  const imports = classInfo.imports.join(' ');
  const tableContent = annotationContent(classInfo.annotations, 'Table');
  const mongoDocument = /data\.mongodb/i.test(imports) && hasAnnotation(classInfo.annotations, 'Document');
  const elasticDocument = /data\.elasticsearch/i.test(imports) && hasAnnotation(classInfo.annotations, 'Document');
  const isEntity = hasAnnotation(classInfo.annotations, 'Entity') || tableContent !== null;
  if (!isEntity && !mongoDocument && !elasticDocument) return null;

  if (isEntity) {
    const tableName = tableContent?.match(/\bname\s*=\s*"([^"]+)"/i)?.[1] || classInfo.name;
    const schema = tableContent?.match(/\bschema\s*=\s*"([^"]+)"/i)?.[1] || '';
    return {
      className: classInfo.name,
      classFullName: classInfo.fullName,
      engine: 'relational-unknown',
      kind: 'table',
      name: tableName,
      schema,
      fullName: schema ? `${schema}.${tableName}` : tableName,
      fields: classInfo.fields,
      file: file.relative,
      module: file.module,
      line: classInfo.line,
      source: { file: file.relative, line: classInfo.line, excerpt: excerptAt(file.text, classInfo.start) },
    };
  }
  const documentContent = annotationContent(classInfo.annotations, 'Document') || '';
  if (mongoDocument) {
    const collection = documentContent.match(/\b(?:collection|value)\s*=\s*"([^"]+)"/i)?.[1] || classInfo.name;
    return {
      className: classInfo.name,
      classFullName: classInfo.fullName,
      engine: 'mongodb',
      kind: 'collection',
      name: collection,
      schema: '',
      fullName: collection,
      fields: classInfo.fields,
      file: file.relative,
      module: file.module,
      line: classInfo.line,
      source: { file: file.relative, line: classInfo.line, excerpt: excerptAt(file.text, classInfo.start) },
    };
  }
  const indexName = documentContent.match(/\bindexName\s*=\s*"([^"]+)"/i)?.[1] || classInfo.name.toLowerCase();
  return {
    className: classInfo.name,
    classFullName: classInfo.fullName,
    engine: 'elasticsearch',
    kind: 'index',
    name: indexName,
    schema: '',
    fullName: indexName,
    fields: classInfo.fields,
    file: file.relative,
    module: file.module,
    line: classInfo.line,
    source: { file: file.relative, line: classInfo.line, excerpt: excerptAt(file.text, classInfo.start) },
  };
}

function extractSpringEndpoints(classInfo, file) {
  const endpoints = [];
  const isController = hasAnnotation(classInfo.annotations, 'RestController') || hasAnnotation(classInfo.annotations, 'Controller');
  const classPaths = mappingPaths(classInfo.annotations, 'RequestMapping');
  for (const method of classInfo.methods) {
    const mappings = [
      ['GetMapping', ['GET']],
      ['PostMapping', ['POST']],
      ['PutMapping', ['PUT']],
      ['PatchMapping', ['PATCH']],
      ['DeleteMapping', ['DELETE']],
      ['RequestMapping', []],
    ];
    for (const [annotationName, fixedMethods] of mappings) {
      if (!hasAnnotation(method.annotations, annotationName)) continue;
      if (!isController && annotationName !== 'RequestMapping') continue;
      const paths = mappingPaths(method.annotations, annotationName);
      let httpMethods = fixedMethods;
      if (annotationName === 'RequestMapping') {
        const content = annotationContent(method.annotations, annotationName) || '';
        httpMethods = [...content.matchAll(/RequestMethod\.(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)/gi)].map((m) => m[1].toUpperCase());
        if (!httpMethods.length) httpMethods = ['ANY'];
      }
      for (const route of combineRoutePaths(classPaths, paths)) {
        for (const httpMethod of httpMethods) {
          endpoints.push({
            id: stableId('endpoint', 'spring', httpMethod, route, file.relative, method.name),
            framework: 'spring',
            method: httpMethod,
            path: route,
            className: classInfo.name,
            classFullName: classInfo.fullName,
            handler: method.name,
            module: file.module,
            file: file.relative,
            line: method.line,
            source: { file: file.relative, line: method.line, excerpt: excerptAt(file.text, method.start) },
            callChain: [],
            databaseObjectIds: [],
            unresolvedCalls: [],
          });
        }
      }
    }
  }
  return endpoints;
}

function extractVertxEndpoints(classInfo, file) {
  const endpoints = [];
  const seen = new Set();
  const text = file.text;

  function addEndpoint(httpMethod, routePath, handler, index, confidence = 'high') {
    const method = String(httpMethod).toUpperCase();
    const normalizedPath = normalizeEndpointPath(routePath);
    const key = `${method}|${normalizedPath}|${handler}|${index}`;
    if (seen.has(key)) return;
    seen.add(key);
    endpoints.push({
      id: stableId('endpoint', 'vertx', method, normalizedPath, file.relative, handler),
      framework: 'vertx', method, path: normalizedPath,
      className: classInfo.name, classFullName: classInfo.fullName, handler, module: file.module,
      file: file.relative, line: lineNumberAt(text, index),
      source: { file: file.relative, line: lineNumberAt(text, index), excerpt: excerptAt(text, index) },
      callChain: [], databaseObjectIds: [], unresolvedCalls: [], confidence,
    });
  }

  const routeForms = [
    {
      // router.get("/path").handler(this::handle)
      regex: /\b[A-Za-z_$][\w$]*\s*\.\s*(get|post|put|patch|delete|head|options)\s*\(\s*"([^"]+)"\s*\)\s*(?:\.[A-Za-z_$][\w$]*\s*\([^)]*\)\s*)*\.handler\s*\(\s*(?:this|[A-Za-z_$][\w$]*)\s*::\s*([A-Za-z_$][\w$]*)/gi,
      method: (m) => m[1], path: (m) => m[2], handler: (m) => m[3], confidence: 'high',
    },
    {
      // router.get("/path").handler(ctx -> handle(ctx))
      regex: /\b[A-Za-z_$][\w$]*\s*\.\s*(get|post|put|patch|delete|head|options)\s*\(\s*"([^"]+)"\s*\)\s*(?:\.[A-Za-z_$][\w$]*\s*\([^)]*\)\s*)*\.handler\s*\(\s*[A-Za-z_$][\w$]*\s*->\s*([A-Za-z_$][\w$]*)\s*\(/gi,
      method: (m) => m[1], path: (m) => m[2], handler: (m) => m[3], confidence: 'high',
    },
    {
      // router.route(HttpMethod.GET, "/path").handler(this::handle)
      regex: /\b[A-Za-z_$][\w$]*\s*\.\s*route\s*\(\s*HttpMethod\.(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s*,\s*"([^"]+)"\s*\)\s*(?:\.[A-Za-z_$][\w$]*\s*\([^)]*\)\s*)*\.handler\s*\(\s*(?:this|[A-Za-z_$][\w$]*)\s*::\s*([A-Za-z_$][\w$]*)/gi,
      method: (m) => m[1], path: (m) => m[2], handler: (m) => m[3], confidence: 'high',
    },
    {
      // router.route(HttpMethod.GET, "/path").handler(ctx -> handle(ctx))
      regex: /\b[A-Za-z_$][\w$]*\s*\.\s*route\s*\(\s*HttpMethod\.(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s*,\s*"([^"]+)"\s*\)\s*(?:\.[A-Za-z_$][\w$]*\s*\([^)]*\)\s*)*\.handler\s*\(\s*[A-Za-z_$][\w$]*\s*->\s*([A-Za-z_$][\w$]*)\s*\(/gi,
      method: (m) => m[1], path: (m) => m[2], handler: (m) => m[3], confidence: 'high',
    },
    {
      // router.route("/path").method(HttpMethod.GET).handler(this::handle)
      regex: /\b[A-Za-z_$][\w$]*\s*\.\s*route\s*\(\s*"([^"]+)"\s*\)\s*\.\s*method\s*\(\s*HttpMethod\.(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s*\)\s*(?:\.[A-Za-z_$][\w$]*\s*\([^)]*\)\s*)*\.handler\s*\(\s*(?:this|[A-Za-z_$][\w$]*)\s*::\s*([A-Za-z_$][\w$]*)/gi,
      method: (m) => m[2], path: (m) => m[1], handler: (m) => m[3], confidence: 'high',
    },
    {
      // router.route("/path").method(HttpMethod.GET).handler(ctx -> handle(ctx))
      regex: /\b[A-Za-z_$][\w$]*\s*\.\s*route\s*\(\s*"([^"]+)"\s*\)\s*\.\s*method\s*\(\s*HttpMethod\.(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s*\)\s*(?:\.[A-Za-z_$][\w$]*\s*\([^)]*\)\s*)*\.handler\s*\(\s*[A-Za-z_$][\w$]*\s*->\s*([A-Za-z_$][\w$]*)\s*\(/gi,
      method: (m) => m[2], path: (m) => m[1], handler: (m) => m[3], confidence: 'high',
    },
  ];

  for (const form of routeForms) {
    let match;
    while ((match = form.regex.exec(text))) addEndpoint(form.method(match), form.path(match), form.handler(match), match.index, form.confidence);
  }
  return endpoints;
}

function extractJavaSqlObjects(classInfo, file) {
  const objects = [];
  for (const method of classInfo.methods) {
    const queryContent = annotationContent(method.annotations, 'Query');
    if (queryContent !== null) {
      const sql = extractJavaStrings(queryContent).join(' ');
      if (/\b(select|insert|update|delete|merge|from|join)\b/i.test(sql)) {
        objects.push(...extractSqlObjects(sql, {
          file: file.relative, module: file.module, sourceText: file.text, baseIndex: method.start,
          owner: `${classInfo.name}#${method.name}`, ownerClass: classInfo.name, ownerMethod: method.name,
          via: '@Query', confidence: 'high',
        }));
      }
    }
    const body = method._body;
    const clientRegex = /\b(?:jdbcTemplate|namedParameterJdbcTemplate|entityManager|sqlClient|pool|connection|client)\s*\.\s*(?:query|queryForObject|queryForList|update|execute|preparedQuery|createNativeQuery)\s*\(\s*((?:"(?:\\.|[^"\\])*"\s*\+?\s*)+)/gi;
    let match;
    while ((match = clientRegex.exec(body))) {
      const sql = extractJavaStrings(match[1]).join(' ');
      if (!sql) continue;
      objects.push(...extractSqlObjects(sql, {
        file: file.relative, module: file.module, sourceText: file.text, baseIndex: method.bodyStart + match.index,
        owner: `${classInfo.name}#${method.name}`, ownerClass: classInfo.name, ownerMethod: method.name,
        via: 'java-sql-client', confidence: 'high',
      }));
    }
  }
  return objects;
}

function makeNonSqlObject(engine, kind, name, classInfo, method, file, index, operation, via, columns = []) {
  return {
    id: stableId('dbobj', engine, kind, name, file.relative, method?.name || classInfo.name, index),
    engine, kind, schema: '', name, fullName: name, operations: [operation], columns: unique(columns), module: file.module,
    owner: method ? `${classInfo.name}#${method.name}` : classInfo.name,
    ownerClass: classInfo.name, ownerMethod: method?.name || '', via,
    source: { file: file.relative, line: lineNumberAt(file.text, index), excerpt: excerptAt(file.text, index) },
    confidence: 'high',
  };
}

function extractNoSqlObjects(classInfo, file, entity) {
  const objects = [];
  if (entity && ['mongodb', 'elasticsearch'].includes(entity.engine)) {
    objects.push({
      id: stableId('dbobj', entity.engine, entity.kind, entity.fullName, file.relative, 'mapping'),
      engine: entity.engine, kind: entity.kind, schema: entity.schema, name: entity.name, fullName: entity.fullName,
      operations: ['MAPPED'], columns: entity.fields.map((field) => field.column), module: file.module,
      owner: classInfo.name, ownerClass: classInfo.name, ownerMethod: '', via: 'document-mapping', source: entity.source,
      confidence: 'medium', mappingOnly: true,
    });
  }
  for (const method of classInfo.methods) {
    const body = method._body;
    let match;
    const mongoRegex = /\b(?:mongoClient|mongoTemplate|reactiveMongoTemplate)\s*\.\s*(find|findOne|save|insert|updateCollection|updateMulti|remove|removeDocuments|count)\s*\(\s*"([^"]+)"/gi;
    while ((match = mongoRegex.exec(body))) {
      const operation = /find|count/i.test(match[1]) ? 'SELECT' : /remove/i.test(match[1]) ? 'DELETE' : /update/i.test(match[1]) ? 'UPDATE' : 'INSERT_OR_UPDATE';
      objects.push(makeNonSqlObject('mongodb', 'collection', match[2], classInfo, method, file, method.bodyStart + match.index, operation, 'mongo-client'));
    }
    const redisRegex = /\b(?:redisTemplate|stringRedisTemplate|reactiveRedisTemplate|redisAPI|redisClient)[\s\S]{0,100}?\.(get|set|put|delete|remove|expire|hget|hset)\s*\(\s*"([^"]+)"/gi;
    while ((match = redisRegex.exec(body))) {
      const operation = /get|hget/i.test(match[1]) ? 'READ' : /delete|remove/i.test(match[1]) ? 'DELETE' : 'WRITE';
      objects.push(makeNonSqlObject('redis', 'key-pattern', match[2], classInfo, method, file, method.bodyStart + match.index, operation, 'redis-client'));
    }
    const indexRegex = /\b(?:elasticsearchOperations|elasticClient|openSearchClient|elasticsearchClient)\s*\.[\s\S]{0,120}?index\s*\(\s*"([^"]+)"/gi;
    while ((match = indexRegex.exec(body))) objects.push(makeNonSqlObject('elasticsearch', 'index', match[1], classInfo, method, file, method.bodyStart + match.index, 'ACCESS', 'elasticsearch-client'));

    for (const annotationName of ['Cacheable', 'CachePut', 'CacheEvict']) {
      const content = annotationContent(method.annotations, annotationName);
      if (content === null) continue;
      const names = annotationStrings(content);
      for (const name of names.slice(0, 2)) {
        objects.push(makeNonSqlObject('redis', 'cache', name, classInfo, method, file, method.start, annotationName === 'Cacheable' ? 'READ' : annotationName === 'CacheEvict' ? 'DELETE' : 'WRITE', `@${annotationName}`));
      }
    }
  }
  return objects;
}

function parseRepository(classInfo) {
  const headerTypes = [...classInfo.extendsTypes, ...classInfo.implementsTypes];
  const headerText = classInfo.extendsTypes.join(' ');
  const fullHeader = classInfo.annotations + ' ' + headerText;
  const sourceText = classInfo._sourceText || '';
  const classHeader = sourceText.slice(classInfo.start, Math.min(classInfo.open + 1, classInfo.start + 1500));
  const repoMatch = classHeader.match(/\b(?:JpaRepository|CrudRepository|PagingAndSortingRepository|MongoRepository|ReactiveMongoRepository|ElasticsearchRepository|ReactiveElasticsearchRepository)\s*<\s*([A-Za-z_$][\w$]*)/);
  if (!repoMatch) return null;
  let engine = 'relational-unknown';
  if (/MongoRepository/i.test(classHeader)) engine = 'mongodb';
  if (/ElasticsearchRepository/i.test(classHeader)) engine = 'elasticsearch';
  return { className: classInfo.name, entityClass: repoMatch[1], engine, types: headerTypes };
}

function parseMapperXml(files) {
  const objects = [];
  const mapperMethods = [];
  for (const file of files) {
    if (file.kind !== 'xml' || !/<mapper\b/i.test(file.text)) continue;
    const namespace = file.text.match(/<mapper\b[^>]*\bnamespace\s*=\s*"([^"]+)"/i)?.[1] || '';
    const className = namespace.split('.').pop() || path.basename(file.relative, '.xml');
    const regex = /<(select|insert|update|delete)\b([^>]*)>([\s\S]*?)<\/\1>/gi;
    let match;
    while ((match = regex.exec(file.text))) {
      const id = match[2].match(/\bid\s*=\s*"([^"]+)"/i)?.[1];
      if (!id) continue;
      const sql = match[3].replace(/<[^>]+>/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
      const extracted = extractSqlObjects(sql, {
        file: file.relative, module: file.module, sourceText: file.text, baseIndex: match.index,
        owner: `${className}#${id}`, ownerClass: className, ownerMethod: id,
        via: 'mybatis-xml', confidence: 'high',
      });
      objects.push(...extracted);
      mapperMethods.push({ className, classFullName: namespace, method: id, file: file.relative, line: lineNumberAt(file.text, match.index), objectIds: extracted.map((object) => object.id) });
    }
  }
  return { objects, mapperMethods };
}

function inferRepositoryOperation(methodName) {
  if (/^(find|get|read|query|search|count|exists|load)/i.test(methodName)) return 'SELECT';
  if (/^(delete|remove)/i.test(methodName)) return 'DELETE';
  if (/^(save|insert|add|create)/i.test(methodName)) return 'INSERT_OR_UPDATE';
  if (/^(update|patch|modify)/i.test(methodName)) return 'UPDATE';
  return 'ACCESS';
}

function makeRepositoryEntityObject(repository, methodName, entity, callSource) {
  return {
    id: stableId('dbobj', repository.className, methodName, entity.fullName, callSource.file, callSource.line),
    engine: entity.engine === 'relational-unknown' ? repository.engine : entity.engine,
    kind: entity.kind,
    schema: entity.schema,
    name: entity.name,
    fullName: entity.fullName,
    operations: [inferRepositoryOperation(methodName)],
    columns: entity.fields.map((field) => field.column),
    module: entity.module,
    owner: `${repository.className}#${methodName}`,
    ownerClass: repository.className,
    ownerMethod: methodName,
    via: 'spring-data-repository',
    source: callSource,
    confidence: 'high',
  };
}

function resolveClassByType(type, classesByName, implementations) {
  if (!type) return null;
  if (classesByName.has(type)) {
    const direct = classesByName.get(type);
    if (direct.methods?.length) return direct;
  }
  const impls = implementations.get(type) || [];
  if (impls.length === 1) return impls[0];
  return classesByName.get(type) || null;
}

function linkBackendFlows(result, config) {
  const classesByName = new Map(result.classes.map((classInfo) => [classInfo.name, classInfo]));
  const methodsByKey = new Map();
  for (const method of result.methods) methodsByKey.set(`${method.className}#${method.name}`, method);
  const implementations = new Map();
  for (const classInfo of result.classes) {
    for (const type of classInfo.implementsTypes) {
      if (!implementations.has(type)) implementations.set(type, []);
      implementations.get(type).push(classInfo);
    }
  }
  const repositoryByClass = new Map(result.repositories.map((repo) => [repo.className, repo]));
  const entityByClass = new Map(result.entities.map((entity) => [entity.className, entity]));
  const dbByOwner = new Map();
  for (const object of result.databaseObjects) {
    const key = `${object.ownerClass || ''}#${object.ownerMethod || ''}`;
    if (!dbByOwner.has(key)) dbByOwner.set(key, []);
    dbByOwner.get(key).push(object);
  }
  const mapperObjectByOwner = dbByOwner;
  const maxDepth = Number(config.analysis.maxCallDepth || 10);
  const maxNodes = Number(config.analysis.maxFlowNodes || 250);

  for (const endpoint of result.endpoints) {
    const queue = [{ className: endpoint.className, methodName: endpoint.handler, depth: 0, parent: endpoint.id, source: endpoint.source }];
    const visited = new Set();
    const chain = [];
    const objectMap = new Map();
    const unresolved = [];
    while (queue.length && visited.size < maxNodes) {
      const current = queue.shift();
      if (current.depth > maxDepth) continue;
      const key = `${current.className}#${current.methodName}`;
      if (visited.has(key)) continue;
      visited.add(key);
      const method = methodsByKey.get(key);
      if (!method) {
        const terminalObjects = mapperObjectByOwner.get(key) || [];
        for (const object of terminalObjects) objectMap.set(object.id, object);
        if (!terminalObjects.length) unresolved.push({ target: key, from: current.parent, reason: 'method-not-found' });
        continue;
      }
      chain.push({ from: current.parent, to: key, depth: current.depth, source: { file: method.file, line: method.line } });
      for (const object of dbByOwner.get(key) || []) objectMap.set(object.id, object);
      const ownerClass = classesByName.get(method.className);
      for (const call of method.calls) {
        let targetClassName = method.className;
        if (call.receiver && call.receiver !== 'this') {
          targetClassName = ownerClass?.fieldTypes?.[call.receiver] || (classesByName.has(call.receiver) ? call.receiver : '');
        }
        if (!targetClassName) {
          unresolved.push({ target: call.name, from: key, reason: 'receiver-type-unresolved' });
          continue;
        }
        const repository = repositoryByClass.get(targetClassName);
        if (repository) {
          for (const object of dbByOwner.get(`${targetClassName}#${call.method}`) || []) objectMap.set(object.id, object);
          const entity = entityByClass.get(repository.entityClass);
          if (entity) {
            const callSource = { file: method.file, line: lineNumberAt(method._body, call.index) + method.line, excerpt: `${call.receiver}.${call.method}(...)` };
            const object = makeRepositoryEntityObject(repository, call.method, entity, callSource);
            objectMap.set(object.id, object);
          }
          chain.push({ from: key, to: `${targetClassName}#${call.method}`, depth: current.depth + 1, terminal: 'repository' });
          continue;
        }
        const targetClass = resolveClassByType(targetClassName, classesByName, implementations);
        const resolvedClassName = targetClass?.name || targetClassName;
        const targetKey = `${resolvedClassName}#${call.method}`;
        if (methodsByKey.has(targetKey) || (dbByOwner.get(targetKey) || []).length) {
          queue.push({ className: resolvedClassName, methodName: call.method, depth: current.depth + 1, parent: key, source: method.source });
        } else {
          unresolved.push({ target: targetKey, from: key, reason: 'target-method-not-indexed' });
        }
      }
    }
    endpoint.callChain = chain;
    endpoint.databaseObjects = [...objectMap.values()];
    endpoint.databaseObjectIds = [...objectMap.keys()];
    endpoint.unresolvedCalls = unresolved.slice(0, 100);
  }

  const usedObjects = [];
  const seen = new Set(result.databaseObjects.map((object) => object.id));
  usedObjects.push(...result.databaseObjects);
  for (const endpoint of result.endpoints) {
    for (const object of endpoint.databaseObjects || []) {
      if (!seen.has(object.id)) {
        seen.add(object.id);
        usedObjects.push(object);
      }
    }
  }
  result.databaseObjects = mergeDatabaseObjects(usedObjects);
}

function analyzeJava(files, config) {
  const result = {
    classes: [], methods: [], endpoints: [], entities: [], repositories: [], databaseObjects: [], warnings: [],
  };
  const javaFiles = files.filter((file) => file.extension === '.java');
  for (const file of javaFiles) {
    const classInfo = parseClass(file);
    if (!classInfo) continue;
    classInfo._sourceText = file.text;
    classInfo.methods = extractMethods(file, classInfo);
    classInfo.fields = extractFields(file, classInfo, classInfo.methods);
    for (const field of classInfo.fields) classInfo.fieldTypes[field.name] = field.type;
    result.classes.push(classInfo);
    result.methods.push(...classInfo.methods);
    const entity = extractEntity(classInfo, file);
    if (entity) result.entities.push(entity);
    const repository = parseRepository(classInfo);
    if (repository) result.repositories.push(repository);
    result.endpoints.push(...extractSpringEndpoints(classInfo, file));
    result.endpoints.push(...extractVertxEndpoints(classInfo, file));
    result.databaseObjects.push(...extractJavaSqlObjects(classInfo, file));
    result.databaseObjects.push(...extractNoSqlObjects(classInfo, file, entity));
  }

  const mapper = parseMapperXml(files);
  result.databaseObjects.push(...mapper.objects);
  result.mapperMethods = mapper.mapperMethods;
  result.databaseObjects = mergeDatabaseObjects(result.databaseObjects);
  linkBackendFlows(result, config);

  const kotlinFiles = files.filter((file) => file.extension === '.kt');
  if (kotlinFiles.length) result.warnings.push({ type: 'kotlin-limited', count: kotlinFiles.length, message: 'Kotlin 파일은 일반 문자열·설정 탐지만 수행하며 Java 수준의 호출 그래프는 생성하지 않음' });
  return result;
}

module.exports = {
  analyzeJava,
  parseClass,
  extractMethods,
  extractSpringEndpoints,
  extractVertxEndpoints,
  linkBackendFlows,
  annotationContent,
  hasAnnotation,
};
