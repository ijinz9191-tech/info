'use strict';

const path = require('path');
const { lineNumberAt, excerptAt, redactSecret, unique, stableId, normalizeSlashes, cleanQuoted } = require('../core/text');

function profileFromFile(relative) {
  const base = path.basename(relative).toLowerCase();
  let match = base.match(/^application[-.]([^.]+)\.(?:ya?ml|properties)$/);
  if (match) return match[1];
  match = base.match(/^\.env\.([^.]+)$/);
  if (match) return match[1];
  return 'default';
}

function normalizeConfigScalar(value) {
  return cleanQuoted(String(value ?? '').trim());
}

function normalizeHostToken(value) {
  let token = normalizeConfigScalar(value).trim();
  token = token.replace(/^[,;]+|[,;]+$/g, '');
  if (!token) return '';
  if (token.includes('@')) token = token.slice(token.lastIndexOf('@') + 1);
  if (/^\$\{[^}]+\}(?::(?:\d{2,5}|\$\{[^}]+\}))?$/.test(token)) return token;
  if (/^\[[0-9a-f:]+\](?::(?:\d{2,5}|\$\{[^}]+\}))?$/i.test(token)) return token;
  if (!/^[A-Za-z0-9_.-]+(?::(?:\d{2,5}|\$\{[^}]+\}))?$/.test(token)) return '';
  if (/^(jdbc|oracle|thin|mongodb|redis|http|https|tcp|ssl|srv)$/i.test(token)) return '';
  if (/^\d+$/.test(token)) return '';
  return token;
}

function parseHostPortTokens(value) {
  const text = normalizeConfigScalar(value);
  if (!text) return [];
  const exactPlaceholder = normalizeHostToken(text);
  if (/^\$\{[^}]+\}(?::(?:\d{2,5}|\$\{[^}]+\}))?$/.test(text) && exactPlaceholder) return [exactPlaceholder];

  const hosts = [];
  const authorityRegex = /(?:jdbc:)?[a-z][a-z0-9+.-]*:\/\/([^/\s?#;]+)/gi;
  let authorityMatch;
  while ((authorityMatch = authorityRegex.exec(text))) {
    const authority = authorityMatch[1].replace(/^[^@]+@/, '');
    for (const part of authority.split(',')) {
      const host = normalizeHostToken(part);
      if (host) hosts.push(host);
    }
  }
  if (hosts.length) return unique(hosts);

  let plain = text;
  if (plain.startsWith('[') && plain.endsWith(']') && plain.includes(',')) plain = plain.slice(1, -1);
  for (const part of plain.split(/\s*[,;]\s*|\s+/)) {
    const host = normalizeHostToken(part);
    if (host) hosts.push(host);
  }
  return unique(hosts);
}

function parseOracleJdbc(value) {
  const text = String(value || '');
  const hosts = [];
  let database = '';
  let match = text.match(/jdbc:oracle:thin:@\/\/([^/]+)\/([^?;\s]+)/i);
  if (match) {
    hosts.push(...match[1].split(',').map((v) => v.trim()).filter(Boolean));
    database = match[2];
    return { hosts: unique(hosts), database };
  }
  match = text.match(/jdbc:oracle:thin:@(?:\([^)]*HOST\s*=\s*([^)]+)[^)]*PORT\s*=\s*([^)]+)[\s\S]*?SERVICE_NAME\s*=\s*([^)]+))/i);
  if (match) {
    hosts.push(`${match[1].trim()}:${match[2].trim()}`);
    database = match[3].trim();
    return { hosts: unique(hosts), database };
  }
  match = text.match(/jdbc:oracle:thin:@([^:()\s]+):(\d+):([^?;\s]+)/i);
  if (match) {
    hosts.push(`${match[1]}:${match[2]}`);
    database = match[3];
  }
  return { hosts: unique(hosts), database };
}

function parseMongoUri(value) {
  const text = String(value || '');
  const sanitized = text.replace(/mongodb(?:\+srv)?:\/\/[^/@\s]+@/i, (segment) => segment.replace(/\/\/.*@/, '//'));
  const match = sanitized.match(/mongodb(?:\+srv)?:\/\/([^/?\s]+)(?:\/([^?\s]+))?/i);
  if (!match) return { hosts: parseHostPortTokens(text), database: '' };
  return { hosts: unique(match[1].split(',').map((v) => v.trim()).filter(Boolean)), database: match[2] || '' };
}

function classifyConnection(key, value) {
  const joined = `${key} ${value}`.toLowerCase();
  if (joined.includes('jdbc:oracle') || /oracle/.test(key)) return 'oracle';
  if (joined.includes('jdbc:postgresql') || /postgres|postgresql/.test(key)) return 'postgresql';
  if (joined.includes('jdbc:mysql') || /mysql/.test(key)) return 'mysql';
  if (joined.includes('jdbc:mariadb') || /mariadb/.test(key)) return 'mariadb';
  if (joined.includes('jdbc:sqlserver') || /sqlserver|mssql/.test(key)) return 'sqlserver';
  if (joined.includes('mongodb://') || joined.includes('mongodb+srv://') || /mongo/.test(key)) return 'mongodb';
  if (joined.includes('redis://') || /redis/.test(key)) return 'redis';
  if (/opensearch/.test(joined)) return 'opensearch';
  if (/elasticsearch|elastic\.uris|spring\.elastic/.test(joined)) return 'elasticsearch';
  if (/bootstrap.?servers|kafka/.test(key)) return 'kafka';
  if (/prometheus/.test(joined)) return 'prometheus';
  if (/loki/.test(joined)) return 'loki';
  if (/grafana/.test(joined)) return 'grafana';
  if (/jdbc:/.test(joined) || /(?:^|[._-])(?:datasource|r2dbc)(?:[._-]|$)/.test(key.toLowerCase())) return 'relational-unknown';
  return '';
}

function parseConnectionDetails(engine, value) {
  const text = String(value || '');
  if (engine === 'oracle') return parseOracleJdbc(text);
  if (engine === 'mongodb') return parseMongoUri(text);
  const hosts = parseHostPortTokens(text);
  let database = '';
  const dbMatch = text.match(/(?:jdbc:[a-z0-9]+:|[a-z][a-z0-9+.-]*:\/\/)[^/\s]+\/([^?;\s]+)/i);
  if (dbMatch) database = dbMatch[1];
  return { hosts, database };
}

function isCredentialKey(key) {
  return /(?:^|[._-])(?:password|passwd|pwd|secret|token|api[._-]?key|credential|credentials|username|user)$/i.test(String(key || ''));
}

function safeConfigValue(key, value, redact) {
  if (isCredentialKey(key)) return '***';
  const normalized = normalizeConfigScalar(value);
  return redact ? redactSecret(normalized) : normalized;
}

function connectionRole(key, value) {
  const lower = String(key || '').toLowerCase();
  const normalized = normalizeConfigScalar(value);
  if (isCredentialKey(lower)) return 'credential';
  if (/(?:^|[._-])ports?$/.test(lower)) return 'port';
  if (/(?:^|[._-])(?:database|db|service[._-]?name|sid)$/.test(lower)) return 'database';
  if (/(?:^|[._-])(?:host|hostname)$/.test(lower)) return 'host';
  if (/(?:^|[._-])(?:jdbc[._-]?url|url|uri|uris|hosts|nodes|addresses|endpoints|bootstrap[._-]?servers|contact[._-]?points)$/.test(lower)) return 'endpoint';
  if (/(?:jdbc:[a-z0-9]+:|[a-z][a-z0-9+.-]*:\/\/)/i.test(normalized)) return 'endpoint';
  return 'other';
}

function connectionPrefix(key) {
  const text = String(key || '');
  const suffix = /(?:[._-](?:bootstrap[._-]?servers|contact[._-]?points|service[._-]?name|jdbc[._-]?url|hostname|database|addresses|endpoints|uris|hosts|nodes|host|ports?|url|uri|db|sid))$/i;
  const stripped = text.replace(suffix, '');
  return stripped || text;
}

function normalizePort(value) {
  const port = normalizeConfigScalar(value);
  if (/^(?:\d{2,5}|\$\{[^}]+\})$/.test(port)) return port;
  return '';
}

function hostHasPort(host) {
  const normalized = String(host || '').replace(/\$\{[^}]+\}/g, 'ENV');
  return /^\[[^\]]+\]:(?:\d{2,5}|ENV)$/.test(normalized) || /:(?:\d{2,5}|ENV)$/.test(normalized);
}

function appendPort(host, port) {
  if (!host || !port || hostHasPort(host)) return host;
  return `${host}:${port}`;
}

function connectionPart(entry, file, config) {
  const engine = classifyConnection(entry.key, entry.value);
  if (!engine) return null;
  const role = connectionRole(entry.key, entry.value);
  if (role === 'credential' || role === 'other') return null;
  const value = normalizeConfigScalar(entry.value);
  const safeValue = safeConfigValue(entry.key, value, config.analysis.redactSecrets !== false);
  const details = role === 'endpoint'
    ? parseConnectionDetails(engine, value)
    : role === 'host'
      ? { hosts: parseHostPortTokens(value), database: '' }
      : { hosts: [], database: role === 'database' ? value : '' };
  return {
    engine,
    module: file.module,
    profile: profileFromFile(file.relative),
    prefix: connectionPrefix(entry.key),
    role,
    key: entry.key,
    value: safeValue,
    hosts: details.hosts || [],
    database: details.database || '',
    port: role === 'port' ? normalizePort(value) : '',
    source: { file: file.relative, line: entry.line, excerpt: `${entry.key}=${safeValue}` },
  };
}

function aggregateConnectionParts(parts) {
  const grouped = new Map();
  for (const part of parts) {
    const groupKey = [part.engine, part.module, part.profile, part.prefix].join('|');
    if (!grouped.has(groupKey)) grouped.set(groupKey, []);
    grouped.get(groupKey).push(part);
  }

  const rawConnections = [];
  for (const groupParts of grouped.values()) {
    const first = groupParts[0];
    const ports = unique(groupParts.map((part) => part.port));
    const preferredPort = ports.length === 1 ? ports[0] : '';
    let hosts = unique(groupParts.flatMap((part) => part.hosts || []));
    if (preferredPort) hosts = hosts.map((host) => appendPort(host, preferredPort));
    const databases = unique(groupParts.flatMap((part) => part.database ? [normalizeConfigScalar(part.database)] : []));
    const keys = unique(groupParts.map((part) => part.key));
    const values = unique(groupParts.map((part) => part.value));
    const sourcePart = groupParts.find((part) => part.role === 'endpoint')
      || groupParts.find((part) => part.role === 'host')
      || groupParts.find((part) => part.role === 'database')
      || groupParts[0];
    const groupLabel = hosts.length ? hosts.join(',') : `${first.profile}:${first.prefix}`;
    rawConnections.push({
      id: stableId('conn', first.engine, first.module, first.profile, groupLabel, databases.join(',')),
      engine: first.engine,
      module: first.module,
      profile: first.profile,
      prefix: first.prefix,
      key: keys.join(', '),
      keys,
      value: values.join(', '),
      values,
      hosts,
      database: databases.join(', '),
      databases,
      groupLabel,
      source: sourcePart.source,
      sources: groupParts.map((part) => part.source),
      properties: groupParts.map((part) => ({ key: part.key, role: part.role, value: part.value, source: part.source })),
      confidence: hosts.length ? 'high' : 'medium',
    });
  }

  const deduped = new Map();
  for (const connection of rawConnections) {
    const signature = [
      connection.engine,
      connection.module,
      connection.profile,
      [...connection.hosts].sort().join(','),
      connection.database,
      connection.hosts.length ? '' : connection.prefix,
    ].join('|');
    if (!deduped.has(signature)) {
      deduped.set(signature, connection);
      continue;
    }
    const current = deduped.get(signature);
    current.keys = unique([...current.keys, ...connection.keys]);
    current.values = unique([...current.values, ...connection.values]);
    current.sources = [...current.sources, ...connection.sources];
    current.properties = [...current.properties, ...connection.properties];
    current.key = current.keys.join(', ');
    current.value = current.values.join(', ');
  }
  return [...deduped.values()];
}

function extractKeyValueLines(file) {
  const entries = [];
  const lines = file.text.split(/\r?\n/);
  const yamlStack = [];
  for (let i = 0; i < lines.length; i += 1) {
    const raw = lines[i];
    if (!raw.trim() || raw.trimStart().startsWith('#') || raw.trimStart().startsWith('//')) continue;
    const indent = raw.length - raw.trimStart().length;
    while (yamlStack.length && yamlStack[yamlStack.length - 1].indent >= indent) yamlStack.pop();
    const match = raw.match(/^\s*([A-Za-z0-9_.\-\[\]]+)\s*[:=]\s*(.*?)\s*$/);
    if (!match) continue;
    const keyPart = match[1];
    const value = match[2].replace(/\s+#.*$/, '').trim();
    if (!value && raw.includes(':')) {
      yamlStack.push({ indent, key: keyPart });
      continue;
    }
    const fullKey = [...yamlStack.map((item) => item.key), keyPart].join('.');
    entries.push({ key: fullKey, value, line: i + 1, index: file.text.indexOf(raw) });
  }
  return entries;
}

function findUrlsAndIps(file) {
  const literals = [];
  const patterns = [
    { type: 'url', regex: /\b(?:https?|tcp|ssl|redis|mongodb(?:\+srv)?):\/\/[^\s"'`<>]+/gi },
    { type: 'jdbc', regex: /\bjdbc:[^\s"'`<>]+/gi },
    { type: 'ipv4', regex: /\b(?:25[0-5]|2[0-4]\d|1?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}(?::\d{2,5})?\b/g },
    { type: 'service-dns', regex: /\b[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.svc(?:\.cluster\.local)?(?::\d+)?\b/g },
  ];
  for (const { type, regex } of patterns) {
    let match;
    while ((match = regex.exec(file.text))) {
      literals.push({
        id: stableId('literal', file.relative, type, match.index, match[0]),
        type,
        value: redactSecret(match[0]),
        module: file.module,
        source: { file: file.relative, line: lineNumberAt(file.text, match.index), excerpt: excerptAt(file.text, match.index) },
      });
    }
  }
  return literals;
}

function analyzeConfigurations(files, config) {
  const connectionParts = [];
  const literals = [];
  const propertyEntries = [];
  const relevantKinds = new Set(['config', 'build', 'json', 'javascript', 'jvm']);
  for (const file of files) {
    if (!relevantKinds.has(file.kind)) continue;
    literals.push(...findUrlsAndIps(file));
    if (!['config', 'build', 'json'].includes(file.kind)) continue;
    const entries = extractKeyValueLines(file);
    for (const entry of entries) {
      const safeValue = safeConfigValue(entry.key, entry.value, config.analysis.redactSecrets !== false);
      propertyEntries.push({ ...entry, value: safeValue, file: file.relative, module: file.module });
      const part = connectionPart(entry, file, config);
      if (part) connectionParts.push(part);
    }
  }

  const connections = aggregateConnectionParts(connectionParts);
  const dedupLiterals = [];
  const literalSeen = new Set();
  for (const literal of literals) {
    const key = [literal.type, literal.value, literal.source.file, literal.source.line].join('|');
    if (!literalSeen.has(key)) {
      literalSeen.add(key);
      dedupLiterals.push(literal);
    }
  }

  return {
    connections,
    literals: dedupLiterals,
    properties: propertyEntries,
  };
}

function connectionGroupTitle(connection) {
  const hosts = connection.hosts?.length ? connection.hosts.join(', ') : 'host-unresolved';
  return `${connection.engine} / ${hosts} / ${connection.profile}`;
}

function moduleDistance(objectModule, connectionModule) {
  const a = normalizeSlashes(objectModule || '.');
  const b = normalizeSlashes(connectionModule || '.');
  if (a === b) return 100;
  if (a.startsWith(`${b}/`) || b.startsWith(`${a}/`)) return 60;
  return 0;
}

function compatibleEngine(objectEngine, connectionEngine) {
  if (!objectEngine || objectEngine === 'relational-unknown') {
    return ['oracle', 'postgresql', 'mysql', 'mariadb', 'sqlserver', 'relational-unknown'].includes(connectionEngine);
  }
  if (objectEngine === connectionEngine) return true;
  if (objectEngine === 'elasticsearch' && connectionEngine === 'opensearch') return true;
  if (objectEngine === 'opensearch' && connectionEngine === 'elasticsearch') return true;
  return false;
}

function assignConnectionGroups(objects, connections) {
  return (objects || []).map((object) => {
    const candidates = (connections || [])
      .filter((connection) => compatibleEngine(object.engine, connection.engine))
      .map((connection) => ({ connection, score: moduleDistance(object.module, connection.module) }))
      .filter((item) => item.score > 0)
      .sort((a, b) => b.score - a.score);
    const bestScore = candidates[0]?.score || 0;
    const best = candidates.filter((item) => item.score === bestScore).map((item) => item.connection);
    return {
      ...object,
      connectionGroups: best.map((connection) => ({
        id: connection.id,
        engine: connection.engine,
        hosts: connection.hosts,
        database: connection.database,
        profile: connection.profile,
        title: connectionGroupTitle(connection),
      })),
      connectionResolution: best.length === 1 ? 'resolved' : best.length > 1 ? 'ambiguous' : 'unresolved',
    };
  });
}

module.exports = {
  analyzeConfigurations,
  assignConnectionGroups,
  classifyConnection,
  parseConnectionDetails,
  parseHostPortTokens,
  connectionRole,
  connectionGroupTitle,
};
