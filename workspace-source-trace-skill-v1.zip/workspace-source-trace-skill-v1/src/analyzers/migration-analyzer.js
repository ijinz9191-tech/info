'use strict';

const {
  lineNumberAt,
  excerptAt,
  stableId,
  unique,
  redactSecret,
} = require('../core/text');

function normalizeReplacements(clusterMap) {
  const raw = clusterMap?.replacements || clusterMap?.migration?.replacements || {};
  if (Array.isArray(raw)) {
    const result = {};
    for (const item of raw) {
      if (item && typeof item === 'object' && item.from !== undefined) result[String(item.from)] = String(item.to ?? '');
    }
    return result;
  }
  if (!raw || typeof raw !== 'object') return {};
  return Object.fromEntries(Object.entries(raw).filter(([from]) => from && !from.startsWith('#')).map(([from, to]) => [String(from), String(to ?? '')]));
}

function applyReplacement(value, replacements) {
  const text = String(value ?? '');
  if (Object.prototype.hasOwnProperty.call(replacements, text)) {
    return { matched: true, from: text, to: replacements[text], target: replacements[text], mode: 'exact' };
  }
  const keys = Object.keys(replacements).sort((a, b) => b.length - a.length);
  for (const from of keys) {
    if (from && text.includes(from)) {
      return { matched: true, from, to: replacements[from], target: text.split(from).join(replacements[from]), mode: 'substring' };
    }
  }
  return { matched: false, from: '', to: '', target: '', mode: '' };
}

function verificationFor(category) {
  const map = {
    'database-connection': '애플리케이션 기동 후 연결 풀 생성, 간단 조회, 오류 로그를 확인',
    'message-broker': 'producer/consumer 연결과 테스트 메시지 송수신, consumer lag를 확인',
    'observability-endpoint': '메트릭 수집, 로그 유입, 대시보드 데이터 갱신을 확인',
    'source-url': '신규 주소에서 DNS·TLS·응답 코드와 애플리케이션 기능을 확인',
    'source-ip': '신규 네트워크 경로와 방화벽 정책, 포트 연결을 확인',
    'service-dns': '신규 네임스페이스에서 Service DNS 해석과 포트 연결을 확인',
    'kubernetes-client': '대상 context·namespace에서 list/watch 권한과 실제 리소스 조회를 확인',
    'database-data-column': '변경 전후 대상 행 수, 참조 무결성, 애플리케이션 조회 결과를 비교',
    'database-schema-column': 'DDL 적용 전 영향도·인덱스·제약조건을 검토하고 스테이징에서 마이그레이션 검증',
  };
  return map[category] || '신규 클러스터 배포 후 관련 기능과 로그를 확인';
}

function candidateFromLiteral(literal, replacements) {
  const replacement = applyReplacement(literal.value, replacements);
  let category = 'source-url';
  if (literal.type === 'ipv4') category = 'source-ip';
  if (literal.type === 'service-dns') category = 'service-dns';
  if (literal.type === 'jdbc') category = 'database-connection';
  const currentValue = redactSecret(literal.value);
  return {
    id: stableId('migration', category, literal.source.file, literal.source.line, currentValue),
    scope: 'source',
    category,
    severity: ['database-connection', 'service-dns'].includes(category) ? 'required' : 'review',
    currentValue,
    targetValue: replacement.matched ? redactSecret(replacement.target) : '',
    targetStatus: replacement.matched ? 'mapped' : 'not-specified',
    changeType: 'value-change',
    exactChange: replacement.matched
      ? `현재 값 '${currentValue}'을(를) '${redactSecret(replacement.target)}'(으)로 변경`
      : `현재 값 '${currentValue}'이 신규 클러스터에서도 유효한지 확인하고, 다르면 신규 값으로 변경`,
    reason: '클러스터 이동 시 네트워크 주소·서비스 DNS·접속 URL이 달라질 수 있음',
    verification: verificationFor(category),
    source: literal.source,
    module: literal.module,
    confidence: replacement.matched ? 'high' : 'medium',
    replacement,
  };
}

function candidateFromConnection(connection, replacements) {
  const current = connection.hosts?.length ? connection.hosts.join(',') : connection.value;
  const replacement = applyReplacement(current, replacements);
  const propertyChanges = [];
  for (const property of connection.properties || []) {
    const propertyReplacement = applyReplacement(property.value, replacements);
    if (!propertyReplacement.matched) continue;
    propertyChanges.push({
      key: property.key,
      role: property.role,
      currentValue: redactSecret(property.value),
      targetValue: redactSecret(propertyReplacement.target),
      source: property.source,
      replacement: propertyReplacement,
    });
  }
  let category = 'database-connection';
  if (connection.engine === 'kafka') category = 'message-broker';
  if (['prometheus', 'loki', 'grafana', 'elasticsearch', 'opensearch'].includes(connection.engine)) category = 'observability-endpoint';
  const exactPropertyChange = propertyChanges
    .map((item) => `${item.key}: '${item.currentValue}' → '${item.targetValue}'`)
    .join('; ');
  const source = propertyChanges[0]?.source || connection.source;
  return {
    id: stableId('migration', category, connection.id),
    scope: 'configuration',
    category,
    severity: 'required',
    currentValue: redactSecret(current),
    targetValue: replacement.matched ? redactSecret(replacement.target) : propertyChanges.length === 1 ? propertyChanges[0].targetValue : '',
    targetStatus: replacement.matched || propertyChanges.length ? 'mapped' : 'not-specified',
    changeType: 'connection-change',
    exactChange: exactPropertyChange || (replacement.matched
      ? `${connection.key}의 접속 대상을 '${redactSecret(current)}'에서 '${redactSecret(replacement.target)}'(으)로 변경`
      : `${connection.key}의 ${connection.engine} 접속 대상이 신규 클러스터/망에서 유지되는지 확인하고 필요한 경우 host·port·service/database 값을 변경`),
    reason: `${connection.engine} 연결 설정이 소스에서 확인됨`,
    verification: verificationFor(category),
    source,
    module: connection.module,
    engine: connection.engine,
    connectionGroupId: connection.id,
    propertyChanges,
    confidence: connection.hosts?.length ? 'high' : 'medium',
    replacement,
  };
}

function candidateFromManifest(reference, replacements) {
  const replacement = applyReplacement(reference.value, replacements);
  return {
    id: stableId('migration', reference.category, reference.id),
    scope: 'kubernetes-manifest',
    category: reference.category,
    severity: reference.severity || 'required',
    currentValue: reference.value,
    targetValue: replacement.matched ? replacement.target : '',
    targetStatus: replacement.matched ? 'mapped' : 'not-specified',
    changeType: 'manifest-change',
    exactChange: replacement.matched ? `${reference.key}: '${reference.value}' → '${replacement.target}'` : reference.action,
    reason: `Kubernetes 매니페스트의 ${reference.key} 항목은 클러스터 종속 가능성이 있음`,
    verification: '신규 클러스터에서 dry-run/렌더링 결과를 확인한 뒤 배포하고 리소스 Ready·이벤트·접속 상태를 확인',
    source: reference.source,
    module: reference.module,
    confidence: replacement.matched ? 'high' : 'medium',
    replacement,
  };
}

function extractClusterSensitiveStrings(files, replacements, keywords) {
  const candidates = [];
  const keywordPattern = keywords.map((keyword) => keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
  const assignmentRegex = new RegExp(`\\b([A-Za-z_$][\\w$.-]*(?:${keywordPattern})[A-Za-z0-9_$.-]*)\\s*[:=]\\s*(["'])([^"'\\n]+)\\2`, 'gi');
  const kubeClientRegex = /\b(?:withMasterUrl|masterUrl|setMasterUrl|withNamespace|namespace|currentContext|context|kubeconfig|KUBECONFIG)\s*\(?\s*[:=,]?\s*["']([^"'\n]+)["']/gi;

  for (const file of files) {
    if (!['javascript', 'jvm', 'config', 'build', 'json'].includes(file.kind)) continue;
    let match;
    while ((match = assignmentRegex.exec(file.text))) {
      const key = match[1];
      const value = match[3];
      if (/^(true|false|null|none)$/i.test(value)) continue;
      const replacement = applyReplacement(value, replacements);
      candidates.push({
        id: stableId('migration', 'cluster-sensitive-value', file.relative, match.index, key, value),
        scope: 'source',
        category: 'cluster-sensitive-value',
        key,
        severity: 'review',
        currentValue: redactSecret(value),
        targetValue: replacement.matched ? redactSecret(replacement.target) : '',
        targetStatus: replacement.matched ? 'mapped' : 'not-specified',
        changeType: 'value-change',
        exactChange: replacement.matched ? `${key}: '${redactSecret(value)}' → '${redactSecret(replacement.target)}'` : `${key} 값이 신규 클러스터에서도 동일한지 확인하고 필요 시 변경`,
        reason: `키 이름 '${key}'이 클러스터·네트워크·접속 정보와 관련됨`,
        verification: '해당 값을 사용하는 기능의 기동·조회·호출 결과를 신규 클러스터에서 확인',
        source: { file: file.relative, line: lineNumberAt(file.text, match.index), excerpt: excerptAt(file.text, match.index) },
        module: file.module,
        confidence: replacement.matched ? 'high' : 'medium',
        replacement,
      });
    }
    while ((match = kubeClientRegex.exec(file.text))) {
      const value = match[1];
      const replacement = applyReplacement(value, replacements);
      candidates.push({
        id: stableId('migration', 'kubernetes-client', file.relative, match.index, value),
        scope: 'source',
        category: 'kubernetes-client',
        severity: 'required',
        currentValue: value,
        targetValue: replacement.matched ? replacement.target : '',
        targetStatus: replacement.matched ? 'mapped' : 'not-specified',
        changeType: 'client-configuration-change',
        exactChange: replacement.matched ? `Kubernetes client 대상 '${value}' → '${replacement.target}'` : 'Kubernetes client의 API server/context/namespace 설정을 신규 클러스터 값으로 변경',
        reason: 'Kubernetes client가 클러스터 또는 namespace를 직접 지정함',
        verification: verificationFor('kubernetes-client'),
        source: { file: file.relative, line: lineNumberAt(file.text, match.index), excerpt: excerptAt(file.text, match.index) },
        module: file.module,
        confidence: 'high',
        replacement,
      });
    }
  }
  return candidates;
}

function keywordMatch(name, keywords) {
  const normalized = String(name || '').toLowerCase().replace(/[^a-z0-9]+/g, '_');
  return keywords.some((keyword) => {
    const k = String(keyword).toLowerCase().replace(/[^a-z0-9]+/g, '_');
    return normalized === k || normalized.includes(k);
  });
}

function normalizeIdentifier(value) {
  return String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
}

function uniqueReplacementPairs(pairs) {
  const seen = new Set();
  const result = [];
  for (const pair of pairs || []) {
    if (!pair || pair.length < 2) continue;
    const key = `${pair[0]}\u0000${pair[1]}`;
    if (seen.has(key)) continue;
    seen.add(key);
    result.push(pair);
  }
  return result;
}

function relevantReplacementEntries(field, replacements, sourceCandidates = []) {
  const entries = Object.entries(replacements || {});
  const name = `${field?.name || ''} ${field?.column || ''}`.toLowerCase();
  if (!entries.length) return [];

  const fieldIdentifiers = unique([field?.name, field?.column].map(normalizeIdentifier));
  const evidencePairs = [];
  for (const candidate of sourceCandidates || []) {
    if (!candidate?.key || !candidate?.replacement?.matched) continue;
    const candidateKey = normalizeIdentifier(candidate.key);
    const keyMatches = fieldIdentifiers.some((identifier) => identifier && (
      candidateKey === identifier || candidateKey.endsWith(identifier) || identifier.endsWith(candidateKey)
    ));
    if (keyMatches) evidencePairs.push([candidate.replacement.from, candidate.replacement.to]);
  }
  if (evidencePairs.length) return uniqueReplacementPairs(evidencePairs);

  const isIp = (value) => /\b(?:\d{1,3}\.){3}\d{1,3}\b/.test(String(value));
  const isHostLike = (value) => isIp(value) || /[.:/]/.test(String(value));
  const pairText = ([from, to]) => `${from} ${to}`;
  const filterNamed = (pattern) => entries.filter((pair) => pattern.test(pairText(pair)));
  if (/registry/.test(name)) return filterNamed(/registry/i);
  if (/namespace|(^|_)ns($|_)/.test(name)) return filterNamed(/namespace|(^|[-_.])ns($|[-_.])/i);
  if (/(^|_)ip($|_)/.test(name)) return entries.filter(([from, to]) => isIp(from) || isIp(to));
  if (/mongo/.test(name)) return filterNamed(/mongo/i);
  if (/redis/.test(name)) return filterNamed(/redis/i);
  if (/kafka|broker/.test(name)) return filterNamed(/kafka|broker/i);

  const clusterNamed = /cluster/.test(name) ? filterNamed(/cluster/i) : [];
  if (/url|uri|endpoint|host/.test(name)) {
    if (clusterNamed.length) return clusterNamed;
    return entries.filter(([from, to]) => isHostLike(from) || isHostLike(to));
  }
  if (/cluster|context/.test(name)) return clusterNamed.length ? clusterNamed : entries;
  if (/region/.test(name)) {
    const regionPairs = filterNamed(/(?:^|[-_.])(ap|us|eu|sa|ca|me|af)-(?:north|south|east|west|central|northeast|southeast|northwest|southwest)-?\d/i);
    return regionPairs.length ? regionPairs : [];
  }
  if (/service|ingress/.test(name)) return entries.filter(([from, to]) => isHostLike(from) || isHostLike(to));
  return [];
}

function databaseColumnCandidates(entities, databaseObjects, replacements, keywords, sourceCandidates = []) {
  const candidates = [];

  for (const entity of entities || []) {
    for (const field of entity.fields || []) {
      if (!keywordMatch(field.name, keywords) && !keywordMatch(field.column, keywords)) continue;
      const relatedObjects = (databaseObjects || []).filter((object) => object.fullName?.toLowerCase() === entity.fullName.toLowerCase());
      const operationEvidence = unique(relatedObjects.flatMap((object) => object.operations || []));
      const resolvedEngines = unique(relatedObjects.map((object) => object.engine).filter((engine) => engine && engine !== 'relational-unknown'));
      const resolvedEngine = resolvedEngines.length === 1 ? resolvedEngines[0] : entity.engine;
      const relevantPairs = relevantReplacementEntries(field, replacements, sourceCandidates);
      const maxNewLength = relevantPairs.reduce((max, [, value]) => Math.max(max, String(value).length), 0);
      candidates.push({
        id: stableId('migration', 'database-data-column', entity.fullName, field.column, field.source.file, field.source.line),
        scope: 'database',
        category: 'database-data-column',
        severity: 'required',
        currentValue: 'DB 실데이터 조회 필요',
        targetValue: relevantPairs.length ? 'cluster-map.yaml의 일치하는 매핑값 적용' : '',
        targetStatus: relevantPairs.length ? 'mapping-available-needs-row-match' : 'not-specified',
        changeType: 'database-data-change',
        exactChange: `${resolvedEngine} ${entity.kind} '${entity.fullName}'의 '${field.column}' 컬럼/필드 값을 조회하여 기존 클러스터 식별값이 저장된 행만 신규 값으로 변경`,
        reason: `필드명 '${field.name}' 또는 컬럼명 '${field.column}'이 클러스터 이전 영향 키워드와 일치`,
        verification: verificationFor('database-data-column'),
        source: field.source,
        module: entity.module,
        engine: resolvedEngine,
        databaseObject: { kind: entity.kind, name: entity.fullName, column: field.column, javaField: field.name, javaType: field.type, length: field.length },
        operationEvidence,
        replacementCandidates: relevantPairs.map(([from, to]) => ({ from, to })),
        queryTemplate: entity.kind === 'table'
          ? `SELECT <PK>, ${field.column} FROM ${entity.fullName} WHERE ${field.column} IN (<OLD_VALUES>);`
          : `${entity.kind} '${entity.fullName}'에서 필드 '${field.column}'이 <OLD_VALUES>인 문서를 조회`,
        updateTemplate: entity.kind === 'table'
          ? `UPDATE ${entity.fullName} SET ${field.column} = <NEW_VALUE> WHERE ${field.column} = <OLD_VALUE>;`
          : `${entity.kind} '${entity.fullName}'의 '${field.column}' 값을 <OLD_VALUE>에서 <NEW_VALUE>로 변경`,
        confidence: relatedObjects.length ? 'high' : 'medium',
      });

      if (field.length && maxNewLength && maxNewLength > field.length) {
        candidates.push({
          id: stableId('migration', 'database-schema-column', entity.fullName, field.column, field.length, maxNewLength),
          scope: 'database',
          category: 'database-schema-column',
          severity: 'required',
          currentValue: `length=${field.length}`,
          targetValue: `requiredLength>=${maxNewLength}`,
          targetStatus: 'length-risk-detected',
          changeType: 'database-schema-change',
          exactChange: `${entity.fullName}.${field.column}의 허용 길이 ${field.length}보다 관련 신규 매핑값 최대 길이 ${maxNewLength}가 길어 컬럼 길이 확대 검토 필요`,
          reason: `해당 컬럼과 관련성이 있는 replacement map 신규 값이 @Column(length=${field.length}) 제한을 초과`,
          verification: verificationFor('database-schema-column'),
          source: field.source,
          module: entity.module,
          engine: resolvedEngine,
          databaseObject: { kind: entity.kind, name: entity.fullName, column: field.column, length: field.length },
          replacementCandidates: relevantPairs.map(([from, to]) => ({ from, to })),
          confidence: 'high',
        });
      }
    }
  }

  for (const object of databaseObjects || []) {
    for (const column of object.columns || []) {
      if (!keywordMatch(column, keywords)) continue;
      const already = candidates.some((candidate) => candidate.databaseObject?.name?.toLowerCase() === object.fullName?.toLowerCase() && candidate.databaseObject?.column?.toLowerCase() === String(column).toLowerCase());
      if (already) continue;
      const relevantPairs = relevantReplacementEntries({ name: column, column }, replacements, sourceCandidates);
      candidates.push({
        id: stableId('migration', 'database-data-column', object.fullName, column, object.source?.file, object.source?.line),
        scope: 'database', category: 'database-data-column', severity: 'review',
        currentValue: 'DB 실데이터 조회 필요',
        targetValue: relevantPairs.length ? 'cluster-map.yaml의 일치하는 매핑값 적용' : '',
        targetStatus: relevantPairs.length ? 'mapping-available-needs-row-match' : 'not-specified',
        changeType: 'database-data-change',
        exactChange: `${object.engine} ${object.kind} '${object.fullName}'의 '${column}' 값이 클러스터 이전 대상인지 SQL 사용 맥락을 확인한 뒤 필요한 행만 변경`,
        reason: `SQL에서 클러스터 이전 영향 키워드와 일치하는 컬럼 '${column}'이 발견됨`,
        verification: verificationFor('database-data-column'),
        source: object.source,
        module: object.module,
        engine: object.engine,
        databaseObject: { kind: object.kind, name: object.fullName, column },
        operationEvidence: object.operations,
        replacementCandidates: relevantPairs.map(([from, to]) => ({ from, to })),
        confidence: 'medium',
      });
    }
  }
  return candidates;
}

function deduplicateCandidates(candidates, maxCandidates) {
  const map = new Map();
  for (const candidate of candidates) {
    const key = [candidate.category, candidate.source?.file, candidate.source?.line, candidate.currentValue, candidate.databaseObject?.name, candidate.databaseObject?.column].join('|');
    if (!map.has(key)) map.set(key, candidate);
    else {
      const current = map.get(key);
      if (current.targetStatus !== 'mapped' && candidate.targetStatus === 'mapped') map.set(key, candidate);
    }
  }
  return [...map.values()]
    .sort((a, b) => {
      const severityOrder = { required: 0, review: 1, optional: 2 };
      return (severityOrder[a.severity] ?? 9) - (severityOrder[b.severity] ?? 9) ||
        String(a.source?.file || '').localeCompare(String(b.source?.file || '')) ||
        Number(a.source?.line || 0) - Number(b.source?.line || 0);
    })
    .slice(0, maxCandidates);
}

function analyzeMigration({ files, configuration, manifests, backend, clusterMap, config }) {
  const replacements = normalizeReplacements(clusterMap);
  const candidates = [];
  const connectionSourceLines = new Set((configuration.connections || []).map((connection) => `${connection.source?.file}:${connection.source?.line}`));
  for (const literal of configuration.literals || []) {
    const sourceKey = `${literal.source?.file}:${literal.source?.line}`;
    // 같은 설정 줄이 정식 connection으로 분류되었다면 URL/IP literal 후보를 중복 생성하지 않는다.
    if (connectionSourceLines.has(sourceKey) && ['jdbc', 'url', 'ipv4'].includes(literal.type)) continue;
    candidates.push(candidateFromLiteral(literal, replacements));
  }
  for (const connection of configuration.connections || []) candidates.push(candidateFromConnection(connection, replacements));
  for (const reference of manifests.references || []) candidates.push(candidateFromManifest(reference, replacements));
  const keywords = config.analysis.databaseColumnKeywords || [];
  const sourceSensitiveCandidates = extractClusterSensitiveStrings(files, replacements, keywords);
  candidates.push(...sourceSensitiveCandidates);
  if (config.migration.detectDatabaseValueColumns !== false) {
    candidates.push(...databaseColumnCandidates(backend.entities || [], backend.databaseObjects || [], replacements, keywords, sourceSensitiveCandidates));
  }
  const deduped = deduplicateCandidates(candidates, Number(config.analysis.maxMigrationCandidates || 5000));
  const byCategory = {};
  for (const candidate of deduped) {
    if (!byCategory[candidate.category]) byCategory[candidate.category] = [];
    byCategory[candidate.category].push(candidate.id);
  }
  return {
    replacements,
    mappingConfigured: Object.keys(replacements).length > 0,
    candidates: deduped,
    byCategory,
    summary: {
      total: deduped.length,
      required: deduped.filter((item) => item.severity === 'required').length,
      review: deduped.filter((item) => item.severity === 'review').length,
      databaseData: deduped.filter((item) => item.category === 'database-data-column').length,
      databaseSchema: deduped.filter((item) => item.category === 'database-schema-column').length,
      mappedTargets: deduped.filter((item) => ['mapped', 'mapped-set', 'mapping-available-needs-row-match'].includes(item.targetStatus)).length,
    },
  };
}

module.exports = {
  analyzeMigration,
  normalizeReplacements,
  applyReplacement,
  databaseColumnCandidates,
};
