'use strict';

const { lineNumberAt, excerptAt, unique, stableId } = require('../core/text');

function cleanIdentifier(identifier) {
  return String(identifier || '')
    .trim()
    .replace(/[;,)]+$/g, '')
    .replace(/^[(`\[]+|[`"\]]+$/g, '')
    .replace(/"/g, '')
    .replace(/`/g, '')
    .replace(/\[/g, '')
    .replace(/\]/g, '');
}

function splitObjectName(identifier) {
  const cleaned = cleanIdentifier(identifier);
  const parts = cleaned.split('.').filter(Boolean);
  if (parts.length >= 2) {
    return { schema: parts.slice(0, -1).join('.'), name: parts[parts.length - 1], fullName: cleaned };
  }
  return { schema: '', name: cleaned, fullName: cleaned };
}

function inferSqlEngine(sql) {
  const upper = String(sql || '').toUpperCase();
  const scores = {
    oracle: 0,
    postgresql: 0,
    mysql: 0,
    sqlserver: 0,
  };
  const oracleTokens = [' NVL(', ' SYSDATE', ' SYSTIMESTAMP', ' ROWNUM', ' CONNECT BY', ' START WITH', ' VARCHAR2', '.NEXTVAL', ' DUAL', ' DECODE('];
  const pgTokens = [' ILIKE ', ' RETURNING ', '::JSON', '::UUID', ' ON CONFLICT ', ' JSONB_', ' SERIAL'];
  const mysqlTokens = ['`', ' LIMIT ', ' IFNULL(', ' ON DUPLICATE KEY ', ' TINYINT'];
  const sqlServerTokens = [' TOP ', ' ISNULL(', ' GETDATE(', '[DBO].', ' WITH (NOLOCK)', ' NVARCHAR'];
  for (const token of oracleTokens) if (upper.includes(token)) scores.oracle += 1;
  for (const token of pgTokens) if (upper.includes(token)) scores.postgresql += 1;
  for (const token of mysqlTokens) if (upper.includes(token)) scores.mysql += 1;
  for (const token of sqlServerTokens) if (upper.includes(token)) scores.sqlserver += 1;
  const [engine, score] = Object.entries(scores).sort((a, b) => b[1] - a[1])[0];
  return score > 0 ? engine : 'relational-unknown';
}

function parseInsertColumns(sql, tableName) {
  const escaped = tableName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`\\binsert\\s+into\\s+${escaped}\\s*\\(([^)]+)\\)`, 'i');
  const match = regex.exec(sql);
  if (!match) return [];
  return match[1].split(',').map(cleanIdentifier).filter(Boolean);
}

function parseUpdateColumns(sql, tableName) {
  const escaped = tableName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`\\bupdate\\s+${escaped}\\s+set\\s+([\\s\\S]+?)(?:\\bwhere\\b|$)`, 'i');
  const match = regex.exec(sql);
  if (!match) return [];
  const columns = [];
  const assignRegex = /(?:^|,)\s*([A-Za-z_$#][\w$#.]*)\s*=/g;
  let assignment;
  while ((assignment = assignRegex.exec(match[1]))) columns.push(cleanIdentifier(assignment[1].split('.').pop()));
  return unique(columns);
}

function parseReferencedColumns(sql) {
  const columns = [];
  const qualified = /\b[A-Za-z_][\w$#]*\.([A-Za-z_][\w$#]*)\b/g;
  let match;
  while ((match = qualified.exec(sql))) columns.push(match[1]);
  const predicates = /\b(?:where|and|or|on)\s+([A-Za-z_][\w$#.]*)\s*(?:=|<>|!=|<=|>=|<|>|like\b|in\s*\()/gi;
  while ((match = predicates.exec(sql))) columns.push(cleanIdentifier(match[1].split('.').pop()));
  return unique(columns);
}

function extractSqlObjects(sql, context = {}) {
  const text = String(sql || '');
  const engine = context.engine && context.engine !== 'relational-unknown' ? context.engine : inferSqlEngine(text);
  const hits = [];
  const patterns = [
    { operation: 'SELECT', regex: /\b(?:from|join)\s+([A-Za-z_$#][\w$#]*(?:\s*\.\s*[A-Za-z_$#][\w$#]*)?)/gi },
    { operation: 'INSERT', regex: /\binsert\s+into\s+([A-Za-z_$#][\w$#]*(?:\s*\.\s*[A-Za-z_$#][\w$#]*)?)/gi },
    { operation: 'UPDATE', regex: /\bupdate\s+([A-Za-z_$#][\w$#]*(?:\s*\.\s*[A-Za-z_$#][\w$#]*)?)/gi },
    { operation: 'DELETE', regex: /\bdelete\s+from\s+([A-Za-z_$#][\w$#]*(?:\s*\.\s*[A-Za-z_$#][\w$#]*)?)/gi },
    { operation: 'MERGE', regex: /\bmerge\s+into\s+([A-Za-z_$#][\w$#]*(?:\s*\.\s*[A-Za-z_$#][\w$#]*)?)/gi },
    { operation: 'DDL_CREATE', regex: /\bcreate\s+table\s+([A-Za-z_$#][\w$#]*(?:\s*\.\s*[A-Za-z_$#][\w$#]*)?)/gi },
    { operation: 'DDL_ALTER', regex: /\balter\s+table\s+([A-Za-z_$#][\w$#]*(?:\s*\.\s*[A-Za-z_$#][\w$#]*)?)/gi },
    { operation: 'DDL_DROP', regex: /\bdrop\s+table\s+([A-Za-z_$#][\w$#]*(?:\s*\.\s*[A-Za-z_$#][\w$#]*)?)/gi },
  ];

  for (const { operation, regex } of patterns) {
    let match;
    while ((match = regex.exec(text))) {
      const object = splitObjectName(match[1].replace(/\s+/g, ''));
      if (!object.name || /^(select|values|set)$/i.test(object.name)) continue;
      let columns = parseReferencedColumns(text);
      if (operation === 'INSERT') columns = unique([...columns, ...parseInsertColumns(text, match[1].replace(/\s+/g, ''))]);
      if (operation === 'UPDATE') columns = unique([...columns, ...parseUpdateColumns(text, match[1].replace(/\s+/g, ''))]);
      // SCHEMA.TABLE 표기의 TABLE을 컬럼으로 잘못 잡지 않도록 현재 객체명·스키마명은 제거한다.
      columns = columns.filter((column) => ![object.name, object.schema].filter(Boolean).some((identifier) => identifier.toLowerCase() === String(column).toLowerCase()));
      const absoluteIndex = Number(context.baseIndex || 0) + match.index;
      hits.push({
        id: stableId('dbobj', context.file || '', context.owner || '', operation, object.fullName, absoluteIndex),
        engine,
        kind: 'table',
        schema: object.schema,
        name: object.name,
        fullName: object.fullName,
        operations: [operation],
        columns,
        module: context.module || '.',
        owner: context.owner || '',
        ownerClass: context.ownerClass || '',
        ownerMethod: context.ownerMethod || '',
        via: context.via || 'sql',
        source: {
          file: context.file || '',
          line: context.sourceText ? lineNumberAt(context.sourceText, absoluteIndex) : Number(context.line || 1),
          excerpt: context.sourceText ? excerptAt(context.sourceText, absoluteIndex) : String(context.excerpt || '').slice(0, 220),
        },
        confidence: context.confidence || 'high',
      });
    }
  }
  return mergeDatabaseObjects(hits);
}

function mergeDatabaseObjects(objects) {
  const map = new Map();
  for (const object of objects || []) {
    const key = [object.engine, object.kind, object.module, object.ownerClass, object.ownerMethod, object.fullName, object.source?.file, object.source?.line].join('|');
    if (!map.has(key)) {
      map.set(key, { ...object, operations: unique(object.operations), columns: unique(object.columns), sources: object.sources || [object.source].filter(Boolean) });
    } else {
      const current = map.get(key);
      current.operations = unique([...current.operations, ...(object.operations || [])]);
      current.columns = unique([...current.columns, ...(object.columns || [])]);
      current.sources = [...current.sources, ...(object.sources || [object.source].filter(Boolean))];
    }
  }
  return [...map.values()];
}

function analyzeSqlFiles(files) {
  const objects = [];
  for (const file of files) {
    if (file.kind !== 'sql') continue;
    objects.push(...extractSqlObjects(file.text, {
      file: file.relative,
      module: file.module,
      sourceText: file.text,
      owner: file.relative,
      via: 'sql-file',
    }));
  }
  return { objects: mergeDatabaseObjects(objects) };
}

module.exports = {
  analyzeSqlFiles,
  extractSqlObjects,
  mergeDatabaseObjects,
  inferSqlEngine,
  cleanIdentifier,
};
