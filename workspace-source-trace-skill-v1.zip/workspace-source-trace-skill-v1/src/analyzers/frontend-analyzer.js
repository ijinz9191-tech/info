'use strict';

const path = require('path');
const {
  lineNumberAt,
  excerptAt,
  findMatchingBrace,
  normalizeEndpointPath,
  pathBasenameWithoutExtensions,
  stableId,
  unique,
  normalizeSlashes,
} = require('../core/text');

const JS_EXTENSIONS = ['.ts', '.tsx', '.js', '.jsx'];
const CALL_KEYWORDS = new Set([
  'if', 'for', 'while', 'switch', 'catch', 'return', 'throw', 'typeof', 'new', 'await',
  'function', 'useEffect', 'useMemo', 'useCallback', 'setTimeout', 'setInterval', 'Promise',
]);

function extractImports(file) {
  const imports = [];
  const text = file.text;
  const regex = /\bimport\s+([\s\S]*?)\s+from\s+['"]([^'"]+)['"]\s*;?/g;
  let match;
  while ((match = regex.exec(text))) {
    const clause = match[1].trim();
    const source = match[2];
    if (clause.startsWith('{')) {
      const inner = clause.replace(/^\{|\}$/g, '');
      for (const item of inner.split(',')) {
        const parts = item.trim().split(/\s+as\s+/);
        if (!parts[0]) continue;
        imports.push({ local: parts[1] || parts[0], imported: parts[0], source, kind: 'named', line: lineNumberAt(text, match.index) });
      }
    } else if (clause.startsWith('* as ')) {
      const local = clause.slice(5).trim();
      imports.push({ local, imported: '*', source, kind: 'namespace', line: lineNumberAt(text, match.index) });
    } else {
      const comma = clause.indexOf(',');
      const defaultName = (comma >= 0 ? clause.slice(0, comma) : clause).trim();
      if (defaultName) imports.push({ local: defaultName, imported: 'default', source, kind: 'default', line: lineNumberAt(text, match.index) });
      if (comma >= 0) {
        const rest = clause.slice(comma + 1).trim();
        if (rest.startsWith('{')) {
          const inner = rest.replace(/^\{|\}$/g, '');
          for (const item of inner.split(',')) {
            const parts = item.trim().split(/\s+as\s+/);
            if (parts[0]) imports.push({ local: parts[1] || parts[0], imported: parts[0], source, kind: 'named', line: lineNumberAt(text, match.index) });
          }
        }
      }
    }
  }
  const requireRegex = /\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*require\s*\(\s*['"]([^'"]+)['"]\s*\)/g;
  while ((match = requireRegex.exec(text))) {
    imports.push({ local: match[1], imported: 'default', source: match[2], kind: 'require', line: lineNumberAt(text, match.index) });
  }
  return imports;
}

function extractFunctionCalls(body) {
  const calls = [];
  const objectCall = /\b([A-Za-z_$][\w$]*)\s*\.\s*([A-Za-z_$][\w$]*)\s*\(/g;
  let match;
  while ((match = objectCall.exec(body))) {
    calls.push({ receiver: match[1], method: match[2], name: `${match[1]}.${match[2]}`, index: match.index });
  }
  const plainCall = /(?<![.\w$])([A-Za-z_$][\w$]*)\s*\(/g;
  while ((match = plainCall.exec(body))) {
    if (CALL_KEYWORDS.has(match[1])) continue;
    calls.push({ receiver: '', method: match[1], name: match[1], index: match.index });
  }
  const seen = new Set();
  return calls.filter((call) => {
    const key = `${call.name}|${call.index}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function extractFunctions(file) {
  const functions = [];
  const seenRanges = new Set();
  const patterns = [
    { regex: /\b(?:export\s+)?(?:default\s+)?(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\([^)]*\)\s*\{/g, nameGroup: 1 },
    { regex: /\b(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>\s*\{/g, nameGroup: 1 },
    { regex: /\b(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?[A-Za-z_$][\w$]*\s*=>\s*\{/g, nameGroup: 1 },
  ];
  for (const pattern of patterns) {
    let match;
    while ((match = pattern.regex.exec(file.text))) {
      const open = file.text.indexOf('{', match.index + match[0].lastIndexOf('{'));
      const close = findMatchingBrace(file.text, open);
      if (close < 0) continue;
      const rangeKey = `${open}:${close}`;
      if (seenRanges.has(rangeKey)) continue;
      seenRanges.add(rangeKey);
      const name = match[pattern.nameGroup];
      const body = file.text.slice(open + 1, close);
      functions.push({
        id: stableId('jsfn', file.relative, name, open),
        name,
        file: file.relative,
        module: file.module,
        line: lineNumberAt(file.text, match.index),
        start: match.index,
        bodyStart: open + 1,
        end: close,
        calls: extractFunctionCalls(body),
        _body: body,
      });
    }
  }

  // 중괄호가 없는 표현식 화살표 함수도 이벤트 핸들러/서비스 래퍼로 추적한다.
  const expressionArrowRegex = /\b(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:\([^)]*\)|[A-Za-z_$][\w$]*)\s*=>\s*(?!\{)([^;\n]+)\s*;?/g;
  let expressionMatch;
  while ((expressionMatch = expressionArrowRegex.exec(file.text))) {
    const name = expressionMatch[1];
    const body = expressionMatch[2].trim();
    const bodyStart = expressionMatch.index + expressionMatch[0].indexOf(expressionMatch[2]);
    const end = bodyStart + expressionMatch[2].length;
    const rangeKey = `${bodyStart}:${end}`;
    if (seenRanges.has(rangeKey)) continue;
    seenRanges.add(rangeKey);
    functions.push({
      id: stableId('jsfn', file.relative, name, bodyStart),
      name,
      file: file.relative,
      module: file.module,
      line: lineNumberAt(file.text, expressionMatch.index),
      start: expressionMatch.index,
      bodyStart,
      end,
      calls: extractFunctionCalls(body),
      _body: body,
    });
  }

  const objectRegex = /\b(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*\{/g;
  let objectMatch;
  while ((objectMatch = objectRegex.exec(file.text))) {
    const objectName = objectMatch[1];
    const open = file.text.indexOf('{', objectMatch.index);
    const close = findMatchingBrace(file.text, open);
    if (close < 0) continue;
    const objectBody = file.text.slice(open + 1, close);
    const methodPatterns = [
      /\b([A-Za-z_$][\w$]*)\s*:\s*(?:async\s*)?\([^)]*\)\s*=>\s*\{/g,
      /\b(?:async\s+)?([A-Za-z_$][\w$]*)\s*\([^)]*\)\s*\{/g,
    ];
    for (const methodRegex of methodPatterns) {
      let methodMatch;
      while ((methodMatch = methodRegex.exec(objectBody))) {
        const methodOpen = open + 1 + objectBody.indexOf('{', methodMatch.index + methodMatch[0].lastIndexOf('{'));
        const methodClose = findMatchingBrace(file.text, methodOpen);
        if (methodClose < 0 || methodClose > close) continue;
        const rangeKey = `${methodOpen}:${methodClose}`;
        if (seenRanges.has(rangeKey)) continue;
        seenRanges.add(rangeKey);
        const name = `${objectName}.${methodMatch[1]}`;
        const body = file.text.slice(methodOpen + 1, methodClose);
        functions.push({
          id: stableId('jsfn', file.relative, name, methodOpen),
          name,
          file: file.relative,
          module: file.module,
          line: lineNumberAt(file.text, open + 1 + methodMatch.index),
          start: open + 1 + methodMatch.index,
          bodyStart: methodOpen + 1,
          end: methodClose,
          calls: extractFunctionCalls(body),
          _body: body,
        });
      }
    }
  }
  return functions.sort((a, b) => a.start - b.start || a.end - b.end);
}

function ownerFunctionAt(functions, index) {
  return functions
    .filter((fn) => fn.start <= index && fn.end >= index)
    .sort((a, b) => (a.end - a.start) - (b.end - b.start))[0] || null;
}

function inferFetchMethod(text, callIndex, closingIndex) {
  const slice = text.slice(callIndex, Math.min(text.length, Math.max(closingIndex + 500, callIndex + 500)));
  const match = slice.match(/\bmethod\s*:\s*['"](GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)['"]/i);
  return match ? match[1].toUpperCase() : 'GET';
}

function addApiCall(calls, file, functions, data) {
  const owner = ownerFunctionAt(functions, data.index);
  const normalizedPath = normalizeEndpointPath(data.rawPath);
  const item = {
    id: stableId('apicall', file.relative, data.index, data.method, normalizedPath, data.client),
    file: file.relative,
    module: file.module,
    line: lineNumberAt(file.text, data.index),
    client: data.client,
    method: (data.method || 'UNKNOWN').toUpperCase(),
    rawPath: data.rawPath,
    path: normalizedPath,
    ownerFunction: owner?.name || '',
    source: { file: file.relative, line: lineNumberAt(file.text, data.index), excerpt: excerptAt(file.text, data.index) },
    confidence: data.confidence || 'high',
  };
  if (!calls.some((existing) => existing.file === item.file && existing.line === item.line && existing.method === item.method && existing.path === item.path)) calls.push(item);
}

function extractApiCalls(file, functions) {
  const calls = [];
  let match;
  const fetchRegex = /\bfetch\s*\(\s*([`'"])([^`'"]+?)\1/g;
  while ((match = fetchRegex.exec(file.text))) {
    addApiCall(calls, file, functions, {
      index: match.index,
      client: 'fetch',
      method: inferFetchMethod(file.text, match.index, fetchRegex.lastIndex),
      rawPath: match[2],
      confidence: 'high',
    });
  }

  const methodRegex = /\b([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s*\.\s*(get|post|put|patch|delete|head|options)\s*\(\s*([`'"])([^`'"]+?)\3/gi;
  while ((match = methodRegex.exec(file.text))) {
    const client = match[1];
    const rawPath = match[4];
    const likelyClient = /(axios|api|http|client|request|rest|gateway|service|instance)/i.test(client) || rawPath.startsWith('/') || /^https?:/i.test(rawPath);
    if (!likelyClient) continue;
    addApiCall(calls, file, functions, { index: match.index, client, method: match[2], rawPath, confidence: /(axios|api|http|client)/i.test(client) ? 'high' : 'medium' });
  }

  const requestObjectRegex = /\b([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s*\(\s*\{([\s\S]{0,1200}?)\}\s*\)/g;
  while ((match = requestObjectRegex.exec(file.text))) {
    if (!/(request|api|http|client|axios)/i.test(match[1])) continue;
    const block = match[2];
    const url = block.match(/\b(?:url|uri|path)\s*:\s*([`'"])(.*?)\1/i);
    if (!url) continue;
    const method = block.match(/\bmethod\s*:\s*['"](GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)['"]/i);
    addApiCall(calls, file, functions, { index: match.index, client: match[1], method: method?.[1] || 'UNKNOWN', rawPath: url[2], confidence: 'medium' });
  }
  return calls;
}

function cleanJsxLabel(value) {
  return String(value || '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\{[^}]+\}/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 120);
}

function handlerRefs(expression) {
  const refs = [];
  const objectRegex = /\b([A-Za-z_$][\w$]*)\.([A-Za-z_$][\w$]*)\s*\(/g;
  let match;
  while ((match = objectRegex.exec(expression))) refs.push(`${match[1]}.${match[2]}`);
  const callRegex = /(?<![.\w$])([A-Za-z_$][\w$]*)\s*\(/g;
  while ((match = callRegex.exec(expression))) if (!CALL_KEYWORDS.has(match[1])) refs.push(match[1]);
  const direct = expression.trim().match(/^([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)$/);
  if (direct) refs.push(direct[1]);
  return unique(refs);
}

function screenNameAt(functions, file, index) {
  const owner = ownerFunctionAt(functions, index);
  if (owner && /^[A-Z]/.test(owner.name)) return owner.name;
  const capitalized = functions.find((fn) => /^[A-Z]/.test(fn.name));
  return capitalized?.name || pathBasenameWithoutExtensions(file.relative);
}

function extractTriggers(file, functions) {
  const triggers = [];
  const tagRegex = /<([A-Za-z][A-Za-z0-9_.]*)\b([^>]*?)>/g;
  let match;
  while ((match = tagRegex.exec(file.text))) {
    const tag = match[1];
    const attrs = match[2];
    const eventRegex = /\b(on(?:Click|Submit|Change|Blur|KeyDown|KeyUp|Press|Select|Load))\s*=\s*\{([^}]*)\}/g;
    let eventMatch;
    while ((eventMatch = eventRegex.exec(attrs))) {
      const absoluteIndex = match.index + eventMatch.index;
      const expression = eventMatch[2].trim();
      let label = '';
      const aria = attrs.match(/\b(?:aria-label|title|label|name)\s*=\s*['"]([^'"]+)['"]/i);
      if (aria) label = aria[1];
      if (!label) {
        const closing = new RegExp(`<\\/${tag.replace('.', '\\.')}>`, 'i');
        const after = file.text.slice(tagRegex.lastIndex, tagRegex.lastIndex + 600);
        const closeMatch = closing.exec(after);
        if (closeMatch) label = cleanJsxLabel(after.slice(0, closeMatch.index));
      }
      triggers.push({
        id: stableId('trigger', file.relative, absoluteIndex, eventMatch[1], expression),
        file: file.relative,
        module: file.module,
        line: lineNumberAt(file.text, absoluteIndex),
        screen: screenNameAt(functions, file, match.index),
        tag,
        label: label || tag,
        event: eventMatch[1],
        mode: /^onLoad$/i.test(eventMatch[1]) ? 'automatic' : 'manual',
        handlerExpression: expression,
        startFunctions: handlerRefs(expression),
        source: { file: file.relative, line: lineNumberAt(file.text, absoluteIndex), excerpt: excerptAt(file.text, match.index) },
        apiCallIds: [],
        callChain: [],
      });
    }
  }

  const effectRegex = /\buseEffect\s*\(\s*(?:async\s*)?\(\s*\)\s*=>\s*\{/g;
  while ((match = effectRegex.exec(file.text))) {
    const open = file.text.indexOf('{', match.index);
    const close = findMatchingBrace(file.text, open);
    if (close < 0) continue;
    const body = file.text.slice(open + 1, close);
    const refs = extractFunctionCalls(body).map((call) => call.name);
    triggers.push({
      id: stableId('trigger', file.relative, match.index, 'useEffect'),
      file: file.relative,
      module: file.module,
      line: lineNumberAt(file.text, match.index),
      screen: screenNameAt(functions, file, match.index),
      tag: 'React.useEffect',
      label: '화면 진입/의존성 변경 자동 조회',
      event: 'useEffect',
      mode: 'automatic',
      handlerExpression: body.slice(0, 300),
      startFunctions: unique(refs),
      source: { file: file.relative, line: lineNumberAt(file.text, match.index), excerpt: excerptAt(file.text, match.index) },
      apiCallIds: [],
      callChain: [],
    });
  }

  const queryRegex = /\b(useQuery|useInfiniteQuery|useSuspenseQuery)\s*\(([\s\S]{0,1000}?)(?:\)\s*;|\),)/g;
  while ((match = queryRegex.exec(file.text))) {
    const block = match[2];
    const refs = [];
    const queryFn = block.match(/\bqueryFn\s*:\s*(?:\([^)]*\)\s*=>\s*)?([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)/);
    if (queryFn) refs.push(queryFn[1]);
    const positional = block.match(/,\s*([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s*(?:,|$)/);
    if (positional) refs.push(positional[1]);
    triggers.push({
      id: stableId('trigger', file.relative, match.index, match[1]),
      file: file.relative,
      module: file.module,
      line: lineNumberAt(file.text, match.index),
      screen: screenNameAt(functions, file, match.index),
      tag: `ReactQuery.${match[1]}`,
      label: 'React Query 자동 조회',
      event: match[1],
      mode: 'automatic',
      handlerExpression: block.slice(0, 300),
      startFunctions: unique(refs),
      source: { file: file.relative, line: lineNumberAt(file.text, match.index), excerpt: excerptAt(file.text, match.index) },
      apiCallIds: [],
      callChain: [],
    });
  }
  return triggers;
}

function extractRoutes(file) {
  const routes = [];
  let match;
  const jsxRoute = /<Route\b([^>]*?)>/g;
  while ((match = jsxRoute.exec(file.text))) {
    const attrs = match[1];
    const routePath = attrs.match(/\bpath\s*=\s*['"]([^'"]+)['"]/i);
    const component = attrs.match(/\b(?:element\s*=\s*\{\s*<|Component\s*=\s*\{?)([A-Za-z_$][\w$]*)/i);
    if (!routePath) continue;
    routes.push({
      id: stableId('route', file.relative, match.index, routePath[1]),
      path: normalizeEndpointPath(routePath[1]),
      component: component?.[1] || '',
      file: file.relative,
      module: file.module,
      line: lineNumberAt(file.text, match.index),
      source: { file: file.relative, line: lineNumberAt(file.text, match.index), excerpt: excerptAt(file.text, match.index) },
    });
  }
  const objectRoute = /\bpath\s*:\s*['"]([^'"]+)['"]([\s\S]{0,350}?)(?=\n\s*[,}]|$)/g;
  while ((match = objectRoute.exec(file.text))) {
    const component = match[2].match(/\b(?:element\s*:\s*<|Component\s*:\s*)([A-Za-z_$][\w$]*)/);
    routes.push({
      id: stableId('route', file.relative, match.index, match[1]),
      path: normalizeEndpointPath(match[1]),
      component: component?.[1] || '',
      file: file.relative,
      module: file.module,
      line: lineNumberAt(file.text, match.index),
      source: { file: file.relative, line: lineNumberAt(file.text, match.index), excerpt: excerptAt(file.text, match.index) },
    });
  }
  return routes;
}

function extractHookAliases(file) {
  const aliases = {};
  let match;
  const mutationObject = /\b(?:const|let)\s+([A-Za-z_$][\w$]*)\s*=\s*useMutation\s*\(([\s\S]{0,1200}?)(?:\)\s*;|\),)/g;
  while ((match = mutationObject.exec(file.text))) {
    const mutationFn = match[2].match(/\bmutationFn\s*:\s*(?:\([^)]*\)\s*=>\s*)?([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)/);
    if (!mutationFn) continue;
    aliases[`${match[1]}.mutate`] = mutationFn[1];
    aliases[`${match[1]}.mutateAsync`] = mutationFn[1];
  }
  const mutationDestructure = /\b(?:const|let)\s*\{([^}]+)\}\s*=\s*useMutation\s*\(([\s\S]{0,1200}?)(?:\)\s*;|\),)/g;
  while ((match = mutationDestructure.exec(file.text))) {
    const mutationFn = match[2].match(/\bmutationFn\s*:\s*(?:\([^)]*\)\s*=>\s*)?([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)/);
    if (!mutationFn) continue;
    for (const part of match[1].split(',')) {
      const item = part.trim().split(/\s*:\s*/);
      if (item[0] === 'mutate' || item[0] === 'mutateAsync') aliases[item[1] || item[0]] = mutationFn[1];
    }
  }
  return aliases;
}

function resolveImportSource(file, source, fileSet, config) {
  const normalizedSource = normalizeSlashes(source);
  let base;
  if (normalizedSource.startsWith('.')) {
    base = normalizeSlashes(path.posix.normalize(path.posix.join(path.posix.dirname(file.relative), normalizedSource)));
  } else {
    const aliases = config.scan.aliasRoots || {};
    const alias = Object.keys(aliases).sort((a, b) => b.length - a.length).find((prefix) => normalizedSource.startsWith(prefix));
    if (!alias) return '';
    const suffix = normalizedSource.slice(alias.length);
    base = normalizeSlashes(path.posix.join(file.module === '.' ? '' : file.module, aliases[alias], suffix));
  }
  const candidates = [base];
  for (const ext of JS_EXTENSIONS) candidates.push(`${base}${ext}`);
  for (const ext of JS_EXTENSIONS) candidates.push(`${base}/index${ext}`);
  return candidates.find((candidate) => fileSet.has(candidate)) || '';
}

function buildFunctionIndex(functions) {
  const index = new Map();
  for (const fn of functions) {
    const key = `${fn.file}#${fn.name}`;
    index.set(key, fn);
  }
  return index;
}

function resolveFunctionReference(currentFile, reference, fileInfo, functionIndex, aliasDepth = 0) {
  if (!reference) return null;
  if (aliasDepth < 5 && fileInfo?.hookAliases?.[reference] && fileInfo.hookAliases[reference] !== reference) {
    return resolveFunctionReference(currentFile, fileInfo.hookAliases[reference], fileInfo, functionIndex, aliasDepth + 1);
  }
  const exact = functionIndex.get(`${currentFile}#${reference}`);
  if (exact) return exact;
  if (reference.includes('.')) {
    const [receiver, method] = reference.split('.', 2);
    const importItem = fileInfo.imports.find((item) => item.local === receiver);
    if (importItem?.resolvedFile) {
      return functionIndex.get(`${importItem.resolvedFile}#${method}`) ||
        functionIndex.get(`${importItem.resolvedFile}#${receiver}.${method}`) || null;
    }
  } else {
    const importItem = fileInfo.imports.find((item) => item.local === reference);
    if (importItem?.resolvedFile) {
      const targetName = importItem.imported === 'default' ? reference : importItem.imported;
      return functionIndex.get(`${importItem.resolvedFile}#${targetName}`) ||
        [...functionIndex.values()].find((fn) => fn.file === importItem.resolvedFile && importItem.imported === 'default' && /^[A-Z]/.test(fn.name)) ||
        [...functionIndex.values()].find((fn) => fn.file === importItem.resolvedFile && importItem.imported === 'default') || null;
    }
  }
  return null;
}

function linkTriggers(frontend, config) {
  const functionIndex = buildFunctionIndex(frontend.functions);
  const apisByFunction = new Map();
  for (const call of frontend.apiCalls) {
    if (!call.ownerFunction) continue;
    const key = `${call.file}#${call.ownerFunction}`;
    if (!apisByFunction.has(key)) apisByFunction.set(key, []);
    apisByFunction.get(key).push(call);
  }
  const fileInfoMap = new Map(frontend.files.map((file) => [file.file, file]));
  const maxDepth = Number(config.analysis.maxCallDepth || 10);
  const maxNodes = Number(config.analysis.maxFlowNodes || 250);

  for (const trigger of frontend.triggers) {
    const queue = trigger.startFunctions.map((reference) => ({ file: trigger.file, reference, depth: 0, parent: '' }));
    const visited = new Set();
    const chain = [];
    const apiIds = new Set();
    while (queue.length && visited.size < maxNodes) {
      const current = queue.shift();
      if (current.depth > maxDepth) continue;
      const info = fileInfoMap.get(current.file);
      if (!info) continue;
      const fn = resolveFunctionReference(current.file, current.reference, info, functionIndex);
      if (!fn) {
        chain.push({ from: current.parent || trigger.id, to: current.reference, status: 'unresolved', depth: current.depth });
        continue;
      }
      const key = `${fn.file}#${fn.name}`;
      if (visited.has(key)) continue;
      visited.add(key);
      chain.push({ from: current.parent || trigger.id, to: key, status: 'resolved', depth: current.depth });
      for (const api of apisByFunction.get(key) || []) apiIds.add(api.id);
      const fnInfo = fileInfoMap.get(fn.file);
      for (const call of fn.calls) {
        const next = resolveFunctionReference(fn.file, call.name, fnInfo, functionIndex);
        if (next || !CALL_KEYWORDS.has(call.method)) {
          queue.push({ file: fn.file, reference: call.name, depth: current.depth + 1, parent: key });
        }
      }
    }
    if (!apiIds.size) {
      const owner = ownerFunctionAt(frontend.functions.filter((fn) => fn.file === trigger.file), frontend.files.find((f) => f.file === trigger.file)?._textIndexByLine?.[trigger.line] || 0);
      if (owner && /(fetch|axios|api|http|client|request)/i.test(trigger.handlerExpression)) {
        for (const api of apisByFunction.get(`${owner.file}#${owner.name}`) || []) apiIds.add(api.id);
      }
    }
    trigger.apiCallIds = [...apiIds];
    trigger.callChain = chain;
  }
}

function buildScreens(frontend) {
  const screens = [];
  const screenMap = new Map();
  for (const file of frontend.files) {
    const names = file.functions.filter((fn) => /^[A-Z]/.test(fn.name) && !fn.name.includes('.')).map((fn) => fn.name);
    const hasTriggers = frontend.triggers.some((trigger) => trigger.file === file.file);
    // API 유틸·라우터 설정 파일을 화면으로 오인하지 않도록 실제 컴포넌트 또는 UI 트리거가 있는 파일만 화면화한다.
    if (!names.length && !hasTriggers) continue;
    const fallback = pathBasenameWithoutExtensions(file.file);
    for (const name of names.length ? names : [fallback]) {
      const key = `${file.file}#${name}`;
      const screen = {
        id: stableId('screen', file.file, name),
        name,
        file: file.file,
        module: file.module,
        routes: [],
        triggerIds: [],
      };
      screens.push(screen);
      screenMap.set(key, screen);
    }
  }

  for (const route of frontend.routes) {
    let target = route.component ? screenMap.get(`${route.file}#${route.component}`) : null;
    if (!target && route.component) {
      const routeFile = frontend.files.find((item) => item.file === route.file);
      const importItem = routeFile?.imports.find((item) => item.local === route.component);
      if (importItem?.resolvedFile) {
        target = screenMap.get(`${importItem.resolvedFile}#${route.component}`) ||
          screens.find((screen) => screen.file === importItem.resolvedFile);
      }
    }
    if (!target) target = screens.find((screen) => screen.file === route.file);
    if (target) target.routes.push(route.path);
  }
  for (const trigger of frontend.triggers) {
    const target = screenMap.get(`${trigger.file}#${trigger.screen}`) || screens.find((screen) => screen.file === trigger.file);
    if (target) {
      target.triggerIds.push(trigger.id);
      trigger.route = target.routes[0] || '';
    }
  }
  for (const screen of screens) {
    screen.routes = unique(screen.routes);
    screen.triggerIds = unique(screen.triggerIds);
  }
  frontend.screens = screens;
}

function analyzeFrontend(files, config) {
  const jsFiles = files.filter((file) => file.kind === 'javascript');
  const fileSet = new Set(jsFiles.map((file) => file.relative));
  const result = { files: [], functions: [], apiCalls: [], triggers: [], routes: [], screens: [] };
  for (const file of jsFiles) {
    const functions = extractFunctions(file);
    const imports = extractImports(file).map((item) => ({
      ...item,
      resolvedFile: resolveImportSource(file, item.source, fileSet, config),
    }));
    const apiCalls = extractApiCalls(file, functions);
    const triggers = extractTriggers(file, functions);
    const routes = extractRoutes(file);
    const hookAliases = extractHookAliases(file);
    result.files.push({ file: file.relative, module: file.module, imports, functions, hookAliases, _text: file.text });
    result.functions.push(...functions);
    result.apiCalls.push(...apiCalls);
    result.triggers.push(...triggers);
    result.routes.push(...routes);
  }
  linkTriggers(result, config);
  buildScreens(result);
  return result;
}

module.exports = {
  analyzeFrontend,
  extractFunctions,
  extractApiCalls,
  extractTriggers,
  extractRoutes,
  resolveImportSource,
};
