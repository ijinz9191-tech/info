'use strict';

const { lineNumberAt, excerptAt, stableId, unique } = require('../core/text');

function looksLikeKubernetesYaml(file) {
  if (!['.yml', '.yaml'].includes(file.extension)) return false;
  return /(^|\n)\s*apiVersion\s*:/m.test(file.text) && /(^|\n)\s*kind\s*:/m.test(file.text);
}

function splitYamlDocuments(text) {
  const documents = [];
  let offset = 0;
  const regex = /^---\s*$/gm;
  let match;
  let start = 0;
  while ((match = regex.exec(text))) {
    if (match.index > start) documents.push({ text: text.slice(start, match.index), offset: start });
    start = regex.lastIndex;
  }
  if (start < text.length) documents.push({ text: text.slice(start), offset: start });
  return documents.filter((doc) => doc.text.trim());
}

function scalarAt(doc, key) {
  const regex = new RegExp(`^\\s*${key.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\$&')}\\s*:\\s*["']?([^"'\\s#]+)["']?`, 'm');
  return regex.exec(doc)?.[1] || '';
}

function addReference(references, file, doc, docOffset, match, category, key, value, action, severity = 'required') {
  const absoluteIndex = docOffset + match.index;
  references.push({
    id: stableId('k8sref', file.relative, category, key, value, absoluteIndex),
    category,
    key,
    value,
    action,
    severity,
    module: file.module,
    source: { file: file.relative, line: lineNumberAt(file.text, absoluteIndex), excerpt: excerptAt(file.text, absoluteIndex) },
  });
}

function analyzeManifestDocument(file, document) {
  const references = [];
  const doc = document.text;
  const kind = scalarAt(doc, 'kind');
  const nameMatch = /(^|\n)\s*name\s*:\s*["']?([^"'\s#]+)["']?/m.exec(doc);
  const namespaceMatch = /(^|\n)\s*namespace\s*:\s*["']?([^"'\s#]+)["']?/m.exec(doc);
  const resource = {
    id: stableId('resource', file.relative, document.offset, kind, nameMatch?.[2] || ''),
    kind,
    name: nameMatch?.[2] || '',
    namespace: namespaceMatch?.[2] || '',
    module: file.module,
    source: { file: file.relative, line: lineNumberAt(file.text, document.offset), excerpt: `${kind || 'Unknown'} ${nameMatch?.[2] || ''}`.trim() },
  };

  if (namespaceMatch) addReference(references, file, doc, document.offset, namespaceMatch, 'kubernetes-namespace', 'namespace', namespaceMatch[2], '신규 클러스터의 네임스페이스 존재 여부와 명칭을 확인하고 필요 시 값 변경');

  const patterns = [
    { category: 'image-registry', key: 'image', regex: /(^|\n)\s*image\s*:\s*["']?([^"'\s#]+)["']?/gm, valueGroup: 2, action: '신규 클러스터가 접근 가능한 레지스트리·프로젝트·태그로 변경하고 imagePullSecret 확인' },
    { category: 'image-pull-secret', key: 'imagePullSecrets.name', regex: /(^|\n)\s*-?\s*name\s*:\s*["']?([^"'\s#]+)["']?[\s\S]{0,80}?(?=\n\s*[^-\s]|$)/gm, valueGroup: 2, action: '신규 클러스터에 동일한 이미지 풀 시크릿을 생성하거나 참조명 변경', conditional: (m) => /imagePullSecrets/i.test(doc.slice(Math.max(0, m.index - 120), m.index + 120)) },
    { category: 'service-account', key: 'serviceAccountName', regex: /(^|\n)\s*serviceAccountName\s*:\s*["']?([^"'\s#]+)["']?/gm, valueGroup: 2, action: '신규 클러스터의 ServiceAccount와 RoleBinding 존재 여부 확인' },
    { category: 'storage-class', key: 'storageClassName', regex: /(^|\n)\s*storageClassName\s*:\s*["']?([^"'\s#]+)["']?/gm, valueGroup: 2, action: '신규 클러스터에서 제공되는 StorageClass로 변경하거나 동일 이름 생성' },
    { category: 'ingress-host', key: 'host', regex: /(^|\n)\s*-?\s*host\s*:\s*["']?([^"'\s#]+)["']?/gm, valueGroup: 2, action: '신규 Ingress/LB/DNS 도메인으로 변경하고 인증서 SAN 확인' },
    { category: 'cluster-ip', key: 'clusterIP', regex: /(^|\n)\s*clusterIP\s*:\s*["']?([^"'\s#]+)["']?/gm, valueGroup: 2, action: '고정 clusterIP 사용을 피하고 신규 클러스터에서 재할당되도록 검토', severity: 'review' },
    { category: 'external-name', key: 'externalName', regex: /(^|\n)\s*externalName\s*:\s*["']?([^"'\s#]+)["']?/gm, valueGroup: 2, action: '신규 클러스터 네트워크에서 접근 가능한 대상 DNS로 변경' },
    { category: 'configmap-reference', key: 'configMapRef/name', regex: /\bconfigMap(?:Key)?Ref\s*:\s*\n\s*name\s*:\s*["']?([^"'\s#]+)["']?/gm, valueGroup: 1, action: '신규 클러스터에 ConfigMap을 이관하고 참조명·키 일치 확인' },
    { category: 'secret-reference', key: 'secretRef/name', regex: /\bsecret(?:Key)?Ref\s*:\s*\n\s*name\s*:\s*["']?([^"'\s#]+)["']?/gm, valueGroup: 1, action: '신규 클러스터에 Secret을 안전하게 재생성하고 참조명·키 일치 확인' },
    { category: 'node-selector', key: 'nodeSelector', regex: /(^|\n)\s*nodeSelector\s*:\s*\n([\s\S]{0,500}?)(?=\n\s{0,6}[A-Za-z_-]+\s*:|$)/gm, valueGroup: 2, action: '신규 클러스터 노드 라벨과 일치하도록 nodeSelector 변경', severity: 'review' },
    { category: 'affinity', key: 'affinity', regex: /(^|\n)\s*affinity\s*:/gm, valueGroup: 0, action: '신규 클러스터의 노드·존 라벨 기준과 affinity 규칙 호환성 확인', severity: 'review' },
    { category: 'toleration', key: 'tolerations', regex: /(^|\n)\s*tolerations\s*:/gm, valueGroup: 0, action: '신규 클러스터 taint와 toleration 규칙 호환성 확인', severity: 'review' },
  ];

  for (const pattern of patterns) {
    let match;
    while ((match = pattern.regex.exec(doc))) {
      if (pattern.conditional && !pattern.conditional(match)) continue;
      const value = pattern.valueGroup === 0 ? pattern.key : String(match[pattern.valueGroup] || '').trim().replace(/\s+/g, ' ').slice(0, 300);
      addReference(references, file, doc, document.offset, match, pattern.category, pattern.key, value, pattern.action, pattern.severity || 'required');
    }
  }

  const envLiteralRegex = /(^|\n)\s*-\s*name\s*:\s*([A-Za-z0-9_]+)\s*\n\s*value\s*:\s*["']?([^"'\n#]+)["']?/gm;
  let envMatch;
  while ((envMatch = envLiteralRegex.exec(doc))) {
    const key = envMatch[2];
    const value = envMatch[3].trim();
    if (/(cluster|namespace|host|ip|url|uri|endpoint|context|registry|broker|datasource|mongo|redis|oracle|elastic|kafka)/i.test(`${key} ${value}`)) {
      addReference(references, file, doc, document.offset, envMatch, 'environment-value', key, value, '신규 클러스터의 연결 정보·이름 체계에 맞게 환경변수 값을 변경');
    }
  }

  return { resource, references };
}

function analyzeManifests(files) {
  const resources = [];
  const references = [];
  for (const file of files) {
    if (!looksLikeKubernetesYaml(file)) continue;
    for (const document of splitYamlDocuments(file.text)) {
      const analyzed = analyzeManifestDocument(file, document);
      resources.push(analyzed.resource);
      references.push(...analyzed.references);
    }
  }
  const seen = new Set();
  return {
    resources,
    references: references.filter((reference) => {
      const key = `${reference.category}|${reference.value}|${reference.source.file}|${reference.source.line}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    }),
  };
}

module.exports = { analyzeManifests, looksLikeKubernetesYaml, splitYamlDocuments };
