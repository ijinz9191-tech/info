'use strict';

function parseArgs(argv) {
  const args = { workspace: process.cwd(), config: '', clean: false, quiet: false };
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];
    if (token === '--workspace' || token === '-w') args.workspace = argv[++i];
    else if (token === '--config' || token === '-c') args.config = argv[++i];
    else if (token === '--clean') args.clean = true;
    else if (token === '--quiet') args.quiet = true;
    else if (token === '--help' || token === '-h') args.help = true;
    else throw new Error(`알 수 없는 인자: ${token}`);
  }
  return args;
}

function helpText() {
  return `Workspace Source Trace Skill\n\n` +
    `사용법:\n` +
    `  node scripts/run.js --workspace <워크스페이스> [--config <config.yaml>] [--clean]\n\n` +
    `규칙:\n` +
    `  - 스킬 폴더와 config 파일은 워크스페이스 내부에 있어야 합니다.\n` +
    `  - 심볼릭 링크는 따라가지 않습니다.\n` +
    `  - 네트워크, 외부 명령, 실제 DB 접속을 사용하지 않습니다.\n`;
}

module.exports = { parseArgs, helpText };
