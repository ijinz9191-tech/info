'use strict';

const fs = require('fs');
const path = require('path');
const { WorkspaceGuard, WorkspaceBoundaryError } = require('./core/workspace-guard');
const { scanWorkspace } = require('./core/scanner');
const { loadConfig, loadOptionalYaml } = require('./config');
const { analyzeFrontend } = require('./analyzers/frontend-analyzer');
const { analyzeJava } = require('./analyzers/java-analyzer');
const { analyzeSqlFiles, mergeDatabaseObjects } = require('./analyzers/sql-analyzer');
const { analyzeConfigurations, assignConnectionGroups } = require('./analyzers/config-analyzer');
const { analyzeManifests } = require('./analyzers/manifest-analyzer');
const { analyzeMigration } = require('./analyzers/migration-analyzer');
const { correlate } = require('./analyzers/correlator');
const { writeReports, publicView } = require('./report/writers');
const { updateMemo, readMemoContext } = require('./report/memo');
const { sha256, unique } = require('./core/text');

function enforceImmutableSafety(config) {
  const violations = [];
  if (config.workspace.strictBoundary === false) violations.push('workspace.strictBoundary=false');
  if (config.workspace.requireSkillInsideWorkspace === false) violations.push('workspace.requireSkillInsideWorkspace=false');
  if (config.workspace.followSymlinks === true) violations.push('workspace.followSymlinks=true');
  if (config.workspace.allowExternalReads === true) violations.push('workspace.allowExternalReads=true');
  if (config.workspace.allowNetwork === true) violations.push('workspace.allowNetwork=true');
  if (config.workspace.allowChildProcess === true) violations.push('workspace.allowChildProcess=true');
  if (violations.length) {
    throw new Error(`완화할 수 없는 안전 규칙 위반: ${violations.join(', ')}`);
  }
}

function resolveRelationalEngine(object) {
  if (object.engine !== 'relational-unknown') return object;
  const groups = object.connectionGroups || [];
  const engines = unique(groups.map((group) => group.engine).filter((engine) => ['oracle', 'postgresql', 'mysql', 'mariadb', 'sqlserver'].includes(engine)));
  if (engines.length === 1) return { ...object, engine: engines[0], engineResolution: 'from-connection-group' };
  return object;
}

function assignAllConnections(objects, connections) {
  return assignConnectionGroups(objects, connections).map(resolveRelationalEngine);
}

function objectIdentity(object) {
  return object.id || [object.engine, object.kind, object.fullName, object.ownerClass, object.ownerMethod, object.source?.file, object.source?.line].join('|');
}

function relinkEndpointObjects(backend, assignedObjects) {
  const byId = new Map(assignedObjects.map((object) => [objectIdentity(object), object]));
  for (const endpoint of backend.endpoints) {
    endpoint.databaseObjects = (endpoint.databaseObjects || []).map((object) => {
      const resolved = byId.get(objectIdentity(object));
      if (resolved) return resolved;
      const assigned = assignAllConnections([object], backend.__connections || [])[0];
      byId.set(objectIdentity(assigned), assigned);
      return assigned;
    });
    endpoint.databaseObjectIds = endpoint.databaseObjects.map(objectIdentity);
  }
}

function canonicalize(value) {
  if (Array.isArray(value)) return value.map(canonicalize);
  if (!value || typeof value !== 'object') return value;
  const result = {};
  for (const key of Object.keys(value).filter((item) => !item.startsWith('__')).sort()) result[key] = canonicalize(value[key]);
  return result;
}

function buildControlFingerprint(config, clusterMap) {
  const controls = {
    scan: config.scan,
    analysis: config.analysis,
    migration: { ...config.migration, mappingFile: '[workspace-internal-mapping-file]' },
    clusterMap,
  };
  return sha256(JSON.stringify(canonicalize(controls))).slice(0, 24);
}

function buildWorkspaceFingerprint(files, controlFingerprint = '') {
  const source = files
    .map((file) => `${file.relative}:${file.hash}`)
    .sort()
    .join('\n');
  return sha256(`${source}\ncontrol:${controlFingerprint}`).slice(0, 24);
}

function buildAnalysis({ guard, scan, frontend, backend, configuration, manifests, databases, migration, flows, warnings, memoContext, controlFingerprint }) {
  const workspaceFingerprint = buildWorkspaceFingerprint(scan.files, controlFingerprint);
  const previousFingerprint = memoContext?.previousWorkspaceFingerprint || '';
  const comparison = previousFingerprint ? (previousFingerprint === workspaceFingerprint ? 'unchanged' : 'changed') : 'first-analysis';
  return {
    meta: {
      generatedAt: new Date().toISOString(),
      workspaceName: path.basename(guard.root),
      workspaceRoot: '.',
      workspaceFingerprint,
      controlFingerprint,
      fileCount: scan.files.length,
      moduleCount: scan.modules.length,
      modules: scan.modules,
      safety: {
        workspaceOnly: true,
        externalReads: false,
        networkUsed: false,
        childProcessUsed: false,
        symlinksFollowed: false,
      },
    },
    memory: {
      memoExists: memoContext?.exists === true,
      memoPath: memoContext?.path || 'memo.md',
      previousAnalysisAt: memoContext?.previousAnalysisAt || '',
      previousWorkspaceFingerprint: previousFingerprint,
      comparison,
      manualLineCount: memoContext?.manualLineCount || 0,
    },
    frontend,
    backend,
    databases,
    manifests,
    migration,
    endpointFlows: flows,
    warnings,
  };
}

async function runAnalysis(options) {
  const skillRoot = path.resolve(options.skillRoot);
  const guard = new WorkspaceGuard(options.workspace, { strict: true, followSymlinks: false });
  guard.assertSkillInside(skillRoot);
  const configPath = options.config ? guard.resolveInside(options.config, { mustExist: true }) : path.join(skillRoot, 'config.yaml');
  const config = loadConfig(guard, skillRoot, configPath);
  enforceImmutableSafety(config);
  const memoContext = readMemoContext(guard, config);

  const outputDir = guard.resolveInside(config.workspace.outputDir || '.workspace-analysis', { mustExist: false });
  if (options.clean && fs.existsSync(outputDir)) guard.removeTree(outputDir);

  const scan = scanWorkspace(guard, config, skillRoot);
  const configuration = analyzeConfigurations(scan.files, config);
  const manifests = analyzeManifests(scan.files);
  const frontend = analyzeFrontend(scan.files, config);
  const backend = analyzeJava(scan.files, config);
  const standaloneSql = analyzeSqlFiles(scan.files);

  const allDbObjectsRaw = mergeDatabaseObjects([...backend.databaseObjects, ...standaloneSql.objects]);
  const allDbObjects = assignAllConnections(allDbObjectsRaw, configuration.connections);
  backend.__connections = configuration.connections;
  backend.databaseObjects = allDbObjects.filter((object) => !standaloneSql.objects.some((sqlObject) => sqlObject.id === object.id) || object.ownerClass);
  relinkEndpointObjects(backend, allDbObjects);
  delete backend.__connections;

  const mappingFile = config.migration.mappingFile || path.join(skillRoot, 'cluster-map.yaml');
  const clusterMap = loadOptionalYaml(guard, mappingFile, { SKILL_ROOT: skillRoot, WORKSPACE_ROOT: guard.root });
  const migration = analyzeMigration({ files: scan.files, configuration, manifests, backend: { ...backend, databaseObjects: allDbObjects }, clusterMap, config });
  const controlFingerprint = buildControlFingerprint(config, clusterMap);
  const flows = correlate({ frontend, backend, migration, config });

  const warnings = [...scan.warnings, ...(backend.warnings || [])];
  const databases = {
    connections: configuration.connections,
    objects: allDbObjects,
    standaloneSqlObjects: assignAllConnections(standaloneSql.objects, configuration.connections),
  };
  const analysis = buildAnalysis({ guard, scan, frontend, backend, configuration, manifests, databases, migration, flows, warnings, memoContext, controlFingerprint });

  const reportResult = writeReports(guard, analysis, config);
  let memoPath = '';
  if (config.reports.updateMemo !== false) memoPath = updateMemo(guard, publicView(analysis), config, skillRoot);
  const auditPath = path.join(outputDir, 'boundary-audit.json');
  guard.writeJson(auditPath, {
    workspaceRoot: '.',
    strictBoundary: true,
    externalReads: false,
    networkUsed: false,
    childProcessUsed: false,
    symlinksFollowed: false,
    skippedSymlinks: guard.audit.skippedSymlinks,
    deniedAttempts: guard.audit.denied.map((item) => ({ message: item.message, candidate: '[redacted-boundary-attempt]' })),
    readCount: guard.audit.reads,
    writeCountBeforeAudit: guard.audit.writes,
  });
  reportResult.files.push(guard.relative(auditPath));

  return { analysis: publicView(analysis), reportResult, memoPath, guardAudit: guard.audit };
}

module.exports = {
  runAnalysis,
  enforceImmutableSafety,
  assignAllConnections,
  WorkspaceBoundaryError,
};
