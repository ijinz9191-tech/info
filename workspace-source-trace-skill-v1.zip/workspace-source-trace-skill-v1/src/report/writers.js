'use strict';

const path = require('path');
const {
  escapeMarkdown,
  csvCell,
  unique,
  sha256,
  redactSecret,
} = require('../core/text');

function publicView(value) {
  if (typeof value === 'string') return redactSecret(value);
  if (Array.isArray(value)) return value.map(publicView);
  if (!value || typeof value !== 'object') return value;
  const result = {};
  for (const [key, child] of Object.entries(value)) {
    if (key.startsWith('_') || key === 'absolute' || key === 'text') continue;
    result[key] = publicView(child);
  }
  return result;
}

function sourceLink(source) {
  if (!source?.file) return '-';
  return `\`${source.file}:${source.line || 1}\``;
}

function objectDisplay(object) {
  const engine = object.engine || 'unknown';
  const name = object.fullName || object.name || 'unknown';
  const operations = (object.operations || []).join(', ') || 'ACCESS';
  const columns = (object.columns || []).length ? ` / columns: ${(object.columns || []).join(', ')}` : '';
  return `${engine} ${object.kind || 'object'} \`${name}\` / ${operations}${columns}`;
}

function renderSummary(analysis) {
  const meta = analysis.meta;
  const lines = [
    '# Workspace Source Trace Summary',
    '',
    `- 분석 시각: ${meta.generatedAt}`,
    `- 워크스페이스: \`${meta.workspaceName}\``,
    `- 워크스페이스 지문: \`${meta.workspaceFingerprint}\``,
    `- 분석 파일: ${meta.fileCount}개 / 모듈: ${meta.moduleCount}개`,
    `- React 화면: ${analysis.frontend.screens.length}개 / 트리거: ${analysis.frontend.triggers.length}개 / API 호출: ${analysis.frontend.apiCalls.length}개`,
    `- Spring·Vert.x 엔드포인트: ${analysis.backend.endpoints.length}개`,
    `- 엔드포인트 흐름: ${analysis.endpointFlows.length}개`,
    `- DB 객체: ${analysis.databases.objects.length}개 / 연결 그룹: ${analysis.databases.connections.length}개`,
    `- 클러스터 이전 후보: ${analysis.migration.summary.total}개 (필수 ${analysis.migration.summary.required}, 검토 ${analysis.migration.summary.review})`,
    `- 이전값→신규값 매핑: ${analysis.migration.mappingConfigured ? '설정됨' : '미설정 — 변경 위치는 제시하지만 목표값은 확정하지 않음'}`,
    `- memo 연속성: ${analysis.memory?.comparison || 'first-analysis'}${analysis.memory?.previousAnalysisAt ? ` / 이전 분석 ${analysis.memory.previousAnalysisAt}` : ''}`,
    '',
    '## 분석 원칙',
    '',
    '- 워크스페이스 내부 파일만 읽었으며 심볼릭 링크는 따라가지 않았다.',
    '- 네트워크, 웹 검색, 실제 DB·클러스터 연결, 외부 명령 실행을 사용하지 않았다.',
    '- 결과는 정적 소스 증거에 기반하며 확정할 수 없는 연결은 `unresolved` 또는 `ambiguous`로 표시했다.',
    '',
    '## 주요 산출물',
    '',
    '- `endpoint-catalog.md`: 화면·버튼·자동조회부터 API, 백엔드 호출, DB까지의 흐름',
    '- `database-catalog.md`: DB 엔진 → IP/호스트·프로필 그룹 → 테이블·컬렉션·키·인덱스',
    '- `cluster-migration.md`: 클러스터 이전 시 실제 변경 위치와 DB 컬럼 후보',
    '- `unresolved.md`: 소스만으로 확정하지 못한 항목',
    '- `analysis.json`: 전체 구조화 데이터',
    '',
  ];
  if (analysis.warnings.length) {
    lines.push('## 경고', '');
    for (const warning of analysis.warnings.slice(0, 200)) lines.push(`- ${warning.path ? `\`${warning.path}\`: ` : ''}${warning.message || warning.type}`);
    lines.push('');
  }
  return lines.join('\n');
}

function renderEndpointCatalog(analysis) {
  const lines = [
    '# Endpoint Deep Analysis Catalog',
    '',
    '> 각 항목은 워크스페이스 내부 증거만으로 연결한 화면 → 트리거 → 프런트 API → Spring/Vert.x → DB 흐름이다.',
    '',
  ];
  for (const flow of analysis.endpointFlows) {
    lines.push(`## ${flow.method} ${flow.path}`, '');
    lines.push(`- 흐름 ID: \`${flow.id}\``);
    lines.push(`- 신뢰도: **${flow.confidence}** / 매칭 점수: ${flow.matchScore}`);
    lines.push(`- 유형: ${flow.sourceKind}`);
    lines.push('');

    lines.push('### 화면·버튼·자동조회', '');
    if (!flow.frontendTriggers.length) lines.push('- 연결된 React 트리거를 찾지 못함.');
    for (const trigger of flow.frontendTriggers) {
      lines.push(`- **${escapeMarkdown(trigger.screen)}** ${trigger.route ? `(${escapeMarkdown(trigger.route)})` : ''} → ${escapeMarkdown(trigger.label)} / ${trigger.event} / ${trigger.mode} / ${sourceLink(trigger.source)}`);
      if (trigger.callChain?.length) {
        const resolved = trigger.callChain.filter((step) => step.status === 'resolved').map((step) => step.to);
        if (resolved.length) lines.push(`  - 프런트 호출 체인: ${resolved.map((item) => `\`${item}\``).join(' → ')}`);
      }
    }
    lines.push('');

    lines.push('### 프런트엔드 API 호출', '');
    if (!flow.frontendCalls.length) lines.push('- 직접 호출 증거 없음.');
    for (const call of flow.frontendCalls) {
      lines.push(`- \`${call.client}.${call.method}\` → \`${call.path}\` / owner: \`${call.ownerFunction || 'unresolved'}\` / ${sourceLink(call.source)}`);
    }
    lines.push('');

    lines.push('### 백엔드 엔드포인트·호출 체인', '');
    if (!flow.backendEndpoints.length) lines.push('- 일치하는 Spring/Vert.x 엔드포인트를 찾지 못함.');
    for (const endpoint of flow.backendEndpoints) {
      lines.push(`- **${endpoint.framework}** \`${endpoint.method} ${endpoint.path}\` → \`${endpoint.className}#${endpoint.handler}\` / ${sourceLink(endpoint.source)}`);
      if (endpoint.callChain?.length) {
        for (const step of endpoint.callChain) lines.push(`  - ${'  '.repeat(Math.min(step.depth || 0, 8))}\`${step.from}\` → \`${step.to}\`${step.terminal ? ` (${step.terminal})` : ''}`);
      }
    }
    lines.push('');

    lines.push('### 사용하는 DB 객체', '');
    if (!flow.databaseObjects.length) lines.push('- 이 흐름에서 DB 객체 사용 증거를 찾지 못함.');
    for (const object of flow.databaseObjects) {
      lines.push(`- ${objectDisplay(object)} / via: ${object.via} / ${sourceLink(object.source)}`);
      if (object.connectionGroups?.length) {
        for (const group of object.connectionGroups) lines.push(`  - 연결 그룹: \`${group.title}\` (${object.connectionResolution})`);
      } else {
        lines.push(`  - 연결 그룹: \`unresolved\``);
      }
    }
    lines.push('');

    lines.push('### 클러스터 이전 변경점', '');
    if (!flow.migrationCandidates.length) lines.push('- 이 흐름에 직접 연결되는 변경 후보를 찾지 못함.');
    for (const candidate of flow.migrationCandidates.slice(0, 100)) {
      lines.push(`- [${candidate.severity}] **${candidate.category}** — ${escapeMarkdown(candidate.exactChange)} / ${sourceLink(candidate.source)}`);
      if (candidate.databaseObject) lines.push(`  - DB: \`${candidate.databaseObject.name}.${candidate.databaseObject.column || ''}\``);
    }
    lines.push('');

    lines.push('### 미해결 항목', '');
    if (!flow.unresolved.length) lines.push('- 없음.');
    for (const item of flow.unresolved.slice(0, 100)) lines.push(`- ${escapeMarkdown(item.message || `${item.reason}: ${item.target}`)}`);
    lines.push('', '---', '');
  }
  return lines.join('\n');
}

function groupDatabaseObjects(objects, connections) {
  const engines = new Map();
  for (const connection of connections || []) {
    const engine = connection.engine || 'unknown';
    if (!engines.has(engine)) engines.set(engine, new Map());
    const group = {
      id: connection.id,
      title: `${connection.engine} / ${connection.hosts?.length ? connection.hosts.join(',') : 'host-unresolved'} / ${connection.profile}`,
      hosts: connection.hosts || [],
      database: connection.database || '',
      profile: connection.profile || '',
      source: connection.source,
    };
    if (!engines.get(engine).has(group.id)) engines.get(engine).set(group.id, { group, objects: [] });
  }
  for (const object of objects) {
    const engine = object.engine || 'unknown';
    if (!engines.has(engine)) engines.set(engine, new Map());
    const groups = object.connectionGroups?.length ? object.connectionGroups : [{ id: 'unresolved', title: 'host/IP unresolved', hosts: [], profile: '' }];
    for (const group of groups) {
      const groupKey = group.id || group.title;
      if (!engines.get(engine).has(groupKey)) engines.get(engine).set(groupKey, { group, objects: [] });
      engines.get(engine).get(groupKey).objects.push(object);
    }
  }
  return engines;
}

function renderDatabaseCatalog(analysis) {
  const lines = [
    '# Database Catalog',
    '',
    '> DB 엔진별로 분리하고, 같은 엔진 안에서는 소스에서 확인된 IP·호스트·프로필 연결 그룹별로 나눈다.',
    '',
  ];
  const grouped = groupDatabaseObjects(analysis.databases.objects, analysis.databases.connections);
  for (const [engine, groups] of [...grouped.entries()].sort((a, b) => a[0].localeCompare(b[0]))) {
    lines.push(`## ${engine}`, '');
    for (const { group, objects } of groups.values()) {
      const hosts = group.hosts?.length ? group.hosts.join(', ') : 'unresolved';
      lines.push(`### ${escapeMarkdown(group.title || `${engine} / ${hosts}`)}`, '');
      lines.push(`- Host/IP: \`${hosts}\``);
      if (group.database) lines.push(`- Database/Service: \`${group.database}\``);
      if (group.profile) lines.push(`- Profile: \`${group.profile}\``);
      lines.push('');
      const objectMap = new Map();
      for (const object of objects) {
        const key = `${object.kind}|${object.fullName}`;
        if (!objectMap.has(key)) objectMap.set(key, { ...object, operations: [], columns: [], sources: [] });
        const current = objectMap.get(key);
        current.operations = unique([...current.operations, ...(object.operations || [])]);
        current.columns = unique([...current.columns, ...(object.columns || [])]);
        current.sources.push(object.source);
      }
      if (!objectMap.size) {
        lines.push('- 이 연결 그룹을 사용하는 테이블·컬렉션·키·인덱스 증거를 워크스페이스에서 찾지 못함.', '');
      } else {
        lines.push('| 종류 | 객체 | 작업 | 컬럼/필드 | 근거 |', '|---|---|---|---|---|');
        for (const object of [...objectMap.values()].sort((a, b) => a.fullName.localeCompare(b.fullName))) {
          lines.push(`| ${escapeMarkdown(object.kind)} | \`${escapeMarkdown(object.fullName)}\` | ${escapeMarkdown(object.operations.join(', '))} | ${escapeMarkdown(object.columns.join(', '))} | ${object.sources.slice(0, 3).map(sourceLink).join(', ')} |`);
        }
        lines.push('');
      }
    }
  }
  if (!grouped.size) lines.push('- DB 객체를 찾지 못함.', '');
  return lines.join('\n');
}

function renderMigrationReport(analysis) {
  const migration = analysis.migration;
  const lines = [
    '# Cluster Migration Change Plan',
    '',
    `- 변경 후보: ${migration.summary.total}개`,
    `- 필수: ${migration.summary.required}개 / 검토: ${migration.summary.review}개`,
    `- DB 데이터 컬럼 후보: ${migration.summary.databaseData}개`,
    `- DB 스키마 변경 위험: ${migration.summary.databaseSchema}개`,
    `- 목표값이 매핑된 후보: ${migration.summary.mappedTargets}개`,
    '',
  ];
  if (!migration.mappingConfigured) {
    lines.push('> `cluster-map.yaml`의 replacements가 비어 있어 목표값을 임의 추정하지 않았다. 현재 변경 위치·항목·검증 방법만 제시한다.', '');
  }

  const categoryMap = new Map();
  for (const candidate of migration.candidates) {
    if (!categoryMap.has(candidate.category)) categoryMap.set(candidate.category, []);
    categoryMap.get(candidate.category).push(candidate);
  }
  for (const [category, candidates] of categoryMap) {
    lines.push(`## ${category}`, '');
    for (const candidate of candidates) {
      lines.push(`### ${candidate.severity.toUpperCase()} — ${sourceLink(candidate.source)}`, '');
      lines.push(`- 변경: ${escapeMarkdown(candidate.exactChange)}`);
      lines.push(`- 현재값: \`${escapeMarkdown(candidate.currentValue || 'unknown')}\``);
      lines.push(`- 신규값: \`${escapeMarkdown(candidate.targetValue || '미지정')}\``);
      lines.push(`- 근거: ${escapeMarkdown(candidate.reason)}`);
      lines.push(`- 검증: ${escapeMarkdown(candidate.verification)}`);
      if (candidate.databaseObject) {
        lines.push(`- DB 객체: \`${candidate.engine || 'unknown'} / ${candidate.databaseObject.name} / ${candidate.databaseObject.column || ''}\``);
        if (candidate.replacementCandidates?.length) {
          lines.push(`- 적용 후보 매핑: ${candidate.replacementCandidates.map((pair) => `\`${escapeMarkdown(pair.from)} → ${escapeMarkdown(pair.to)}\``).join(', ')}`);
        }
        if (candidate.queryTemplate) lines.push(`- 조회 템플릿: \`${candidate.queryTemplate}\``);
        if (candidate.updateTemplate) lines.push(`- 변경 템플릿: \`${candidate.updateTemplate}\``);
      }
      lines.push('');
    }
  }
  return lines.join('\n');
}

function renderUnresolved(analysis) {
  const lines = ['# Unresolved and Ambiguous Items', ''];
  const items = [];
  for (const flow of analysis.endpointFlows) {
    for (const unresolved of flow.unresolved || []) items.push({ flow: `${flow.method} ${flow.path}`, ...unresolved });
  }
  for (const object of analysis.databases.objects) {
    if (object.connectionResolution !== 'resolved') {
      items.push({ flow: '-', type: 'database-connection', message: `${object.engine} ${object.fullName}: ${object.connectionResolution}` });
    }
  }
  if (!items.length) return `${lines.join('\n')}\n- 없음.\n`;
  lines.push('| 흐름 | 유형 | 내용 |', '|---|---|---|');
  for (const item of items.slice(0, 5000)) lines.push(`| ${escapeMarkdown(item.flow)} | ${escapeMarkdown(item.type || item.reason)} | ${escapeMarkdown(item.message || item.target || JSON.stringify(item))} |`);
  lines.push('');
  return lines.join('\n');
}

function endpointCsv(analysis) {
  const rows = [['flow_id', 'method', 'path', 'confidence', 'screen', 'trigger', 'trigger_mode', 'frontend_source', 'backend_framework', 'backend_handler', 'backend_source', 'db_engine', 'db_object', 'db_operations', 'connection_group', 'migration_count', 'unresolved_count']];
  for (const flow of analysis.endpointFlows) {
    const triggers = flow.frontendTriggers.length ? flow.frontendTriggers : [{}];
    const endpoints = flow.backendEndpoints.length ? flow.backendEndpoints : [{}];
    const objects = flow.databaseObjects.length ? flow.databaseObjects : [{}];
    for (const trigger of triggers) for (const endpoint of endpoints) for (const object of objects) {
      rows.push([
        flow.id, flow.method, flow.path, flow.confidence, trigger.screen || '', trigger.label || '', trigger.mode || '', trigger.source ? `${trigger.source.file}:${trigger.source.line}` : '',
        endpoint.framework || '', endpoint.className ? `${endpoint.className}#${endpoint.handler}` : '', endpoint.source ? `${endpoint.source.file}:${endpoint.source.line}` : '',
        object.engine || '', object.fullName || '', (object.operations || []).join(';'), (object.connectionGroups || []).map((group) => group.title).join(';'),
        flow.migrationCandidates.length, flow.unresolved.length,
      ]);
    }
  }
  return rows.map((row) => row.map(csvCell).join(',')).join('\n') + '\n';
}

function databaseCsv(analysis) {
  const rows = [['engine', 'kind', 'object', 'operations', 'columns', 'connection_resolution', 'connection_groups', 'owner', 'via', 'source']];
  for (const object of analysis.databases.objects) rows.push([
    object.engine, object.kind, object.fullName, (object.operations || []).join(';'), (object.columns || []).join(';'), object.connectionResolution,
    (object.connectionGroups || []).map((group) => group.title).join(';'), object.owner, object.via, object.source ? `${object.source.file}:${object.source.line}` : '',
  ]);
  return rows.map((row) => row.map(csvCell).join(',')).join('\n') + '\n';
}

function migrationCsv(analysis) {
  const rows = [['id', 'severity', 'scope', 'category', 'change_type', 'current_value', 'target_value', 'target_status', 'exact_change', 'engine', 'db_object', 'db_column', 'source', 'verification', 'confidence']];
  for (const candidate of analysis.migration.candidates) rows.push([
    candidate.id, candidate.severity, candidate.scope, candidate.category, candidate.changeType, candidate.currentValue, candidate.targetValue, candidate.targetStatus,
    candidate.exactChange, candidate.engine || '', candidate.databaseObject?.name || '', candidate.databaseObject?.column || '',
    candidate.source ? `${candidate.source.file}:${candidate.source.line}` : '', candidate.verification, candidate.confidence,
  ]);
  return rows.map((row) => row.map(csvCell).join(',')).join('\n') + '\n';
}

function writeReports(guard, analysis, config) {
  const outputDir = guard.resolveInside(config.workspace.outputDir || '.workspace-analysis', { mustExist: false });
  guard.ensureDirectory(outputDir);
  const publicAnalysis = publicView(analysis);
  const written = [];
  function write(name, content) {
    const target = path.join(outputDir, name);
    guard.writeText(target, content);
    written.push(guard.relative(target));
  }
  if (config.reports.writeJson !== false) write('analysis.json', `${JSON.stringify(publicAnalysis, null, 2)}\n`);
  if (config.reports.writeMarkdown !== false) {
    write('summary.md', renderSummary(publicAnalysis));
    write('endpoint-catalog.md', renderEndpointCatalog(publicAnalysis));
    write('database-catalog.md', renderDatabaseCatalog(publicAnalysis));
    write('cluster-migration.md', renderMigrationReport(publicAnalysis));
    write('unresolved.md', renderUnresolved(publicAnalysis));
  }
  if (config.reports.writeCsv !== false) {
    write('endpoint-catalog.csv', endpointCsv(publicAnalysis));
    write('database-catalog.csv', databaseCsv(publicAnalysis));
    write('migration-changes.csv', migrationCsv(publicAnalysis));
  }
  const manifest = {
    generatedAt: analysis.meta.generatedAt,
    workspaceFingerprint: analysis.meta.workspaceFingerprint,
    files: written.map((relative) => {
      const absolute = guard.resolveInside(relative, { mustExist: true });
      return { path: relative, sha256: sha256(guard.readBuffer(absolute)) };
    }),
  };
  write('report-manifest.json', `${JSON.stringify(manifest, null, 2)}\n`);
  return { outputDir: guard.relative(outputDir), files: written };
}

module.exports = {
  writeReports,
  publicView,
  renderSummary,
  renderEndpointCatalog,
  renderDatabaseCatalog,
  renderMigrationReport,
};
