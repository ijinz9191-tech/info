'use strict';

const path = require('path');
const fs = require('fs');
const { escapeMarkdown, unique } = require('../core/text');

const START = '<!-- WORKSPACE-SOURCE-TRACE:START -->';
const END = '<!-- WORKSPACE-SOURCE-TRACE:END -->';

function readMemoContext(guard, config) {
  const memoPath = guard.resolveInside(config.workspace.memoFile || 'memo.md', { mustExist: false });
  if (!fs.existsSync(memoPath)) {
    return {
      exists: false,
      path: guard.relative(memoPath),
      previousAnalysisAt: '',
      previousWorkspaceFingerprint: '',
      manualLineCount: 0,
    };
  }
  const text = guard.readText(memoPath);
  const startIndex = text.indexOf(START);
  const endIndex = text.indexOf(END);
  const generated = startIndex >= 0 && endIndex > startIndex ? text.slice(startIndex, endIndex + END.length) : '';
  const manual = generated ? `${text.slice(0, startIndex)}\n${text.slice(endIndex + END.length)}` : text;
  const analysisMatch = generated.match(/^- 마지막 분석:\s*(.+)$/m);
  const fingerprintMatch = generated.match(/^- 워크스페이스 지문:\s*`([^`]+)`/m);
  const manualLineCount = manual
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line && !line.startsWith('#') && !/^이 파일은|^자동 생성 구간/.test(line)).length;
  return {
    exists: true,
    path: guard.relative(memoPath),
    previousAnalysisAt: analysisMatch?.[1]?.trim() || '',
    previousWorkspaceFingerprint: fingerprintMatch?.[1]?.trim() || '',
    manualLineCount,
  };
}

function generatedMemo(analysis) {
  const lines = [
    START,
    '## 자동 생성 기억',
    '',
    `- 마지막 분석: ${analysis.meta.generatedAt}`,
    `- 워크스페이스 지문: \`${analysis.meta.workspaceFingerprint}\``,
    `- 이전 분석 대비: ${analysis.memory?.comparison || 'first-analysis'}`,
    `- 파일 ${analysis.meta.fileCount}개 / 모듈 ${analysis.meta.moduleCount}개`,
    `- 화면 ${analysis.frontend.screens.length}개 / API 호출 ${analysis.frontend.apiCalls.length}개 / 백엔드 엔드포인트 ${analysis.backend.endpoints.length}개`,
    `- DB 객체 ${analysis.databases.objects.length}개 / 이전 변경 후보 ${analysis.migration.summary.total}개`,
    '',
    '### 화면·엔드포인트 기억',
    '',
  ];
  for (const flow of analysis.endpointFlows.slice(0, 200)) {
    const screens = unique(flow.frontendTriggers.map((trigger) => trigger.screen)).join(', ') || '화면 연결 미확정';
    const db = unique(flow.databaseObjects.map((object) => `${object.engine}:${object.fullName}`)).join(', ') || 'DB 사용 미확정';
    lines.push(`- \`${flow.method} ${flow.path}\` — ${escapeMarkdown(screens)} — ${escapeMarkdown(db)} — confidence=${flow.confidence}`);
  }
  lines.push('', '### DB 연결 그룹 기억', '');
  for (const connection of analysis.databases.connections.slice(0, 200)) {
    const host = connection.hosts?.length ? connection.hosts.join(', ') : 'host-unresolved';
    lines.push(`- ${connection.engine} / module=\`${connection.module}\` / profile=\`${connection.profile}\` / host=\`${host}\` / source=\`${connection.source.file}:${connection.source.line}\``);
  }
  lines.push('', '### 클러스터 이전 핵심 기억', '');
  const required = analysis.migration.candidates.filter((candidate) => candidate.severity === 'required');
  for (const candidate of required.slice(0, 300)) {
    const db = candidate.databaseObject ? ` / DB=${candidate.databaseObject.name}.${candidate.databaseObject.column || ''}` : '';
    lines.push(`- [${candidate.category}] ${escapeMarkdown(candidate.exactChange)}${db} / \`${candidate.source.file}:${candidate.source.line}\``);
  }
  lines.push('', '### 미해결 기억', '');
  const unresolved = [];
  for (const flow of analysis.endpointFlows) for (const item of flow.unresolved || []) unresolved.push(`${flow.method} ${flow.path}: ${item.message || `${item.reason} ${item.target}`}`);
  if (!unresolved.length) lines.push('- 없음.');
  else for (const item of unresolved.slice(0, 300)) lines.push(`- ${escapeMarkdown(item)}`);
  lines.push('', '> 이 구간은 다음 실행 시 갱신된다. 수동 메모는 이 마커 밖에 기록한다.', END, '');
  return lines.join('\n');
}

function updateMemo(guard, analysis, config, skillRoot) {
  const memoPath = guard.resolveInside(config.workspace.memoFile || 'memo.md', { mustExist: false });
  let current = '';
  if (fs.existsSync(memoPath)) current = guard.readText(memoPath);
  else {
    const templatePath = path.join(skillRoot, 'memo.template.md');
    current = fs.existsSync(templatePath) ? guard.readText(templatePath) : '# Workspace Analysis Memo\n\n';
  }
  const generated = generatedMemo(analysis);
  let next;
  const startIndex = current.indexOf(START);
  const endIndex = current.indexOf(END);
  if (startIndex >= 0 && endIndex > startIndex) {
    next = `${current.slice(0, startIndex)}${generated}${current.slice(endIndex + END.length)}`;
  } else {
    next = `${current.trimEnd()}\n\n${generated}`;
  }
  guard.writeText(memoPath, next);
  return guard.relative(memoPath);
}

module.exports = { updateMemo, generatedMemo, readMemoContext, START, END };
