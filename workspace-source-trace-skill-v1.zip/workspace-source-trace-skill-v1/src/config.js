'use strict';

const path = require('path');
const { stripInlineComment, cleanQuoted } = require('./core/text');

function parseScalar(raw) {
  const value = stripInlineComment(String(raw)).trim();
  if (value === '') return '';
  if (value === 'true') return true;
  if (value === 'false') return false;
  if (value === 'null' || value === '~') return null;
  if (/^-?\d+(?:\.\d+)?$/.test(value)) return Number(value);
  if (value.startsWith('[') && value.endsWith(']')) {
    const inner = value.slice(1, -1).trim();
    if (!inner) return [];
    return inner.split(',').map((part) => parseScalar(part));
  }
  return cleanQuoted(value);
}

function findKeySeparator(content) {
  let quote = null;
  let escaped = false;
  for (let i = 0; i < content.length; i += 1) {
    const ch = content[i];
    if (escaped) {
      escaped = false;
      continue;
    }
    if (ch === '\\') {
      escaped = true;
      continue;
    }
    if (quote) {
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'") {
      quote = ch;
      continue;
    }
    if (ch === ':') return i;
  }
  return -1;
}

function tokenizeYaml(text) {
  const tokens = [];
  const lines = text.replace(/^\uFEFF/, '').split(/\r?\n/);
  for (let lineNo = 0; lineNo < lines.length; lineNo += 1) {
    const rawLine = lines[lineNo].replace(/\t/g, '  ');
    if (!rawLine.trim() || rawLine.trimStart().startsWith('#')) continue;
    const uncommented = stripInlineComment(rawLine).replace(/\s+$/, '');
    if (!uncommented.trim()) continue;
    const indent = uncommented.length - uncommented.trimStart().length;
    tokens.push({ indent, content: uncommented.trimStart(), line: lineNo + 1 });
  }
  return tokens;
}

function parseYaml(text) {
  const tokens = tokenizeYaml(text);

  function parseBlock(startIndex, indent) {
    if (startIndex >= tokens.length) return { value: {}, next: startIndex };
    const isArray = tokens[startIndex].indent === indent && tokens[startIndex].content.startsWith('- ');
    const value = isArray ? [] : {};
    let index = startIndex;

    while (index < tokens.length) {
      const token = tokens[index];
      if (token.indent < indent) break;
      if (token.indent > indent) {
        throw new Error(`YAML 들여쓰기가 올바르지 않습니다. line=${token.line}`);
      }

      if (isArray) {
        if (!token.content.startsWith('- ')) break;
        const itemText = token.content.slice(2).trim();
        if (!itemText) {
          const nextToken = tokens[index + 1];
          if (!nextToken || nextToken.indent <= indent) {
            value.push(null);
            index += 1;
          } else {
            const child = parseBlock(index + 1, nextToken.indent);
            value.push(child.value);
            index = child.next;
          }
          continue;
        }
        const separator = findKeySeparator(itemText);
        if (separator > 0) {
          const object = {};
          const key = cleanQuoted(itemText.slice(0, separator).trim());
          const rest = itemText.slice(separator + 1).trim();
          object[key] = rest ? parseScalar(rest) : {};
          index += 1;
          if (index < tokens.length && tokens[index].indent > indent) {
            const child = parseBlock(index, tokens[index].indent);
            if (rest === '' && Object.keys(child.value).length && !Array.isArray(child.value)) {
              object[key] = child.value;
            } else if (!Array.isArray(child.value)) {
              Object.assign(object, child.value);
            }
            index = child.next;
          }
          value.push(object);
        } else {
          value.push(parseScalar(itemText));
          index += 1;
        }
      } else {
        if (token.content.startsWith('- ')) break;
        const separator = findKeySeparator(token.content);
        if (separator < 0) throw new Error(`YAML 키 구문을 해석할 수 없습니다. line=${token.line}`);
        const key = cleanQuoted(token.content.slice(0, separator).trim());
        const rest = token.content.slice(separator + 1).trim();
        if (rest) {
          value[key] = parseScalar(rest);
          index += 1;
        } else {
          const nextToken = tokens[index + 1];
          if (!nextToken || nextToken.indent <= indent) {
            value[key] = {};
            index += 1;
          } else {
            const child = parseBlock(index + 1, nextToken.indent);
            value[key] = child.value;
            index = child.next;
          }
        }
      }
    }
    return { value, next: index };
  }

  if (!tokens.length) return {};
  return parseBlock(0, tokens[0].indent).value;
}

function expandEnvironment(value, env) {
  if (Array.isArray(value)) return value.map((item) => expandEnvironment(item, env));
  if (value && typeof value === 'object') {
    const result = {};
    for (const [key, child] of Object.entries(value)) result[key] = expandEnvironment(child, env);
    return result;
  }
  if (typeof value !== 'string') return value;
  return value.replace(/\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?\}/g, (_match, name, fallback) => {
    if (Object.prototype.hasOwnProperty.call(env, name) && env[name] !== '') return env[name];
    return fallback !== undefined ? fallback : `\${${name}}`;
  });
}

function deepMerge(base, override) {
  if (Array.isArray(override)) return override.slice();
  if (!override || typeof override !== 'object') return override;
  const result = { ...(base && typeof base === 'object' && !Array.isArray(base) ? base : {}) };
  for (const [key, value] of Object.entries(override)) {
    if (value && typeof value === 'object' && !Array.isArray(value)) result[key] = deepMerge(result[key], value);
    else result[key] = Array.isArray(value) ? value.slice() : value;
  }
  return result;
}

const DEFAULTS = {
  version: 1,
  workspace: {
    strictBoundary: true,
    requireSkillInsideWorkspace: true,
    followSymlinks: false,
    allowExternalReads: false,
    allowNetwork: false,
    allowChildProcess: false,
    outputDir: '.workspace-analysis',
    memoFile: 'memo.md',
  },
  scan: {
    maxFileBytes: 3145728,
    maxDepth: 60,
    includeExtensions: ['.js', '.jsx', '.ts', '.tsx', '.java', '.kt', '.xml', '.sql', '.yml', '.yaml', '.properties', '.env', '.json'],
    includeFileNames: ['Dockerfile', 'Jenkinsfile', 'pom.xml', 'package.json'],
    ignoreDirectories: ['.git', 'node_modules', 'target', 'build', 'dist', '.workspace-analysis'],
    ignorePaths: [],
    aliasRoots: {},
  },
  analysis: {
    maxCallDepth: 10,
    maxFlowNodes: 250,
    maxMigrationCandidates: 5000,
    endpointMatchMinimumScore: 45,
    redactSecrets: true,
    includeEvidenceExcerpt: true,
    databaseColumnKeywords: ['cluster', 'namespace', 'host', 'ip', 'endpoint', 'url', 'region', 'context'],
  },
  migration: {
    mappingFile: 'cluster-map.yaml',
    detectHardcodedIps: true,
    detectUrls: true,
    detectServiceDns: true,
    detectKubernetesReferences: true,
    detectDatabaseValueColumns: true,
  },
  reports: {
    writeJson: true,
    writeMarkdown: true,
    writeCsv: true,
    updateMemo: true,
  },
};

function loadConfig(guard, skillRoot, configPath) {
  const candidate = configPath || path.join(skillRoot, 'config.yaml');
  const absolute = guard.resolveInside(candidate, { mustExist: true });
  const parsed = parseYaml(guard.readText(absolute));
  const merged = deepMerge(DEFAULTS, parsed);
  const env = { ...process.env, WORKSPACE_ROOT: guard.root, SKILL_ROOT: skillRoot };
  const expanded = expandEnvironment(merged, env);
  expanded.__configPath = absolute;
  expanded.__skillRoot = skillRoot;
  return expanded;
}

function loadOptionalYaml(guard, candidate, env = {}) {
  if (!candidate) return {};
  const absolute = guard.resolveInside(candidate, { mustExist: false });
  const fs = require('fs');
  if (!fs.existsSync(absolute)) return {};
  return expandEnvironment(parseYaml(guard.readText(absolute)), { ...process.env, ...env });
}

module.exports = {
  parseYaml,
  loadConfig,
  loadOptionalYaml,
  expandEnvironment,
  deepMerge,
  DEFAULTS,
};
