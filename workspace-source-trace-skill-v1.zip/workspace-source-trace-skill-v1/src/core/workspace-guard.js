'use strict';

const fs = require('fs');
const path = require('path');
const { toPosixRelative } = require('./text');

class WorkspaceBoundaryError extends Error {
  constructor(message, details = {}) {
    super(message);
    this.name = 'WorkspaceBoundaryError';
    this.details = details;
  }
}

function lexicalInside(root, candidate) {
  const relative = path.relative(root, candidate);
  return relative === '' || (!relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative));
}

class WorkspaceGuard {
  constructor(workspaceRoot, options = {}) {
    const requested = path.resolve(workspaceRoot || process.cwd());
    if (!fs.existsSync(requested)) {
      throw new WorkspaceBoundaryError('워크스페이스가 존재하지 않습니다.', { requested });
    }
    const stat = fs.lstatSync(requested);
    if (!stat.isDirectory() || stat.isSymbolicLink()) {
      throw new WorkspaceBoundaryError('워크스페이스 루트는 심볼릭 링크가 아닌 실제 디렉터리여야 합니다.', { requested });
    }
    this.root = fs.realpathSync.native(requested);
    this.strict = options.strict !== false;
    this.followSymlinks = false;
    this.audit = {
      denied: [],
      skippedSymlinks: [],
      reads: 0,
      writes: 0,
    };
  }

  relative(candidate) {
    return toPosixRelative(this.root, path.resolve(candidate));
  }

  resolveInside(candidate, options = {}) {
    const base = options.base ? this.resolveInside(options.base, { mustExist: true }) : this.root;
    const absolute = path.isAbsolute(candidate) ? path.normalize(candidate) : path.resolve(base, candidate);
    if (!lexicalInside(this.root, absolute)) {
      this.#deny('워크스페이스 외부 경로 접근이 차단되었습니다.', absolute);
    }
    this.#assertNoSymlinkSegments(absolute, options.mustExist === true);
    if (options.mustExist) {
      if (!fs.existsSync(absolute)) this.#deny('요청 경로가 존재하지 않습니다.', absolute);
      const real = fs.realpathSync.native(absolute);
      if (!lexicalInside(this.root, real)) this.#deny('실제 경로가 워크스페이스 외부를 가리킵니다.', absolute);
      return real;
    }
    return absolute;
  }

  assertSkillInside(skillRoot) {
    const resolved = this.resolveInside(skillRoot, { mustExist: true });
    const stat = fs.lstatSync(resolved);
    if (!stat.isDirectory()) this.#deny('스킬 루트가 디렉터리가 아닙니다.', resolved);
    return resolved;
  }

  readText(candidate, encoding = 'utf8') {
    const absolute = this.resolveInside(candidate, { mustExist: true });
    const stat = fs.lstatSync(absolute);
    if (stat.isSymbolicLink()) this.#deny('심볼릭 링크 파일 읽기는 허용되지 않습니다.', absolute);
    if (!stat.isFile()) this.#deny('파일이 아닌 경로는 읽을 수 없습니다.', absolute);
    this.audit.reads += 1;
    return fs.readFileSync(absolute, encoding);
  }

  readBuffer(candidate) {
    const absolute = this.resolveInside(candidate, { mustExist: true });
    const stat = fs.lstatSync(absolute);
    if (stat.isSymbolicLink() || !stat.isFile()) this.#deny('안전하지 않은 파일 읽기가 차단되었습니다.', absolute);
    this.audit.reads += 1;
    return fs.readFileSync(absolute);
  }

  writeText(candidate, content, encoding = 'utf8') {
    const absolute = this.resolveInside(candidate, { mustExist: false });
    this.ensureDirectory(path.dirname(absolute));
    this.#assertNoSymlinkSegments(path.dirname(absolute), true);
    if (fs.existsSync(absolute) && fs.lstatSync(absolute).isSymbolicLink()) {
      this.#deny('심볼릭 링크 대상 쓰기는 허용되지 않습니다.', absolute);
    }
    fs.writeFileSync(absolute, content, { encoding });
    this.audit.writes += 1;
    return absolute;
  }

  writeJson(candidate, value) {
    return this.writeText(candidate, `${JSON.stringify(value, null, 2)}\n`);
  }

  ensureDirectory(candidate) {
    const absolute = this.resolveInside(candidate, { mustExist: false });
    let cursor = absolute;
    const missing = [];
    while (!fs.existsSync(cursor)) {
      missing.push(cursor);
      const parent = path.dirname(cursor);
      if (parent === cursor) break;
      cursor = parent;
    }
    this.#assertNoSymlinkSegments(cursor, true);
    for (let i = missing.length - 1; i >= 0; i -= 1) {
      fs.mkdirSync(missing[i]);
    }
    return absolute;
  }

  removeTree(candidate) {
    const absolute = this.resolveInside(candidate, { mustExist: false });
    if (absolute === this.root) this.#deny('워크스페이스 루트 삭제는 금지됩니다.', absolute);
    if (!fs.existsSync(absolute)) return;
    this.#assertNoSymlinkSegments(absolute, true);
    fs.rmSync(absolute, { recursive: true, force: true });
    this.audit.writes += 1;
  }

  noteSkippedSymlink(candidate) {
    let display;
    try {
      display = this.relative(candidate);
    } catch {
      display = '[outside-workspace]';
    }
    this.audit.skippedSymlinks.push(display);
  }

  #assertNoSymlinkSegments(candidate, requireLeaf) {
    if (!lexicalInside(this.root, candidate)) this.#deny('경로가 워크스페이스 경계를 벗어납니다.', candidate);
    const relative = path.relative(this.root, candidate);
    if (!relative) return;
    const segments = relative.split(path.sep).filter(Boolean);
    let cursor = this.root;
    for (let i = 0; i < segments.length; i += 1) {
      cursor = path.join(cursor, segments[i]);
      if (!fs.existsSync(cursor)) {
        if (requireLeaf || i < segments.length - 1) {
          if (requireLeaf) this.#deny('경로가 존재하지 않습니다.', cursor);
        }
        break;
      }
      const stat = fs.lstatSync(cursor);
      if (stat.isSymbolicLink()) this.#deny('심볼릭 링크를 통한 경로 접근이 차단되었습니다.', cursor);
    }
  }

  #deny(message, candidate) {
    const details = { candidate: String(candidate), workspaceRoot: this.root };
    this.audit.denied.push({ message, candidate: String(candidate) });
    throw new WorkspaceBoundaryError(message, details);
  }
}

module.exports = {
  WorkspaceGuard,
  WorkspaceBoundaryError,
  lexicalInside,
};
