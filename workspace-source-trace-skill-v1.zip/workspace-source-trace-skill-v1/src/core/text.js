'use strict';

const crypto = require('crypto');
const path = require('path');

function sha256(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

function lineNumberAt(text, index) {
  if (index <= 0) return 1;
  let line = 1;
  for (let i = 0; i < index && i < text.length; i += 1) {
    if (text.charCodeAt(i) === 10) line += 1;
  }
  return line;
}

function lineRange(text, index, radius = 0) {
  const line = lineNumberAt(text, index);
  return { start: Math.max(1, line - radius), end: line + radius };
}

function excerptAt(text, index, maxLength = 220) {
  const start = Math.max(0, text.lastIndexOf('\n', Math.max(0, index - 1)) + 1);
  let end = text.indexOf('\n', index);
  if (end < 0) end = text.length;
  const raw = text.slice(start, end).trim().replace(/\s+/g, ' ');
  return raw.length > maxLength ? `${raw.slice(0, maxLength - 1)}…` : raw;
}

function unique(values) {
  return [...new Set((values || []).filter((v) => v !== undefined && v !== null && v !== ''))];
}

function cleanQuoted(value) {
  if (value === undefined || value === null) return '';
  let result = String(value).trim();
  if ((result.startsWith('"') && result.endsWith('"')) ||
      (result.startsWith("'") && result.endsWith("'")) ||
      (result.startsWith('`') && result.endsWith('`'))) {
    result = result.slice(1, -1);
  }
  return result;
}

function redactSecret(value) {
  if (!value) return value;
  let result = String(value);
  result = result.replace(/([a-z][a-z0-9+.-]*:\/\/)([^/@\s]+)@/gi, '$1***:***@');
  result = result.replace(/([?&](?:password|passwd|pwd|token|secret|api[_-]?key)=)[^&\s]+/gi, '$1***');
  result = result.replace(/((?:password|passwd|pwd|token|secret|api[_-]?key)\s*[:=]\s*)[^\s,;]+/gi, '$1***');
  return result;
}

function stripInlineComment(line) {
  let quote = null;
  let escaped = false;
  for (let i = 0; i < line.length; i += 1) {
    const ch = line[i];
    if (escaped) {
      escaped = false;
      continue;
    }
    if (ch === '\\') {
      escaped = true;
      continue;
    }
    if (quote) {
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'" || ch === '`') {
      quote = ch;
      continue;
    }
    if (ch === '#' && (i === 0 || /\s/.test(line[i - 1]))) return line.slice(0, i);
  }
  return line;
}

function findMatchingBrace(text, openIndex, openChar = '{', closeChar = '}') {
  if (openIndex < 0 || text[openIndex] !== openChar) return -1;
  let depth = 0;
  let state = 'code';
  let quote = null;
  let escaped = false;
  for (let i = openIndex; i < text.length; i += 1) {
    const ch = text[i];
    const next = text[i + 1];

    if (state === 'line-comment') {
      if (ch === '\n') state = 'code';
      continue;
    }
    if (state === 'block-comment') {
      if (ch === '*' && next === '/') {
        state = 'code';
        i += 1;
      }
      continue;
    }
    if (state === 'string') {
      if (escaped) {
        escaped = false;
        continue;
      }
      if (ch === '\\') {
        escaped = true;
        continue;
      }
      if (ch === quote) {
        state = 'code';
        quote = null;
      }
      continue;
    }

    if (ch === '/' && next === '/') {
      state = 'line-comment';
      i += 1;
      continue;
    }
    if (ch === '/' && next === '*') {
      state = 'block-comment';
      i += 1;
      continue;
    }
    if (ch === '"' || ch === "'" || ch === '`') {
      state = 'string';
      quote = ch;
      continue;
    }
    if (ch === openChar) depth += 1;
    if (ch === closeChar) {
      depth -= 1;
      if (depth === 0) return i;
    }
  }
  return -1;
}

function splitTopLevel(value, delimiter = ',') {
  const parts = [];
  let current = '';
  let quote = null;
  let escaped = false;
  let depthParen = 0;
  let depthBrace = 0;
  let depthBracket = 0;
  for (let i = 0; i < value.length; i += 1) {
    const ch = value[i];
    if (escaped) {
      current += ch;
      escaped = false;
      continue;
    }
    if (ch === '\\') {
      current += ch;
      escaped = true;
      continue;
    }
    if (quote) {
      current += ch;
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'" || ch === '`') {
      quote = ch;
      current += ch;
      continue;
    }
    if (ch === '(') depthParen += 1;
    else if (ch === ')') depthParen -= 1;
    else if (ch === '{') depthBrace += 1;
    else if (ch === '}') depthBrace -= 1;
    else if (ch === '[') depthBracket += 1;
    else if (ch === ']') depthBracket -= 1;

    if (ch === delimiter && depthParen === 0 && depthBrace === 0 && depthBracket === 0) {
      parts.push(current.trim());
      current = '';
    } else {
      current += ch;
    }
  }
  if (current.trim()) parts.push(current.trim());
  return parts;
}

function normalizeSlashes(value) {
  return String(value || '').replace(/\\/g, '/').replace(/\/{2,}/g, '/');
}

function normalizeEndpointPath(raw) {
  if (!raw) return '';
  let value = cleanQuoted(String(raw).trim());
  value = value.replace(/\$\{([^}]+)\}/g, '{$1}');
  value = value.replace(/\+\s*[A-Za-z_$][\w$.[\]]*\s*\+/g, '{var}');
  value = value.replace(/["'`]\s*\+\s*[A-Za-z_$][\w$.[\]]*/g, '{var}');
  value = value.replace(/[A-Za-z_$][\w$.[\]]*\s*\+\s*["'`]/g, '{var}');
  value = value.replace(/^https?:\/\/[^/]+/i, '');
  value = value.replace(/^\{[^}]+\}(?=\/)/, '');
  value = value.split('?')[0].split('#')[0];
  value = value.replace(/:([A-Za-z_]\w*)/g, '{$1}');
  if (value && !value.startsWith('/') && !value.startsWith('{')) value = `/${value}`;
  value = normalizeSlashes(value);
  if (value.length > 1 && value.endsWith('/')) value = value.slice(0, -1);
  return value || '/';
}

function endpointShape(raw) {
  const normalized = normalizeEndpointPath(raw)
    .replace(/\{[^}]+\}/g, '{}')
    .replace(/\b[0-9a-f]{8}-[0-9a-f-]{27,}\b/gi, '{}')
    .replace(/\/\d+(?=\/|$)/g, '/{}');
  return normalized.toLowerCase();
}

function joinEndpointPaths(base, child) {
  const left = base && base !== '/' ? normalizeEndpointPath(base) : '';
  const right = child && child !== '/' ? normalizeEndpointPath(child) : '';
  return normalizeEndpointPath(`${left}/${right}`);
}

function pathBasenameWithoutExtensions(file) {
  let base = path.basename(file);
  base = base.replace(/\.(test|spec)$/i, '');
  while (base.includes('.')) base = base.slice(0, base.lastIndexOf('.'));
  return base;
}

function toPosixRelative(root, absolute) {
  return normalizeSlashes(path.relative(root, absolute)) || '.';
}

function stableId(prefix, ...values) {
  return `${prefix}-${sha256(values.join('|')).slice(0, 12)}`;
}

function escapeMarkdown(value) {
  return String(value ?? '').replace(/\|/g, '\\|').replace(/\r?\n/g, ' ');
}

function csvCell(value) {
  const text = Array.isArray(value) ? value.join('; ') : String(value ?? '');
  if (/[",\r\n]/.test(text)) return `"${text.replace(/"/g, '""')}"`;
  return text;
}

module.exports = {
  sha256,
  lineNumberAt,
  lineRange,
  excerptAt,
  unique,
  cleanQuoted,
  redactSecret,
  stripInlineComment,
  findMatchingBrace,
  splitTopLevel,
  normalizeSlashes,
  normalizeEndpointPath,
  endpointShape,
  joinEndpointPaths,
  pathBasenameWithoutExtensions,
  toPosixRelative,
  stableId,
  escapeMarkdown,
  csvCell,
};
