'use strict';

const fs = require('fs');
const path = require('path');
const { sha256, toPosixRelative, normalizeSlashes } = require('./text');

const MODULE_MARKERS = new Set([
  'pom.xml', 'build.gradle', 'build.gradle.kts', 'settings.gradle', 'settings.gradle.kts',
  'package.json', 'pnpm-workspace.yaml', 'yarn.lock', 'gradlew',
]);

function classifyFile(relativePath) {
  const lower = relativePath.toLowerCase();
  const base = path.basename(lower);
  const ext = path.extname(lower);
  if (['.tsx', '.jsx', '.ts', '.js'].includes(ext)) return 'javascript';
  if (ext === '.java' || ext === '.kt') return 'jvm';
  if (ext === '.sql') return 'sql';
  if (ext === '.xml') return 'xml';
  if (['.yml', '.yaml', '.properties', '.env'].includes(ext) || base.startsWith('.env')) return 'config';
  if (['dockerfile', 'jenkinsfile'].includes(base) || ['.gradle', '.kts', '.groovy', '.sh', '.ps1', '.cmd'].includes(ext)) return 'build';
  if (ext === '.json') return 'json';
  return 'text';
}

function looksBinary(buffer) {
  const sample = buffer.subarray(0, Math.min(buffer.length, 8192));
  let zeroes = 0;
  for (const byte of sample) if (byte === 0) zeroes += 1;
  return zeroes > 0;
}

function shouldIgnore(relative, name, isDirectory, config, autoIgnorePaths) {
  const normalized = normalizeSlashes(relative);
  const segments = normalized.split('/').filter(Boolean);
  const ignoreDirs = new Set((config.scan.ignoreDirectories || []).map(String));
  if (isDirectory && ignoreDirs.has(name)) return true;
  if (segments.some((segment) => ignoreDirs.has(segment))) return true;
  const ignores = [...(config.scan.ignorePaths || []), ...(autoIgnorePaths || [])]
    .map((v) => normalizeSlashes(String(v)).replace(/^\.\//, '').replace(/\/$/, ''))
    .filter(Boolean);
  return ignores.some((item) => normalized === item || normalized.startsWith(`${item}/`));
}

function isIncluded(name, config) {
  const ext = path.extname(name).toLowerCase();
  const includes = new Set((config.scan.includeExtensions || []).map((v) => String(v).toLowerCase()));
  const names = new Set((config.scan.includeFileNames || []).map((v) => String(v).toLowerCase()));
  const lower = name.toLowerCase();
  return includes.has(ext) || names.has(lower) || lower.startsWith('.env');
}

function discoverModuleRoots(files) {
  const markerDirs = new Set(['.']);
  for (const file of files) {
    if (MODULE_MARKERS.has(path.basename(file.relative))) {
      const dir = normalizeSlashes(path.dirname(file.relative));
      markerDirs.add(dir === '' ? '.' : dir);
    }
  }
  const roots = [...markerDirs].sort((a, b) => b.length - a.length);
  for (const file of files) {
    const dir = normalizeSlashes(path.dirname(file.relative));
    const match = roots.find((root) => root === '.' || dir === root || dir.startsWith(`${root}/`));
    file.module = match || '.';
  }
  return roots.sort();
}

function scanWorkspace(guard, config, skillRoot) {
  const files = [];
  const warnings = [];
  const maxBytes = Number(config.scan.maxFileBytes || 3 * 1024 * 1024);
  const maxDepth = Number(config.scan.maxDepth || 60);
  const autoIgnorePaths = [];
  if (skillRoot) {
    const relativeSkill = toPosixRelative(guard.root, skillRoot);
    if (relativeSkill !== '.') autoIgnorePaths.push(relativeSkill);
  }
  const outputDir = normalizeSlashes(String(config.workspace.outputDir || '.workspace-analysis'));
  autoIgnorePaths.push(outputDir);

  function walk(directory, depth) {
    if (depth > maxDepth) {
      warnings.push({ type: 'max-depth', path: guard.relative(directory), message: `최대 탐색 깊이 ${maxDepth}를 초과해 하위 경로를 건너뜀` });
      return;
    }
    const entries = fs.readdirSync(directory, { withFileTypes: true });
    for (const entry of entries) {
      const absolute = path.join(directory, entry.name);
      const relative = toPosixRelative(guard.root, absolute);
      if (entry.isSymbolicLink()) {
        guard.noteSkippedSymlink(absolute);
        warnings.push({ type: 'symlink-skipped', path: relative, message: '심볼릭 링크는 경계 보호를 위해 분석하지 않음' });
        continue;
      }
      if (shouldIgnore(relative, entry.name, entry.isDirectory(), config, autoIgnorePaths)) continue;
      if (entry.isDirectory()) {
        walk(absolute, depth + 1);
        continue;
      }
      if (!entry.isFile() || !isIncluded(entry.name, config)) continue;
      const stat = fs.lstatSync(absolute);
      if (stat.size > maxBytes) {
        warnings.push({ type: 'large-file-skipped', path: relative, size: stat.size, message: `파일 크기가 제한(${maxBytes})을 초과함` });
        continue;
      }
      const buffer = guard.readBuffer(absolute);
      if (looksBinary(buffer)) {
        warnings.push({ type: 'binary-skipped', path: relative, message: '바이너리로 판단되어 건너뜀' });
        continue;
      }
      const text = buffer.toString('utf8');
      files.push({
        absolute,
        relative,
        name: entry.name,
        extension: path.extname(entry.name).toLowerCase(),
        kind: classifyFile(relative),
        size: stat.size,
        hash: sha256(buffer),
        text,
        module: '.',
      });
    }
  }

  walk(guard.root, 0);
  const modules = discoverModuleRoots(files);
  return { files, modules, warnings, autoIgnorePaths };
}

module.exports = {
  scanWorkspace,
  classifyFile,
  discoverModuleRoots,
};
