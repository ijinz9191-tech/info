@echo off
setlocal
set "SKILL_ROOT=%~dp0"
if "%~1"=="" (
  set "WORKSPACE=%CD%"
) else (
  set "WORKSPACE=%~1"
)
node "%SKILL_ROOT%scripts\run.js" --workspace "%WORKSPACE%"
exit /b %ERRORLEVEL%
