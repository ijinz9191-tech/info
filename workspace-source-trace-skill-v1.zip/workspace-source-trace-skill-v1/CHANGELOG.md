# Changelog

## 1.0.0 — 2026-08-12

- 워크스페이스 realpath 경계 강제 및 심볼릭 링크 미추적
- React 화면, 버튼, 자동조회, API 호출 체인 분석
- Spring Boot와 Vert.x endpoint 및 Java 호출 그래프 분석
- JPA, Spring Data, MyBatis, SQL client, Mongo, Redis, Elasticsearch 객체 분석
- DB 엔진 및 host/IP/profile 연결 그룹 분리
- 분리형 host/port/database 설정 통합 및 credential 결과 마스킹
- Kubernetes·접속 설정·DB 컬럼 기반 클러스터 이전 분석
- 동일 소스 키와 DB 필드명을 근거로 replacement 후보 정밀 연결
- `memo.md` 자동 기억 갱신 및 이전 지문 기반 변경 여부 비교
- Markdown, CSV, JSON 보고서 생성
- 외부 npm 의존성 제거
