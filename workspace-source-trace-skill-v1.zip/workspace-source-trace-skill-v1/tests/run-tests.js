'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { parseYaml, DEFAULTS } = require('../src/config');
const { WorkspaceGuard, WorkspaceBoundaryError } = require('../src/core/workspace-guard');
const { analyzeFrontend } = require('../src/analyzers/frontend-analyzer');
const { analyzeJava } = require('../src/analyzers/java-analyzer');
const { extractSqlObjects } = require('../src/analyzers/sql-analyzer');
const { databaseColumnCandidates } = require('../src/analyzers/migration-analyzer');
const { endpointMatchScore } = require('../src/analyzers/correlator');
const { analyzeConfigurations } = require('../src/analyzers/config-analyzer');
const { readMemoContext, updateMemo, START, END } = require('../src/report/memo');

function file(relative, text, kind, extension, module = '.') {
  return { relative, text, kind, extension, module, name: path.basename(relative), size: Buffer.byteLength(text), hash: 'test' };
}

function testYaml() {
  const value = parseYaml(`a:\n  b: true\n  list:\n    - one\n    - two\nmap:\n  "@/": src/\n`);
  assert.strictEqual(value.a.b, true);
  assert.deepStrictEqual(value.a.list, ['one', 'two']);
  assert.strictEqual(value.map['@/'], 'src/');
}

function testBoundary() {
  const root = path.resolve(__dirname, '..');
  const guard = new WorkspaceGuard(root);
  guard.assertSkillInside(root);
  assert.throws(() => guard.resolveInside(path.resolve(root, '..', 'outside.txt')), WorkspaceBoundaryError);
  const tempDir = path.join(root, 'tests', '.tmp-boundary');
  fs.rmSync(tempDir, { recursive: true, force: true });
  fs.mkdirSync(tempDir, { recursive: true });
  const target = path.join(tempDir, 'target');
  fs.mkdirSync(target);
  const link = path.join(tempDir, 'link');
  try {
    fs.symlinkSync(target, link, process.platform === 'win32' ? 'junction' : 'dir');
    assert.throws(() => guard.resolveInside(link, { mustExist: true }), WorkspaceBoundaryError);
  } finally {
    fs.rmSync(tempDir, { recursive: true, force: true });
  }
}

function testFrontend() {
  const files = [
    file('src/api.ts', `import axios from 'axios';\nexport const load = () => axios.get('/api/items');\nexport const save = (id) => axios.patch(\`/api/items/\${id}\`);`, 'javascript', '.ts'),
    file('src/Page.tsx', `import {useEffect} from 'react';\nimport {load, save} from './api';\nexport default function Page(){\n useEffect(() => { load(); }, []);\n const click = () => save('1');\n return <button onClick={click}>저장</button>;\n}`, 'javascript', '.tsx'),
    file('src/router.tsx', `import Page from './Page';\nexport const routes=[{path:'/items', element:<Page/>}];`, 'javascript', '.tsx'),
  ];
  const result = analyzeFrontend(files, DEFAULTS);
  assert.strictEqual(result.screens.length, 1);
  assert.strictEqual(result.apiCalls.length, 2);
  assert.strictEqual(result.triggers.length, 2);
  const click = result.triggers.find((trigger) => trigger.mode === 'manual');
  assert(click.apiCallIds.some((id) => result.apiCalls.find((call) => call.id === id && call.method === 'PATCH')));
  const automatic = result.triggers.find((trigger) => trigger.mode === 'automatic');
  assert(automatic.apiCallIds.some((id) => result.apiCalls.find((call) => call.id === id && call.method === 'GET')));
}

function testJava() {
  const files = [
    file('src/User.java', `package a; import jakarta.persistence.*; @Entity @Table(name="TB_USER", schema="APP") public class User { @Id private Long id; @Column(name="CLUSTER_ENDPOINT", length=10) private String clusterEndpoint; }`, 'jvm', '.java'),
    file('src/UserRepository.java', `package a; import org.springframework.data.jpa.repository.JpaRepository; public interface UserRepository extends JpaRepository<User,Long>{}`, 'jvm', '.java'),
    file('src/UserService.java', `package a; public class UserService { private final UserRepository repo; public UserService(UserRepository repo){this.repo=repo;} public Object list(){return repo.findAll();} }`, 'jvm', '.java'),
    file('src/UserController.java', `package a; import org.springframework.web.bind.annotation.*; @RestController @RequestMapping("/api/users") public class UserController { private final UserService service; public UserController(UserService service){this.service=service;} @GetMapping public Object list(){return service.list();} }`, 'jvm', '.java'),
    file('src/Routes.java', `package a; public class Routes { private final UserService service; public void mount(io.vertx.ext.web.Router router){router.get("/internal/users").handler(this::handle);} private void handle(Object ctx){service.list();} }`, 'jvm', '.java'),
  ];
  const result = analyzeJava(files, DEFAULTS);
  assert(result.endpoints.some((endpoint) => endpoint.framework === 'spring' && endpoint.path === '/api/users'));
  assert(result.endpoints.some((endpoint) => endpoint.framework === 'vertx' && endpoint.path === '/internal/users'));
  const spring = result.endpoints.find((endpoint) => endpoint.framework === 'spring');
  assert(spring.databaseObjects.some((object) => object.fullName === 'APP.TB_USER'));
}

function testSql() {
  const objects = extractSqlObjects('SELECT A.ID, A.CLUSTER_IP FROM APP.TB_AUDIT A WHERE A.CLUSTER_IP = :ip', { file: 'a.sql', module: '.', sourceText: 'SELECT A.ID, A.CLUSTER_IP FROM APP.TB_AUDIT A WHERE A.CLUSTER_IP = :ip' });
  assert.strictEqual(objects[0].fullName, 'APP.TB_AUDIT');
  assert(objects[0].columns.includes('CLUSTER_IP'));
  assert(!objects[0].columns.includes('TB_AUDIT'));
}

function testMigrationColumn() {
  const entity = {
    className: 'User', engine: 'relational-unknown', kind: 'table', fullName: 'APP.TB_USER', module: '.',
    fields: [{ name: 'clusterEndpoint', column: 'CLUSTER_ENDPOINT', type: 'String', length: 10, source: { file: 'User.java', line: 1 } }],
  };
  const dbObject = { engine: 'oracle', kind: 'table', fullName: 'APP.TB_USER', operations: ['SELECT'], columns: ['CLUSTER_ENDPOINT'], module: '.', source: { file: 'Repo.java', line: 1 } };
  const sourceCandidates = [{ key: 'clusterEndpoint', replacement: { matched: true, from: 'old.internal', to: 'new-cluster.internal' } }];
  const candidates = databaseColumnCandidates(
    [entity],
    [dbObject],
    { 'old.internal': 'new-cluster.internal', 'mongo-old.internal': 'mongo-new.internal', 'old-registry.internal': 'new-registry.internal' },
    DEFAULTS.analysis.databaseColumnKeywords,
    sourceCandidates,
  );
  assert(candidates.some((candidate) => candidate.category === 'database-data-column' && candidate.engine === 'oracle'));
  assert(candidates.some((candidate) => candidate.category === 'database-schema-column'));
  assert(candidates.every((candidate) => (candidate.replacementCandidates || []).length === 1));
  assert(candidates.every((candidate) => candidate.replacementCandidates[0].from === 'old.internal'));
}

function testSplitDatabaseConfiguration() {
  const files = [
    file('config/application-prod.yml', `spring:
  data:
    redis:
      host: 10.0.0.1
      port: 6379
      database: 2
      username: redis-user
      password: redis-secret
    mongodb:
      host: mongo.internal
      port: 27017
      database: audit
      username: mongo-user
      password: mongo-secret
`, 'config', '.yml', 'backend'),
  ];
  const result = analyzeConfigurations(files, DEFAULTS);
  assert.strictEqual(result.connections.length, 2);
  const redis = result.connections.find((connection) => connection.engine === 'redis');
  const mongo = result.connections.find((connection) => connection.engine === 'mongodb');
  assert(redis);
  assert(mongo);
  assert.deepStrictEqual(redis.hosts, ['10.0.0.1:6379']);
  assert.strictEqual(redis.database, '2');
  assert.deepStrictEqual(mongo.hosts, ['mongo.internal:27017']);
  assert.strictEqual(mongo.database, 'audit');
  assert(!JSON.stringify(result).includes('redis-secret'));
  assert(!JSON.stringify(result).includes('mongo-secret'));
  assert(!redis.keys.some((key) => /password|username/i.test(key)));
  assert(!mongo.keys.some((key) => /password|username/i.test(key)));
  const passwordProperties = result.properties.filter((property) => /password|username/i.test(property.key));
  assert(passwordProperties.every((property) => property.value === '***'));
}

function testMemoContinuity() {
  const tempDir = path.join(__dirname, '.tmp-memo');
  fs.rmSync(tempDir, { recursive: true, force: true });
  fs.mkdirSync(tempDir, { recursive: true });
  try {
    const memoPath = path.join(tempDir, 'memo.md');
    fs.writeFileSync(memoPath, `# 수동 메모\n\n- 유지할 내용\n\n${START}\n## 자동 생성 기억\n\n- 마지막 분석: 2026-08-12T00:00:00.000Z\n- 워크스페이스 지문: \`old-fingerprint\`\n${END}\n`);
    const guard = new WorkspaceGuard(tempDir);
    const config = { workspace: { memoFile: 'memo.md' } };
    const context = readMemoContext(guard, config);
    assert.strictEqual(context.previousWorkspaceFingerprint, 'old-fingerprint');
    assert.strictEqual(context.previousAnalysisAt, '2026-08-12T00:00:00.000Z');
    assert(context.manualLineCount > 0);
    const analysis = {
      meta: { generatedAt: '2026-08-12T01:00:00.000Z', workspaceFingerprint: 'new-fingerprint', fileCount: 1, moduleCount: 1 },
      memory: { comparison: 'changed' },
      frontend: { screens: [], apiCalls: [] },
      backend: { endpoints: [] },
      databases: { objects: [], connections: [] },
      migration: { summary: { total: 0 }, candidates: [] },
      endpointFlows: [],
    };
    updateMemo(guard, analysis, config, tempDir);
    const updated = fs.readFileSync(memoPath, 'utf8');
    assert(updated.includes('- 유지할 내용'));
    assert(updated.includes('new-fingerprint'));
    assert.strictEqual(updated.split(START).length - 1, 1);
    assert.strictEqual(updated.split(END).length - 1, 1);
  } finally {
    fs.rmSync(tempDir, { recursive: true, force: true });
  }
}

function testEndpointScore() {
  const score = endpointMatchScore({ method: 'GET', path: '/api/users/{id}', module: 'a' }, { method: 'GET', path: '/users/{userId}', module: 'a' });
  assert(score >= 45);
}

const tests = [testYaml, testBoundary, testFrontend, testJava, testSql, testMigrationColumn, testSplitDatabaseConfiguration, testMemoContinuity, testEndpointScore];
let passed = 0;
for (const test of tests) {
  test();
  passed += 1;
  process.stdout.write(`PASS ${test.name}\n`);
}
process.stdout.write(`All ${passed} tests passed.\n`);
