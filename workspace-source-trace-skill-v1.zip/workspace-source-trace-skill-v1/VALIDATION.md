# Validation

검증일: 2026-08-12

## 자동 테스트

```text
npm test
PASS testYaml
PASS testBoundary
PASS testFrontend
PASS testJava
PASS testSql
PASS testMigrationColumn
PASS testSplitDatabaseConfiguration
PASS testMemoContinuity
PASS testEndpointScore
All 9 tests passed.
```

## 통합 검증 범위

- React `useEffect` 자동조회와 버튼 `onClick` 수동 호출을 서로 다른 endpoint 흐름으로 분리
- Axios 호출을 Spring Boot Controller → Service → Repository → Oracle table까지 연결
- Vert.x backend-only route를 Service → Repository → Oracle table까지 연결
- Oracle JDBC URL, 분리형 MongoDB host/port/database, 분리형 Redis host/port/database 그룹 생성
- Oracle 안에서 host/IP·profile 연결 그룹별 table 분리
- JPA `@Column`과 source payload key를 연결하여 DB 데이터 컬럼 및 길이 확대 위험 식별
- cluster-map 기반 설정 key, namespace, ServiceAccount, image registry, ingress host 변경 생성
- 외부 `/etc`를 가리키는 symlink를 건너뛰고 target을 읽지 않음
- password·username과 절대 workspace path가 보고서에 노출되지 않음
- `memo.md` 수동 영역 보존, 이전 지문 재사용, unchanged/changed 판정

## 실행 원칙

검증 과정에서도 analyzer는 네트워크, 외부 Git, 실제 DB/Kubernetes 연결, child process 기반 프로젝트 실행을 사용하지 않았다.
