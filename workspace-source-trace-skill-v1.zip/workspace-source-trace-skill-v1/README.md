# Workspace Source Trace Skill v1

React 화면의 버튼·자동조회부터 Spring Boot/Vert.x API와 Oracle·MongoDB 등 DB 객체까지 연결하고, 클러스터 전체 이전 시 바꿀 위치를 찾아주는 **워크스페이스 전용 오프라인 정적 분석 스킬**이다.

## 핵심 특징

- 워크스페이스 밖 읽기·쓰기 차단
- 심볼릭 링크 미추적
- 웹 검색·외부 Git·실제 DB·Kubernetes 접속 없음
- React 화면/라우트/버튼/useEffect/useQuery/useMutation 분석
- Spring Controller/Service/Repository/MyBatis/JPA 분석
- Vert.x Router/Handler/SQL·Mongo client 분석
- DB 엔진별 분리 후 host/IP/profile별 연결 그룹 생성
- `host`, `port`, `database`가 나뉜 설정을 하나의 연결 그룹으로 결합
- username/password/token 등 자격정보를 결과 전체에서 마스킹
- 테이블·컬렉션·Redis key·Elasticsearch index 수집
- 클러스터 이전의 파일 설정, Kubernetes 리소스, DB 컬럼 변경 후보 생성
- `memo.md`에 결과와 미해결 사항 누적 기억
- 이전 memo 지문을 읽어 소스·분석 설정·migration map 변경 여부 비교
- 외부 npm 의존성 없음

## 설치 위치

압축을 **분석할 워크스페이스 내부**에 직접 푼다.

```text
D:\work\hcp\
├─ react-ui\
├─ spring-api\
├─ vertx-api\
├─ deploy\
└─ workspace-source-trace-skill-v1\
```

스킬을 `D:\tools`처럼 워크스페이스 밖에 두고 내부 프로젝트를 분석하는 방식은 차단된다.

## 요구 환경

- Windows 또는 Linux
- Node.js 18 이상
- npm install 불필요
- Python/Conda 불필요

## 가장 빠른 실행

PowerShell에서 워크스페이스 루트로 이동한 뒤 실행한다.

```powershell
.\workspace-source-trace-skill-v1\run.ps1 -Workspace .
```

직접 실행:

```powershell
node .\workspace-source-trace-skill-v1\scripts\run.js --workspace . --clean
```

경계만 먼저 검증:

```powershell
node .\workspace-source-trace-skill-v1\scripts\verify-boundary.js --workspace .
```

## 클러스터 이전 매핑 입력

현재값과 신규값을 알고 있는 항목만 `cluster-map.yaml`에 기록한다.

```yaml
version: 1
replacements:
  old-cluster: new-cluster
  old-api.company.internal: new-api.company.internal
  10.1.10.20: 10.2.10.20
  old-namespace: new-namespace
```

비워 두어도 분석은 된다. 다만 신규값은 “미지정”으로 남고 변경 위치만 나온다.

## 결과 파일

실행 후 워크스페이스 루트에 다음이 생긴다.

```text
memo.md
.workspace-analysis/
├─ summary.md
├─ endpoint-catalog.md
├─ database-catalog.md
├─ cluster-migration.md
├─ unresolved.md
├─ analysis.json
├─ endpoint-catalog.csv
├─ database-catalog.csv
├─ migration-changes.csv
├─ boundary-audit.json
└─ report-manifest.json
```

### endpoint-catalog.md

각 endpoint별로 다음을 한 흐름으로 표시한다.

```text
UsersPage / 조회 버튼 / onClick
→ handleSearch
→ userApi.search
→ GET /api/users
→ UserController#search
→ UserService#search
→ UserRepository#find...
→ Oracle 10.10.10.10:1521 / APP.TB_USER
```

### database-catalog.md

Oracle, MongoDB, Redis, Elasticsearch/OpenSearch 등을 분리하고 같은 DB 안에서도 IP·host·profile별로 테이블·컬렉션을 나눈다. 접속 설정만 있고 사용하는 객체가 발견되지 않으면 그 사실도 표시한다.

### cluster-migration.md

다음을 파일·라인 또는 테이블·컬럼 단위로 제시한다.

- namespace, ingress host, registry, ServiceAccount
- ConfigMap/Secret, StorageClass, nodeSelector
- Oracle/Mongo/Redis/Elasticsearch/Kafka host와 IP
- Kubernetes client context/API server/namespace
- `TB_CLUSTER.CLUSTER_ENDPOINT` 같은 DB 데이터 변경 후보
- 신규 값 길이가 `@Column(length=N)`을 초과하는 스키마 변경 위험
- 소스의 동일 키(예: `clusterEndpoint`)와 DB 필드를 연결해 관련 replacement만 우선 적용

## 설정

`config.yaml`에서 스캔 확장자, 제외 폴더, alias root, 호출 깊이, 출력 경로를 조정할 수 있다. 다음 안전 항목은 `false`로 바꿀 수 없고, 바꾸면 실행이 중단된다.

```yaml
workspace:
  strictBoundary: true
  requireSkillInsideWorkspace: true
  followSymlinks: false
  allowExternalReads: false
  allowNetwork: false
  allowChildProcess: false
```

## 모노레포 처리

`pom.xml`, `build.gradle*`, `package.json`, `settings.gradle*`이 있는 경로를 모듈로 잡는다. DB 객체는 먼저 같은 모듈의 연결 설정에 배정한다. 같은 모듈에 Oracle datasource가 여러 개면 임의로 하나를 선택하지 않고 `ambiguous`로 남긴다.

## `memo.md` 사용

자동 생성 구간 밖에는 수동 메모를 자유롭게 적을 수 있다.

```markdown
## 수동 메모
- prod datasource는 application-prod.yml 기준
- legacy-api 모듈은 이전 대상 제외

<!-- WORKSPACE-SOURCE-TRACE:START -->
자동 생성 영역
<!-- WORKSPACE-SOURCE-TRACE:END -->
```

다시 실행해도 수동 메모는 유지된다. 다음 실행은 이전 자동 생성 지문을 읽어 `unchanged` 또는 `changed`를 보고하며, 수동 메모를 endpoint·DB 관계의 근거로 오인하지 않는다.

## 분석 한계

정적 분석이므로 런타임에 조합되는 endpoint, Spring reflection/AOP, DI 후보가 여러 개인 구조, 복잡한 custom ORM DSL, 생성된 소스가 제외 폴더에만 있는 경우는 미해결로 남을 수 있다. 이때 스킬은 외부에서 보완 소스를 찾지 않는다.
