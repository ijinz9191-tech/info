# Grafana·Prometheus·Loki 분석 상세 규칙

## Grafana

- Dashboard UID/title/tags/version/folder 정보를 기록한다.
- Panel ID/title/type/datasource/query/refId를 기록한다.
- Alert가 있는 Panel/Unified Alert Rule은 별도 표시한다.
- Datasource UID가 있으면 provisioning 또는 Runtime datasource 목록과 연결한다.

## Prometheus

- Micrometer metric 생성 코드와 actuator/prometheus 노출 설정을 추출한다.
- scrape job과 static target, Kubernetes monitor selector를 기록한다.
- Recording rule과 Alert rule을 구분하고 expression 원문을 기록한다.
- Grafana PromQL query의 metric name과 Prometheus metric 자산을 연결 후보로 만든다.

## Loki

- Promtail/Alloy scrape job, target path, labels, pipeline stage를 기록한다.
- Loki appender/push client와 endpoint를 추출한다.
- Grafana LogQL query와 datasource를 연결한다.
- 로그 본문과 개인정보 가능 데이터는 산출물에 넣지 않는다.

## 운영자 매뉴얼 화면

- Grafana: Dashboard별 캡처
- Prometheus: Targets, Alerts, Rules
- Loki: 기본 상태 화면은 선택 사항이며 보통 Grafana Explore/Dashboard를 우선
- 캡처마다 URL, 제목, 태그, 성공/실패 상태, 오류를 metadata로 저장한다.
