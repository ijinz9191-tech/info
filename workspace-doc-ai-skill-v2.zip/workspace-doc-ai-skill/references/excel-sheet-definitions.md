# Excel 시트 정의

## 인터페이스명세서.xlsx

- `API 인터페이스`: HTTP method/path/controller/method/parameter/response/근거
- `외부연계`: Feign/HTTP/JDBC/Resource dependency 기반 외부 연계
- `Interface-Impl`: Interface와 구현 Class 연결
- `주입연결`: 주입 대상, 구현체 후보, Qualifier, 상태
- `Bean연결`: Configuration Class와 `@Bean` 반환 Type
- `리소스연계`: 7종 Resource 통합 송수신/호출 연결
- `Oracle연계`: SQL operation, Table/Procedure, Mapper/Method, 근거
- `Redis연계`: Cache/Key/Lock/PubSub/TTL/Operation
- `Elasticsearch연계`: Index/Repository/Search/Bulk/Index/Delete
- `Kafka연계`: Producer/Consumer/Topic/Group/Direction
- `모니터링연계`: Metric/Dashboard/Prometheus/Loki/LogQL 연결
- `런타임점검`: Resource별 상태, endpoint, 조회 결과/오류
- `JAR-Dependency`: GAV, scope, repository, 다운로드 후보, cache/local path
- `JAR내부구조`: Manifest, package, class 수, SPI, AutoConfiguration
- `JAR사용연결`: 소스 Import와 Local JAR package 연결

## 프로그램목록.xlsx

- `모듈목록`
- `파일목록`
- `클래스목록`
- `메서드목록`
- `화면-라우트`
- `공통소스`
- `Listener-Scheduler`
- `배포워크로드`
- `리소스자산`

## WorkBook.xlsx

- `요약`
- `문서생성체크리스트`
- `분석범위`
- `리소스현황`
- `공통모듈분석`
- `JAR가져오기`
- `JAR서비스연결`
- `구현흐름`
- `리소스토폴로지`
- `런타임점검`
- `변경영향도`
- `검토항목`

## 테이블정의서.xlsx

- `테이블목록`: SQL/JPA/Runtime 출처 구분
- `컬럼정의`: Name/Type/Length/Nullable/Default/Comment
- `PK-FK`: PK/FK/Unique 및 참조 Table/Column
- `인덱스`
- `시퀀스`
- `View`
- `PLSQL오브젝트`: Package/Procedure/Function/Trigger
- `Synonym`
- `Entity매핑`
- `MyBatis매퍼`
- `SQL사용처`

## 아키텍쳐정의서.xlsx

- `시스템개요`
- `모듈구조`
- `컴포넌트`
- `공통모듈`
- `의존성흐름`
- `인터페이스연결`
- `리소스토폴로지`
- `운영리소스`
- `배포워크로드`
- `관측구성`
- `설정-런타임`
- `런타임점검`
- `JAR구조`
- `리스크-확인필요`
