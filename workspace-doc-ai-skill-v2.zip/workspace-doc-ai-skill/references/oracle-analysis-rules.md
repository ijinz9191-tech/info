# Oracle 분석 상세 규칙

## DDL

- Schema.Table 표기를 분리하고 Quote identifier 원문을 보존한다.
- Column의 datatype, length/precision/scale, nullable, default를 추출한다.
- Inline/Out-of-line PK, FK, Unique constraint를 모두 추출한다.
- Index, Sequence, View, Materialized View 후보를 구분한다.
- `COMMENT ON`을 Table/Column 설명에 연결한다.

## PL/SQL

- Package, Package Body, Procedure, Function, Trigger를 오브젝트로 기록한다.
- Parameter와 내부 호출은 파서가 확인 가능한 범위에서만 기록한다.
- Dynamic SQL의 실제 대상은 추정하지 않는다.
- DB Link와 Synonym은 외부 DB 연계 가능성이 있으므로 검토항목으로 표시한다.

## 사용처

- MyBatis namespace/statement id와 SQL operation을 연결한다.
- JPA Entity/Table과 Repository를 연결한다.
- Native Query/JdbcTemplate SQL의 Table/Procedure를 연결한다.
- Read/Write/Call 방향을 분리한다.

## Runtime metadata 병합

- 동일 Schema/Object/Column이면 Source와 Runtime 근거를 함께 표시한다.
- Runtime에만 존재하는 오브젝트는 `RUNTIME_ONLY`로 표시한다.
- Source에만 존재하는 오브젝트는 배포 전 DDL일 수 있으므로 `SOURCE_ONLY`로 표시한다.
