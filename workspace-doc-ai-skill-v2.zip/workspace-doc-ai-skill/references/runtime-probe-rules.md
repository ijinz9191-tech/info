# Runtime 점검 규칙

## 공통

- Runtime 점검은 선택 기능이며 기본값은 비활성이다.
- 점검 계정과 토큰은 환경변수에서 읽는다.
- Timeout을 적용하고 실패가 전체 문서 생성을 중단시키지 않게 한다.
- 모든 결과에 `checked_at`, `status`, `endpoint`, `checks`, `error`를 남긴다.
- Secret과 민감 Header는 결과 파일에 저장하지 않는다.

## Oracle

허용:

- `SELECT 1 FROM DUAL`
- 현재 Database/Schema 조회
- USER_TABLES, USER_TAB_COLUMNS, USER_CONSTRAINTS, USER_SEQUENCES, USER_OBJECTS 계열 조회

금지:

- DDL/DML 실행
- Procedure/Function 실행
- DBA_* 또는 민감 catalog의 무제한 수집

## Redis

기본 허용:

- PING
- INFO
- DBSIZE

선택 허용:

- SCAN으로 Key 이름만 제한 수집

금지:

- GET/HGET/LRANGE 등 Value 조회
- SET/DEL/FLUSH/CONFIG 변경

## Elasticsearch

허용 GET API:

- Root info
- Cluster health
- `_cat/indices`
- `_aliases`

문서 `_search`, `_source` 조회는 수행하지 않는다.

## Kafka

허용:

- Broker socket 연결
- Cluster metadata
- Topic name 목록
- Consumer group name/summary

금지:

- Message consume/produce
- Topic/ACL/config 변경

## Grafana

허용 GET API:

- `/api/health`
- Datasource, folder, dashboard search, alert rule metadata

Dashboard 내용은 운영 화면 캡처 또는 metadata 수준으로만 사용한다.

## Prometheus

허용 GET API:

- `/-/ready`
- `/api/v1/status/buildinfo`
- `/api/v1/status/runtimeinfo`
- `/api/v1/targets`
- `/api/v1/rules`

Metric sample query는 기본적으로 수행하지 않는다.

## Loki

허용 GET API:

- `/ready`
- `/loki/api/v1/status/buildinfo`
- `/loki/api/v1/labels`
- 제한된 `/loki/api/v1/series`

로그 본문 Query는 수행하지 않는다.
