# 아키텍처 분석 규칙

## 1. 모듈 식별

- Gradle `settings.gradle(.kts)`의 include와 프로젝트 참조
- Maven parent의 `modules`
- 하위 `build.gradle`, `build.gradle.kts`, `pom.xml` 보유 디렉터리
- build 파일이 없더라도 공통 source root가 명확한 경우 검토 후보로 기록

## 2. 공통 모듈 및 공통 소스

- 경로 또는 package에 common/core/shared/base/framework/util/config/security 포함
- 다수 모듈에서 import되는 클래스
- 인증, 예외, 응답 래퍼, 설정, 공통 DTO, 공통 utility, 공통 client
- 공통 모듈의 배포 단위 여부와 JAR 산출 여부는 build 설정을 근거로 구분

## 3. 코드 의존성 흐름

- `IMPORT`: 내부 package import 연결
- `IMPLEMENTS`: Interface와 구현체 연결
- `INJECTION`: 생성자/필드/Resource/Qualifier 주입 연결
- `BEAN_FACTORY`: `@Bean` 팩토리 메서드와 런타임 Bean 연결
- `API_CALL`: Controller 또는 Client의 API 연결
- `RESOURCE_CALL`: Oracle/Redis/Elasticsearch/Kafka/Prometheus/Loki 연결

대표 흐름은 다음 형태로 구성한다.

```text
화면/외부호출 → Controller/API → Service Interface → Implementation
→ Repository/Mapper/Client → Oracle·Redis·Elasticsearch·Kafka
→ Prometheus Metric·Loki Log → Grafana Dashboard
```

## 4. Resource Topology

- 애플리케이션 Class/Method를 Source node로 둔다.
- Oracle Table/Procedure, Redis Cache/Key/Channel, Elasticsearch Index, Kafka Topic/Group, Prometheus Metric, Loki Stream/Query를 Target node로 둔다.
- 방향은 `INBOUND`, `OUTBOUND`, `READ`, `WRITE`, `PUBLISH`, `CONSUME`, `OBSERVE`로 표현한다.
- 설정만 존재하고 호출부가 확인되지 않으면 Resource Inventory에는 포함하되 Topology 확정 연결로 단정하지 않는다.

## 5. JAR 획득 및 내부 구조

- Maven Central, 사내 Nexus/Artifactory, Gradle repository, local `libs/*.jar`를 구분한다.
- GAV와 repository를 통해 다운로드 URL 후보를 만든다.
- Version 미기재, dynamic version, SNAPSHOT은 검토대상으로 기록한다.
- JAR Manifest, Maven coordinate, exported package, Service Provider, Spring AutoConfiguration을 분석한다.
- 소스 Import와 JAR package가 일치할 때만 JAR 사용 연결을 만든다.

## 6. 배포 아키텍처

- Workload → Container/Image → Port/Service → Ingress 흐름을 구성한다.
- ConfigMap/Secret/Env → 애플리케이션 설정 → 외부 Resource 연결을 구성한다.
- ServiceMonitor/PodMonitor → Prometheus → Grafana 흐름을 구성한다.
- Application Log → Promtail/Alloy → Loki → Grafana 흐름을 구성한다.

## 7. 정적 분석과 런타임 병합

- 정적 결과는 `SOURCE`, 런타임 결과는 `RUNTIME` 출처로 구분한다.
- 런타임 메타데이터가 정적 이름과 일치하면 연결 후보를 강화한다.
- 런타임에서만 발견된 리소스는 별도 행으로 추가하고 소스 사용 여부를 `확인필요`로 둔다.
- 연결 실패는 장애로 단정하지 않고 점검 시각과 오류 유형을 함께 기록한다.

## 8. 리스크 분류

- HIGH: 분석 대상 없음, Secret 원문 노출 위험, 필수 산출물 생성 실패
- MEDIUM: 구현체 미확인, 동적 API/Topic/Index/Table, JAR 획득 경로 미확인
- LOW: 설정만 존재하고 사용처 미확인, 파서가 처리하지 못한 파일, 선택적 런타임 점검 실패
