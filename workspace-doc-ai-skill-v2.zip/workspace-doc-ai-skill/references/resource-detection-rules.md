# 운영 Resource 자동 탐지 규칙

## 지원 Resource

- ORACLE
- REDIS
- ELASTICSEARCH
- KAFKA
- GRAFANA
- PROMETHEUS
- LOKI

## 탐지 신호

각 Resource는 다음 신호를 조합하여 탐지한다.

1. Dependency coordinate
2. Source import/annotation/method call
3. Application configuration key
4. Docker/Kubernetes/Helm env와 manifest
5. SQL/JSON/YAML 운영 자산
6. 선택적 Runtime endpoint와 metadata

## 상태 기준

- `DETECTED`: 설정, dependency, code, asset 중 하나 이상 탐지
- `CONNECTED`: 코드 인터페이스와 target이 연결됨
- `RUNTIME_OK`: 읽기 전용 Runtime 점검 성공
- `RUNTIME_FAILED`: 점검 시도 후 실패
- `REVIEW_REQUIRED`: 동적 값, 사용처 없음, 출처 충돌

## Resource별 핵심 Interface

| Resource | OUTBOUND/WRITE | INBOUND/READ | Asset |
|---|---|---|---|
| Oracle | INSERT/UPDATE/DELETE/MERGE/CALL | SELECT/CURSOR | Table/View/Sequence/PLSQL |
| Redis | SET/CACHE_PUT/PUBLISH/LOCK | GET/CACHE_GET/SUBSCRIBE | Key/Cache/Channel/Lock |
| Elasticsearch | INDEX/BULK/UPDATE/DELETE | SEARCH/GET | Index/Alias/Template |
| Kafka | PRODUCE/PUBLISH | CONSUME/LISTEN | Topic/Group/Stream |
| Grafana | Provisioning/API | Dashboard 조회 | Dashboard/Panel/Datasource/Alert |
| Prometheus | Metric expose/Rule config | Scrape/Query | Metric/Target/Rule |
| Loki | Push/Append | Query | Stream/Label/LogQL/Job |

## Endpoint 자동 사용 제한

- 소스에서 탐지된 endpoint는 문서화 후보로만 사용한다.
- 실제 접속은 `runtime_probe.enabled=true`이면서 `allow_discovered_endpoints=true`인 경우에만 허용한다.
- 환경변수로 명시한 endpoint가 우선한다.
- endpoint는 사용자정보/Password/Token을 제거하거나 마스킹해서 저장한다.
