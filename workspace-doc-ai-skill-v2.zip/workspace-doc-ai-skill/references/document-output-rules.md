# 산출물 작성 규칙

## 1. 공통

- 모든 문서에는 시스템명, 생성일, Workspace root, 분석 출처를 표기한다.
- 사실은 분석 JSON 또는 Runtime 결과의 근거만 사용한다.
- 확정할 수 없는 내용은 `확인필요` 또는 `requires_review`로 표시한다.
- Password, token, secret, API key, credential, private key는 `***MASKED***`로 표시한다.
- 파일 경로와 Line을 가능한 모든 표에 포함한다.
- 동일 항목의 Source/Runtime 근거는 출처를 구분하여 함께 남긴다.

## 2. PowerPoint 매뉴얼

### 공통 구조

1. 표지: 문서명, 시스템명, 생성일
2. 목차/대상 화면 또는 운영 항목
3. 화면/리소스별 상세 장표
4. 확인필요 및 캡처 실패 항목

### 사용자메뉴얼

- 화면명, URL, 대상 사용자, 태그, 기능 설명, 사용 절차, 확인 항목, 캡처 이미지를 포함한다.
- DOM에서 추출한 버튼/입력/표 제목은 실제 화면 요소로만 기록한다.
- 업무 의미를 코드나 화면명만으로 임의 생성하지 않는다.
- 캡처 실패 시 URL, 실패 시각, 오류 사유를 표시한다.

### 운영자메뉴얼

- Oracle, Redis, Elasticsearch, Kafka, Grafana, Prometheus, Loki별 탐지 결과를 요약한다.
- Runtime 점검 활성화 여부, 상태, endpoint 마스킹 값, 점검 항목을 표시한다.
- Grafana dashboard와 Prometheus Targets/Alerts/Rules 화면을 가능한 경우 포함한다.
- UI가 없는 Resource는 구성, 코드 연계, 운영 점검 절차를 표 형식으로 설명한다.
- 로그 본문, Redis 값, Secret 값은 포함하지 않는다.

## 3. Excel 문서

- 첫 시트는 요약 또는 핵심 목록으로 둔다.
- 각 시트는 제목행, 설명행, 헤더행, 데이터행 순으로 구성한다.
- 헤더 고정, 자동 필터, 줄바꿈, 적정 열 너비를 적용한다.
- 데이터가 없더라도 필수 시트와 헤더를 유지한다.
- 주요 시트에 `근거파일`, `Line`, `출처`, `상태/확인필요` 컬럼을 둔다.
- 한 Cell에 Secret 원문이나 과도한 소스 전문을 넣지 않는다.

## 4. 문서별 핵심 목적

- 인터페이스명세서: API, 코드 연결, 외부 Resource 송수신 및 Runtime 연결
- 프로그램목록: 모듈/파일/Class/Method/화면/공통소스/배포 단위
- WorkBook: 분석 범위, 근거, 리소스 현황, 구현 흐름, 검토 체크리스트
- 테이블정의서: Oracle DDL/JPA/MyBatis/SQL/Runtime metadata 통합
- 아키텍쳐정의서: 모듈/컴포넌트/JAR/배포/Resource/관측 Topology

## 5. 품질 검증

- 2개 PPT와 5개 Excel이 모두 생성되어야 한다.
- 생성 파일은 실제로 다시 열어 손상 여부를 검사한다.
- Excel 필수 시트명과 PPT 최소 슬라이드 수를 검사한다.
- 분석 오류와 확인필요 항목이 누락되지 않았는지 확인한다.
