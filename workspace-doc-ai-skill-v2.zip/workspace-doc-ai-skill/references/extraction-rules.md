# Workspace 추출 규칙

## 1. 분석 우선순위

1. 소스 코드와 빌드 파일을 기준으로 정적 분석한다.
2. 설정 파일, Kubernetes/Helm 리소스, 관측 설정을 함께 연결한다.
3. 로컬 JAR 내부 메타데이터와 소스 Import를 연결한다.
4. 런타임 점검이 활성화된 경우 정적 분석 결과에 조회성 메타데이터를 병합한다.
5. 서로 다른 근거가 충돌하면 임의로 하나를 선택하지 않고 `확인필요`로 남긴다.

## 2. Java/Kotlin/Spring

- `@RestController`, `@Controller`와 Mapping Annotation으로 API를 추출한다.
- Class level path와 Method level path를 결합한다.
- `@FeignClient`, WebClient, RestTemplate, HTTP client 사용을 외부 연계 후보로 추출한다.
- `interface`, `implements`, 상속 관계로 Interface-Implementation 연결을 만든다.
- 필드/생성자 `@Autowired`, `@Inject`, `@Resource`, `@Qualifier`와 `@Bean`을 주입 관계로 추출한다.
- `@Entity`, `@Table`, `@Column`, `@Id`, Spring Data Repository로 Entity-Table 연결을 추출한다.
- `@Scheduled`, `@KafkaListener`, ApplicationRunner/CommandLineRunner는 Listener-Scheduler 프로그램으로 분류한다.
- 패키지 또는 경로에 common/core/shared/base/framework/util/config/security가 포함되면 공통소스 후보로 분류한다.

## 3. Maven/Gradle/JAR

- `pom.xml`, `build.gradle`, `build.gradle.kts`, `settings.gradle`, `libs.versions.toml`을 분석한다.
- dependency의 group/artifact/version/scope 또는 configuration, repository, plugin, module을 추출한다.
- `files(...)`, `fileTree(...)`, `libs/*.jar`와 Workspace 내 `.jar`를 로컬 JAR로 기록한다.
- JAR의 Manifest, `pom.properties`, package, class 수, `META-INF/services`, Spring AutoConfiguration 정보를 추출한다.
- repository와 GAV를 조합해 다운로드 URL 후보를 만든다.
- 선택적으로 `.m2` 및 Gradle cache에서 실제 JAR 위치를 찾는다.
- 소스 Import가 로컬 JAR package와 일치하면 JAR사용연결로 기록한다.

## 4. Oracle

- Spring datasource, JDBC URL, driver, JPA dialect, MyBatis 설정을 Oracle 연결 후보로 추출한다.
- SQL 파일에서 Table, Column, PK/FK/Unique, Index, Sequence, View, Package, Procedure, Function, Trigger, Synonym을 추출한다.
- `COMMENT ON TABLE/COLUMN`을 설명에 연결한다.
- Java/Kotlin의 native query, JDBC SQL, JPA annotation과 MyBatis statement에서 SELECT/INSERT/UPDATE/DELETE/MERGE/CALL 대상 오브젝트를 추출한다.
- Schema가 생략된 오브젝트는 임의의 Schema를 붙이지 않는다.
- Dynamic SQL과 변수 치환 오브젝트명은 원문을 남기고 `확인필요`로 표시한다.

## 5. Redis

- `spring.data.redis`, `spring.redis`, Redisson 설정과 Kubernetes env를 추출한다.
- RedisTemplate/StringRedisTemplate, Spring Cache, `@Cacheable`, `@CachePut`, `@CacheEvict`, Redisson Lock, Pub/Sub 사용을 추출한다.
- Key/Cache name/Topic/TTL이 상수이면 값과 출처를 기록하고, 표현식이면 표현식을 그대로 보존한다.
- 런타임 Key 값은 읽지 않는다. Key 이름 스캔도 명시적으로 활성화된 경우에만 수행한다.

## 6. Elasticsearch

- URI/host/port/username/API key 관련 설정을 마스킹하여 추출한다.
- `@Document(indexName=...)`, ElasticsearchRepository, RestHighLevelClient, Java API Client, Spring Data operations를 추출한다.
- Search/Index/Bulk/Update/Delete 호출과 대상 Index 후보를 인터페이스로 기록한다.
- Index alias/template/ILM 관련 JSON/YAML 설정이 있으면 리소스 자산으로 기록한다.

## 7. Kafka

- bootstrap servers, security protocol, SASL/SSL, serializer/deserializer 설정을 추출한다.
- KafkaTemplate, ProducerRecord, `@KafkaListener`, Consumer, Streams source/sink를 추출한다.
- Topic, Group ID, Client ID가 literal이면 값으로 기록하고 placeholder/SpEL이면 원문을 보존한다.
- Producer는 OUTBOUND, Consumer/Listener는 INBOUND로 구분한다.

## 8. Grafana

- Dashboard JSON에서 dashboard UID/title/tags, panel ID/title/type, datasource, query, alert를 추출한다.
- provisioning datasource/dashboard YAML을 추출한다.
- Prometheus와 Loki datasource를 Query 언어 및 운영 리소스와 연결한다.
- 화면 캡처는 Dashboard URL을 자동 생성하되 인증 실패와 접근 불가를 문서에 남긴다.

## 9. Prometheus

- Micrometer MeterRegistry, Counter, Gauge, Timer, DistributionSummary와 metric name/tag 후보를 추출한다.
- `prometheus.yml` scrape_config, ServiceMonitor, PodMonitor, PrometheusRule를 추출한다.
- Targets/Alerts/Rules 화면을 운영자 매뉴얼 캡처 후보로 만든다.
- Expression과 Rule 이름을 변경하지 않고 원문으로 기록한다.

## 10. Loki

- Loki endpoint, Promtail/Alloy scrape config, pipeline stage, label, tenant 설정을 추출한다.
- Logback/Log4j Loki appender와 push client를 추출한다.
- Grafana panel의 LogQL query를 Loki Query로 연결한다.
- 로그 본문은 분석하거나 문서에 포함하지 않는다.

## 11. Kubernetes/배포

- Deployment, StatefulSet, DaemonSet, CronJob, Job, Service, Ingress, ConfigMap, Secret 참조를 추출한다.
- Workload, container image, port, env/envFrom, volume, probe, resource request/limit을 가능한 범위에서 기록한다.
- Secret의 값은 읽거나 출력하지 않는다.
- ServiceMonitor, PodMonitor, PrometheusRule와 대상 Service/Namespace를 연결한다.

## 12. 근거 및 신뢰도

- 각 항목에는 가능한 한 `source_path`, `line`, annotation/config key/evidence를 기록한다.
- 정적 분석으로 확정되지 않는 동적 값은 `확인필요`로 표시한다.
- 런타임 결과는 정적 분석 결과를 덮어쓰지 않고 별도 출처로 병합한다.
- 분석 실패 파일은 `analysis_errors`와 검토항목에 남긴다.
