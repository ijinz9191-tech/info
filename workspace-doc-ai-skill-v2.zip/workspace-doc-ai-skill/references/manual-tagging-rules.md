# 화면 태그 규칙

- URL 또는 제목에 login/sign/auth가 있으면 `인증`
- dashboard/main/home이면 `메인`, `현황`
- admin/operator/ops/manage이면 `운영`
- user/member/account이면 `사용자관리`
- search/list/grid/table이면 `조회`
- create/new/register이면 `등록`
- edit/update/modify이면 `수정`
- delete/remove이면 `삭제`
- report/stat/chart이면 `통계`, `리포트`
- health/monitor/metric/log이면 `모니터링`, `운영`

자동 태그는 항상 근거 텍스트를 남기고, 확신이 낮으면 `확인필요`를 추가한다.
