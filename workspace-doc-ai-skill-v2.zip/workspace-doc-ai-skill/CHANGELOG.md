# Changelog

## 2.0.0

- Oracle DDL/PLSQL/Runtime schema metadata 분석 추가
- Redis cache/key/lock/pubsub와 Runtime INFO 분석 추가
- Elasticsearch index/repository/client 및 cluster/index Runtime 분석 추가
- Kafka producer/consumer/topic/group/streams 및 broker/topic Runtime 분석 추가
- Grafana dashboard/panel/datasource/query/API 분석 추가
- Prometheus metric/scrape/ServiceMonitor/PodMonitor/PrometheusRule 분석 추가
- Loki/Promtail/LogQL/Logging appender 분석 추가
- Grafana/Prometheus/Loki 운영 화면 자동 캡처 스크립트 추가
- Local JAR 내부 Manifest/Maven/SPI/Spring AutoConfiguration 분석 추가
- Maven/Gradle Repository 다운로드 후보와 dependency cache 위치 분석 추가
- Java constructor injection, Kotlin 기본 분석, `@Bean` 연결 추가
- 모든 Excel 문서에 리소스별 상세 시트 추가
- 운영자 매뉴얼에 리소스별 점검·runtime 상태·관측 스택 슬라이드 추가
- Secret 마스킹과 읽기 전용 runtime probe 안전장치 강화
- 생성된 JSON/Excel/PPT 자동 무결성 검증과 `validation_report.json` 추가
- 운영 UI 자동 발견 URL 접속을 별도 opt-in으로 제한
- Generic Java class/record 및 공통 모듈 탐지 보강
