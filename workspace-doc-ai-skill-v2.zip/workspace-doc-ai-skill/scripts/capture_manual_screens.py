from __future__ import annotations

import argparse
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List
from urllib.parse import urljoin

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from utils.config_loader import ensure_dir, env_or_empty, load_config, resolve_path

try:
    import yaml
except Exception:
    yaml = None

TAG_RULES = [
    (("login", "sign", "auth"), ["인증"]),
    (("dashboard", "main", "home"), ["메인", "현황"]),
    (("admin", "operator", "ops", "manage"), ["운영"]),
    (("user", "member", "account"), ["사용자관리"]),
    (("search", "list", "grid", "table"), ["조회"]),
    (("create", "new", "register"), ["등록"]),
    (("edit", "update", "modify"), ["수정"]),
    (("delete", "remove"), ["삭제"]),
    (("report", "stat", "chart"), ["통계", "리포트"]),
    (("health", "monitor", "metric", "log"), ["모니터링", "운영"]),
]


def slugify(value: str) -> str:
    value = re.sub(r"[^0-9A-Za-z가-힣._-]+", "-", value.strip())
    return value.strip("-") or "screen"


def normalize_base_url(base_url: str) -> str:
    return base_url.rstrip("/") + "/"


def build_url(base_url: str, path_or_url: str) -> str:
    if path_or_url.startswith("http://") or path_or_url.startswith("https://"):
        return path_or_url
    return urljoin(normalize_base_url(base_url), path_or_url.lstrip("/"))


def derive_tags(title: str, path: str, text: str = "") -> List[str]:
    source = f"{title} {path} {text[:500]}".lower()
    tags: List[str] = []
    for keys, values in TAG_RULES:
        if any(k in source for k in keys):
            tags.extend(values)
    if not tags:
        tags.append("확인필요")
    return sorted(set(tags))


def load_pages(cfg: Dict[str, Any], base_dir: Path, analysis_path: Path) -> List[Dict[str, Any]]:
    ss = cfg.get("screenshots", {}) or {}
    page_file = ss.get("manual_pages_file", "")
    pages: List[Dict[str, Any]] = []
    if page_file:
        pf = resolve_path(base_dir, page_file)
        if pf.exists() and yaml is not None:
            data = yaml.safe_load(pf.read_text(encoding="utf-8")) or {}
            pages.extend(data.get("pages", []))
    if not pages and analysis_path.exists():
        analysis = json.loads(analysis_path.read_text(encoding="utf-8"))
        for idx, route in enumerate(analysis.get("frontend", {}).get("routes", [])[:200], start=1):
            path = route.get("path", "")
            title = route.get("title") or path.strip("/").replace("/", " > ") or "메인"
            pages.append({
                "id": f"route-{idx}",
                "title": title,
                "audience": "user",
                "path": path,
                "tags": derive_tags(title, path),
                "content": "프론트 라우트 분석으로 자동 생성된 화면 후보다. 실제 업무 설명 확인이 필요하다.",
                "steps": ["화면에 접속한다.", "표시되는 주요 항목을 확인한다."],
                "checks": ["화면명과 업무 설명을 담당자가 검토해야 한다."],
                "requires_review": True,
                "source_path": route.get("source_path", ""),
            })
    return pages


def extract_dom_metadata(page: Any) -> Dict[str, Any]:
    metadata: Dict[str, Any] = {"document_title": "", "headings": [], "buttons": [], "inputs": [], "links": [], "text_sample": ""}
    try:
        metadata["document_title"] = page.title()
    except Exception:
        pass
    try:
        headings = page.locator("h1,h2,h3,[role='heading']").all_inner_texts()
        metadata["headings"] = [h.strip() for h in headings if h.strip()][:20]
    except Exception:
        pass
    try:
        buttons = page.locator("button,input[type='button'],input[type='submit'],[role='button']").all_inner_texts()
        metadata["buttons"] = [b.strip() for b in buttons if b.strip()][:50]
    except Exception:
        pass
    try:
        inputs = page.locator("input,select,textarea").evaluate_all("""
            els => els.slice(0, 80).map(e => ({
                name: e.getAttribute('name') || '',
                placeholder: e.getAttribute('placeholder') || '',
                type: e.getAttribute('type') || e.tagName.toLowerCase(),
                label: e.getAttribute('aria-label') || ''
            }))
        """)
        metadata["inputs"] = inputs
    except Exception:
        pass
    try:
        links = page.locator("a").evaluate_all("els => els.slice(0, 80).map(e => ({text: (e.innerText || '').trim(), href: e.getAttribute('href') || ''}))")
        metadata["links"] = [x for x in links if x.get("text") or x.get("href")]
    except Exception:
        pass
    try:
        text = page.locator("body").inner_text(timeout=3000)
        metadata["text_sample"] = re.sub(r"\s+", " ", text).strip()[:2000]
    except Exception:
        pass
    return metadata


def enrich_page(page_def: Dict[str, Any], dom: Dict[str, Any]) -> Dict[str, Any]:
    p = dict(page_def)
    title = p.get("title") or (dom.get("headings") or [""])[0] or dom.get("document_title") or p.get("path") or p.get("id")
    p["title"] = title
    text_source = " ".join(dom.get("headings", [])) + " " + dom.get("text_sample", "")
    if not p.get("tags"):
        p["tags"] = derive_tags(title, p.get("path", ""), text_source)
        p["tags_auto_generated"] = True
    if not p.get("content"):
        headings = ", ".join(dom.get("headings", [])[:5])
        p["content"] = f"화면에서 확인된 주요 문구: {headings or dom.get('text_sample', '')[:300] or '확인필요'}"
        p["requires_review"] = True
    if not p.get("steps"):
        buttons = [b for b in dom.get("buttons", []) if b]
        p["steps"] = [f"'{b}' 버튼을 확인하거나 클릭한다." for b in buttons[:5]] or ["화면에 접속한다.", "표시된 항목을 확인한다."]
        p["requires_review"] = True
    if not p.get("checks"):
        p["checks"] = ["화면 데이터와 권한별 노출 여부를 확인한다."]
    p["dom_metadata"] = dom
    return p


def run_login(context: Any, page: Any, cfg: Dict[str, Any], base_url: str) -> None:
    login = (cfg.get("screenshots", {}) or {}).get("login", {}) or {}
    if not login.get("enabled"):
        return
    username = env_or_empty(login.get("username_env", "DOC_LOGIN_USERNAME"))
    password = env_or_empty(login.get("password_env", "DOC_LOGIN_PASSWORD"))
    if not username or not password:
        print("login skipped: username/password env missing")
        return
    url = build_url(base_url, login.get("url", "/login"))
    page.goto(url, wait_until="domcontentloaded", timeout=int((cfg.get("screenshots", {}) or {}).get("wait_timeout_ms", 20000)))
    page.fill(login.get("username_selector", "input[name='username']"), username)
    page.fill(login.get("password_selector", "input[name='password']"), password)
    page.click(login.get("submit_selector", "button[type='submit']"))
    success_selector = login.get("success_selector", "body")
    page.wait_for_selector(success_selector, timeout=int((cfg.get("screenshots", {}) or {}).get("wait_timeout_ms", 20000)))


def main() -> None:
    parser = argparse.ArgumentParser(description="Capture screenshots and build manual page metadata.")
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    cfg = load_config(args.config)
    base_dir = Path(cfg["_base_dir"])
    output_root = resolve_path(base_dir, cfg.get("output", {}).get("dir", "output"))
    analysis_path = output_root / "analysis" / "workspace_analysis.json"
    ss = cfg.get("screenshots", {}) or {}
    screenshot_dir = ensure_dir(resolve_path(base_dir, ss.get("output_dir", str(output_root / "screenshots"))))
    generated_path = screenshot_dir / "manual_pages.generated.json"

    pages = load_pages(cfg, base_dir, analysis_path)
    if not pages:
        generated_path.write_text(json.dumps({"generated_at": datetime.now().isoformat(), "pages": []}, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"no pages. metadata written: {generated_path}")
        return

    if not ss.get("enabled", False):
        # 캡처 비활성화여도 PPT에 들어갈 태그/내용 파일은 만든다.
        normalized = []
        for p in pages:
            title = p.get("title") or p.get("id") or p.get("path") or "화면"
            if not p.get("tags"):
                p["tags"] = derive_tags(title, p.get("path", ""))
            p["screenshot_status"] = "SKIPPED"
            p["screenshot_error"] = "screenshots.enabled=false"
            normalized.append(p)
        generated_path.write_text(json.dumps({"generated_at": datetime.now().isoformat(), "pages": normalized}, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"screenshot disabled. metadata written: {generated_path}")
        return

    try:
        from playwright.sync_api import sync_playwright
    except Exception as e:
        for p in pages:
            p["screenshot_status"] = "FAILED"
            p["screenshot_error"] = f"playwright import failed: {e}"
        generated_path.write_text(json.dumps({"generated_at": datetime.now().isoformat(), "pages": pages}, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"playwright unavailable. metadata written: {generated_path}")
        return

    base_url = ss.get("base_url", "http://localhost:3000")
    wait_until = ss.get("wait_until", "networkidle")
    wait_timeout = int(ss.get("wait_timeout_ms", 20000))
    viewport = ss.get("viewport", {}) or {"width": 1440, "height": 1000}
    full_page = bool(ss.get("full_page", True))
    extract_dom = bool(ss.get("extract_dom_text", True))

    captured = []
    with sync_playwright() as pctx:
        browser = pctx.chromium.launch(headless=bool(ss.get("headless", True)))
        context = browser.new_context(viewport={"width": int(viewport.get("width", 1440)), "height": int(viewport.get("height", 1000))})
        page = context.new_page()
        try:
            run_login(context, page, cfg, base_url)
        except Exception as e:
            print(f"login failed: {e}")
        for idx, page_def in enumerate(pages, start=1):
            pd = dict(page_def)
            path = pd.get("url") or pd.get("path") or "/"
            url = build_url(base_url, path)
            screen_id = slugify(pd.get("id") or pd.get("title") or path or f"screen-{idx}")
            img_path = screenshot_dir / f"{idx:03d}-{screen_id}.png"
            try:
                page.goto(url, wait_until=wait_until, timeout=wait_timeout)
                dom = extract_dom_metadata(page) if extract_dom else {}
                pd = enrich_page(pd, dom)
                page.screenshot(path=str(img_path), full_page=full_page)
                pd["url"] = url
                pd["screenshot_path"] = str(img_path)
                pd["screenshot_status"] = "OK"
            except Exception as e:
                pd["url"] = url
                pd["screenshot_status"] = "FAILED"
                pd["screenshot_error"] = str(e)
                if not pd.get("tags"):
                    pd["tags"] = derive_tags(pd.get("title", ""), path)
                pd.setdefault("content", "화면 캡처 실패로 실제 화면 내용 확인이 필요하다.")
                pd["requires_review"] = True
            captured.append(pd)
        browser.close()

    generated_path.write_text(json.dumps({"generated_at": datetime.now().isoformat(), "pages": captured}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"manual metadata written: {generated_path}")


if __name__ == "__main__":
    main()
