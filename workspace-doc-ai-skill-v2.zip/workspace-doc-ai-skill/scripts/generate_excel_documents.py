from __future__ import annotations

import argparse
import json
import math
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from utils.config_loader import ensure_dir, load_config, resolve_path

try:
    from openpyxl import Workbook
    from openpyxl.formatting.rule import CellIsRule
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
except Exception as exc:
    raise RuntimeError("openpyxl is required. install requirements.txt") from exc

TITLE_FILL = "17365D"
HEADER_FILL = "D9EAF7"
SUB_FILL = "EEF5FB"
WARN_FILL = "FFF2CC"
FAIL_FILL = "F4CCCC"
OK_FILL = "D9EAD3"
THIN = Side(style="thin", color="D9E2F3")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
MAX_EXCEL_DATA_ROWS = 1_000_000


def text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (list, tuple, set)):
        return ", ".join(text(item) for item in value)
    if isinstance(value, dict):
        return json.dumps(value, ensure_ascii=False, default=str)
    return str(value)


def new_workbook(first_sheet: str) -> Workbook:
    workbook = Workbook()
    workbook.active.title = first_sheet[:31]
    return workbook


def set_doc_props(workbook: Workbook, title: str, author: str) -> None:
    workbook.properties.title = title
    workbook.properties.creator = author
    workbook.properties.created = datetime.now()
    workbook.properties.description = "Workspace static analysis and optional read-only runtime probe generated documentation"


def get_or_create_sheet(workbook: Workbook, name: str, use_active: bool = False) -> Any:
    clean = name[:31]
    if clean in workbook.sheetnames:
        return workbook[clean]
    if use_active and len(workbook.sheetnames) == 1 and workbook.active.max_row == 1 and workbook.active["A1"].value is None:
        workbook.active.title = clean
        return workbook.active
    return workbook.create_sheet(clean)


def auto_width(sheet: Any, max_col: int) -> None:
    width_caps = {1: 24, 2: 30}
    for col in range(1, max_col + 1):
        letter = get_column_letter(col)
        max_len = 10
        for cell in sheet[letter]:
            if cell.value is not None:
                lines = str(cell.value).splitlines()
                first_line = lines[0] if lines else ""
                max_len = max(max_len, min(80, len(first_line) + 2))
        cap = 55 if col > 2 else width_caps.get(col, 40)
        sheet.column_dimensions[letter].width = min(max_len, cap)


def write_table(sheet: Any, title: str, headers: Sequence[str], rows: Sequence[Sequence[Any]], start_row: int = 1) -> None:
    row_no = start_row
    max_col = max(1, len(headers))
    sheet.merge_cells(start_row=row_no, start_column=1, end_row=row_no, end_column=max_col)
    title_cell = sheet.cell(row=row_no, column=1, value=title)
    title_cell.font = Font(bold=True, size=14, color="FFFFFF")
    title_cell.fill = PatternFill("solid", fgColor=TITLE_FILL)
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    sheet.row_dimensions[row_no].height = 26
    row_no += 2
    for col, header in enumerate(headers, start=1):
        cell = sheet.cell(row=row_no, column=col, value=header)
        cell.font = Font(bold=True, color="1F1F1F")
        cell.fill = PatternFill("solid", fgColor=HEADER_FILL)
        cell.border = BORDER
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    header_row = row_no
    row_no += 1
    if not rows:
        sheet.cell(row=row_no, column=1, value="데이터 없음").border = BORDER
        row_no += 1
    else:
        for values in rows:
            for col, value in enumerate(values, start=1):
                cell = sheet.cell(row=row_no, column=col, value=text(value))
                cell.border = BORDER
                cell.alignment = Alignment(vertical="top", wrap_text=True)
                if isinstance(value, (int, float)) and not isinstance(value, bool):
                    cell.value = value
            row_no += 1
    sheet.freeze_panes = sheet.cell(row=header_row + 1, column=1).coordinate
    sheet.auto_filter.ref = f"A{header_row}:{get_column_letter(max_col)}{max(header_row, row_no - 1)}"
    sheet.sheet_view.showGridLines = False
    auto_width(sheet, max_col)
    # Common status highlighting.
    for col, header in enumerate(headers, start=1):
        if any(keyword in str(header).lower() for keyword in ("상태", "status", "심각도", "confidence")):
            letter = get_column_letter(col)
            end_row = max(header_row + 1, row_no - 1)
            sheet.conditional_formatting.add(f"{letter}{header_row+1}:{letter}{end_row}", CellIsRule(operator="equal", formula=['"UP"'], fill=PatternFill("solid", fgColor=OK_FILL)))
            sheet.conditional_formatting.add(f"{letter}{header_row+1}:{letter}{end_row}", CellIsRule(operator="equal", formula=['"DOWN"'], fill=PatternFill("solid", fgColor=FAIL_FILL)))
            sheet.conditional_formatting.add(f"{letter}{header_row+1}:{letter}{end_row}", CellIsRule(operator="equal", formula=['"확인필요"'], fill=PatternFill("solid", fgColor=WARN_FILL)))


def write_dataset(workbook: Workbook, base_name: str, title: str, headers: Sequence[str], rows: Iterable[Sequence[Any]], use_active: bool = False) -> None:
    data = list(rows)
    if not data:
        sheet = get_or_create_sheet(workbook, base_name, use_active=use_active)
        write_table(sheet, title, headers, [])
        return
    chunks = math.ceil(len(data) / MAX_EXCEL_DATA_ROWS)
    for index in range(chunks):
        start = index * MAX_EXCEL_DATA_ROWS
        end = min(len(data), start + MAX_EXCEL_DATA_ROWS)
        suffix = "" if index == 0 else f"-{index+1}"
        sheet = get_or_create_sheet(workbook, (base_name[: 31 - len(suffix)] + suffix), use_active=use_active and index == 0)
        write_table(sheet, title + (f" ({index+1}/{chunks})" if chunks > 1 else ""), headers, data[start:end])


def save(workbook: Workbook, path: Path, title: str, author: str) -> None:
    set_doc_props(workbook, title, author)
    path.parent.mkdir(parents=True, exist_ok=True)
    workbook.save(path)
    print(f"excel written: {path}")


def resource_rows(analysis: Dict[str, Any], resource_type: Optional[str] = None) -> List[List[Any]]:
    rows = []
    for item in analysis.get("resources", {}).get("interfaces", []):
        if resource_type and item.get("resource_type") != resource_type:
            continue
        rows.append([
            item.get("resource_type"), item.get("direction"), item.get("source_component"), item.get("operation"),
            item.get("target"), item.get("client_api"), item.get("detail"), item.get("confidence"),
            item.get("source_path"), item.get("line"),
        ])
    return rows


def runtime_rows(analysis: Dict[str, Any]) -> List[List[Any]]:
    rows = []
    for result in (((analysis.get("resources") or {}).get("runtime_probe") or {}).get("results") or []):
        details = result.get("details") or {}
        summary = {
            "ORACLE": f"schema={details.get('current_schema','')}, tables={len(details.get('tables',[]) or [])}",
            "REDIS": f"dbsize={details.get('dbsize','')}, version={((details.get('server') or {}).get('redis_version',''))}",
            "ELASTICSEARCH": f"cluster={details.get('cluster_name','')}, indices={len(details.get('indices',[]) or [])}",
            "KAFKA": f"topics={len(details.get('topics',[]) or [])}, reachable={len(details.get('reachable_brokers',[]) or [])}",
            "GRAFANA": f"dashboards={len(details.get('dashboards',[]) or [])}, datasources={len(details.get('datasources',[]) or [])}",
            "PROMETHEUS": f"targets={len((((details.get('targets') or {}).get('data') or {}).get('activeTargets') or []))}",
            "LOKI": f"labels={len(((details.get('labels') or {}).get('data') or []))}",
        }.get(result.get("resource_type"), "")
        rows.append([
            result.get("resource_type"), result.get("target"), result.get("status"), result.get("latency_ms"),
            summary, result.get("error"), result.get("source"),
        ])
    return rows


def generate_interface_spec(analysis: Dict[str, Any], out: Path, author: str) -> None:
    workbook = new_workbook("API 인터페이스")
    write_dataset(workbook, "API 인터페이스", "API 인터페이스", ["모듈", "Controller", "HTTP", "URL", "Method", "Request", "Response", "Annotation", "근거파일", "Line"], (
        [item.get("module"), item.get("controller"), item.get("http_method"), item.get("path"), item.get("method_name"), item.get("request_params"), item.get("response_type"), item.get("annotation"), item.get("source_path"), item.get("line")]
        for item in analysis.get("java", {}).get("endpoints", [])
    ), use_active=True)
    write_dataset(workbook, "외부연계", "외부연계", ["유형", "명칭", "대상/버전", "근거", "근거파일", "Line"], (
        [item.get("type"), item.get("name"), item.get("target"), item.get("evidence"), item.get("source_path"), item.get("line")]
        for item in analysis.get("java", {}).get("external_interfaces", [])
    ))
    write_dataset(workbook, "Interface-Impl", "Interface-Impl", ["Interface", "Interface FQN", "구현체", "구현체 FQN", "Interface 근거", "구현체 근거", "상태", "Line"], (
        [row.get("interface_name"), row.get("interface_fqn"), row.get("implementation_class"), row.get("implementation_fqn"), row.get("interface_source_path"), row.get("implementation_source_path"), row.get("status"), row.get("line")]
        for row in analysis.get("java", {}).get("interface_impl", [])
    ))
    write_dataset(workbook, "주입연결", "주입연결", ["Source Class", "Injection", "Target Type", "Field", "Parameter", "Qualifier", "구현체 후보", "상태", "근거파일", "Line"], (
        [row.get("source_class"), row.get("injection_type"), row.get("target_type"), row.get("field_name"), row.get("parameter_name"), row.get("qualifier"), row.get("implementation_candidates"), row.get("status"), row.get("source_path"), row.get("line")]
        for row in analysis.get("java", {}).get("injections", [])
    ))
    write_dataset(workbook, "Bean연결", "Spring Bean Factory 연결", ["Configuration", "Bean Name", "Return Type", "Method", "근거파일", "Line"], (
        [row.get("configuration_class"), row.get("bean_name"), row.get("return_type"), row.get("method_name"), row.get("source_path"), row.get("line")]
        for row in analysis.get("java", {}).get("beans", [])
    ))
    headers = ["리소스", "방향", "Source Component", "Operation", "Target", "Client/API", "상세", "Confidence", "근거파일", "Line"]
    write_dataset(workbook, "리소스연계", "전체 리소스 연계", headers, resource_rows(analysis))
    for resource_type, sheet_name in (("ORACLE", "Oracle연계"), ("REDIS", "Redis연계"), ("ELASTICSEARCH", "Elasticsearch연계"), ("KAFKA", "Kafka연계")):
        write_dataset(workbook, sheet_name, sheet_name, headers, resource_rows(analysis, resource_type))
    monitoring = [row for resource in ("GRAFANA", "PROMETHEUS", "LOKI") for row in resource_rows(analysis, resource)]
    write_dataset(workbook, "모니터링연계", "Grafana / Prometheus / Loki 연계", headers, monitoring)
    write_dataset(workbook, "런타임점검", "선택적 읽기 전용 런타임 점검", ["리소스", "대상", "상태", "지연(ms)", "요약", "오류", "대상출처"], runtime_rows(analysis))
    write_dataset(workbook, "JAR-Dependency", "JAR / Dependency 획득", ["Scope", "Group", "Artifact/JAR", "Version", "획득방식", "Repository 후보", "캐시파일", "근거파일", "Line"], (
        [dep.get("configuration"), dep.get("group"), dep.get("artifact"), dep.get("version"), dep.get("acquisition_method"), dep.get("download_candidates"), dep.get("cached_files"), dep.get("source_path"), dep.get("line")]
        for dep in analysis.get("dependencies", {}).get("artifacts", [])
    ))
    write_dataset(workbook, "JAR내부구조", "Workspace Local JAR 내부 구조", ["JAR", "Class Count", "Packages", "Maven Coordinates", "Spring Auto Config", "오류"], (
        [jar.get("source_path"), jar.get("class_count"), jar.get("packages"), jar.get("maven_coordinates"), jar.get("spring_auto_configurations"), jar.get("errors")]
        for jar in analysis.get("dependencies", {}).get("jar_details", [])
    ))
    write_dataset(workbook, "JAR사용연결", "소스 Import와 Local JAR 연결", ["Source Class", "Import", "JAR", "Matched Package", "근거파일"], (
        [row.get("source_class"), row.get("import"), row.get("jar_file"), row.get("matched_package"), row.get("source_path")]
        for row in analysis.get("dependencies", {}).get("jar_usage", [])
    ))
    save(workbook, out / "인터페이스명세서.xlsx", "인터페이스명세서", author)


def generate_program_list(analysis: Dict[str, Any], out: Path, author: str) -> None:
    workbook = new_workbook("모듈목록")
    write_dataset(workbook, "모듈목록", "모듈목록", ["모듈명", "경로", "Build File 여부", "Build Files", "출처"], (
        [row.get("module_name"), row.get("module_path"), row.get("has_build_file"), row.get("build_files"), row.get("source_type")]
        for row in analysis.get("modules", [])
    ), use_active=True)
    write_dataset(workbook, "파일목록", "파일목록", ["모듈", "경로", "파일명", "확장자", "분류", "크기", "SHA1", "수정시각"], (
        [row.get("module"), row.get("path"), row.get("name"), row.get("extension"), row.get("kind"), row.get("size_bytes"), row.get("sha1"), row.get("modified_time")]
        for row in analysis.get("files", [])
    ))
    write_dataset(workbook, "클래스목록", "클래스목록", ["모듈", "종류", "Component Type", "Class", "FQN", "Extends", "Implements", "Annotations", "근거파일", "Line"], (
        [row.get("module"), row.get("kind"), row.get("component_type"), row.get("name"), row.get("fqn"), row.get("extends"), row.get("implements"), row.get("annotations"), row.get("source_path"), row.get("line")]
        for row in analysis.get("java", {}).get("classes", [])
    ))
    write_dataset(workbook, "메서드목록", "메서드목록", ["모듈", "Class", "Method", "Return", "Visibility", "Modifiers", "Params", "Annotations", "근거파일", "Line"], (
        [row.get("module"), row.get("class"), row.get("name"), row.get("return_type"), row.get("visibility"), row.get("modifiers"), row.get("params"), row.get("annotations"), row.get("source_path"), row.get("line")]
        for row in analysis.get("java", {}).get("methods", [])
    ))
    write_dataset(workbook, "화면-라우트", "화면-라우트", ["URL/Route", "Title", "확인필요", "근거파일"], (
        [row.get("path"), row.get("title"), row.get("requires_review"), row.get("source_path")]
        for row in analysis.get("frontend", {}).get("routes", [])
    ))
    write_dataset(workbook, "공통소스", "공통소스", ["모듈", "Class", "FQN", "Component Type", "선정사유", "근거파일", "Line"], (
        [row.get("module"), row.get("class_name"), row.get("fqn"), row.get("component_type"), row.get("reason"), row.get("source_path"), row.get("line")]
        for row in analysis.get("architecture", {}).get("common_sources", [])
    ))
    listeners = []
    for method in analysis.get("java", {}).get("methods", []):
        annotations = set(method.get("annotations", []) or [])
        matched = annotations.intersection({"KafkaListener", "Scheduled", "EventListener", "RabbitListener", "JmsListener", "RedisListener"})
        if matched:
            listeners.append([method.get("module"), method.get("class"), method.get("name"), sorted(matched), method.get("source_path"), method.get("line")])
    write_dataset(workbook, "Listener-Scheduler", "Listener / Scheduler", ["모듈", "Class", "Method", "종류", "근거파일", "Line"], listeners)
    write_dataset(workbook, "배포워크로드", "배포 워크로드", ["Kind", "Workload", "Namespace", "Container", "Image", "Ports", "Env Names", "근거파일"], (
        [row.get("kind"), row.get("workload"), row.get("namespace"), row.get("container"), row.get("image"), row.get("ports"), row.get("env_names"), row.get("source_path")]
        for row in analysis.get("deployment", {}).get("workloads", [])
    ))
    write_dataset(workbook, "리소스자산", "운영 리소스 자산", ["리소스", "Asset Type", "Name", "상세", "근거파일", "Line"], (
        [row.get("resource_type"), row.get("asset_type"), row.get("name"), row.get("detail"), row.get("source_path"), row.get("line")]
        for row in analysis.get("resources", {}).get("assets", [])
    ))
    save(workbook, out / "프로그램목록.xlsx", "프로그램목록", author)


def generate_workbook(analysis: Dict[str, Any], out: Path, author: str) -> None:
    workbook = new_workbook("요약")
    write_dataset(workbook, "요약", "요약", ["항목", "값"], ([key, value] for key, value in analysis.get("summary", {}).items()), use_active=True)
    checks = [
        ["Workspace 분석 JSON", "생성", "output/analysis/workspace_analysis.json"],
        ["런타임 점검 JSON", "조건부 생성", "output/analysis/runtime_probe.json"],
        ["인터페이스명세서", "생성", "output/excel/인터페이스명세서.xlsx"],
        ["프로그램목록", "생성", "output/excel/프로그램목록.xlsx"],
        ["사용자메뉴얼", "생성", "output/ppt/사용자메뉴얼.pptx"],
        ["운영자메뉴얼", "생성", "output/ppt/운영자메뉴얼.pptx"],
        ["테이블정의서", "생성", "output/excel/테이블정의서.xlsx"],
        ["아키텍쳐정의서", "생성", "output/excel/아키텍쳐정의서.xlsx"],
    ]
    write_dataset(workbook, "문서생성체크리스트", "문서생성체크리스트", ["문서", "상태", "경로"], checks)
    write_dataset(workbook, "분석범위", "분석범위", ["항목", "값"], [
        ["Workspace", analysis.get("workspace", {}).get("root")], ["시스템명", analysis.get("workspace", {}).get("name")],
        ["생성일", analysis.get("generated_at")], ["Schema Version", analysis.get("schema_version")],
        ["내부패키지루트", analysis.get("workspace", {}).get("internal_package_roots")], ["DB Engine", analysis.get("database", {}).get("engine")],
    ])
    write_dataset(workbook, "리소스현황", "리소스 자동탐지 현황", ["리소스", "Name", "Role", "Target", "Detection", "Confidence", "근거파일", "Line"], (
        [row.get("resource_type"), row.get("name"), row.get("role"), row.get("target"), row.get("detection"), row.get("confidence"), row.get("source_path"), row.get("line")]
        for row in analysis.get("resources", {}).get("inventory", [])
    ))
    write_dataset(workbook, "공통모듈분석", "공통모듈분석", ["모듈", "Class", "FQN", "Component Type", "사유", "근거파일", "Line"], (
        [row.get("module"), row.get("class_name"), row.get("fqn"), row.get("component_type"), row.get("reason"), row.get("source_path"), row.get("line")]
        for row in analysis.get("architecture", {}).get("common_sources", [])
    ))
    jar_rows = [["Repository", row.get("type"), row.get("url"), "", row.get("source_path"), row.get("line")] for row in analysis.get("dependencies", {}).get("repositories", [])]
    jar_rows += [["Dependency", row.get("configuration"), f"{row.get('group')}:{row.get('artifact')}:{row.get('version')}", row.get("acquisition_method"), row.get("source_path"), row.get("line")] for row in analysis.get("dependencies", {}).get("artifacts", [])]
    write_dataset(workbook, "JAR가져오기", "JAR가져오기", ["구분", "유형/Scope", "URL 또는 GAV", "획득방식", "근거파일", "Line"], jar_rows)
    write_dataset(workbook, "JAR서비스연결", "JAR Service Provider / Auto Configuration", ["JAR", "Service Interface", "Providers", "Spring Auto Config"], (
        [jar.get("source_path"), service.get("service_interface"), service.get("providers"), jar.get("spring_auto_configurations")]
        for jar in analysis.get("dependencies", {}).get("jar_details", []) for service in (jar.get("service_providers", []) or [{}])
    ))
    write_dataset(workbook, "구현흐름", "구현흐름", ["연결유형", "Source", "Target", "Source Module", "Target Module", "근거파일", "Line"], (
        [row.get("edge_type"), row.get("source"), row.get("target"), row.get("source_module"), row.get("target_module"), row.get("source_path"), row.get("line")]
        for row in analysis.get("architecture", {}).get("edges", []) if row.get("edge_type") != "RESOURCE_INTERFACE"
    ))
    write_dataset(workbook, "리소스토폴로지", "리소스토폴로지", ["리소스", "Source", "Target", "Operation", "Confidence", "근거파일", "Line"], (
        [row.get("resource_type"), row.get("source"), row.get("target"), row.get("operation"), row.get("confidence"), row.get("source_path"), row.get("line")]
        for row in analysis.get("resources", {}).get("topology_edges", [])
    ))
    write_dataset(workbook, "런타임점검", "런타임점검", ["리소스", "대상", "상태", "지연(ms)", "요약", "오류", "대상출처"], runtime_rows(analysis))
    write_dataset(workbook, "변경영향도", "변경영향도", ["대상", "영향 후보", "연결유형", "Source Module", "Target Module", "확인상태", "근거파일", "Line"], (
        [row.get("source"), row.get("target"), row.get("edge_type"), row.get("source_module"), row.get("target_module"), "정적분석기준", row.get("source_path"), row.get("line")]
        for row in analysis.get("architecture", {}).get("edges", [])
    ))
    write_dataset(workbook, "검토항목", "검토항목", ["심각도", "메시지", "대상", "근거파일", "Line"], (
        [row.get("severity"), row.get("message"), row.get("target"), row.get("source_path"), row.get("line")]
        for row in analysis.get("review_items", [])
    ))
    save(workbook, out / "WorkBook.xlsx", "WorkBook", author)


def generate_table_definition(analysis: Dict[str, Any], out: Path, author: str) -> None:
    workbook = new_workbook("테이블목록")
    static_tables = [[row.get("schema"), row.get("table_name"), row.get("comment"), "SQL", row.get("source_path"), row.get("line")] for row in analysis.get("database", {}).get("sql_tables", [])]
    entity_tables = analysis.get("database", {}).get("entity_tables", [])
    static_tables += [[row.get("schema"), row.get("table_name"), "", "JPA Entity", row.get("source_path"), row.get("line")] for row in entity_tables]
    oracle_runtime = analysis.get("database", {}).get("oracle_runtime", {}) or {}
    static_tables += [[oracle_runtime.get("schema"), row.get("table_name"), row.get("comments"), "Oracle Runtime", "runtime_probe", 0] for row in oracle_runtime.get("tables", [])]
    write_dataset(workbook, "테이블목록", "Oracle 테이블목록", ["Schema", "Table", "Comment", "출처", "근거파일", "Line"], static_tables, use_active=True)
    columns = [[row.get("schema"), row.get("table_name"), row.get("column_name"), row.get("data_type"), row.get("nullable"), row.get("default"), row.get("comment"), "SQL", row.get("source_path"), row.get("line")] for row in analysis.get("database", {}).get("sql_columns", [])]
    for entity in entity_tables:
        for column in entity.get("columns", []):
            columns.append([entity.get("schema"), entity.get("table_name"), column.get("column_name"), column.get("java_type"), "확인필요", "", "", "JPA Entity", entity.get("source_path"), column.get("line")])
    for column in oracle_runtime.get("columns", []):
        type_detail = column.get("data_type")
        if column.get("data_precision") is not None:
            type_detail = f"{type_detail}({column.get('data_precision')},{column.get('data_scale')})"
        elif column.get("data_length") is not None:
            type_detail = f"{type_detail}({column.get('data_length')})"
        columns.append([oracle_runtime.get("schema"), column.get("table_name"), column.get("column_name"), type_detail, column.get("nullable"), column.get("data_default"), "", "Oracle Runtime", "runtime_probe", 0])
    write_dataset(workbook, "컬럼정의", "Oracle 컬럼정의", ["Schema", "Table", "Column", "Type", "Nullable", "Default", "Comment", "출처", "근거파일", "Line"], columns)
    write_dataset(workbook, "PK-FK", "PK / FK / UNIQUE", ["유형", "Constraint", "Schema", "Table", "Column", "Ref Schema", "Ref Table", "Ref Column", "상태", "근거파일", "Line"], (
        [row.get("type"), row.get("constraint_name"), row.get("schema"), row.get("table_name"), row.get("column_name"), row.get("ref_schema"), row.get("ref_table"), row.get("ref_column"), row.get("status"), row.get("source_path"), row.get("line")]
        for row in analysis.get("database", {}).get("relations", [])
    ))
    write_dataset(workbook, "인덱스", "Oracle 인덱스", ["Schema", "Index", "Table", "Columns", "Unique", "근거파일", "Line"], (
        [row.get("schema"), row.get("index_name"), row.get("table_name"), row.get("columns"), row.get("unique"), row.get("source_path"), row.get("line")]
        for row in analysis.get("database", {}).get("indexes", [])
    ))
    sequence_rows = [[row.get("schema"), row.get("sequence_name"), row.get("start_with"), row.get("increment_by"), "SQL", row.get("source_path"), row.get("line")] for row in analysis.get("database", {}).get("sequences", [])]
    sequence_rows += [[oracle_runtime.get("schema"), row.get("sequence_name"), row.get("min_value"), row.get("increment_by"), "Oracle Runtime", "runtime_probe", 0] for row in oracle_runtime.get("sequences", [])]
    write_dataset(workbook, "시퀀스", "Oracle 시퀀스", ["Schema", "Sequence", "Start/Min", "Increment", "출처", "근거파일", "Line"], sequence_rows)
    write_dataset(workbook, "View", "Oracle View", ["Schema", "View", "Query Sample", "근거파일", "Line"], (
        [row.get("schema"), row.get("view_name"), row.get("query_sample"), row.get("source_path"), row.get("line")]
        for row in analysis.get("database", {}).get("views", [])
    ))
    program_rows = [[row.get("schema"), row.get("object_name"), row.get("object_type"), "", "SQL", row.get("source_path"), row.get("line")] for row in analysis.get("database", {}).get("programs", [])]
    program_rows += [[oracle_runtime.get("schema"), row.get("object_name"), row.get("object_type"), row.get("status"), "Oracle Runtime", "runtime_probe", 0] for row in oracle_runtime.get("programs", [])]
    write_dataset(workbook, "PLSQL오브젝트", "PL/SQL 및 Oracle Object", ["Schema", "Object", "Type", "Status", "출처", "근거파일", "Line"], program_rows)
    write_dataset(workbook, "Synonym", "Oracle Synonym", ["Schema", "Synonym", "Target Schema", "Target Object", "DB Link", "근거파일", "Line"], (
        [row.get("schema"), row.get("synonym_name"), row.get("target_schema"), row.get("target_object"), row.get("db_link"), row.get("source_path"), row.get("line")]
        for row in analysis.get("database", {}).get("synonyms", [])
    ))
    entity_rows = []
    for entity in entity_tables:
        for column in entity.get("columns", []):
            entity_rows.append([entity.get("class"), entity.get("schema"), entity.get("table_name"), column.get("field_name"), column.get("column_name"), column.get("java_type"), column.get("is_id"), column.get("annotations"), entity.get("source_path"), column.get("line")])
    write_dataset(workbook, "Entity매핑", "Entity매핑", ["Entity", "Schema", "Table", "Field", "Column", "Java Type", "ID", "Annotations", "근거파일", "Line"], entity_rows)
    write_dataset(workbook, "MyBatis매퍼", "MyBatis매퍼", ["Namespace", "SQL Type", "ID", "Parameter", "Result", "Database ID", "SQL Sample", "근거파일", "Line"], (
        [row.get("namespace"), row.get("sql_type"), row.get("id"), row.get("parameter_type"), row.get("result_type"), row.get("database_id"), row.get("sql_sample"), row.get("source_path"), row.get("line")]
        for row in analysis.get("database", {}).get("mybatis_mappers", [])
    ))
    write_dataset(workbook, "SQL사용처", "SQL 테이블 사용처", ["Operation", "Schema", "Table", "Statement ID", "근거파일", "Line"], (
        [row.get("operation"), row.get("schema"), row.get("table_name"), row.get("statement_id"), row.get("source_path"), row.get("line")]
        for row in analysis.get("database", {}).get("sql_references", [])
    ))
    save(workbook, out / "테이블정의서.xlsx", "테이블정의서", author)


def generate_architecture_definition(analysis: Dict[str, Any], out: Path, author: str) -> None:
    workbook = new_workbook("시스템개요")
    overview = [["시스템명", analysis.get("workspace", {}).get("name")], ["Workspace", analysis.get("workspace", {}).get("root")], ["생성일", analysis.get("generated_at")], ["DB", analysis.get("database", {}).get("engine")]]
    overview += [[key, value] for key, value in analysis.get("summary", {}).items()]
    write_dataset(workbook, "시스템개요", "시스템개요", ["항목", "값"], overview, use_active=True)
    write_dataset(workbook, "모듈구조", "모듈구조", ["모듈명", "경로", "Build File", "Build Files", "출처"], (
        [row.get("module_name"), row.get("module_path"), row.get("has_build_file"), row.get("build_files"), row.get("source_type")]
        for row in analysis.get("modules", [])
    ))
    write_dataset(workbook, "컴포넌트", "컴포넌트", ["모듈", "종류", "Component Type", "Class", "FQN", "Annotations", "근거파일", "Line"], (
        [row.get("module"), row.get("kind"), row.get("component_type"), row.get("name"), row.get("fqn"), row.get("annotations"), row.get("source_path"), row.get("line")]
        for row in analysis.get("java", {}).get("classes", [])
    ))
    write_dataset(workbook, "공통모듈", "공통모듈 / 공통소스", ["모듈", "Class", "FQN", "Component Type", "사유", "근거파일", "Line"], (
        [row.get("module"), row.get("class_name"), row.get("fqn"), row.get("component_type"), row.get("reason"), row.get("source_path"), row.get("line")]
        for row in analysis.get("architecture", {}).get("common_sources", [])
    ))
    write_dataset(workbook, "의존성흐름", "의존성흐름", ["유형", "Source", "Target", "Source Module", "Target Module", "Source Package", "Target Import", "근거파일", "Line"], (
        [row.get("edge_type"), row.get("source"), row.get("target"), row.get("source_module"), row.get("target_module"), row.get("source_package"), row.get("target_import"), row.get("source_path"), row.get("line")]
        for row in analysis.get("architecture", {}).get("edges", [])
    ))
    interface_rows = [["Interface-Impl", row.get("interface_name"), row.get("implementation_class"), row.get("status"), row.get("implementation_source_path"), row.get("line")] for row in analysis.get("java", {}).get("interface_impl", [])]
    interface_rows += [["Injection", row.get("source_class"), row.get("target_type"), row.get("status"), row.get("source_path"), row.get("line")] for row in analysis.get("java", {}).get("injections", [])]
    interface_rows += [["Bean", row.get("configuration_class"), row.get("return_type"), "Bean Factory", row.get("source_path"), row.get("line")] for row in analysis.get("java", {}).get("beans", [])]
    write_dataset(workbook, "인터페이스연결", "인터페이스연결", ["구분", "Source/Interface", "Target/Impl", "상태", "근거파일", "Line"], interface_rows)
    write_dataset(workbook, "리소스토폴로지", "Oracle / Redis / Elasticsearch / Kafka / Observability Topology", ["리소스", "Source", "Target", "Operation", "Confidence", "근거파일", "Line"], (
        [row.get("resource_type"), row.get("source"), row.get("target"), row.get("operation"), row.get("confidence"), row.get("source_path"), row.get("line")]
        for row in analysis.get("resources", {}).get("topology_edges", [])
    ))
    write_dataset(workbook, "운영리소스", "운영리소스", ["리소스", "Name", "Role", "Target", "Detection", "Confidence", "근거파일", "Line"], (
        [row.get("resource_type"), row.get("name"), row.get("role"), row.get("target"), row.get("detection"), row.get("confidence"), row.get("source_path"), row.get("line")]
        for row in analysis.get("resources", {}).get("inventory", [])
    ))
    write_dataset(workbook, "배포워크로드", "배포워크로드", ["Kind", "Workload", "Namespace", "Container", "Image", "Ports", "Env Names", "근거파일"], (
        [row.get("kind"), row.get("workload"), row.get("namespace"), row.get("container"), row.get("image"), row.get("ports"), row.get("env_names"), row.get("source_path")]
        for row in analysis.get("deployment", {}).get("workloads", [])
    ))
    observability_rows = []
    observability_rows += [["Grafana Dashboard", row.get("title"), row.get("uid"), row.get("tags"), row.get("source_path")] for row in analysis.get("resources", {}).get("grafana", {}).get("dashboards", [])]
    observability_rows += [["Grafana Datasource", row.get("name"), row.get("type"), row.get("url"), row.get("source_path")] for row in analysis.get("resources", {}).get("grafana", {}).get("datasources", [])]
    observability_rows += [["Prometheus Scrape", row.get("job_name"), row.get("target"), row.get("path"), row.get("source_path")] for row in analysis.get("resources", {}).get("prometheus", {}).get("scrape_configs", [])]
    observability_rows += [["Prometheus Rule", row.get("name"), row.get("type"), row.get("expr"), row.get("source_path")] for row in analysis.get("resources", {}).get("prometheus", {}).get("rules", [])]
    observability_rows += [["Loki Job", row.get("job_name"), row.get("pipeline_stage_count"), "", row.get("source_path")] for row in analysis.get("resources", {}).get("loki", {}).get("jobs", [])]
    write_dataset(workbook, "관측구성", "Grafana / Prometheus / Loki 구성", ["구분", "Name", "Type/UID", "Target/Query", "근거파일"], observability_rows)
    write_dataset(workbook, "설정-런타임", "설정-런타임", ["Key", "Value Sample", "Format", "Line", "근거파일"], (
        [row.get("key"), row.get("value_sample"), row.get("format"), row.get("line"), row.get("source_path")]
        for row in analysis.get("architecture", {}).get("config_keys", [])
    ))
    write_dataset(workbook, "런타임점검", "런타임점검", ["리소스", "대상", "상태", "지연(ms)", "요약", "오류", "대상출처"], runtime_rows(analysis))
    write_dataset(workbook, "JAR구조", "JAR구조", ["JAR", "Class Count", "Packages", "Maven Coordinates", "Service Providers", "Spring Auto Config", "오류"], (
        [row.get("source_path"), row.get("class_count"), row.get("packages"), row.get("maven_coordinates"), row.get("service_providers"), row.get("spring_auto_configurations"), row.get("errors")]
        for row in analysis.get("dependencies", {}).get("jar_details", [])
    ))
    write_dataset(workbook, "리스크-확인필요", "리스크-확인필요", ["심각도", "메시지", "대상", "근거파일", "Line"], (
        [row.get("severity"), row.get("message"), row.get("target"), row.get("source_path"), row.get("line")]
        for row in analysis.get("review_items", [])
    ))
    save(workbook, out / "아키텍쳐정의서.xlsx", "아키텍쳐정의서", author)


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate Excel documentation from workspace_analysis.json")
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    cfg = load_config(args.config)
    base_dir = Path(cfg["_base_dir"])
    output_root = resolve_path(base_dir, cfg.get("output", {}).get("dir", "output"))
    analysis_path = output_root / "analysis" / "workspace_analysis.json"
    if not analysis_path.exists():
        raise FileNotFoundError(f"analysis json not found: {analysis_path}. run analyze_workspace.py first.")
    analysis = json.loads(analysis_path.read_text(encoding="utf-8"))
    out = ensure_dir(resolve_path(base_dir, cfg.get("excel", {}).get("output_dir", str(output_root / "excel"))))
    author = cfg.get("excel", {}).get("author", "Workspace Documentation Generator")
    generate_interface_spec(analysis, out, author)
    generate_program_list(analysis, out, author)
    generate_workbook(analysis, out, author)
    generate_table_definition(analysis, out, author)
    generate_architecture_definition(analysis, out, author)


if __name__ == "__main__":
    main()
