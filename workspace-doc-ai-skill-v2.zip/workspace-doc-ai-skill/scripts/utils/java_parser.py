from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from .file_utils import read_text_safely

COMMENT_BLOCK_RE = re.compile(r"/\*.*?\*/", re.S)
COMMENT_LINE_RE = re.compile(r"//.*?$", re.M)
PACKAGE_RE = re.compile(r"\bpackage\s+([\w\.]+)\s*;")
IMPORT_RE = re.compile(r"\bimport\s+(?:static\s+)?([\w\.\*]+)\s*;")
CLASS_RE = re.compile(
    r"(?P<mods>(?:public|protected|private|abstract|final|static|sealed|non-sealed|strictfp|\s)+)?\b"
    r"(?P<kind>class|interface|enum|record)\s+"
    r"(?P<name>[A-Za-z_][\w$]*)"
    r"(?:\s*<[^>{}()]+>)?"
    r"(?:\s+extends\s+(?P<extends>[A-Za-z0-9_$\.,\s<>?]+?))?"
    r"(?:\s+implements\s+(?P<implements>[A-Za-z0-9_$\.,\s<>?]+?))?"
    r"\s*[\{(]",
    re.M,
)
ANNOTATION_RE = re.compile(r"@([A-Za-z_][\w\.]*)(?:\s*\((.*?)\))?", re.S)
METHOD_RE = re.compile(
    r"^[ \t]*(?P<mods>(?:(?:public|protected|private|static|final|synchronized|abstract|native|default|strictfp)\s+)*)"
    r"(?P<ret>[A-Za-z_$][\w$<>,\[\]\.? \t&]*)[ \t]+"
    r"(?P<name>[A-Za-z_$][\w$]*)[ \t]*"
    r"\((?P<params>(?:[^()\"']|\"[^\"]*\"|'[^']*'|\([^()]*\))*)\)[ \t]*"
    r"(?:throws[ \t]+[^\{;\n]+)?[ \t]*(?:\{|;)",
    re.M,
)

FIELD_INJECTION_RE = re.compile(
    r"(?P<ann>(?:\s*@(?:Autowired|Inject|Resource|Qualifier|Value)[^\n]*\n)+)\s*"
    r"(?P<mods>private|protected|public)?\s*(?:static\s+)?(?:final\s+)?(?P<type>[A-Za-z_$][\w$<>\.?,\s\[\]]*)\s+(?P<name>[A-Za-z_$][\w$]*)\s*[;=]",
    re.M,
)
FIELD_RE = re.compile(
    r"(?P<ann>(?:\s*@[A-Za-z_$][\w.$]*(?:\([^\n]*\))?\s*\n)*)\s*"
    r"(?P<mods>private|protected|public)?\s*(?:static\s+)?(?:final\s+)?(?P<type>[A-Za-z_$][\w$<>\.?,\s\[\]]*)\s+(?P<name>[A-Za-z_$][\w$]*)\s*(?:=[^;]*)?;",
    re.M,
)
TABLE_NAME_RE = re.compile(r"@Table\s*\((.*?)\)", re.S)
COLUMN_FIELD_RE = re.compile(
    r"(?P<ann>(?:\s*@(Id|EmbeddedId|Column|GeneratedValue|ManyToOne|OneToMany|OneToOne|ManyToMany|JoinColumn|Enumerated|Temporal)[^\n]*\n)+)\s*"
    r"(?P<mods>private|protected|public)?\s*(?:final\s+)?(?P<type>[A-Za-z_$][\w$<>\.?,\s\[\]]*)\s+(?P<name>[A-Za-z_$][\w$]*)\s*;",
    re.M,
)
FEIGN_RE = re.compile(r"@FeignClient\s*\((.*?)\)", re.S)

MAPPING_ANNOTATIONS = {
    "RequestMapping": "ANY", "GetMapping": "GET", "PostMapping": "POST", "PutMapping": "PUT",
    "PatchMapping": "PATCH", "DeleteMapping": "DELETE",
}
COMPONENT_ANNOTATIONS = {
    "RestController": "REST_CONTROLLER", "Controller": "CONTROLLER", "Service": "SERVICE",
    "Repository": "REPOSITORY", "Component": "COMPONENT", "Configuration": "CONFIGURATION",
    "Entity": "ENTITY", "Mapper": "MYBATIS_MAPPER", "FeignClient": "FEIGN_CLIENT",
}


def _line(text: str, offset: int) -> int:
    return text.count("\n", 0, max(0, offset)) + 1


def strip_comments(text: str) -> str:
    def preserve(match: re.Match[str]) -> str:
        return "\n" * match.group(0).count("\n")
    text = COMMENT_BLOCK_RE.sub(preserve, text)
    text = COMMENT_LINE_RE.sub("", text)
    return text


def parse_annotations(text: str) -> List[Dict[str, str]]:
    result = []
    for match in ANNOTATION_RE.finditer(text or ""):
        result.append({
            "name": match.group(1).split(".")[-1],
            "raw": "@" + match.group(1) + (f"({match.group(2)})" if match.group(2) is not None else ""),
        })
    return result


def _first_string(raw: str) -> str:
    match = re.search(r'"([^\"]*)"', raw or "")
    return match.group(1) if match else ""


def parse_named_annotation_arg(raw: str, names: Sequence[str] = ("value", "path")) -> str:
    if not raw:
        return ""
    for name in names:
        match = re.search(rf"\b{name}\s*=\s*(?:\{{\s*)?\"([^\"]*)\"", raw)
        if match:
            return match.group(1)
    return _first_string(raw)


def normalize_path(*parts: str) -> str:
    cleaned = []
    for part in parts:
        if not part:
            continue
        value = str(part).strip().strip('"\'').strip("/")
        if value:
            cleaned.append(value)
    return "/" + "/".join(cleaned) if cleaned else "확인필요"


def annotations_before(text: str, start: int, max_lines: int = 30) -> str:
    lines = text[:start].splitlines()[-max_lines:]
    selected: List[str] = []
    paren_depth = 0
    started = False
    for line in reversed(lines):
        stripped = line.strip()
        if not stripped:
            if started:
                continue
            continue
        if stripped.startswith("@") or paren_depth > 0 or stripped.endswith((")", ",")):
            selected.append(stripped)
            started = True
            paren_depth += stripped.count(")") - stripped.count("(")
            continue
        break
    return "\n".join(reversed(selected))


def split_type_list(value: Optional[str]) -> List[str]:
    if not value:
        return []
    value = re.sub(r"<[^>]+>", "", value)
    return [x.strip() for x in value.split(",") if x.strip()]


def split_params(params: str) -> List[str]:
    result: List[str] = []
    buf: List[str] = []
    depth = 0
    for ch in params:
        if ch in "<([{":
            depth += 1
        elif ch in ">)]}":
            depth = max(0, depth - 1)
        if ch == "," and depth == 0:
            value = "".join(buf).strip()
            if value:
                result.append(value)
            buf = []
        else:
            buf.append(ch)
    value = "".join(buf).strip()
    if value:
        result.append(value)
    return result


def parse_params(params: str) -> List[Dict[str, str]]:
    result = []
    for raw in split_params(params or ""):
        annotations = parse_annotations(raw)
        no_ann = re.sub(r"@[A-Za-z_][\w.]*\s*(?:\([^)]*\))?\s*", "", raw).strip()
        no_ann = re.sub(r"\bfinal\s+", "", no_ann)
        parts = no_ann.split()
        if len(parts) >= 2:
            result.append({"type": " ".join(parts[:-1]), "name": parts[-1].replace("...", ""), "annotations": [a["name"] for a in annotations]})
        elif parts:
            result.append({"type": parts[0], "name": "", "annotations": [a["name"] for a in annotations]})
    return result


def method_mappings(method_annotations: List[Dict[str, str]], class_base_path: str) -> List[Dict[str, str]]:
    mappings = []
    for annotation in method_annotations:
        name = annotation["name"]
        if name in MAPPING_ANNOTATIONS:
            mappings.append({
                "http_method": MAPPING_ANNOTATIONS[name],
                "path": normalize_path(class_base_path, parse_named_annotation_arg(annotation["raw"])),
                "annotation": annotation["raw"],
            })
    return mappings


def _component_type(annotations: Sequence[Dict[str, str]]) -> str:
    for annotation in annotations:
        if annotation["name"] in COMPONENT_ANNOTATIONS:
            return COMPONENT_ANNOTATIONS[annotation["name"]]
    return "JAVA_TYPE"


def parse_entity_columns(text: str, class_name: str) -> Dict[str, Any]:
    entity = {"is_entity": "@Entity" in text, "schema": "", "table_name": "", "columns": []}
    table_match = TABLE_NAME_RE.search(text)
    if table_match:
        raw = table_match.group(1)
        entity["table_name"] = parse_named_annotation_arg(raw, ("name", "value"))
        entity["schema"] = parse_named_annotation_arg(raw, ("schema",))
    for match in COLUMN_FIELD_RE.finditer(text):
        raw_ann = match.group("ann") or ""
        column_name = ""
        column_match = re.search(r"@Column\s*\((.*?)\)", raw_ann, re.S)
        if column_match:
            column_name = parse_named_annotation_arg(column_match.group(1), ("name", "value"))
        join_match = re.search(r"@JoinColumn\s*\((.*?)\)", raw_ann, re.S)
        if join_match and not column_name:
            column_name = parse_named_annotation_arg(join_match.group(1), ("name", "value"))
        entity["columns"].append({
            "field_name": match.group("name"), "java_type": " ".join((match.group("type") or "").split()),
            "column_name": column_name or match.group("name"), "is_id": "@Id" in raw_ann or "@EmbeddedId" in raw_ann,
            "annotations": [a["name"] for a in parse_annotations(raw_ann)], "line": _line(text, match.start()),
        })
    if entity["is_entity"] and not entity["table_name"]:
        entity["table_name"] = class_name
    return entity


def parse_feign(text: str, rel: str) -> List[Dict[str, Any]]:
    clients = []
    for match in FEIGN_RE.finditer(text):
        raw = match.group(1)
        clients.append({
            "name": parse_named_annotation_arg(raw, ("name", "value")),
            "url": parse_named_annotation_arg(raw, ("url",)),
            "path": parse_named_annotation_arg(raw, ("path",)),
            "context_id": parse_named_annotation_arg(raw, ("contextId",)),
            "raw": "@FeignClient(" + raw + ")", "source_path": rel, "line": _line(text, match.start()),
        })
    return clients


def parse_java_file(path: Path, root: Path) -> Dict[str, Any]:
    rel = str(path.relative_to(root)).replace("\\", "/")
    raw = read_text_safely(path, max_chars=5_000_000)
    text = strip_comments(raw)
    package_match = PACKAGE_RE.search(text)
    package = package_match.group(1) if package_match else ""
    imports = IMPORT_RE.findall(text)

    result: Dict[str, Any] = {
        "path": rel, "language": "java", "package": package, "imports": imports,
        "classes": [], "methods": [], "endpoints": [], "injections": [], "beans": [],
        "entities": [], "feign_clients": parse_feign(text, rel), "uses": [],
    }

    use_keywords = {
        "RestTemplate": "REST_CLIENT", "WebClient": "WEB_CLIENT", "HttpClient": "HTTP_CLIENT",
        "KafkaTemplate": "KAFKA", "@KafkaListener": "KAFKA", "RedisTemplate": "REDIS",
        "StringRedisTemplate": "REDIS", "RedissonClient": "REDIS", "JdbcTemplate": "JDBC",
        "NamedParameterJdbcTemplate": "JDBC", "EntityManager": "JPA", "Oracle": "ORACLE",
        "ElasticsearchOperations": "ELASTICSEARCH", "ElasticsearchClient": "ELASTICSEARCH",
        "MeterRegistry": "PROMETHEUS", "Loki": "LOKI",
    }
    for keyword, use in use_keywords.items():
        if keyword in text:
            result["uses"].append(use)
    result["uses"] = sorted(set(result["uses"]))

    main_class_name = ""
    class_base_path = ""
    class_base_paths: Dict[str, str] = {}
    class_spans: List[Dict[str, Any]] = []
    for match in CLASS_RE.finditer(text):
        ann_text = annotations_before(text, match.start())
        annotations = parse_annotations(ann_text)
        class_name = match.group("name")
        detected_base_path = next(
            (parse_named_annotation_arg(annotation["raw"]) for annotation in annotations if annotation["name"] == "RequestMapping"),
            "",
        )
        class_base_paths[class_name] = detected_base_path
        if not main_class_name:
            main_class_name = class_name
            class_base_path = detected_base_path
        class_row = {
            "name": class_name, "fqn": f"{package}.{class_name}" if package else class_name,
            "kind": match.group("kind"), "component_type": _component_type(annotations),
            "extends": split_type_list(match.group("extends")), "implements": split_type_list(match.group("implements")),
            "annotations": [a["name"] for a in annotations], "raw_annotations": [a["raw"] for a in annotations],
            "source_path": rel, "line": _line(text, match.start()),
        }
        result["classes"].append(class_row)
        class_spans.append({"name": class_name, "start": match.start()})

    def class_at(offset: int) -> str:
        candidates = [x for x in class_spans if x["start"] <= offset]
        return candidates[-1]["name"] if candidates else main_class_name

    # Field injection.
    for match in FIELD_INJECTION_RE.finditer(text):
        annotations = parse_annotations(match.group("ann") or "")
        result["injections"].append({
            "class": class_at(match.start()), "injection_type": "FIELD",
            "target_type": " ".join((match.group("type") or "").split()), "field_name": match.group("name"),
            "parameter_name": "", "qualifier": next((parse_named_annotation_arg(a["raw"]) for a in annotations if a["name"] in {"Qualifier", "Resource"}), ""),
            "annotation": "\n".join(a["raw"] for a in annotations), "source_path": rel, "line": _line(text, match.start()),
        })

    # Constructor injection. This deliberately accepts unannotated constructors because Spring favors them.
    for class_row in result["classes"]:
        class_name = class_row["name"]
        constructor_re = re.compile(rf"(?P<ann>(?:\s*@[A-Za-z_$][\w.$]*(?:\([^\n]*\))?\s*)*)\b(?:public|protected|private)?\s*{re.escape(class_name)}\s*\((?P<params>[^)]*)\)")
        for match in constructor_re.finditer(text):
            for param in parse_params(match.group("params") or ""):
                result["injections"].append({
                    "class": class_name, "injection_type": "CONSTRUCTOR", "target_type": param.get("type", ""),
                    "field_name": "", "parameter_name": param.get("name", ""),
                    "qualifier": "", "annotation": match.group("ann") or "", "source_path": rel, "line": _line(text, match.start()),
                })

    for match in METHOD_RE.finditer(text):
        name = match.group("name")
        owner_class = class_at(match.start())
        if name == owner_class or name in {"if", "for", "while", "switch", "catch", "return", "new", "throw", "synchronized"}:
            continue
        annotations = parse_annotations(annotations_before(text, match.start()))
        modifiers = (match.group("mods") or "").split()
        method = {
            "class": owner_class, "name": name,
            "return_type": " ".join((match.group("ret") or "").split()),
            "visibility": next((x for x in modifiers if x in {"public", "protected", "private"}), "package"),
            "modifiers": modifiers, "params": parse_params(match.group("params") or ""),
            "annotations": [a["name"] for a in annotations], "raw_annotations": [a["raw"] for a in annotations],
            "source_path": rel, "line": _line(text, match.start()),
        }
        result["methods"].append(method)
        for mapping in method_mappings(annotations, class_base_paths.get(owner_class, class_base_path)):
            result["endpoints"].append({
                "controller": method["class"], "method_name": name, "http_method": mapping["http_method"],
                "path": mapping["path"], "request_params": method["params"], "response_type": method["return_type"],
                "source_path": rel, "line": method["line"], "annotation": mapping["annotation"],
            })
        if "Bean" in method["annotations"]:
            bean_ann = next((a for a in annotations if a["name"] == "Bean"), None)
            result["beans"].append({
                "configuration_class": method["class"], "bean_name": parse_named_annotation_arg(bean_ann["raw"]) if bean_ann else name,
                "return_type": method["return_type"], "method_name": name, "source_path": rel, "line": method["line"],
            })

    entity = parse_entity_columns(text, main_class_name)
    if entity["is_entity"]:
        entity.update({"class": main_class_name, "package": package, "source_path": rel, "line": next((c["line"] for c in result["classes"] if c["name"] == main_class_name), 0)})
        result["entities"].append(entity)
    return result
