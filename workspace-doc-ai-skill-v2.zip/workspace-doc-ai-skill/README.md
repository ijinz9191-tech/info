# Workspace Documentation Generator AI Skill v2

Workspace 전체를 정적 분석하고, 필요할 때 Oracle·Redis·Elasticsearch·Kafka·Grafana·Prometheus·Loki를 읽기 전용으로 점검해서 공식 문서를 자동 생성한다.

- 매뉴얼: PowerPoint
- 인터페이스/프로그램/Work Book/테이블/아키텍처: Excel
- 화면 이미지: Playwright 자동 캡처
- 근거: 파일 경로, 라인, 설정 키, 코드 인터페이스, 선택적 Runtime API

## 1. 설치

필수 환경: Python 3.9 이상, Java 프로젝트 분석 대상 Workspace, Excel/PPT 생성용 Python 패키지.

```bash
cd workspace-doc-ai-skill
python -m venv .venv

# Windows
.venv\Scripts\activate

# Linux/macOS
# source .venv/bin/activate

pip install -r requirements.txt
playwright install chromium
```

Oracle·Redis·Kafka 런타임 점검까지 사용할 때:

```bash
pip install -r requirements-runtime.txt
```

정적 분석과 Excel/PPT 생성은 runtime 전용 패키지가 없어도 동작한다.

## 2. 설정

`config.yaml`에서 최소한 아래만 수정한다.

```yaml
workspace:
  root: "C:/work/project"
  name: "MY_SYSTEM"
```

Runtime 점검은 기본 비활성이다. 환경변수를 설정한 다음 활성화한다.

```yaml
runtime_probe:
  enabled: true
  allow_discovered_endpoints: false
```

환경변수 예시는 `examples/runtime.env.example`을 참고한다. 비밀번호와 토큰을 `config.yaml`에 직접 적지 않는다.

## 3. 전체 실행

```bash
python scripts/generate_all.py --config config.yaml
```

분석만:

```bash
python scripts/generate_all.py --config config.yaml --analysis-only
```

화면 캡처를 제외하고 문서 생성:

```bash
python scripts/generate_all.py --config config.yaml --skip-screenshots
```

Runtime 점검을 제외하고 문서 생성:

```bash
python scripts/generate_all.py --config config.yaml --skip-runtime-probe
```

## 4. 자동 분석 항목

### 코드와 모듈

- Gradle/Maven 멀티모듈
- Java/Kotlin/Groovy Class, Interface, Implementation
- Field/Constructor Injection, `@Bean`, Import/Module 연결
- Controller/API, Feign, Repository, JPA, MyBatis
- 공통/core/shared/framework 소스

### JAR

- Repository와 GAV
- Version Catalog와 local JAR
- 실제 다운로드 URL 후보
- 선택적 `.m2`/Gradle cache 탐색
- Manifest, Maven coordinate, class package, SPI, Spring AutoConfiguration
- 소스 import와 local JAR package 매칭

### Oracle

- DDL과 PL/SQL
- Table/Column/PK/FK/Index/Sequence/View/Package/Procedure/Function/Trigger/Synonym
- JPA Entity, MyBatis SQL, JDBC/JPA Query 사용처
- 선택적 현재 Schema metadata 조회

### Redis / Elasticsearch / Kafka

- Cache/Key/Lock/PubSub
- Index/Document/Repository/Search/Index API
- Producer/Consumer/Topic/Group/Streams
- 설정 키, dependency, Kubernetes env, endpoint 후보

### Grafana / Prometheus / Loki

- Grafana dashboard JSON, panels, datasource, query
- Prometheus metric, scrape config, ServiceMonitor, PodMonitor, PrometheusRule
- Loki/Promtail client, job, pipeline, LogQL
- 운영 화면 자동 캡처 후보 생성

## 5. 화면 캡처

애플리케이션 화면은 `examples/manual_pages.example.yaml` 형식으로 정의한다.

```yaml
screenshots:
  enabled: true
  base_url: "http://localhost:3000"
```

Grafana와 Prometheus 화면은 Runtime URL 또는 `resource_screenshots` 설정에서 자동 생성한다.

```yaml
resource_screenshots:
  enabled: true
  auto_generate: true
  allow_discovered_endpoints: false
```

소스에서 발견한 Grafana/Prometheus/Loki URL은 기본적으로 문서 후보로만 사용한다. 실제 화면 접속은 URL을 직접 지정하거나 `allow_discovered_endpoints: true`로 명시해야 한다.

인증 정보는 `auth_profiles`의 환경변수 이름으로 전달한다.

## 6. 산출물

```text
output/
  analysis/
    workspace_analysis.json
    workspace_summary.md
    runtime_probe.json
    validation_report.json
  screenshots/
  resource-screenshots/
  excel/
    인터페이스명세서.xlsx
    프로그램목록.xlsx
    WorkBook.xlsx
    테이블정의서.xlsx
    아키텍쳐정의서.xlsx
  ppt/
    사용자메뉴얼.pptx
    운영자메뉴얼.pptx
```

## 7. 런타임 점검 안전 기준

- Oracle: `SELECT`만 수행
- Redis: `PING`, `INFO`, `DBSIZE`; Key scan은 기본 false
- Elasticsearch/Grafana/Prometheus/Loki: GET만 수행
- Kafka: socket 연결과 metadata/topic 조회
- 실패해도 문서 생성은 계속
- Secret은 JSON/Excel/PPT에 마스킹
- 소스에서 찾은 endpoint는 `allow_discovered_endpoints=true`일 때만 실제 접속

## 8. 주요 스크립트

```text
scripts/analyze_workspace.py              전체 정적 분석
scripts/probe_runtime_resources.py        7종 리소스 읽기 전용 점검
scripts/capture_manual_screens.py         애플리케이션 화면 캡처
scripts/capture_resource_screens.py       Grafana/Prometheus/Loki 운영 화면 캡처
scripts/generate_excel_documents.py       5개 Excel 문서 생성
scripts/generate_manual_ppt.py            사용자/운영자 PPT 생성
scripts/validate_outputs.py               JSON/Excel/PPT 무결성 및 필수 시트 검증
scripts/generate_all.py                   전체 파이프라인 + 최종 검증
```
## 9. 자동 검증

전체 실행의 마지막 단계에서 `scripts/validate_outputs.py`가 다음을 검사한다.

- 분석 JSON 및 Runtime JSON 파싱/선택적 Schema 검증
- 5개 Excel 파일 열림 여부와 필수 시트
- 2개 PowerPoint 파일 열림 여부와 최소 슬라이드 수
- 결과: `output/analysis/validation_report.json`

개별 실행:

```bash
python scripts/validate_outputs.py --config config.yaml
```

