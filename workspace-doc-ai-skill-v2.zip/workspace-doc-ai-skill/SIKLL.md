---
name: workspace-documentation-generator
version: 2.0.0
description: Analyze an entire software workspace, including common modules, JAR acquisition and internals, Java/Kotlin interface wiring, Oracle, Redis, Elasticsearch, Kafka, Grafana, Prometheus and Loki integrations. Generate user/operator manuals as PowerPoint and all specifications as Excel.
---

# Workspace Documentation Generator Skill

## 목적

개발 Workspace의 모든 분석 가능한 리소스를 먼저 수집하고, 근거 기반으로 아래 공식 산출물을 생성한다.

- `사용자메뉴얼.pptx`
- `운영자메뉴얼.pptx`
- `인터페이스명세서.xlsx`
- `프로그램목록.xlsx`
- `WorkBook.xlsx`
- `테이블정의서.xlsx`
- `아키텍쳐정의서.xlsx`

매뉴얼은 PowerPoint, 나머지 문서는 Excel이어야 한다.

## 필수 분석 범위

다음 범위를 누락하지 않는다.

1. Workspace 구조
   - 루트/멀티모듈 구조, Gradle/Maven 모듈, 공통·core·shared·framework 소스
   - Java, Kotlin, Groovy, SQL, XML, YAML, Properties, JSON, Shell, Docker/Kubernetes/Helm 파일
2. 구현 구조
   - Class, Interface, Implementation, 상속, Import, 필드/생성자 주입, `@Bean`
   - Controller/API, Feign, HTTP client, Repository, JPA Entity, MyBatis Mapper
3. JAR/Dependency
   - Maven/Gradle repository, GAV, scope/configuration, version catalog, local JAR
   - JAR Manifest, `pom.properties`, package, `META-INF/services`, Spring AutoConfiguration
   - 소스 import와 local JAR package 연결
4. Oracle
   - JDBC/JPA/MyBatis/Procedure 연결, SQL 테이블 사용처
   - Table, Column, PK/FK/Unique, Index, Sequence, View, Package, Procedure, Function, Trigger, Synonym
5. Redis
   - `RedisTemplate`, `StringRedisTemplate`, Redisson, Spring Cache, TTL/Key 후보, Lock, Pub/Sub
6. Elasticsearch
   - Spring Data Document/Repository, index, search/index/bulk/delete 호출, endpoint 설정
7. Kafka
   - Producer, Consumer, `@KafkaListener`, Topic, Group ID, Streams source/sink, bootstrap/security 설정
8. 관측 스택
   - Grafana dashboard/panel/datasource/query/alert
   - Prometheus Micrometer metric, scrape config, ServiceMonitor, PodMonitor, PrometheusRule
   - Loki/Promtail client, scrape job, pipeline, LogQL, Logback appender
9. 배포/운영
   - Kubernetes workload/container/image/port/env, Service/Ingress/monitoring CRD
   - 선택적 런타임 상태 및 메타데이터 점검

## 실행 절차

전체 실행:

```bash
python scripts/generate_all.py --config config.yaml
```

내부 실행 순서는 반드시 다음과 같다.

```bash
python scripts/analyze_workspace.py --config config.yaml
python scripts/probe_runtime_resources.py --config config.yaml
python scripts/capture_manual_screens.py --config config.yaml
python scripts/capture_resource_screens.py --config config.yaml
python scripts/generate_excel_documents.py --config config.yaml
python scripts/generate_manual_ppt.py --config config.yaml
python scripts/validate_outputs.py --config config.yaml
```

분석만 수행할 때:

```bash
python scripts/generate_all.py --config config.yaml --analysis-only
```

## 근거 원칙

- 확인한 파일, 설정 키, 코드 위치, 라인, runtime API만 사실로 기록한다.
- 추론은 `confidence`, `확인필요`, `requires_review`로 표시한다.
- 모든 표에는 가능한 경우 `근거파일`과 `Line`을 포함한다.
- 같은 항목이 여러 출처에서 확인되면 출처를 합치거나 행을 분리한다.
- 분석 실패 파일은 숨기지 않고 `analysis_errors`와 `검토항목`에 기록한다.

## 보안 원칙

- Password, token, secret, API key, credential, private key는 항상 `***MASKED***`로 기록한다.
- 런타임 점검 계정은 환경변수에서 읽는다.
- Oracle은 `SELECT`만 수행한다.
- Redis는 기본적으로 `PING/INFO/DBSIZE`만 수행하고 Key 값은 읽지 않는다.
- Elasticsearch, Grafana, Prometheus, Loki는 GET API만 호출한다.
- Kafka는 broker 연결과 metadata/topic 조회만 수행한다.
- Runtime 자동 발견 endpoint 접속은 `runtime_probe.allow_discovered_endpoints=true`일 때만 허용한다.
- 운영 화면 자동 발견 URL 접속은 `resource_screenshots.allow_discovered_endpoints=true`일 때만 허용한다.
- 런타임 점검 실패는 문서 생성을 중단시키지 않는다.

## 화면 매뉴얼 규칙

### 사용자메뉴얼

- 실제 애플리케이션 URL을 Playwright로 캡처한다.
- 화면명, URL, 태그, 화면 설명, 단계, 버튼/입력 항목, 확인 항목, 캡처 이미지를 포함한다.
- DOM에서 제목/버튼/입력을 자동 추출할 수 있으나 업무 설명을 단정하지 않는다.

### 운영자메뉴얼

- Grafana dashboard, Prometheus Targets/Alerts/Rules 등 운영 화면을 자동 생성·캡처한다.
- Oracle, Redis, Elasticsearch, Kafka, Grafana, Prometheus, Loki별 탐지 결과와 점검 절차를 포함한다.
- 캡처할 UI가 없는 리소스는 정적 분석과 런타임 상태 슬라이드로 설명한다.
- 캡처 실패 시 실패 사유를 슬라이드에 표시한다.

## Excel 산출물 기준

### 인터페이스명세서.xlsx

필수 시트:

- API 인터페이스
- 외부연계
- Interface-Impl
- 주입연결
- Bean연결
- 리소스연계
- Oracle연계
- Redis연계
- Elasticsearch연계
- Kafka연계
- 모니터링연계
- 런타임점검
- JAR-Dependency
- JAR내부구조
- JAR사용연결

### 프로그램목록.xlsx

필수 시트:

- 모듈목록
- 파일목록
- 클래스목록
- 메서드목록
- 화면-라우트
- 공통소스
- Listener-Scheduler
- 배포워크로드
- 리소스자산

### WorkBook.xlsx

필수 시트:

- 요약
- 문서생성체크리스트
- 분석범위
- 리소스현황
- 공통모듈분석
- JAR가져오기
- JAR서비스연결
- 구현흐름
- 리소스토폴로지
- 런타임점검
- 변경영향도
- 검토항목

### 테이블정의서.xlsx

Oracle 기준 필수 시트:

- 테이블목록
- 컬럼정의
- PK-FK
- 인덱스
- 시퀀스
- View
- PLSQL오브젝트
- Synonym
- Entity매핑
- MyBatis매퍼
- SQL사용처

### 아키텍쳐정의서.xlsx

필수 시트:

- 시스템개요
- 모듈구조
- 컴포넌트
- 공통모듈
- 의존성흐름
- 인터페이스연결
- 리소스토폴로지
- 운영리소스
- 배포워크로드
- 관측구성
- 설정-런타임
- 런타임점검
- JAR구조
- 리스크-확인필요

## 품질 게이트

문서 생성 전에 다음을 확인한다.

- 분석 파일 수가 0이면 실패 처리한다.
- Interface 구현체를 찾지 못하면 확인필요로 기록한다.
- API URL을 확정하지 못하면 확인필요로 기록한다.
- Oracle 테이블은 SQL/JPA/MyBatis/Runtime 출처를 구분한다.
- Redis Key, Kafka Topic, Elasticsearch Index가 변수 표현식이면 그대로 남기고 확정값으로 변환하지 않는다.
- Grafana/Prometheus/Loki 설정과 dashboard query의 출처 파일을 기록한다.
- 모든 Excel 시트에 제목, 헤더, 필터, freeze pane, 줄바꿈, 근거 컬럼을 적용한다.
- 모든 PPT 화면 슬라이드에 태그와 캡처 또는 실패 사유를 넣는다.
- 분석 JSON과 runtime probe JSON을 남긴다.
- 5개 Excel과 2개 PowerPoint를 다시 열어 필수 시트/최소 슬라이드 수를 검증하고 `validation_report.json`을 남긴다.

## 산출 경로

```text
output/
  analysis/
    workspace_analysis.json
    workspace_summary.md
    runtime_probe.json
    validation_report.json
  screenshots/
    manual_pages.generated.json
    *.png
  resource-screenshots/
    resource_pages.generated.json
    *.png
  excel/
    인터페이스명세서.xlsx
    프로그램목록.xlsx
    WorkBook.xlsx
    테이블정의서.xlsx
    아키텍쳐정의서.xlsx
  ppt/
    사용자메뉴얼.pptx
    운영자메뉴얼.pptx
```
