# 자동 생성 폴더

`RUN.bat` 또는 `scripts/auto_configure.py`가 다음 파일을 생성합니다.

- `config.auto.yaml`
- `discovery-report.json`
- `config-summary.txt`
- `user-choices.yaml`
- `last-run.json`

이 파일들은 Workspace별 로컬 설정이므로 Git에 커밋하지 않습니다.
