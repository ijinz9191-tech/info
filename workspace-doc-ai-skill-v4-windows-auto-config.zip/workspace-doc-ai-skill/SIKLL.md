---
name: workspace-documentation-generator
version: 4.0.0
description: On Windows, automatically discover and configure a complete React, Spring Boot and Vert.x workspace, trace UI-to-API-to-resource flows, inspect common modules and JARs, detect Oracle, Redis Cluster/Sentinel/Standalone, Elasticsearch, Kafka, Grafana, Prometheus and Loki integrations, then generate manuals as PowerPoint and all specifications as Excel.
---

# Workspace Documentation Generator Skill

## 1. 역할

이 스킬은 하나의 Workspace 안에 공존하는 **React 화면**, **Spring Boot 백엔드**, **Vert.x 백엔드**, 공통 모듈, 외부 JAR, 데이터·메시징·관측 리소스를 근거 기반으로 분석한다. 분석 결과로 다음 공식 산출물을 자동 생성한다.

```text
PowerPoint
  사용자메뉴얼.pptx
  운영자메뉴얼.pptx

Excel
  인터페이스명세서.xlsx
  프로그램목록.xlsx
  WorkBook.xlsx
  테이블정의서.xlsx
  아키텍쳐정의서.xlsx
```

매뉴얼은 반드시 PowerPoint로, 나머지 문서는 반드시 Excel로 생성한다.

## 2. 완료 조건

아래 조건을 모두 만족해야 작업 완료로 판단한다.

1. Workspace 전체를 순회하고 분석 제외 사유를 기록한다.
2. React Route·화면·컴포넌트·상태·API 호출을 추출한다.
3. Spring Boot API·Bean·Interface/Implementation·Security·Scheduler·Listener·외부 호출을 추출한다.
4. Vert.x Verticle·Router·Handler·HTTP Server·EventBus·WebClient·비동기 리소스 클라이언트를 추출한다.
5. React API 호출을 Spring Boot 또는 Vert.x 엔드포인트와 연결한다.
6. Spring Boot↔Vert.x 내부 HTTP 호출과 Vert.x EventBus producer/consumer를 연결한다.
7. Oracle, Redis, Elasticsearch, Kafka, Grafana, Prometheus, Loki의 설정·사용처·배포·관측 근거를 추출한다.
8. 공통 모듈과 Maven/Gradle/NPM/JAR 의존성을 분석한다.
9. 실제 React 화면 캡처가 가능하면 이미지·DOM·네트워크 호출을 수집한다.
10. 2개 PPT와 5개 Excel을 생성한 뒤 다시 열어 필수 시트와 최소 슬라이드 수를 검증한다.
11. 확인할 수 없는 항목은 생성하지 않고 `확인필요`, `requires_review`, `confidence`로 표시한다.

## 3. Windows 자동 입력 원칙

Windows 사용자의 필수 준비는 **Python 3.11 이상 64-bit 설치와 `RUN.bat` 실행**이다. 사용자는 `config.yaml`이나 Windows 환경변수를 직접 작성하지 않아도 된다.

`RUN.bat`는 다음 순서로 동작한다.

1. Python 3.11 이상을 확인하고 `.venv`를 생성한다.
2. 필수 패키지와 Oracle·Redis Cluster·Kafka용 선택 패키지를 설치한다.
3. 이전 Workspace가 있으면 재사용 후보로 제시하고, 없으면 Windows 폴더 선택 창을 연다.
4. Workspace의 `application*.yml/properties`, React `.env/package.json`, Vert.x config/code, Helm, Kubernetes, Docker Compose, 관측 설정을 스캔한다.
5. `generated/config.auto.yaml`을 자동 생성한다.
6. 소스에서 확인한 인증정보나 사용자가 입력한 인증정보는 `credentials.local.yaml`에만 분리하고 Git 제외 대상으로 처리한다.
7. React 화면 캡처, 읽기 전용 Runtime 점검, 운영 화면 캡처 여부만 질문한다.
8. 분석과 2개 PPT·5개 Excel 생성 및 검증을 연속 수행한다.

자동 탐지할 수 없는 비밀번호·토큰은 Runtime 점검을 선택한 경우에만 질문한다. 입력하지 않아도 정적 분석과 문서 생성은 계속 수행한다.

CLI/자동화 환경에서는 다음처럼 질문 없이 실행할 수 있다.

```bat
RUN.bat --workspace "D:\workspace\my-system" --non-interactive --static-only
```

## 4. 분석 대상

### 4.1 Workspace·모듈

- Maven: `pom.xml`, parent/child module, repository, dependency, plugin
- Gradle: `settings.gradle[.kts]`, `build.gradle[.kts]`, version catalog, local JAR
- NPM: `package.json`, lock file, workspace, script, dependency/devDependency/peerDependency
- 공통 모듈: common/core/shared/base/framework/util/config/security 경로 및 내부 package 참조
- Java, Kotlin, Groovy, TypeScript, TSX, JavaScript, JSX, SQL, XML, YAML, Properties, JSON, Shell
- Dockerfile, Compose, Kubernetes, Helm, Kustomize, CI/CD 구성

### 4.2 React

다음 항목을 근거 파일과 줄 번호로 수집한다.

- React/Vite/CRA/Next React 여부와 버전
- React Router JSX Route 및 객체형 Route
- Route path, 화면 Component, 보호 여부, 역할/권한 후보, Layout
- 메뉴·링크·내비게이션 경로
- Component, custom Hook, React Hook 사용
- Redux, Zustand, Context, React Query 등 상태/데이터 계층
- Axios, fetch, WebSocket, EventSource/SSE 호출
- HTTP method, URL/path, 동적 표현식 여부, 호출 Component/Hook
- `.env` 참조, proxy, base URL 후보, TypeScript alias
- 실제 캡처 시 DOM 제목·버튼·입력·링크·표·대화상자
- 실제 캡처 시 XHR/fetch/document/WebSocket/EventSource 요청과 실패 요청

### 4.3 Spring Boot

- `@SpringBootApplication`
- `@RestController`, `@Controller`, RequestMapping 계열 API
- WebFlux functional router (`RouterFunction`, `route`, `nest`)
- Controller → Service → Repository/Mapper 흐름
- Interface와 구현체, 생성자/필드 주입, `@Bean`
- `@Configuration`, `@ConfigurationProperties`, `@Value`
- Spring Security request matcher, method security, 역할/권한 후보
- `@Scheduled`, Application/Event listener, Kafka listener
- RestTemplate, WebClient, RestClient, Feign 등 외부/내부 HTTP 호출
- Actuator, Profile, Transaction
- JPA Entity/Repository, JDBC, MyBatis, Redis, Elasticsearch, Kafka, Micrometer 사용

### 4.4 Vert.x

- `Verticle`, `AbstractVerticle`, worker 여부
- `deployVerticle` 및 배포 옵션 후보
- `createHttpServer`, port/host/requestHandler
- `Router`, route/get/post/put/patch/delete/options/head/connect/trace
- Handler와 RoutingContext 연결
- subRouter/mountSubRouter
- EventBus `send`, `publish`, `request`, `consumer`, localConsumer
- EventBus address, producer/consumer, request-reply 여부, codec, service proxy
- WebClient/HttpClient 내부·외부 호출
- Config, SharedData, timer/periodic
- Oracle SQL client, Redis client, Kafka producer/consumer, Micrometer
- 비동기 흐름의 producer→consumer 및 HTTP→EventBus 연결 근거

### 4.5 JAR·공통 소스

- Maven/Gradle repository와 GAV
- scope/configuration, BOM/platform, version catalog, local JAR
- 선택적 `.m2`/Gradle cache 실제 파일 경로
- JAR `MANIFEST.MF`, `pom.properties`, package/class 목록
- `META-INF/services`, Spring AutoConfiguration, SPI
- 소스 import/package와 JAR 내부 package 연결
- React NPM 패키지와 모듈 스크립트
- 공통 모듈을 소비하는 Spring Boot/Vert.x/React 모듈 관계

### 4.6 데이터·메시징·관측 리소스

- Oracle: datasource, JDBC/JPA/MyBatis/Vert.x SQL, DDL, Table/Column/PK/FK/Index/Sequence/View/Synonym/PLSQL, SQL CRUD 사용처
- Redis: Standalone/Sentinel/Cluster 자동 판별, Spring cluster nodes, Redisson `clusterServersConfig`, Vert.x endpoint, RedisTemplate/StringRedisTemplate/Spring Cache, Key/TTL/Lock/PubSub
- Redis Runtime: startup node, master/replica topology, `CLUSTER INFO`, `CLUSTER NODES`, slot 분배, cluster state를 읽기 전용으로 수집
- Elasticsearch: client, Spring Data Document/Repository, index/alias/search/index/bulk/delete
- Kafka: Spring/Vert.x producer·consumer, topic, group, Streams, bootstrap/security
- Grafana: dashboard, UID, panel, datasource, query, alert
- Prometheus: scrape config, ServiceMonitor, PodMonitor, PrometheusRule, Micrometer metric
- Loki: Promtail/Loki client, job, pipeline, LogQL, appender

## 5. 연결 분석 규칙

### 5.1 React → Backend

1. React API 호출 path에서 origin, query, fragment를 제거하고 path를 정규화한다.
2. Spring Boot annotation/functional API와 Vert.x route를 통합 endpoint 목록으로 만든다.
3. HTTP method와 정규화 path를 비교한다.
4. exact path를 우선하고 `{id}`, `:id`, `*` 등 path parameter를 비교한다.
5. 동일 점수 후보가 여러 개면 단정하지 않고 `AMBIGUOUS`로 남긴다.
6. 매핑 결과에 React Component, Route, Backend framework, component/handler, source path/line을 포함한다.

### 5.2 Spring Boot ↔ Vert.x

- RestTemplate/WebClient/RestClient/Feign/Vert.x WebClient URL을 통합 endpoint와 비교한다.
- host가 달라도 동일 path로 내부 서비스 후보를 연결하되 신뢰도를 표시한다.
- 서비스 디스커버리명, Kubernetes Service명, ingress prefix가 있으면 근거로 함께 기록한다.

### 5.3 Vert.x EventBus

- 동일 address의 producer와 consumer를 연결한다.
- `request`는 request-reply, `send`는 point-to-point, `publish`는 broadcast 후보로 기록한다.
- consumer가 없거나 producer가 없으면 `UNMATCHED`와 확인필요를 남긴다.
- 동적 address는 표현식 그대로 보존하며 확정 문자열로 바꾸지 않는다.

## 6. 화면 캡처 및 매뉴얼

### 6.1 자동 화면 목록

`screenshots.manual_pages_file`이 비어 있으면 React Router 분석 결과로 화면 목록을 자동 생성한다. 별도 YAML을 제공하면 자동 분석 결과와 병합한다.

### 6.2 React SPA 이동

`react_spa.navigation_mode`는 다음을 지원한다.

- `direct`: `base_url + route` 직접 접속
- `hash`: `base_url/#/route` 접속
- `spa`: 루트 접속 후 History API로 route 이동
- `auto`: 직접 접속을 먼저 시도하고 실패 시 SPA 이동으로 보완

### 6.3 화면별 동작

화면 YAML에서 click, fill, select, press, wait, sleep 동작을 지정할 수 있다. 인증은 `credentials.local.yaml`의 로컬 값 또는 기존 환경변수와 selector로 수행한다.

### 6.4 사용자메뉴얼 PPT

각 화면 슬라이드에 가능한 범위에서 다음을 포함한다.

- 화면명, Route/URL, 태그, 대상 역할
- React Component와 근거 파일
- 화면 설명, 사용자 단계, 확인 항목
- DOM에서 관찰한 주요 UI 요소
- 정적 분석한 API 호출과 연결된 Spring Boot/Vert.x endpoint
- 캡처 중 관찰한 네트워크 요청/실패
- 화면 이미지 또는 캡처 실패 사유

### 6.5 운영자메뉴얼 PPT

- 기술 스택과 React→Spring Boot/Vert.x 전체 흐름
- Spring Boot 구성, API, Security, scheduler/listener, 외부 호출
- Vert.x Verticle, HTTP server/route, Handler, EventBus topology
- Oracle/Redis/Elasticsearch/Kafka 연계
- Grafana/Prometheus/Loki 관측 구조 및 운영 화면
- Kubernetes workload와 실행·배포 구성
- Runtime probe 결과와 장애/검토 항목

## 7. Excel 산출물

### 인터페이스명세서.xlsx

React 호출과 두 백엔드의 연결을 한 문서에서 추적한다.

- API 인터페이스
- React API호출
- React-Backend매핑
- 화면-API-Backend
- Spring API / Spring 보안 / Spring 외부호출
- Vertx HTTP Route / Vertx EventBus / EventBus연결 / Vertx 외부호출
- 외부연계 / Interface-Impl / 주입연결 / Bean연결
- Oracle·Redis·Elasticsearch·Kafka·모니터링 연계
- JAR-Dependency / JAR내부구조 / JAR사용연결 / NPM-Dependency

### 프로그램목록.xlsx

- 모듈목록 / 기술스택 / 파일목록
- React 패키지 / React 컴포넌트 / React Hook-State / 화면-라우트 / 화면-API연결
- Spring 컴포넌트 / Spring 스케줄-리스너
- Vertx Verticle / Vertx Handler / Vertx 배포-서버
- 클래스목록 / 메서드목록 / 공통소스 / 배포워크로드 / 리소스자산

### WorkBook.xlsx

- 요약 / 문서생성체크리스트 / 분석범위 / 기술스택
- 프레임워크모듈 / React-Spring-Vertx흐름 / API매핑검토 / EventBus토폴로지
- 실행-배포구성 / 공통모듈분석 / JAR가져오기 / JAR서비스연결
- 구현흐름 / 리소스토폴로지 / 런타임점검 / 변경영향도 / 검토항목

### 테이블정의서.xlsx

- Oracle Table/Column/PK/FK/Index/Sequence/View/PLSQL/Synonym
- Entity매핑 / MyBatis매퍼 / SQL사용처
- DB접근컴포넌트: Spring JDBC/JPA/MyBatis와 Vert.x SQL client 사용처

### 아키텍쳐정의서.xlsx

- 시스템개요 / 기술스택 / 모듈구조
- Frontend구조 / SpringBoot구조 / Vertx구조
- Frontend-Backend / EventBus토폴로지 / Framework공존
- 컴포넌트 / 공통모듈 / 의존성흐름 / 인터페이스연결
- 리소스토폴로지 / 운영리소스 / 배포워크로드 / 관측구성
- 설정-런타임 / 런타임점검 / JAR구조 / Mermaid아키텍처 / 리스크-확인필요

## 8. 실행 절차

### 8.1 Windows 권장 실행

```bat
RUN.bat
```

Config만 다시 자동 생성:

```bat
CONFIGURE_ONLY.bat
```

외부 시스템 접속과 화면 캡처 없이 정적 분석만 수행:

```bat
RUN_STATIC_ONLY.bat
```

자동 생성된 로컬 설정을 초기화:

```bat
RESET_LOCAL_CONFIG.bat
```

### 8.2 내부 실행 순서

```text
1. auto_configure.py                  Workspace/서비스/접속정보 자동 탐지
2. analyze_workspace.py              전체 정적 분석
3. probe_runtime_resources.py        선택적·읽기 전용, Redis Cluster 지원
4. capture_manual_screens.py         선택적 React 화면 캡처
5. capture_resource_screens.py       선택적 Grafana/Prometheus 화면 캡처
6. generate_excel_documents.py
7. generate_manual_ppt.py
8. validate_outputs.py
```

### 8.3 CLI 실행

Config가 없으면 자동 설정을 수행한다.

```bash
python scripts/generate_all.py --workspace "D:/workspace/my-system" --reconfigure
```

기존 자동 Config 사용:

```bash
python scripts/generate_all.py
```

분석만 수행:

```bash
python scripts/generate_all.py --analysis-only
```

## 9. 근거·정확성 규칙

- 코드, 설정, manifest, SQL, dashboard, runtime 응답에서 확인한 내용만 사실로 기록한다.
- 업무 용어·버튼 의미·권한 의미를 이름만 보고 단정하지 않는다.
- 동적 URL, topic, index, key, EventBus address는 표현식을 보존한다.
- 같은 API가 여러 backend에 매칭되면 임의 선택하지 않는다.
- 모든 연결표에 가능한 범위에서 `근거파일`, `Line`, `evidence`, `confidence`, `status`를 넣는다.
- 파싱 실패 파일은 `analysis_errors`에 기록하고 생성 과정을 숨기지 않는다.
- Runtime 접속 실패는 서비스 장애가 아니라 `접속 점검 실패`로 기록한다.

## 10. 보안 규칙

- password, token, secret, credential, API key, private key, authorization은 생성 JSON·Excel·PPT에서 `***MASKED***` 처리한다.
- 인증정보는 `credentials.local.yaml`에만 저장하고 `config.auto.yaml`과 산출물에는 복사하지 않는다.
- `credentials.local.yaml`은 `.gitignore` 대상이며 Windows에서는 가능한 범위에서 현재 사용자 ACL로 제한한다.
- 기존 환경변수 방식도 호환되지만 사용자가 환경변수를 직접 설정할 필요는 없다.
- Kubernetes Secret 값 가져오기는 자동 설정 질문에서 명시적으로 허용한 경우에만 수행한다.
- Oracle은 SELECT와 metadata 조회만 실행한다.
- Redis Cluster는 PING, topology, `CLUSTER INFO/NODES/SLOTS`, 제한된 INFO만 조회하고 key value는 읽지 않는다. Key scan은 기본 비활성이다.
- Elasticsearch/Grafana/Prometheus/Loki는 GET 요청만 사용한다.
- Kafka는 metadata/topic/consumer-group 조회만 수행하고 message payload를 소비하지 않는다.
- 자동 탐지된 주소는 사용자가 Runtime 점검을 선택한 경우에만 실제 접속한다.
- 화면의 민감정보가 캡처될 수 있으므로 운영 데이터 환경에서는 마스킹된 테스트 계정을 사용한다.

## 11. 검증 게이트

`validate_outputs.py`는 다음을 검사한다.

- `workspace_analysis.json`과 `runtime_probe.json` 파싱 및 JSON Schema
- 분석 파일 수 1개 이상
- 5개 Excel의 열림 여부와 필수 시트
- 2개 PPT의 열림 여부와 최소 슬라이드 수
- 생성 파일 크기와 오류 목록
- 최종 `validation_report.json` 결과

검증 실패 상태에서 완료라고 보고하지 않는다.

## 12. 산출 경로

```text
<Workspace>/workspace-doc-output/
  analysis/
    workspace_analysis.json
    workspace_summary.md
    runtime_probe.json
    validation_report.json
  screenshots/
    manual_pages.generated.json
    *.png
  resource-screenshots/
    resource_pages.generated.json
    *.png
  excel/
    인터페이스명세서.xlsx
    프로그램목록.xlsx
    WorkBook.xlsx
    테이블정의서.xlsx
    아키텍쳐정의서.xlsx
  ppt/
    사용자메뉴얼.pptx
    운영자메뉴얼.pptx
```
