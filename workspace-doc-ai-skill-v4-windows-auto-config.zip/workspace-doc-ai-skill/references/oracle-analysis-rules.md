# Oracle 분석 규칙

## Source

- `CREATE TABLE`, column type/null/default/comment
- PK, FK, unique, check
- index, sequence, view, materialized view
- package, procedure, function, trigger, synonym
- JPA `@Entity/@Table/@Column/@Id/@JoinColumn`
- MyBatis namespace, statement, SQL table reference
- Spring JDBC/JPA와 Vert.x Oracle/JDBC reactive client

## Runtime

Runtime probe가 활성화되면 현재 schema metadata를 SELECT로 조회한다. Source DDL과 Runtime object를 구분한다.

## 사용처

SQL별 SELECT/INSERT/UPDATE/DELETE/MERGE와 caller file/line을 기록한다. 문자열 조합 SQL은 object 후보를 확정하지 않는다.

## 보안

- DML/DDL을 실행하지 않는다.
- row data를 조회하지 않는다.
- connection string credential을 마스킹한다.
