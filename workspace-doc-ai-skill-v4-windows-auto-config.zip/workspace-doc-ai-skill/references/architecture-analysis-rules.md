# 아키텍처 분석 규칙

## 계층

```text
User
  → React UI
      → Spring Boot API
      → Vert.x HTTP API
Spring Boot ↔ Vert.x internal HTTP
Vert.x Verticle ↔ EventBus ↔ Verticle
Backend → Oracle/Redis/Elasticsearch/Kafka
Backend → Prometheus/Loki → Grafana
```

## Module role

- FRONTEND_REACT
- BACKEND_SPRING_BOOT
- BACKEND_VERTX
- COMMON_LIBRARY
- DATABASE_MIGRATION
- DEPLOYMENT/OBSERVABILITY

한 module이 여러 역할을 가질 수 있다.

## Edge

- IMPORT/DEPENDENCY/IMPLEMENTS/INJECTS/BEAN
- REACT_ROUTE_COMPONENT
- REACT_API_BACKEND
- BACKEND_INTERNAL_HTTP
- VERTX_EVENTBUS
- RESOURCE_ACCESS
- DEPLOYED_AS/EXPOSED_BY/MONITORED_BY

## 공존 유형

- 별도 서비스: module/workload/image/port가 분리됨
- 동일 프로세스: Spring Bean 또는 application이 Vert.x instance/Verticle을 생성
- 혼합: 일부 Vert.x가 Spring 안에 있고 별도 Vert.x service도 존재

근거가 부족하면 `coexistence`에는 탐지 여부와 검토 항목만 기록한다.
