# 매뉴얼 태그·내용 규칙

## 자동 태그

Route, title, DOM text에서 인증/메인/운영/사용자관리/조회/등록/수정/삭제/통계/모니터링 후보를 만든다. 역할이 확인되면 `권한:ROLE` 태그를 추가한다.

## 내용 우선순위

1. 수동 page YAML의 검토된 설명
2. 실제 DOM heading와 UI 요소
3. React Component/Route/API 정적 근거
4. 위 근거가 없으면 `확인필요`

## 화면 슬라이드 필수 요소

- title, route/URL, tag, audience/role
- React Component와 source
- steps/checks
- static API/backend mapping
- observed network/DOM
- screenshot 또는 실패 사유

업무 절차를 코드 이름만으로 생성한 경우 반드시 검토 필요를 표시한다.
