# Frontend-Backend 매핑 규칙

## 1. Path 정규화

- origin 제거: `https://host/api/users` → `/api/users`
- query/fragment 제거
- 연속 slash 정리
- trailing slash 정리
- React `:id`, Spring `{id}`, Vert.x `:id`를 parameter token으로 비교
- base path/proxy prefix는 근거가 있을 때만 제거

## 2. 점수 우선순위

1. HTTP method와 literal path exact match
2. method와 parameterized path match
3. path match + method 불명
4. suffix/prefix 후보
5. 이름 유사성만 있는 경우는 자동 매핑하지 않음

## 3. 상태

- `MATCHED`: 단일 최상위 후보
- `AMBIGUOUS`: 같은 점수의 복수 후보
- `UNMATCHED`: 후보 없음
- `DYNAMIC`: caller path를 정규화할 수 없음

## 4. 화면 연결

```text
Route path
  └─ React Component
      └─ API call
          └─ Backend endpoint
```

한 Component가 여러 Route에 쓰이면 각각 별도 행으로 만든다. 공통 layout 또는 API client는 직접 화면 소유 근거가 없으면 route 연결을 보수적으로 제한한다.

## 5. 내부 HTTP 연결

Spring Boot 또는 Vert.x HTTP client 호출도 동일 backend endpoint 목록과 비교한다. 자기 자신을 호출하는 route client 구문처럼 parser 오탐 가능성이 있으면 확인필요로 남긴다.

## 6. 검토 대상

- API gateway/ingress rewrite
- 환경변수 base URL
- BFF와 backend path가 다름
- GraphQL 단일 endpoint
- generated API client
- runtime service discovery
