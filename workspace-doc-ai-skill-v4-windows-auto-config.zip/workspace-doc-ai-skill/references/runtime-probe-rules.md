# Runtime Probe 규칙 v4

## 기본 정책

- 자동 Config가 주소를 채워도 실제 접속은 사용자가 `RUN.bat` 질문에서 Runtime 점검을 선택한 경우에만 수행
- `credentials.local.yaml` 또는 기존 환경변수 사용
- timeout 적용
- 실패해도 정적 문서 생성 지속
- 실패는 실제 서비스 장애가 아니라 문서화 프로세스의 접속 점검 실패로 표현

## 읽기 범위

- Oracle: `SELECT 1 FROM DUAL`, 현재 schema/DB, USER_* metadata SELECT
- Redis Standalone: PING, 제한된 INFO, DBSIZE
- Redis Sentinel: master/replica discovery, PING, 제한된 INFO
- Redis Cluster: startup node, PING, topology, `CLUSTER INFO`, `CLUSTER NODES`, slot 분배, 제한된 INFO
- Elasticsearch: cluster health, index/alias metadata GET
- Kafka: broker socket, topic/group metadata; payload 미소비
- Grafana: health/dashboard/datasource/folder/alert metadata GET
- Prometheus: ready, status, targets, rules GET
- Loki: ready/status/label/series metadata GET

## Redis 제한

- key value 조회 금지
- write/delete/failover/reshard 금지
- key scan 기본 비활성
- `scan_keys: true`라도 이름만 제한 개수 수집하고 value는 읽지 않음

## 결과 표현

- `UP`: 읽기 요청 성공
- `PARTIAL`: health 확인 가능하지만 일부 metadata가 인증/권한으로 제한
- `SKIPPED`: 비활성 또는 접속 대상 없음
- `DOWN`: 접속·인증·timeout 실패
