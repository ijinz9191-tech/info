# React 분석 규칙

## 1. 기술 스택

`package.json`에서 React, React DOM, React Router, Vite, CRA, Next, Axios, React Query, Redux, Zustand, MUI, Ant Design 의존성을 수집한다. scripts, workspaces, proxy, homepage, package manager도 기록한다.

## 2. 화면과 Route

### JSX Route

```tsx
<Route path="/users/:id" element={<UserDetail />} />
```

추출:

- path: `/users/:id`
- component: `UserDetail`
- router: React Router
- route source component/file/line
- roles/protected/layout 후보

### 객체형 Route

```ts
{ path: '/events', element: <EventsPage />, children: [...] }
```

중첩 route는 parent path를 보수적으로 합친다. 동적 변수로 조합되는 path는 원문을 남긴다.

## 3. Component·Hook·State

- function/class/arrow component와 export 여부
- `useState`, `useEffect`, `useMemo`, `useCallback`, `useContext` 등 hook 사용
- `useXxx` custom hook
- Redux store/slice/selector/dispatch, Zustand create/store, Context provider/consumer 후보

업무 역할은 이름만 보고 단정하지 않는다.

## 4. API 호출

다음을 수집한다.

- `axios.get/post/put/patch/delete`
- `axios({...})`
- `fetch(url, { method })`
- `new WebSocket(url)`
- `new EventSource(url)`

각 호출에 client, method, path, caller component, hook, source/line, dynamic 여부를 기록한다.

## 5. Route→API 연결

- API 호출 파일의 owner component를 우선 사용한다.
- 해당 component가 route element이면 route와 API를 직접 연결한다.
- custom hook/import를 통한 간접 호출은 import 관계 근거가 있을 때 연결하며 신뢰도를 낮춘다.
- 공통 API client의 모든 호출을 모든 화면에 연결하지 않는다.

## 6. 실제 화면 캡처

- Route 자동 목록과 수동 page YAML을 병합한다.
- BrowserRouter direct 접속 실패 시 root + History API 이동을 시도한다.
- HashRouter는 `#/` 경로를 사용한다.
- DOM과 network는 실제 관찰 사실이며, 화면 의미의 확정 근거로 과대 해석하지 않는다.
- 인증 값은 환경변수로만 전달한다.
