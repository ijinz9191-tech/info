# Spring Boot 분석 규칙

## 1. 애플리케이션과 Component

- `@SpringBootApplication` application class
- `@RestController`, `@Controller`, `@Service`, `@Repository`, `@Component`, `@Configuration`
- Interface/Implementation, extends/implements
- 생성자/field injection, `@Qualifier`, `@Bean`

## 2. HTTP Endpoint

- class-level `@RequestMapping`과 method-level mapping을 결합한다.
- `@GetMapping`, `@PostMapping`, `@PutMapping`, `@PatchMapping`, `@DeleteMapping`, `@RequestMapping`
- method, path, controller, handler method, request parameter 후보, response type를 기록한다.
- WebFlux `RouterFunction`, `RouterFunctions.route`, `route(GET(...))`, `nest`를 별도 functional route로 기록한다.

## 3. Security

- `requestMatchers`, `antMatchers`, `mvcMatchers`, `authorizeHttpRequests`
- `hasRole`, `hasAnyRole`, `hasAuthority`, `permitAll`, `authenticated`
- `@PreAuthorize`, `@Secured`, `@RolesAllowed`

Path와 권한 표현식이 분리되어 파싱이 불확실하면 `확인필요`로 표시한다.

## 4. 비동기·스케줄·이벤트

- `@Scheduled` cron/fixedDelay/fixedRate
- `@EventListener`, `ApplicationListener`
- `@KafkaListener` topic/group 후보
- Transaction과 profile 후보

## 5. HTTP Client

- RestTemplate, WebClient, RestClient, Feign
- literal URL/path와 HTTP method
- caller class/method, source/line

내부 endpoint 매핑 시 host보다 method/path를 우선하되, 외부 URL일 수 있으므로 match type과 confidence를 남긴다.

## 6. 데이터·리소스

- JPA Entity/Repository, JDBC, MyBatis
- RedisTemplate/Redisson/Spring Cache
- Elasticsearch client/repository/document
- KafkaTemplate/listener/stream
- MeterRegistry/Micrometer/Actuator

Spring Bean이 Vert.x instance/Verticle을 생성하거나 배포하는 구성도 공존 구조에 기록한다.
