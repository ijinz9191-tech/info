# 통합 추출 규칙

## 1. 분석 순서

1. Workspace 파일 inventory와 module root를 만든다.
2. Maven/Gradle/NPM manifest로 기술 스택과 모듈 역할을 식별한다.
3. React, JVM 공통, Spring Boot, Vert.x 전용 parser를 각각 실행한다.
4. SQL·Oracle object, 리소스 설정, dashboard/monitoring, deployment를 수집한다.
5. 통합 backend endpoint 목록을 만든다.
6. React API 및 backend 내부 HTTP 호출을 endpoint와 매핑한다.
7. Vert.x EventBus producer/consumer를 address로 매핑한다.
8. architecture edge와 검토 항목을 만든다.
9. 모든 결과에 source path/line을 유지하고 Secret을 마스킹한다.

## 2. 근거 등급

- `HIGH`: 명시적 annotation, literal route/address, manifest key, DDL, runtime metadata
- `MEDIUM`: package/import/client 호출과 path 패턴이 일치
- `LOW`: 이름·경로 기반 후보이며 사람의 검토 필요

## 3. 정적 분석 한계

다음은 확정하지 않는다.

- Runtime에 조합되는 URL·topic·index·key·EventBus address
- Reflection, generated source, annotation processor 결과
- 외부 dependency 내부에서만 구성되는 endpoint
- 빌드 profile/환경변수에 따라 달라지는 최종 설정
- React lazy import의 복잡한 webpack/Vite alias 조합
- Vert.x 동적 Router/Handler 등록

표현식을 원문으로 남기고 `DYNAMIC` 또는 `확인필요`로 표시한다.

## 4. 줄 번호

- Source parser가 찾은 최초 의미 있는 줄을 1-based line으로 기록한다.
- JSON/package/tsconfig처럼 구조 파싱만 가능한 파일은 line 0을 허용한다.
- 생성 문서에서는 line 0을 `구조 분석` 또는 빈 값으로 표시할 수 있다.

## 5. 중복 제거

- React route: module + path + component + source
- HTTP endpoint: framework + method + normalized path + component/handler
- API call: source + line + method + path
- EventBus operation: source + line + operation + address
- Resource: type + operation + target + source

중복을 제거하더라도 서로 다른 근거 파일은 삭제하지 않는다.
