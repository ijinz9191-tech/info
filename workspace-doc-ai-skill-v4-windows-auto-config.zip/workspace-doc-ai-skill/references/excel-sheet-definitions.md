# Excel 시트 정의 v4

모든 시트는 제목행, 헤더, AutoFilter, freeze pane, 줄바꿈, 적정 열 너비, 근거파일/Line을 적용한다. 행이 많으면 Excel 한계를 넘지 않도록 분할한다. 자동 설정에서 발견한 주소·노드·선택값·근거는 민감정보를 제거한 뒤 문서에 남긴다.

## 인터페이스명세서

통합 API, React API, 화면-API-Backend, Spring Boot, Vert.x Route/EventBus, Oracle·Redis·Elasticsearch·Kafka·관측 리소스, JAR/NPM 연결을 제공한다.

## 프로그램목록

모듈·파일·클래스·메서드 외에 React package/component/hook/route, Spring component, Verticle/Handler/deployment를 제공한다.

## WorkBook

- 요약과 문서 생성 체크리스트
- `자동설정`: RUN.bat가 생성한 설정값, Redis Cluster 노드, 사용자 선택, 탐지 근거
- 프레임워크 역할과 React→Spring Boot/Vert.x 흐름
- API/EventBus 검토, 실행·배포·리소스·JAR 흐름
- 런타임 점검과 변경 영향도

## 테이블정의서

Oracle 객체 정의와 Entity/MyBatis/SQL reference 및 Spring Boot/Vert.x DB 접근 component를 제공한다.

## 아키텍쳐정의서

- 시스템·기술스택·모듈 구조
- `자동설정`: 자동 Config와 리소스별 근거
- Frontend/Spring Boot/Vert.x 공존 구조
- API/EventBus, 리소스·배포·관측 구조
- Mermaid 원문, 런타임 결과, 검토 항목
