# Vert.x 분석 규칙

## 1. Verticle

- `Verticle`, `AbstractVerticle` 구현/상속 class
- `start`, `stop` lifecycle 후보
- `deployVerticle` target과 DeploymentOptions
- worker/instances/config 후보

## 2. HTTP Server와 Router

- `createHttpServer`, `requestHandler`, `listen`
- `Router.router(vertx)`
- `route/get/post/put/patch/delete/options/head/connect/trace`
- path, method, handler, consumes, produces, failureHandler
- `mountSubRouter` 및 prefix

Handler method는 `this::handler`, lambda, inline block을 구분한다. 동적 path는 원문을 보존한다.

## 3. EventBus

### Operation 의미

- `send`: 한 consumer로 전달하는 point-to-point 후보
- `publish`: 모든 matching consumer로 전달하는 broadcast 후보
- `request`: reply를 기대하는 request-reply
- `consumer`/`localConsumer`: inbound consumer

### 연결

동일 literal address의 producer와 consumer를 연결한다. 한 producer에 consumer가 여러 개면 operation 의미에 따라 모두 기록하되 실제 분배 방식은 Runtime 구성 확인 대상으로 남긴다.

### 추가 요소

- codec registration
- service proxy / proxy handler 후보
- message reply/fail 후보

## 4. 비동기 클라이언트

- WebClient/HttpClient method/path
- Oracle/JDBC reactive SQL pool
- Redis client/API
- Kafka producer/consumer
- ConfigRetriever/config key
- SharedData/localMap/cluster-wide map
- setTimer/setPeriodic
- Micrometer/metrics options

## 5. Spring Boot 공존

- 동일 JVM에서 Spring Bean이 Vert.x를 생성하는 경우
- 별도 module/service로 배포되는 경우
- Spring HTTP client가 Vert.x route를 호출하는 경우
- Vert.x HTTP client가 Spring endpoint를 호출하는 경우
- Kafka/Redis/Oracle을 양쪽이 공동 사용하는 경우

공존 방식은 코드와 deployment 근거를 함께 사용해 기록한다.
