# 문서 출력 규칙

## PowerPoint

- 16:9 레이아웃
- 화면 이미지 비율 유지, 왜곡 금지
- 한 슬라이드에 과도한 표를 넣지 않고 항목을 분할
- 캡처가 없으면 이유와 정적 근거를 표시
- 사용자매뉴얼과 운영자매뉴얼의 대상을 혼합하지 않음

## Excel

- 데이터는 셀 값으로 기록하고 이미지로 대체하지 않음
- 헤더, filter, freeze, wrap, border, number format 적용
- Source/Runtime/Inference 구분
- 긴 evidence/query는 잘라내되 source 위치 유지

## 파일명

요청된 한글 파일명을 유지한다.

```text
사용자메뉴얼.pptx
운영자메뉴얼.pptx
인터페이스명세서.xlsx
프로그램목록.xlsx
WorkBook.xlsx
테이블정의서.xlsx
아키텍쳐정의서.xlsx
```

## 검증

생성 후 python-pptx/openpyxl로 재열고 필수 구조를 확인한다. 검증 결과를 JSON으로 남긴다.
