# 관측 스택 분석 규칙

## Prometheus

- scrape job, target, metrics path, interval
- ServiceMonitor/PodMonitor selector와 endpoint
- PrometheusRule alert/record expression
- Spring Micrometer 및 Vert.x Micrometer 옵션

## Grafana

- dashboard title/UID/tag
- panel title/type/datasource
- PromQL/LogQL/query expression
- alert definition과 datasource 연결

## Loki

- Promtail scrape job, client URL, label, pipeline stage
- Loki datasource와 LogQL
- Spring/Vert.x logging appender/config 후보

## 연결

Workload/service label, metric name, datasource UID/name, dashboard query를 이용해 관측 대상과 연결한다. query만으로 특정 class를 단정하지 않는다.

## 화면

Grafana와 Prometheus URL이 명시되면 읽기 전용 운영 화면을 캡처한다. 인증 토큰은 문서에 포함하지 않는다.
