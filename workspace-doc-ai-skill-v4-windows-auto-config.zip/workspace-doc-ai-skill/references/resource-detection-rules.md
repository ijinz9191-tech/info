# 리소스 자동 탐지 규칙

## 공통

Dependency, import, configuration key, code operation, deployment env/secret reference, dashboard/query를 교차 확인한다. 실제 credential 값은 마스킹한다.

## Oracle

- JDBC URL, datasource, driver, schema
- JPA/JDBC/MyBatis/Vert.x SQL client
- DDL/PLSQL와 SQL CRUD reference

## Redis

- Spring RedisTemplate/StringRedisTemplate/Redisson/Cache
- Vert.x Redis client
- key expression, TTL, lock, pub/sub channel

## Elasticsearch

- Spring Data Document/Repository와 low/high-level client
- index, alias, search/index/update/delete/bulk operation

## Kafka

- Spring KafkaTemplate/Listener/Streams
- Vert.x Kafka producer/consumer
- topic, group, bootstrap, security protocol

## Grafana/Prometheus/Loki

- Grafana dashboard/panel/datasource/query/alert
- Prometheus scrape config, ServiceMonitor, PodMonitor, PrometheusRule, Micrometer
- Loki/Promtail client, scrape job, pipeline, LogQL, appender

리소스가 dependency에만 있고 사용처가 없으면 `DEPENDENCY_ONLY` 후보로 분리한다.
