@echo off
setlocal
chcp 65001 >nul 2>&1
cd /d "%~dp0"
echo 자동 생성된 로컬 설정을 삭제합니다.
if exist "generated\config.auto.yaml" del /q "generated\config.auto.yaml"
if exist "generated\discovery-report.json" del /q "generated\discovery-report.json"
if exist "generated\user-choices.yaml" del /q "generated\user-choices.yaml"
if exist "generated\last-run.json" del /q "generated\last-run.json"
if exist "generated\config-summary.txt" del /q "generated\config-summary.txt"
if exist "credentials.local.yaml" del /q "credentials.local.yaml"
echo 완료되었습니다. 다음 RUN.bat 실행 시 처음부터 다시 설정합니다.
pause
