# Offline wheelhouse

인터넷이 차단된 Windows 환경에서는 `requirements.txt`와 `requirements-runtime.txt`의 wheel 파일을 이 폴더에 넣습니다.

`RUN.bat`는 이 폴더가 있으면 다음과 같은 오프라인 설치를 우선합니다.

```bat
pip install --no-index --find-links wheelhouse -r requirements.txt
```

Python 3.11 64-bit와 일치하는 wheel을 준비해야 합니다. Playwright Chromium 실행 파일은 별도 사내 배포 또는 미러가 필요할 수 있습니다.
