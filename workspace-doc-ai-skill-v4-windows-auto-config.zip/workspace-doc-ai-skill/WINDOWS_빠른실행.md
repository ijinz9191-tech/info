# Windows 빠른 실행

## 사용자가 하는 일

1. **Python 3.11 이상 64-bit**를 설치한다.
2. ZIP 압축을 해제한다.
3. `RUN.bat`를 더블클릭한다.
4. 폴더 선택 창에서 분석할 Workspace 최상위 폴더를 선택한다.
5. 화면 캡처와 실제 리소스 읽기 전용 점검 여부만 선택한다.

`config.yaml` 또는 Windows 환경변수를 사용자가 직접 작성할 필요는 없다.

## 자동 생성되는 로컬 설정

```text
generated/config.auto.yaml      주소·포트·노드·분석 경로
credentials.local.yaml          비밀번호·토큰 전용, Git 제외
generated/discovery-report.json 자동 탐지 근거
generated/config-summary.txt    설정 요약
```

Oracle 계정처럼 소스에서 확인할 수 없는 인증정보는 실제 Runtime 점검을 선택했을 때만 질문한다. Enter를 누르면 해당 접속만 건너뛰고 정적 분석과 문서 생성은 계속된다.

## Redis Cluster

Spring Boot, Redisson, Vert.x 설정에서 Cluster 노드를 자동 수집한다. 실제 점검을 선택하면 `CLUSTER INFO`, `CLUSTER NODES`, slot 및 master/replica topology를 읽기 전용으로 확인한다. Key value는 읽지 않고 `SCAN`도 기본 비활성이다.

## 외부 접속 없이 문서만 생성

```text
RUN_STATIC_ONLY.bat
```

## 생성 위치

선택한 Workspace 아래에 생성된다.

```text
workspace-doc-output/
  ppt/
    사용자메뉴얼.pptx
    운영자메뉴얼.pptx
  excel/
    인터페이스명세서.xlsx
    프로그램목록.xlsx
    WorkBook.xlsx
    테이블정의서.xlsx
    아키텍쳐정의서.xlsx
  analysis/
```
