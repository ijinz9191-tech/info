@echo off
setlocal
cd /d "%~dp0"
call RUN.bat --static-only %*
