# Package Manifest v4.0.0

## Windows entrypoints

- `RUN.bat` — Python 확인, venv/패키지 설치, 자동 Config, 분석, 문서 생성
- `CONFIGURE_ONLY.bat` — Workspace 자동 탐지와 Config 생성만 수행
- `RUN_STATIC_ONLY.bat` — Runtime 접속과 화면 캡처 없는 정적 분석
- `RESET_LOCAL_CONFIG.bat` — 생성된 로컬 Config/credential 초기화
- `WINDOWS_빠른실행.md` — 사용자용 최소 실행 절차

## Skill and configuration

- `SKILL.md` — AI agent 실행 규칙
- `config.yaml` — 자동 설정 기본값과 수동 실행 template
- `generated/README.md` — 자동 생성 파일 설명
- `credentials.local.yaml` — 실행 시 생성, Git 제외, 인증정보 전용

## Automatic configuration

- `scripts/auto_configure.py` — Windows 폴더 선택, 질문형/무인 설정
- `scripts/windows_launcher.py` — 자동 설정에서 전체 파이프라인까지 연결
- `scripts/utils/auto_config_discovery.py` — React/Spring/Vert.x/리소스 주소와 Secret 참조 탐지
- `scripts/utils/config_loader.py` — generated config와 credentials overlay 병합

## Framework analyzers

- `scripts/utils/react_parser.py`
- `scripts/utils/spring_parser.py`
- `scripts/utils/vertx_parser.py`
- `scripts/utils/framework_mapper.py`

## Resource/JAR analyzers

- `dependency_parser.py`, `jar_parser.py`, `db_parser.py`, `resource_parser.py`
- Oracle, Redis Standalone/Sentinel/Cluster, Elasticsearch, Kafka, Grafana, Prometheus, Loki
- Redis Runtime topology/cluster info/nodes/slots

## Output generators

- `generate_excel_documents.py` — 5개 Excel
- `generate_manual_ppt.py` — 사용자/운영자 PPT
- `capture_manual_screens.py` — React 화면·DOM·network
- `capture_resource_screens.py` — Grafana/Prometheus/Loki 화면
- `validate_outputs.py` — JSON/Excel/PPT 검증

## Offline installation

- `wheelhouse/README.md` — 사내망/offline wheel 설치 방법
- `requirements.txt`
- `requirements-runtime.txt`

## Rules and schemas

- `references/` — 프레임워크·연결·리소스·문서 규칙
- `schemas/` — analysis/runtime/manual JSON Schema
- `prompts/document_writer_prompt.md` — 근거 기반 문서 작성 프롬프트

## Test

- `scripts/self_test.py`
- `tests/fixtures/react-spring-vertx/`
- `SELF_TEST.md`
- `VALIDATION.md`
