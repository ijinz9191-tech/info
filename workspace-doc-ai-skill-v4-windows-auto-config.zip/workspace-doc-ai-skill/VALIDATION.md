# Validation Record — v4.0.0

React + Spring Boot + Vert.x + Redis Cluster 합성 멀티모듈 Workspace로 자동 탐지와 전체 문서 파이프라인을 실행했다.

## 자동 Config 결과

- React: `http://localhost:5173`
- Spring Boot: `http://localhost:8080`
- Vert.x: `http://localhost:8090`
- Oracle DSN: 탐지 PASS
- Redis mode: `cluster`
- Redis startup node: 3개
- Elasticsearch URL: 탐지 PASS
- Kafka bootstrap server: 2개
- Loki URL: 탐지 PASS
- unresolved Secret: 참조명만 기록, 문서에서는 마스킹

## 코드 분석 결과

- React Route: 2
- React API 호출: 2
- React→Backend 매핑: 2/2
- Spring Boot endpoint: 2
- Vert.x HTTP Route: 2
- Verticle: 2
- EventBus 연결: 2 이상
- Oracle table: 2
- Grafana dashboard: 1
- Prometheus scrape: 2
- 분석 오류: 0

## 문서 결과

- Excel 5개 생성 및 필수 시트 재열기 검증 PASS
- WorkBook·아키텍쳐정의서 `자동설정` 시트와 Redis Cluster 3개 노드 기록 PASS
- 사용자메뉴얼 생성 및 재열기 검증 PASS
- 운영자메뉴얼 18슬라이드 생성, 자동 설정 결과 슬라이드 및 Redis Cluster 표시 PASS
- 운영자메뉴얼 전체 슬라이드 렌더링·몽타주 육안 점검 PASS
- 분석 JSON Schema PASS
- Runtime JSON Schema PASS
- validation report PASS

## 통합 실행 검증

다음 경로를 실제 실행했다.

```text
windows_launcher.py
  → auto_configure.py
  → generated/config.auto.yaml
  → generate_all.py
  → analyze
  → Excel 5개
  → PPT 2개
  → validate PASS
```

실제 사용자 Workspace의 동적 route, gateway rewrite, generated client, reflection, runtime service discovery, 외부 Secret Manager 값은 별도 검토가 필요할 수 있다.
