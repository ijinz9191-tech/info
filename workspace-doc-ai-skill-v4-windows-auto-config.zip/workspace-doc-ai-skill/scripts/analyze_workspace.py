from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence, Tuple

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from utils.config_loader import deep_mask, ensure_dir, load_config, resolve_path
from utils.db_parser import parse_mybatis_mapper, parse_sql_file
from utils.dependency_parser import parse_build_file, parse_jar_name
from utils.file_utils import TEXT_EXTENSIONS, classify_file, file_record, iter_workspace_files
from utils.framework_mapper import (
    build_backend_endpoints,
    build_framework_edges,
    build_mermaid_overview,
    build_route_api_links,
    build_stack_summary,
    classify_module_roles,
    match_calls_to_endpoints,
    match_event_bus,
)
from utils.frontend_parser import parse_frontend_file
from utils.jar_parser import enrich_dependency_acquisition, inspect_jar
from utils.jvm_parser import parse_jvm_file
from utils.react_parser import parse_package_json, parse_react_file, parse_tsconfig
from utils.resource_parser import (
    RESOURCE_TYPES,
    analyze_code_integrations,
    build_resource_inventory,
    build_resource_topology,
    detect_resource_config,
    extract_config_entries,
    parse_grafana_dashboard,
    parse_infrastructure_file,
)
from utils.spring_parser import parse_spring_file
from utils.vertx_parser import parse_vertx_file


def dedupe(rows: Iterable[Dict[str, Any]], keys: Sequence[str]) -> List[Dict[str, Any]]:
    result: Dict[Tuple[Any, ...], Dict[str, Any]] = {}
    for row in rows:
        result[tuple(row.get(key) for key in keys)] = row
    return list(result.values())


def infer_modules(root: Path, files: List[Path], build_modules: List[str], package_workspaces: List[str]) -> List[Dict[str, Any]]:
    module_paths = {m.strip("/") for m in build_modules if m and m.strip("/")}
    for workspace_pattern in package_workspaces:
        clean = str(workspace_pattern or "").strip("/")
        if clean and not any(token in clean for token in ("*", "{", "}")):
            module_paths.add(clean)
    for path in files:
        if path.name in {"build.gradle", "build.gradle.kts", "pom.xml", "package.json"} and path.parent != root:
            module_paths.add(str(path.parent.relative_to(root)).replace("\\", "/"))
    if not module_paths:
        module_paths.add(".")
    if any(path.parent == root and path.name in {"build.gradle", "build.gradle.kts", "pom.xml", "package.json"} for path in files):
        module_paths.add(".")
    result = []
    for module_path in sorted(module_paths, key=lambda x: (x != ".", x)):
        absolute = root if module_path == "." else root / module_path
        build_files = [
            name for name in (
                "build.gradle", "build.gradle.kts", "pom.xml", "package.json",
                "settings.gradle", "settings.gradle.kts",
            ) if (absolute / name).exists()
        ]
        result.append({
            "module_name": root.name if module_path == "." else Path(module_path).name,
            "module_path": module_path,
            "has_build_file": bool(build_files),
            "build_files": build_files,
            "source_type": "root" if module_path == "." else "build-or-package-file",
            "roles": [],
            "primary_role": "GENERAL",
        })
    return result


def module_for_path(relative_path: str, modules: List[Dict[str, Any]]) -> str:
    best = ""
    for module in modules:
        module_path = module["module_path"]
        if module_path == ".":
            continue
        if relative_path == module_path or relative_path.startswith(module_path + "/"):
            if len(module_path) > len(best):
                best = module_path
    if best:
        return next((m["module_name"] for m in modules if m["module_path"] == best), Path(best).name)
    root_module = next((m for m in modules if m["module_path"] == "."), None)
    return root_module["module_name"] if root_module else (modules[0]["module_name"] if modules else "root")


def infer_internal_roots(jvm_files: List[Dict[str, Any]], configured: List[str]) -> List[str]:
    roots = [x for x in (configured or []) if x]
    if roots:
        return roots
    packages = []
    for source in jvm_files:
        package = source.get("package") or ""
        parts = package.split(".")
        if len(parts) >= 3:
            packages.append(".".join(parts[:3]))
        elif len(parts) >= 2:
            packages.append(".".join(parts[:2]))
    return [name for name, _ in Counter(packages).most_common(8) if name]


def is_common_source(relative_path: str, package: str, keywords: List[str]) -> bool:
    source = f"{relative_path}/{package}".lower()
    return any(keyword.lower() in source for keyword in keywords or [])


def build_interface_relations(jvm_files: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]]]:
    interfaces: Dict[str, Dict[str, Any]] = {}
    classes: Dict[str, Dict[str, Any]] = {}
    for source in jvm_files:
        for class_row in source.get("classes", []):
            classes[class_row["name"]] = class_row
            if class_row.get("kind") == "interface":
                interfaces[class_row["name"]] = class_row

    implementations = []
    for source in jvm_files:
        for class_row in source.get("classes", []):
            super_types = list(class_row.get("implements", []))
            if class_row.get("kind") != "interface":
                super_types += [x for x in class_row.get("extends", []) if x in interfaces]
            for interface in super_types:
                simple = re.sub(r"<.*>", "", str(interface)).split(".")[-1].strip()
                implementations.append({
                    "interface_name": simple,
                    "interface_fqn": interfaces.get(simple, {}).get("fqn", "확인필요"),
                    "implementation_class": class_row.get("name", ""),
                    "implementation_fqn": class_row.get("fqn", ""),
                    "interface_source_path": interfaces.get(simple, {}).get("source_path", "확인필요"),
                    "implementation_source_path": class_row.get("source_path", ""),
                    "line": class_row.get("line", 0),
                    "status": "연결확인" if simple in interfaces else "인터페이스소스확인필요",
                })

    injections = []
    for source in jvm_files:
        for injection in source.get("injections", []):
            target = re.sub(r"<.*>", "", injection.get("target_type", "")).replace("?", "").split(".")[-1].strip()
            candidates = [row["implementation_class"] for row in implementations if row["interface_name"] == target]
            if not candidates and target in classes and classes[target].get("kind") != "interface":
                candidates = [target]
            injections.append({
                "source_class": injection.get("class", ""),
                "injection_type": injection.get("injection_type", ""),
                "target_type": target or injection.get("target_type", ""),
                "field_name": injection.get("field_name", ""),
                "parameter_name": injection.get("parameter_name", ""),
                "qualifier": injection.get("qualifier", ""),
                "annotation": injection.get("annotation", ""),
                "implementation_candidates": ", ".join(sorted(set(candidates))) if candidates else "확인필요",
                "source_path": injection.get("source_path", ""),
                "line": injection.get("line", 0),
                "status": "구현체후보확인" if candidates else "확인필요",
            })

    beans = []
    for source in jvm_files:
        beans.extend(source.get("beans", []))
    return (
        dedupe(implementations, ("interface_name", "implementation_class", "implementation_source_path")),
        dedupe(injections, ("source_class", "target_type", "field_name", "parameter_name", "source_path", "line")),
        dedupe(beans, ("configuration_class", "bean_name", "return_type", "source_path", "line")),
    )


def build_external_interfaces(
    jvm_files: List[Dict[str, Any]], dependencies: List[Dict[str, Any]],
    spring_clients: Sequence[Dict[str, Any]], vertx_clients: Sequence[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    rows = []
    for source in jvm_files:
        for client in source.get("feign_clients", []):
            rows.append({
                "type": "FEIGN_CLIENT", "name": client.get("name", ""),
                "target": client.get("url") or client.get("path") or "설정참조",
                "source_path": source.get("path", ""), "line": client.get("line", 0), "evidence": client.get("raw", ""),
                "framework": "SPRING_BOOT",
            })
        for use in source.get("uses", []):
            rows.append({
                "type": use, "name": use, "target": "코드사용", "source_path": source.get("path", ""),
                "line": 0, "evidence": use, "framework": "JVM",
            })
    for client in spring_clients:
        rows.append({
            "type": "HTTP_CLIENT", "name": client.get("client_type", "Spring HTTP Client"),
            "target": f"{client.get('http_method')} {client.get('path')}", "source_path": client.get("source_path", ""),
            "line": client.get("line", 0), "evidence": client.get("evidence", ""), "framework": "SPRING_BOOT",
        })
    for client in vertx_clients:
        rows.append({
            "type": "HTTP_CLIENT", "name": client.get("client_type", "Vert.x WebClient"),
            "target": f"{client.get('http_method')} {client.get('path')}", "source_path": client.get("source_path", ""),
            "line": client.get("line", 0), "evidence": client.get("evidence", ""), "framework": "VERTX",
        })
    keyword_map = {
        "oracle": "ORACLE_DB", "ojdbc": "ORACLE_DB", "redis": "REDIS", "redisson": "REDIS",
        "elasticsearch": "ELASTICSEARCH", "opensearch": "OPENSEARCH", "kafka": "KAFKA",
        "prometheus": "PROMETHEUS", "micrometer": "PROMETHEUS", "loki": "LOKI", "grafana": "GRAFANA",
        "feign": "FEIGN", "webflux": "WEB_CLIENT", "httpclient": "HTTP_CLIENT", "vertx": "VERTX",
        "spring-boot": "SPRING_BOOT",
    }
    for dependency in dependencies:
        coordinate = f"{dependency.get('group', '')}:{dependency.get('artifact', '')}".lower()
        for keyword, interface_type in keyword_map.items():
            if keyword in coordinate:
                rows.append({
                    "type": interface_type, "name": dependency.get("artifact", ""), "target": dependency.get("version", ""),
                    "source_path": dependency.get("source_path", ""), "line": dependency.get("line", 0), "evidence": coordinate,
                    "framework": "DEPENDENCY",
                })
                break
    return dedupe(rows, ("type", "name", "target", "source_path", "line"))


def build_architecture_edges(
    jvm_files: List[Dict[str, Any]], implementations: List[Dict[str, Any]], injections: List[Dict[str, Any]],
    beans: List[Dict[str, Any]], internal_roots: List[str], modules: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    edges = []
    class_module: Dict[str, str] = {}
    for source in jvm_files:
        for class_row in source.get("classes", []):
            class_module[class_row.get("name", "")] = module_for_path(class_row.get("source_path", ""), modules)
    for source in jvm_files:
        source_class = source.get("classes", [{}])[0].get("name", Path(source.get("path", "")).stem) if source.get("classes") else Path(source.get("path", "")).stem
        for imported in source.get("imports", []):
            if internal_roots and not any(imported.startswith(root) for root in internal_roots):
                continue
            target_class = imported.split(".")[-1]
            edges.append({
                "edge_type": "IMPORT", "source": source_class, "target": target_class,
                "source_module": module_for_path(source.get("path", ""), modules), "target_module": class_module.get(target_class, "확인필요"),
                "source_package": source.get("package", ""), "target_import": imported,
                "source_path": source.get("path", ""), "line": 0,
            })
    for row in implementations:
        edges.append({
            "edge_type": "IMPLEMENTS", "source": row.get("implementation_class", ""), "target": row.get("interface_name", ""),
            "source_module": class_module.get(row.get("implementation_class", ""), ""), "target_module": class_module.get(row.get("interface_name", ""), ""),
            "source_path": row.get("implementation_source_path", ""), "line": row.get("line", 0),
        })
    for row in injections:
        edges.append({
            "edge_type": "INJECTION", "source": row.get("source_class", ""), "target": row.get("target_type", ""),
            "source_module": class_module.get(row.get("source_class", ""), ""), "target_module": class_module.get(row.get("target_type", ""), "확인필요"),
            "source_path": row.get("source_path", ""), "line": row.get("line", 0),
        })
    for bean in beans:
        edges.append({
            "edge_type": "BEAN_FACTORY", "source": bean.get("configuration_class", ""), "target": bean.get("return_type", ""),
            "source_module": class_module.get(bean.get("configuration_class", ""), ""), "target_module": "RUNTIME_BEAN",
            "source_path": bean.get("source_path", ""), "line": bean.get("line", 0),
        })
    return dedupe(edges, ("edge_type", "source", "target", "source_path", "line"))


def map_local_jar_usage(jvm_files: List[Dict[str, Any]], jar_details: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows = []
    for source in jvm_files:
        for imported in source.get("imports", []):
            for jar in jar_details:
                packages = jar.get("packages", []) or []
                if any(imported == package or imported.startswith(package + ".") for package in packages):
                    rows.append({
                        "source_class": source.get("classes", [{}])[0].get("name", Path(source.get("path", "")).stem) if source.get("classes") else Path(source.get("path", "")).stem,
                        "import": imported, "jar_file": jar.get("source_path", ""),
                        "matched_package": next((p for p in packages if imported == p or imported.startswith(p + ".")), ""),
                        "source_path": source.get("path", ""),
                    })
    return dedupe(rows, ("source_class", "import", "jar_file", "source_path"))


def _framework_resource_interfaces(
    vertx_sql_clients: Sequence[Dict[str, Any]], vertx_redis_clients: Sequence[Dict[str, Any]],
    vertx_kafka_clients: Sequence[Dict[str, Any]], vertx_metrics: Sequence[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for row in vertx_sql_clients:
        rows.append({
            "resource_type": "ORACLE", "direction": "OUTBOUND", "source_component": row.get("source_component", ""),
            "operation": row.get("operation", "SQL"), "target": row.get("target", "확인필요"),
            "client_api": "Vert.x SQL Client", "detail": "Vert.x SQL/Oracle client", "confidence": "MEDIUM",
            "source_path": row.get("source_path", ""), "line": row.get("line", 0),
        })
    for row in vertx_redis_clients:
        rows.append({
            "resource_type": "REDIS", "direction": "OUTBOUND", "source_component": row.get("source_component", ""),
            "operation": row.get("operation", "CREATE_CLIENT"), "target": row.get("target", "확인필요"),
            "client_api": "Vert.x Redis Client", "detail": "Vert.x Redis", "confidence": "MEDIUM",
            "source_path": row.get("source_path", ""), "line": row.get("line", 0),
        })
    for row in vertx_kafka_clients:
        rows.append({
            "resource_type": "KAFKA", "direction": "INBOUND" if row.get("client_type") in {"CONSUMER", "CONSUME"} else "OUTBOUND",
            "source_component": row.get("source_component", ""), "operation": row.get("client_type", "KAFKA_CLIENT"),
            "target": row.get("config", "확인필요"), "client_api": "Vert.x Kafka Client",
            "detail": "Vert.x Kafka", "confidence": "MEDIUM", "source_path": row.get("source_path", ""), "line": row.get("line", 0),
        })
    for row in vertx_metrics:
        rows.append({
            "resource_type": "PROMETHEUS", "direction": "OUTBOUND", "source_component": row.get("source_component", ""),
            "operation": "VERTX_METRICS", "target": row.get("feature", "Vert.x metrics"),
            "client_api": "Vert.x Micrometer", "detail": "Vert.x metrics configuration", "confidence": "HIGH",
            "source_path": row.get("source_path", ""), "line": row.get("line", 0),
        })
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description="Analyze a React + Spring Boot + Vert.x workspace and build normalized documentation data.")
    parser.add_argument("--config", required=True)
    args = parser.parse_args()

    cfg = load_config(args.config)
    base_dir = Path(cfg["_base_dir"])
    workspace_root = resolve_path(base_dir, cfg.get("workspace", {}).get("root", "."))
    if not workspace_root.exists():
        raise FileNotFoundError(f"workspace.root not found: {workspace_root}")

    output_root = resolve_path(base_dir, cfg.get("output", {}).get("dir", "output"))
    analysis_dir = ensure_dir(output_root / "analysis")
    analysis_cfg = cfg.get("analysis", {}) or {}
    files = list(iter_workspace_files(
        workspace_root,
        analysis_cfg.get("ignore_dirs", []),
        analysis_cfg.get("ignore_file_globs", []),
        int(analysis_cfg.get("max_file_mb", 10)),
        int(analysis_cfg.get("max_binary_file_mb", 300)),
    ))
    inventory = [file_record(workspace_root, path) for path in files]

    jvm_files: List[Dict[str, Any]] = []
    dependencies: List[Dict[str, Any]] = []
    repositories: List[Dict[str, Any]] = []
    plugins: List[Dict[str, Any]] = []
    build_modules: List[str] = []
    local_jars: List[Dict[str, Any]] = []
    jar_details: List[Dict[str, Any]] = []

    sql_tables: List[Dict[str, Any]] = []
    sql_columns: List[Dict[str, Any]] = []
    sql_relations: List[Dict[str, Any]] = []
    sql_comments: List[Dict[str, Any]] = []
    sql_sequences: List[Dict[str, Any]] = []
    sql_indexes: List[Dict[str, Any]] = []
    sql_views: List[Dict[str, Any]] = []
    sql_programs: List[Dict[str, Any]] = []
    sql_synonyms: List[Dict[str, Any]] = []
    sql_references: List[Dict[str, Any]] = []
    mybatis_mappers: List[Dict[str, Any]] = []

    frontend_routes: List[Dict[str, Any]] = []
    frontend_menus: List[Dict[str, Any]] = []
    react_manifests: List[Dict[str, Any]] = []
    react_packages: List[Dict[str, Any]] = []
    react_scripts: List[Dict[str, Any]] = []
    react_frameworks: List[Dict[str, Any]] = []
    react_workspaces: List[Dict[str, Any]] = []
    react_components: List[Dict[str, Any]] = []
    react_hooks: List[Dict[str, Any]] = []
    react_stores: List[Dict[str, Any]] = []
    react_api_clients: List[Dict[str, Any]] = []
    react_api_calls: List[Dict[str, Any]] = []
    react_env_refs: List[Dict[str, Any]] = []
    react_imports: List[Dict[str, Any]] = []
    ts_aliases: List[Dict[str, Any]] = []
    ts_compiler_options: List[Dict[str, Any]] = []

    spring_applications: List[Dict[str, Any]] = []
    spring_functional_routes: List[Dict[str, Any]] = []
    spring_security_rules: List[Dict[str, Any]] = []
    spring_configuration_properties: List[Dict[str, Any]] = []
    spring_scheduled_jobs: List[Dict[str, Any]] = []
    spring_event_listeners: List[Dict[str, Any]] = []
    spring_clients: List[Dict[str, Any]] = []
    spring_actuator_endpoints: List[Dict[str, Any]] = []
    spring_profiles: List[Dict[str, Any]] = []
    spring_transactions: List[Dict[str, Any]] = []
    spring_source_paths: set[str] = set()

    vertx_verticles: List[Dict[str, Any]] = []
    vertx_deployments: List[Dict[str, Any]] = []
    vertx_http_servers: List[Dict[str, Any]] = []
    vertx_routes: List[Dict[str, Any]] = []
    vertx_handlers: List[Dict[str, Any]] = []
    vertx_event_bus: List[Dict[str, Any]] = []
    vertx_event_bus_codecs: List[Dict[str, Any]] = []
    vertx_service_proxies: List[Dict[str, Any]] = []
    vertx_web_clients: List[Dict[str, Any]] = []
    vertx_config_keys: List[Dict[str, Any]] = []
    vertx_shared_data: List[Dict[str, Any]] = []
    vertx_timers: List[Dict[str, Any]] = []
    vertx_sql_clients: List[Dict[str, Any]] = []
    vertx_redis_clients: List[Dict[str, Any]] = []
    vertx_kafka_clients: List[Dict[str, Any]] = []
    vertx_metrics: List[Dict[str, Any]] = []
    vertx_subrouter_mounts: List[Dict[str, Any]] = []
    vertx_source_paths: set[str] = set()

    config_entries: List[Dict[str, Any]] = []
    resource_configs: List[Dict[str, Any]] = []
    resource_interfaces: List[Dict[str, Any]] = []
    resource_assets: List[Dict[str, Any]] = []
    manifests: List[Dict[str, Any]] = []
    deployments: List[Dict[str, Any]] = []
    prometheus_scrapes: List[Dict[str, Any]] = []
    prometheus_rules: List[Dict[str, Any]] = []
    loki_jobs: List[Dict[str, Any]] = []
    grafana_dashboards: List[Dict[str, Any]] = []
    grafana_panels: List[Dict[str, Any]] = []
    grafana_datasources: List[Dict[str, Any]] = []
    grafana_queries: List[Dict[str, Any]] = []
    analysis_errors: List[Dict[str, Any]] = []

    for path in files:
        kind = classify_file(path)
        rel = str(path.relative_to(workspace_root)).replace("\\", "/")
        try:
            if kind == "jvm-source":
                parsed_jvm = parse_jvm_file(path, workspace_root)
                jvm_files.append(parsed_jvm)
                spring = parse_spring_file(path, workspace_root)
                if spring.get("is_spring"):
                    spring_source_paths.add(rel)
                    spring_applications.extend(spring.get("applications", []))
                    spring_functional_routes.extend(spring.get("functional_routes", []))
                    spring_security_rules.extend(spring.get("security_rules", []))
                    spring_configuration_properties.extend(spring.get("configuration_properties", []))
                    spring_scheduled_jobs.extend(spring.get("scheduled_jobs", []))
                    spring_event_listeners.extend(spring.get("event_listeners", []))
                    spring_clients.extend(spring.get("clients", []))
                    spring_actuator_endpoints.extend(spring.get("actuator_endpoints", []))
                    spring_profiles.extend(spring.get("profiles", []))
                    spring_transactions.extend(spring.get("transactions", []))
                vertx = parse_vertx_file(path, workspace_root)
                if vertx.get("is_vertx"):
                    vertx_source_paths.add(rel)
                    vertx_verticles.extend(vertx.get("verticles", []))
                    vertx_deployments.extend(vertx.get("deployments", []))
                    vertx_http_servers.extend(vertx.get("http_servers", []))
                    vertx_routes.extend(vertx.get("routes", []))
                    vertx_handlers.extend(vertx.get("handlers", []))
                    vertx_event_bus.extend(vertx.get("event_bus", []))
                    vertx_event_bus_codecs.extend(vertx.get("event_bus_codecs", []))
                    vertx_service_proxies.extend(vertx.get("service_proxies", []))
                    vertx_web_clients.extend(vertx.get("web_clients", []))
                    vertx_config_keys.extend(vertx.get("config_keys", []))
                    vertx_shared_data.extend(vertx.get("shared_data", []))
                    vertx_timers.extend(vertx.get("timers", []))
                    vertx_sql_clients.extend(vertx.get("sql_clients", []))
                    vertx_redis_clients.extend(vertx.get("redis_clients", []))
                    vertx_kafka_clients.extend(vertx.get("kafka_clients", []))
                    vertx_metrics.extend(vertx.get("metrics", []))
                    vertx_subrouter_mounts.extend(vertx.get("subrouter_mounts", []))
            elif kind in {"gradle-build", "maven-build"}:
                parsed = parse_build_file(path, workspace_root)
                dependencies.extend(parsed.get("dependencies", []))
                repositories.extend(parsed.get("repositories", []))
                plugins.extend(parsed.get("plugins", []))
                build_modules.extend(parsed.get("modules", []))
            elif kind == "local-jar":
                local_jars.append(parse_jar_name(path, workspace_root))
                if bool(analysis_cfg.get("inspect_jars", True)):
                    jar_details.append(inspect_jar(path, workspace_root, int(analysis_cfg.get("max_jar_entries", 200000))))
            elif kind == "sql":
                parsed = parse_sql_file(path, workspace_root)
                sql_tables.extend(parsed.get("tables", []))
                sql_columns.extend(parsed.get("columns", []))
                sql_relations.extend(parsed.get("relations", []))
                sql_comments.extend(parsed.get("comments", []))
                sql_sequences.extend(parsed.get("sequences", []))
                sql_indexes.extend(parsed.get("indexes", []))
                sql_views.extend(parsed.get("views", []))
                sql_programs.extend(parsed.get("programs", []))
                sql_synonyms.extend(parsed.get("synonyms", []))
                sql_references.extend(parsed.get("sql_references", []))
            elif kind == "mybatis-mapper":
                parsed = parse_mybatis_mapper(path, workspace_root)
                mybatis_mappers.extend(parsed.get("mappers", []))
                sql_references.extend(parsed.get("sql_references", []))
            elif kind == "frontend-manifest":
                parsed = parse_package_json(path, workspace_root)
                react_manifests.append(parsed.get("manifest", {}))
                react_packages.extend(parsed.get("packages", []))
                react_scripts.extend(parsed.get("scripts", []))
                react_frameworks.extend(parsed.get("frameworks", []))
                react_workspaces.extend(parsed.get("workspaces", []))
            elif kind == "frontend-config":
                if path.name.lower().startswith("tsconfig"):
                    parsed = parse_tsconfig(path, workspace_root)
                    ts_aliases.extend(parsed.get("aliases", []))
                    ts_compiler_options.extend(parsed.get("compiler_options", []))
                if path.suffix.lower() in {".js", ".jsx", ".ts", ".tsx"}:
                    parsed = parse_react_file(path, workspace_root)
                    react_components.extend(parsed.get("components", []))
                    frontend_routes.extend(parsed.get("routes", []))
                    frontend_menus.extend(parsed.get("menus", []))
                    react_hooks.extend(parsed.get("hooks", []))
                    react_stores.extend(parsed.get("stores", []))
                    react_api_clients.extend(parsed.get("api_clients", []))
                    react_api_calls.extend(parsed.get("api_calls", []))
                    react_env_refs.extend(parsed.get("env_refs", []))
                    react_imports.extend(parsed.get("imports", []))
            elif kind == "frontend":
                generic = parse_frontend_file(path, workspace_root)
                frontend_routes.extend(generic.get("routes", []))
                frontend_menus.extend(generic.get("menus", []))
                react = parse_react_file(path, workspace_root)
                if react.get("is_react"):
                    react_components.extend(react.get("components", []))
                    frontend_routes.extend(react.get("routes", []))
                    frontend_menus.extend(react.get("menus", []))
                    react_hooks.extend(react.get("hooks", []))
                    react_stores.extend(react.get("stores", []))
                    react_api_clients.extend(react.get("api_clients", []))
                    react_api_calls.extend(react.get("api_calls", []))
                    react_env_refs.extend(react.get("env_refs", []))
                    react_imports.extend(react.get("imports", []))

            if kind in {"config", "infrastructure", "script", "frontend-config"}:
                entries = extract_config_entries(path, workspace_root)
                config_entries.extend(entries)
                resource_configs.extend(detect_resource_config(entries))
            if path.suffix.lower() in {".yml", ".yaml"}:
                infra = parse_infrastructure_file(path, workspace_root)
                manifests.extend(infra.get("manifests", []))
                deployments.extend(infra.get("deployments", []))
                prometheus_scrapes.extend(infra.get("prometheus_scrapes", []))
                prometheus_rules.extend(infra.get("prometheus_rules", []))
                loki_jobs.extend(infra.get("loki_jobs", []))
                grafana_datasources.extend(infra.get("grafana_datasources", []))
            if path.suffix.lower() == ".json" and kind not in {"frontend-manifest", "frontend-config", "frontend-lock"}:
                dashboard = parse_grafana_dashboard(path, workspace_root)
                grafana_dashboards.extend(dashboard.get("dashboards", []))
                grafana_panels.extend(dashboard.get("panels", []))
                grafana_datasources.extend(dashboard.get("datasources", []))
                grafana_queries.extend(dashboard.get("queries", []))

            if path.suffix.lower() in TEXT_EXTENSIONS and kind not in {"document", "frontend", "frontend-manifest", "frontend-lock"}:
                integration = analyze_code_integrations(path, workspace_root)
                resource_interfaces.extend(integration.get("interfaces", []))
                resource_assets.extend(integration.get("assets", []))
        except Exception as exc:
            analysis_errors.append({"source_path": rel, "kind": kind, "error": str(exc)})

    package_workspace_paths = [row.get("path_pattern", "") for row in react_workspaces]
    modules = infer_modules(workspace_root, files, build_modules, package_workspace_paths)
    for record in inventory:
        record["module"] = module_for_path(str(record["path"]), modules)

    cache_roots = []
    if bool(analysis_cfg.get("inspect_dependency_cache", False)):
        cache_roots = [resolve_path(base_dir, path) for path in analysis_cfg.get("dependency_cache_roots", [])]
    all_dependencies = enrich_dependency_acquisition(dependencies + local_jars, repositories, cache_roots)
    internal_roots = infer_internal_roots(jvm_files, analysis_cfg.get("internal_package_roots", []))
    common_keywords = analysis_cfg.get("common_path_keywords", [])

    classes: List[Dict[str, Any]] = []
    methods: List[Dict[str, Any]] = []
    endpoints: List[Dict[str, Any]] = []
    entities: List[Dict[str, Any]] = []
    common_sources: List[Dict[str, Any]] = []
    spring_components: List[Dict[str, Any]] = []
    for source in jvm_files:
        source_path = source.get("path", "")
        for class_row in source.get("classes", []):
            class_row["module"] = module_for_path(class_row.get("source_path", ""), modules)
            class_row["frameworks"] = sorted(set(
                (["SPRING_BOOT"] if source_path in spring_source_paths else [])
                + (["VERTX"] if source_path in vertx_source_paths else [])
            ))
            classes.append(class_row)
            if source_path in spring_source_paths and class_row.get("component_type") != "JAVA_TYPE":
                spring_components.append(class_row)
            if is_common_source(class_row.get("source_path", ""), class_row.get("fqn", ""), common_keywords):
                common_sources.append({
                    "module": class_row["module"], "class_name": class_row.get("name", ""), "fqn": class_row.get("fqn", ""),
                    "component_type": class_row.get("component_type", ""), "reason": "path/package keyword",
                    "source_path": class_row.get("source_path", ""), "line": class_row.get("line", 0),
                })
        for method in source.get("methods", []):
            method["module"] = module_for_path(method.get("source_path", ""), modules)
            method["frameworks"] = sorted(set(
                (["SPRING_BOOT"] if source_path in spring_source_paths else [])
                + (["VERTX"] if source_path in vertx_source_paths else [])
            ))
            methods.append(method)
        for endpoint in source.get("endpoints", []):
            endpoint["module"] = module_for_path(endpoint.get("source_path", ""), modules)
            endpoint["framework"] = "SPRING_BOOT"
            endpoint["route_style"] = "ANNOTATION"
            endpoints.append(endpoint)
        for entity in source.get("entities", []):
            entity["module"] = module_for_path(entity.get("source_path", ""), modules)
            entities.append(entity)

    for row_group in (
        react_components, react_hooks, react_stores, react_api_clients, react_api_calls, react_env_refs,
        spring_applications, spring_functional_routes, spring_security_rules, spring_configuration_properties,
        spring_scheduled_jobs, spring_event_listeners, spring_clients, spring_actuator_endpoints, spring_profiles,
        spring_transactions, vertx_verticles, vertx_deployments, vertx_http_servers, vertx_routes, vertx_handlers,
        vertx_event_bus, vertx_event_bus_codecs, vertx_service_proxies, vertx_web_clients, vertx_config_keys,
        vertx_shared_data, vertx_timers, vertx_sql_clients, vertx_redis_clients, vertx_kafka_clients, vertx_metrics,
        vertx_subrouter_mounts, frontend_routes, frontend_menus,
    ):
        for row in row_group:
            row["module"] = module_for_path(row.get("source_path", ""), modules)

    modules = classify_module_roles(
        modules, react_manifests, react_components, spring_applications, spring_components, vertx_verticles,
    )

    implementations, injections, beans = build_interface_relations(jvm_files)
    external_interfaces = build_external_interfaces(jvm_files, all_dependencies, spring_clients, vertx_web_clients)
    architecture_edges = build_architecture_edges(jvm_files, implementations, injections, beans, internal_roots, modules)
    jar_usage = map_local_jar_usage(jvm_files, jar_details)

    resource_interfaces.extend(_framework_resource_interfaces(
        vertx_sql_clients, vertx_redis_clients, vertx_kafka_clients, vertx_metrics,
    ))
    resource_configs = dedupe(resource_configs, ("resource_type", "key", "value_sample", "source_path", "line"))
    resource_interfaces = dedupe(resource_interfaces, ("resource_type", "direction", "operation", "target", "source_path", "line"))
    resource_assets = dedupe(resource_assets, ("resource_type", "asset_type", "name", "source_path", "line"))
    manifests = dedupe(manifests, ("kind", "name", "namespace", "source_path"))
    resource_inventory = build_resource_inventory(resource_configs, resource_interfaces, resource_assets, manifests, all_dependencies)
    resource_topology = build_resource_topology(resource_interfaces)
    architecture_edges.extend(resource_topology)

    frontend_routes = dedupe(frontend_routes, ("path", "component", "source_path", "line"))
    enriched_route_keys = {
        (row.get("path"), row.get("source_path"))
        for row in frontend_routes
        if row.get("component") not in {None, "", "확인필요"} or row.get("route_type")
    }
    frontend_routes = [
        row for row in frontend_routes
        if (row.get("path"), row.get("source_path")) not in enriched_route_keys
        or row.get("component") not in {None, ""}
        or row.get("route_type")
    ]
    frontend_menus = dedupe(frontend_menus, ("label", "path", "source_path", "line"))
    react_components = dedupe(react_components, ("name", "source_path", "line"))
    react_hooks = dedupe(react_hooks, ("hook", "kind", "owner_component", "source_path", "line"))
    react_stores = dedupe(react_stores, ("store_type", "name", "source_path", "line"))
    react_api_clients = dedupe(react_api_clients, ("name", "base_url", "source_path", "line"))
    react_api_calls = dedupe(react_api_calls, ("call_id",))
    react_env_refs = dedupe(react_env_refs, ("key", "access", "source_path", "line"))
    react_imports = dedupe(react_imports, ("imported", "module", "source_path", "line"))
    react_frameworks = dedupe(react_frameworks, ("framework", "package", "version", "source_path"))
    react_packages = dedupe(react_packages, ("name", "version", "scope", "source_path"))
    config_entries = dedupe(config_entries, ("key", "value_sample", "source_path", "line"))
    grafana_queries = dedupe(grafana_queries, ("dashboard_title", "panel_title", "ref_id", "query", "source_path"))

    backend_endpoints = build_backend_endpoints(
        endpoints,
        dedupe(spring_functional_routes, ("http_method", "path", "controller", "method_name", "source_path", "line")),
        dedupe(vertx_routes, ("http_method", "path", "handler", "source_path", "line", "mounted_path")),
        lambda source_path: module_for_path(source_path, modules),
    )
    react_backend_mappings = match_calls_to_endpoints(react_api_calls, backend_endpoints, "REACT")
    spring_internal_mappings = match_calls_to_endpoints(spring_clients, backend_endpoints, "SPRING_BOOT")
    vertx_internal_mappings = match_calls_to_endpoints(vertx_web_clients, backend_endpoints, "VERTX")
    backend_internal_mappings = spring_internal_mappings + vertx_internal_mappings
    route_api_links = build_route_api_links(frontend_routes, react_api_calls, react_backend_mappings)
    event_bus_links = match_event_bus(vertx_event_bus, vertx_service_proxies)
    framework_edges = build_framework_edges(route_api_links, event_bus_links, backend_internal_mappings)
    architecture_edges.extend(framework_edges)
    stack_summary = build_stack_summary(react_frameworks, all_dependencies, spring_applications, vertx_verticles, modules)
    mermaid_overview = build_mermaid_overview(stack_summary, route_api_links, event_bus_links)

    summary = {
        "file_count": len(files), "module_count": len(modules), "jvm_file_count": len(jvm_files),
        "class_count": len(classes), "method_count": len(methods), "endpoint_count": len(backend_endpoints),
        "spring_endpoint_count": len([x for x in backend_endpoints if x.get("framework") == "SPRING_BOOT"]),
        "vertx_route_count": len([x for x in backend_endpoints if x.get("framework") == "VERTX"]),
        "dependency_count": len(all_dependencies), "npm_package_count": len(react_packages), "local_jar_count": len(local_jars),
        "table_count": len(sql_tables) + len(entities), "frontend_route_count": len(frontend_routes),
        "react_component_count": len(react_components), "react_api_call_count": len(react_api_calls),
        "frontend_backend_match_count": len([x for x in react_backend_mappings if x.get("status") in {"MATCHED", "AMBIGUOUS"}]),
        "vertx_verticle_count": len(vertx_verticles), "vertx_event_bus_count": len(vertx_event_bus),
        "event_bus_link_count": len([x for x in event_bus_links if x.get("status") == "MATCHED"]),
        "common_source_count": len(common_sources), "resource_interface_count": len(resource_interfaces),
        "resource_inventory_count": len(resource_inventory), "grafana_dashboard_count": len(grafana_dashboards),
        "prometheus_scrape_count": len(prometheus_scrapes), "analysis_error_count": len(analysis_errors),
    }

    resource_sections = {
        "oracle": {
            "interfaces": [x for x in resource_interfaces if x.get("resource_type") == "ORACLE"],
            "sql_references": dedupe(sql_references, ("operation", "schema", "table_name", "statement_id", "source_path")),
            "sequences": sql_sequences, "indexes": sql_indexes, "views": sql_views, "programs": sql_programs, "synonyms": sql_synonyms,
        },
        "redis": {"interfaces": [x for x in resource_interfaces if x.get("resource_type") == "REDIS"]},
        "elasticsearch": {
            "interfaces": [x for x in resource_interfaces if x.get("resource_type") == "ELASTICSEARCH"],
            "indices": [x for x in resource_assets if x.get("resource_type") == "ELASTICSEARCH" and x.get("asset_type") == "INDEX"],
        },
        "kafka": {"interfaces": [x for x in resource_interfaces if x.get("resource_type") == "KAFKA"]},
        "grafana": {
            "dashboards": grafana_dashboards, "panels": grafana_panels,
            "datasources": dedupe(grafana_datasources, ("type", "uid", "name", "source_path")), "queries": grafana_queries,
        },
        "prometheus": {
            "metrics": [x for x in resource_assets if x.get("resource_type") == "PROMETHEUS" and x.get("asset_type") == "METRIC"],
            "scrape_configs": dedupe(prometheus_scrapes, ("type", "job_name", "target", "source_path")),
            "rules": dedupe(prometheus_rules, ("group", "name", "source_path")),
        },
        "loki": {
            "interfaces": [x for x in resource_interfaces if x.get("resource_type") == "LOKI"],
            "jobs": dedupe(loki_jobs, ("job_name", "source_path")),
            "grafana_queries": [x for x in grafana_queries if "loki" in str(x.get("datasource_type", "")).lower() or str(x.get("query", "")).strip().startswith("{")],
        },
    }

    detected_services = cfg.get("detected_services", {}) or {}
    auto_configuration = {
        "generated": bool((cfg.get("auto_config", {}) or {}).get("generated", False)),
        "generated_at_source": (cfg.get("auto_config", {}) or {}).get("generated_at_source", ""),
        "discovery_report": (cfg.get("auto_config", {}) or {}).get("discovery_report", ""),
        "user_choices": (cfg.get("auto_config", {}) or {}).get("user_choices", {}),
        "loaded_config_files": cfg.get("_loaded_config_files", []),
        "detected_services": detected_services,
    }
    summary["auto_config_generated"] = auto_configuration["generated"]
    summary["auto_detected_service_count"] = len([
        name for name, value in detected_services.items()
        if isinstance(value, dict) and value.get("detected")
    ])

    analysis: Dict[str, Any] = {
        "schema_version": "4.0",
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "auto_configuration": auto_configuration,
        "workspace": {
            "name": cfg.get("workspace", {}).get("name", workspace_root.name),
            "root": str(workspace_root), "internal_package_roots": internal_roots,
        },
        "stack": stack_summary,
        "summary": summary,
        "modules": modules,
        "files": inventory,
        "java": {
            "classes": classes, "methods": methods, "endpoints": endpoints,
            "interface_impl": implementations, "injections": injections, "beans": beans,
            "entities": entities, "external_interfaces": external_interfaces,
        },
        "spring": {
            "applications": dedupe(spring_applications, ("application_class", "source_path", "line")),
            "components": dedupe(spring_components, ("name", "source_path", "line")),
            "annotation_endpoints": endpoints,
            "functional_routes": dedupe(spring_functional_routes, ("http_method", "path", "source_path", "line")),
            "security_rules": dedupe(spring_security_rules, ("path", "rule", "source_path", "line")),
            "configuration_properties": dedupe(spring_configuration_properties, ("prefix", "class", "source_path", "line")),
            "scheduled_jobs": dedupe(spring_scheduled_jobs, ("class", "method", "source_path", "line")),
            "event_listeners": dedupe(spring_event_listeners, ("listener_type", "class", "method", "source_path", "line")),
            "http_clients": dedupe(spring_clients, ("call_id",)),
            "actuator_endpoints": dedupe(spring_actuator_endpoints, ("id", "class", "source_path", "line")),
            "profiles": dedupe(spring_profiles, ("class", "source_path", "line")),
            "transactions": dedupe(spring_transactions, ("class", "method", "source_path", "line")),
        },
        "vertx": {
            "verticles": dedupe(vertx_verticles, ("class", "source_path", "line")),
            "deployments": dedupe(vertx_deployments, ("deployer", "verticle", "source_path", "line")),
            "http_servers": dedupe(vertx_http_servers, ("source_component", "port", "host", "source_path", "line")),
            "routes": dedupe(vertx_routes, ("http_method", "path", "handler", "source_path", "line", "mounted_path")),
            "handlers": dedupe(vertx_handlers, ("class", "handler", "source_path", "line")),
            "event_bus": dedupe(vertx_event_bus, ("event_id",)),
            "event_bus_links": event_bus_links,
            "event_bus_codecs": dedupe(vertx_event_bus_codecs, ("message_type", "codec", "source_path", "line")),
            "service_proxies": dedupe(vertx_service_proxies, ("kind", "address", "service", "source_path", "line")),
            "web_clients": dedupe(vertx_web_clients, ("call_id",)),
            "config_keys": dedupe(vertx_config_keys, ("key", "source_path", "line")),
            "shared_data": dedupe(vertx_shared_data, ("map_type", "name", "source_path", "line")),
            "timers": dedupe(vertx_timers, ("timer_type", "delay", "source_path", "line")),
            "sql_clients": dedupe(vertx_sql_clients, ("operation", "target", "source_path", "line")),
            "redis_clients": dedupe(vertx_redis_clients, ("operation", "target", "source_path", "line")),
            "kafka_clients": dedupe(vertx_kafka_clients, ("client_type", "config", "source_path", "line")),
            "metrics": dedupe(vertx_metrics, ("feature", "source_path", "line")),
            "subrouter_mounts": dedupe(vertx_subrouter_mounts, ("router", "prefix", "subrouter", "source_path", "line")),
        },
        "backend": {
            "endpoints": backend_endpoints,
            "react_api_mappings": react_backend_mappings,
            "internal_http_mappings": backend_internal_mappings,
            "event_bus_mappings": event_bus_links,
        },
        "dependencies": {
            "repositories": dedupe(repositories, ("type", "url", "source_path")),
            "plugins": dedupe(plugins, ("plugin_id", "version", "source_path")),
            "artifacts": all_dependencies, "local_jars": local_jars, "jar_details": jar_details, "jar_usage": jar_usage,
            "npm_manifests": react_manifests, "npm_packages": react_packages, "npm_scripts": react_scripts,
        },
        "database": {
            "engine": "ORACLE", "sql_tables": sql_tables, "sql_columns": sql_columns, "relations": sql_relations,
            "comments": sql_comments, "sequences": sql_sequences, "indexes": sql_indexes, "views": sql_views,
            "programs": sql_programs, "synonyms": sql_synonyms, "entity_tables": entities,
            "mybatis_mappers": mybatis_mappers, "sql_references": sql_references,
        },
        "frontend": {
            "framework": "REACT" if react_frameworks or react_components else "확인필요",
            "frameworks": react_frameworks, "manifests": react_manifests, "packages": react_packages,
            "scripts": react_scripts, "workspaces": react_workspaces, "components": react_components,
            "routes": frontend_routes, "menus": frontend_menus, "hooks": react_hooks, "stores": react_stores,
            "api_clients": react_api_clients, "api_calls": react_api_calls, "env_refs": react_env_refs,
            "imports": react_imports, "ts_aliases": ts_aliases, "ts_compiler_options": ts_compiler_options,
            "backend_mappings": react_backend_mappings, "route_api_links": route_api_links,
        },
        "deployment": {
            "manifests": manifests,
            "workloads": dedupe(deployments, ("kind", "workload", "container", "source_path")),
        },
        "resources": {
            "supported_types": list(RESOURCE_TYPES), "configurations": resource_configs, "interfaces": resource_interfaces,
            "assets": resource_assets, "inventory": resource_inventory, "topology_edges": resource_topology,
            **resource_sections,
        },
        "architecture": {
            "common_sources": common_sources,
            "edges": dedupe(architecture_edges, ("edge_type", "source", "target", "operation", "source_path", "line")),
            "framework_edges": framework_edges,
            "config_keys": config_entries,
            "mermaid_overview": mermaid_overview,
        },
        "analysis_errors": analysis_errors,
        "review_items": [],
    }

    if not files:
        analysis["review_items"].append({"severity": "HIGH", "message": "분석 대상 파일이 없습니다.", "target": str(workspace_root)})
    for class_row in classes:
        if class_row.get("kind") == "interface" and not any(row.get("interface_name") == class_row.get("name") for row in implementations):
            analysis["review_items"].append({
                "severity": "MEDIUM", "message": "구현체를 찾지 못한 interface", "target": class_row.get("fqn"),
                "source_path": class_row.get("source_path"), "line": class_row.get("line", 0),
            })
    for endpoint in backend_endpoints:
        if endpoint.get("path") == "확인필요" or not endpoint.get("path"):
            analysis["review_items"].append({
                "severity": "MEDIUM", "message": f"{endpoint.get('framework')} API URL path 확인 필요",
                "target": endpoint.get("component"), "source_path": endpoint.get("source_path"), "line": endpoint.get("line", 0),
            })
    for route in frontend_routes:
        if route.get("component") in {"", "확인필요", None} and route.get("path") not in {"", "(index)"}:
            analysis["review_items"].append({
                "severity": "LOW", "message": "React Route의 화면 Component 확인 필요", "target": route.get("path"),
                "source_path": route.get("source_path", ""), "line": route.get("line", 0),
            })
    for mapping in react_backend_mappings:
        if mapping.get("status") == "UNMATCHED":
            analysis["review_items"].append({
                "severity": "MEDIUM", "message": "React API 호출과 Spring Boot/Vert.x Endpoint 매핑 실패",
                "target": f"{mapping.get('http_method')} {mapping.get('call_path')}",
                "source_path": mapping.get("source_path", ""), "line": mapping.get("line", 0),
            })
        elif mapping.get("status") == "AMBIGUOUS":
            analysis["review_items"].append({
                "severity": "MEDIUM", "message": "React API 호출이 여러 Backend Endpoint와 매칭됨",
                "target": f"{mapping.get('http_method')} {mapping.get('call_path')}",
                "source_path": mapping.get("source_path", ""), "line": mapping.get("line", 0),
            })
    for link in event_bus_links:
        if link.get("status") != "MATCHED":
            analysis["review_items"].append({
                "severity": "MEDIUM", "message": f"Vert.x EventBus {link.get('status')}", "target": link.get("address"),
                "source_path": link.get("source_path", ""), "line": link.get("line", 0),
            })
    if spring_applications and not any(row.get("framework") == "SPRING_BOOT" for row in backend_endpoints):
        analysis["review_items"].append({"severity": "LOW", "message": "Spring Boot는 탐지했지만 HTTP Endpoint를 찾지 못함", "target": "SPRING_BOOT"})
    if vertx_verticles and not vertx_routes:
        analysis["review_items"].append({"severity": "LOW", "message": "Vert.x Verticle은 탐지했지만 HTTP Route를 찾지 못함", "target": "VERTX"})
    detected_types = {row.get("resource_type") for row in resource_inventory}
    for resource_type in RESOURCE_TYPES:
        if resource_type in detected_types and not any(row.get("resource_type") == resource_type for row in resource_interfaces):
            analysis["review_items"].append({
                "severity": "LOW", "message": f"{resource_type} 설정/의존성은 탐지했으나 코드 인터페이스를 특정하지 못함",
                "target": resource_type, "source_path": "",
            })
    for error in analysis_errors:
        analysis["review_items"].append({
            "severity": "LOW", "message": "파일 분석 오류", "target": error.get("error", ""),
            "source_path": error.get("source_path", ""),
        })

    analysis = deep_mask(analysis)
    json_path = analysis_dir / "workspace_analysis.json"
    json_path.write_text(json.dumps(analysis, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    (analysis_dir / "architecture_overview.mmd").write_text(mermaid_overview, encoding="utf-8")
    summary_path = analysis_dir / "workspace_summary.md"
    resource_counts = Counter(row.get("resource_type") for row in resource_inventory)
    summary_lines = [
        "# Workspace Analysis Summary", "", "## Technology stack",
        f"- Frontend: {analysis.get('frontend', {}).get('framework')}",
        f"- Backend: {', '.join(analysis.get('stack', {}).get('backend', {}).get('frameworks', [])) or '확인필요'}",
        "", "## Counts",
    ]
    summary_lines.extend([f"- {key}: {value}" for key, value in summary.items()])
    auto_cfg = analysis.get("auto_configuration", {}) or {}
    detected_cfg = auto_cfg.get("detected_services", {}) or {}
    summary_lines.extend([
        "",
        "## Automatic configuration",
        f"- generated: {auto_cfg.get('generated', False)}",
        f"- loaded config files: {', '.join(auto_cfg.get('loaded_config_files', []) or [])}",
        f"- React URL: {(detected_cfg.get('react') or {}).get('base_url', '')}",
        f"- Spring Boot URL: {(detected_cfg.get('spring_boot') or {}).get('base_url', '')}",
        f"- Vert.x URL: {(detected_cfg.get('vertx') or {}).get('base_url', '')}",
        f"- Redis mode: {(detected_cfg.get('redis') or {}).get('mode', '')}",
        f"- Redis nodes: {', '.join((detected_cfg.get('redis') or {}).get('nodes', []) or [])}",
    ])
    summary_lines.extend(["", "## Detected resources"])
    summary_lines.extend([f"- {key}: {value}" for key, value in sorted(resource_counts.items())])
    summary_lines.extend(["", "## Generated analysis helpers", "- architecture_overview.mmd"])
    summary_path.write_text("\n".join(summary_lines) + "\n", encoding="utf-8")
    print(f"analysis written: {json_path}")


if __name__ == "__main__":
    main()
