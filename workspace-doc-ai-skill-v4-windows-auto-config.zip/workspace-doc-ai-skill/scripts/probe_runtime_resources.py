from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from utils.config_loader import deep_mask, enabled_value, ensure_dir, load_config, resolve_path
from utils.runtime_clients import (
    PROBE_FUNCTIONS,
    ProbeResult,
    discover_targets,
)

RESOURCE_TYPES = ("ORACLE", "REDIS", "ELASTICSEARCH", "KAFKA", "GRAFANA", "PROMETHEUS", "LOKI")


def _resource_cfg(runtime_cfg: Dict[str, Any], resource_type: str) -> Dict[str, Any]:
    value = runtime_cfg.get(resource_type.lower(), {}) or {}
    return dict(value) if isinstance(value, dict) else {}


def _apply_discovered_target(resource_type: str, cfg: Dict[str, Any], candidates: List[str]) -> Dict[str, Any]:
    if not candidates:
        return cfg
    row = dict(cfg)
    candidate = candidates[0]
    if resource_type == "ORACLE" and not row.get("dsn"):
        row["dsn"] = candidate
    elif resource_type == "KAFKA" and not row.get("bootstrap_servers"):
        row["bootstrap_servers"] = candidate
    elif not row.get("url"):
        row["url"] = candidate
    row["target_source"] = "WORKSPACE_AUTO_DISCOVERY"
    return row


def _configured_value_or_env(cfg: Dict[str, Any], value_key: str) -> bool:
    value = cfg.get(value_key)
    if isinstance(value, (list, tuple, set)):
        if any(str(x).strip() for x in value):
            return True
    elif value not in (None, ""):
        return True
    env_name = str(cfg.get(f"{value_key}_env") or "")
    return bool(env_name and os.environ.get(env_name))


def _has_target(resource_type: str, cfg: Dict[str, Any]) -> bool:
    if resource_type == "ORACLE":
        return _configured_value_or_env(cfg, "dsn")
    if resource_type == "KAFKA":
        return _configured_value_or_env(cfg, "bootstrap_servers")
    if resource_type == "REDIS":
        return any(_configured_value_or_env(cfg, key) for key in ("url", "host", "nodes", "sentinel_nodes"))
    return _configured_value_or_env(cfg, "url") or _configured_value_or_env(cfg, "host")


def run_probe(resource_type: str, cfg: Dict[str, Any], timeout: float, max_rows: int, verify_tls: bool) -> ProbeResult:
    fn = PROBE_FUNCTIONS[resource_type]
    if resource_type in {"ELASTICSEARCH", "GRAFANA", "PROMETHEUS", "LOKI"}:
        return fn(cfg, timeout, max_rows, verify_tls)  # type: ignore[misc]
    return fn(cfg, timeout, max_rows)  # type: ignore[misc]


def merge_runtime_details(analysis: Dict[str, Any], results: List[Dict[str, Any]]) -> None:
    resources = analysis.setdefault("resources", {})
    resources["runtime_probe"] = {"generated_at": datetime.now().isoformat(timespec="seconds"), "results": results}
    database = analysis.setdefault("database", {})
    for result in results:
        resource_type = result.get("resource_type")
        details = result.get("details") or {}
        if resource_type == "ORACLE" and result.get("status") == "UP":
            database["oracle_runtime"] = {
                "schema": details.get("current_schema", ""),
                "db_name": details.get("db_name", ""),
                "tables": details.get("tables", []),
                "columns": details.get("columns", []),
                "constraints": details.get("constraints", []),
                "sequences": details.get("sequences", []),
                "programs": details.get("programs", []),
            }
        elif resource_type == "ELASTICSEARCH" and result.get("status") == "UP":
            resources.setdefault("elasticsearch", {})["runtime_indices"] = details.get("indices", [])
            resources.setdefault("elasticsearch", {})["runtime_aliases"] = details.get("aliases", [])
        elif resource_type == "KAFKA" and result.get("status") == "UP":
            resources.setdefault("kafka", {})["runtime_topics"] = details.get("topics", [])
            resources.setdefault("kafka", {})["runtime_consumer_groups"] = details.get("consumer_groups", [])
        elif resource_type == "GRAFANA" and result.get("status") == "UP":
            resources.setdefault("grafana", {})["runtime_dashboards"] = details.get("dashboards", [])
            resources.setdefault("grafana", {})["runtime_datasources"] = details.get("datasources", [])
            resources.setdefault("grafana", {})["runtime_alert_rules"] = details.get("alert_rules", [])
        elif resource_type == "PROMETHEUS" and result.get("status") == "UP":
            resources.setdefault("prometheus", {})["runtime_targets"] = (((details.get("targets") or {}).get("data") or {}).get("activeTargets") or [])
            resources.setdefault("prometheus", {})["runtime_rules"] = details.get("rules", {})
        elif resource_type == "LOKI" and result.get("status") == "UP":
            resources.setdefault("loki", {})["runtime_labels"] = ((details.get("labels") or {}).get("data") or [])
            resources.setdefault("loki", {})["runtime_series"] = ((details.get("series") or {}).get("data") or [])
        elif resource_type == "REDIS" and result.get("status") == "UP":
            resources.setdefault("redis", {})["runtime_info"] = details


def main() -> None:
    parser = argparse.ArgumentParser(description="Run optional read-only runtime probes for Oracle, Redis, Elasticsearch, Kafka, Grafana, Prometheus and Loki.")
    parser.add_argument("--config", required=True)
    args = parser.parse_args()

    cfg = load_config(args.config)
    base_dir = Path(cfg["_base_dir"])
    output_root = resolve_path(base_dir, cfg.get("output", {}).get("dir", "output"))
    analysis_dir = ensure_dir(output_root / "analysis")
    analysis_path = analysis_dir / "workspace_analysis.json"
    if not analysis_path.exists():
        raise FileNotFoundError(f"analysis json not found: {analysis_path}. run analyze_workspace.py first.")
    analysis = json.loads(analysis_path.read_text(encoding="utf-8"))

    runtime_cfg = cfg.get("runtime_probe", {}) or {}
    global_enabled = enabled_value(runtime_cfg.get("enabled", False))
    allow_discovered = bool(runtime_cfg.get("allow_discovered_endpoints", False))
    timeout = float(runtime_cfg.get("timeout_seconds", 5))
    max_rows = int(runtime_cfg.get("max_metadata_rows", 5000))
    verify_tls = bool(runtime_cfg.get("verify_tls", True))
    results: List[Dict[str, Any]] = []

    for resource_type in RESOURCE_TYPES:
        resource_cfg = _resource_cfg(runtime_cfg, resource_type)
        candidates = discover_targets(analysis, resource_type)
        if allow_discovered:
            resource_cfg = _apply_discovered_target(resource_type, resource_cfg, candidates)
        has_target = _has_target(resource_type, resource_cfg) or bool(candidates and allow_discovered)
        resource_enabled = global_enabled and enabled_value(resource_cfg.get("enabled", "auto"), auto_condition=has_target)
        if not resource_enabled:
            reason = "runtime_probe.enabled=false" if not global_enabled else "resource disabled or connection target missing"
            results.append(ProbeResult(resource_type, candidates[0] if candidates else "", "SKIPPED", error=reason, source="STATIC_DISCOVERY" if candidates else "CONFIG").as_dict())
            continue
        result = run_probe(resource_type, resource_cfg, timeout, max_rows, verify_tls)
        result.source = resource_cfg.get("target_source", "CONFIG_OR_ENV")
        results.append(result.as_dict())

    output = deep_mask({
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "enabled": global_enabled,
        "allow_discovered_endpoints": allow_discovered,
        "results": results,
    })
    runtime_path = analysis_dir / "runtime_probe.json"
    runtime_path.write_text(json.dumps(output, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    merge_runtime_details(analysis, results)
    analysis_path.write_text(json.dumps(deep_mask(analysis), ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(f"runtime probe written: {runtime_path}")


if __name__ == "__main__":
    main()
