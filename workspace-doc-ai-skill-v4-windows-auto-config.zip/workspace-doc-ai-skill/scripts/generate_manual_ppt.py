from __future__ import annotations

import argparse
import json
import math
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from utils.config_loader import ensure_dir, load_config, resolve_path

try:
    from pptx import Presentation
    from pptx.dml.color import RGBColor
    from pptx.enum.text import MSO_AUTO_SIZE, PP_ALIGN
    from pptx.util import Inches, Pt
except Exception as exc:
    raise RuntimeError("python-pptx is required. install requirements.txt") from exc

try:
    from PIL import Image
except Exception:
    Image = None

BG = RGBColor(248, 250, 252)
DARK = RGBColor(15, 23, 42)
BLUE = RGBColor(30, 78, 121)
TEAL = RGBColor(15, 118, 110)
GRAY = RGBColor(71, 85, 105)
LIGHT = RGBColor(226, 232, 240)
RED = RGBColor(153, 27, 27)
GREEN = RGBColor(22, 101, 52)
ORANGE = RGBColor(154, 82, 0)

RESOURCE_ORDER = ("ORACLE", "REDIS", "ELASTICSEARCH", "KAFKA", "GRAFANA", "PROMETHEUS", "LOKI")
RESOURCE_CHECKS = {
    "ORACLE": ["연결/세션 상태", "Tablespace 및 객체 상태", "장기 실행 SQL·Lock", "배치/Procedure 오류"],
    "REDIS": ["PING 및 Replica/Cluster 상태", "Memory/Maxmemory", "Eviction/Hit ratio", "Key TTL·Hot key"],
    "ELASTICSEARCH": ["Cluster health", "Unassigned shard", "Index size/문서 수", "검색·색인 오류"],
    "KAFKA": ["Broker 연결", "Topic/Partition", "Consumer lag", "Producer/Consumer 오류"],
    "GRAFANA": ["Datasource 상태", "Dashboard 패널 오류", "Alert rule", "권한·Folder"],
    "PROMETHEUS": ["Target UP/DOWN", "Scrape error", "Rule evaluation", "TSDB/Remote write"],
    "LOKI": ["Readiness", "Promtail 수집", "Label cardinality", "Query/Ingester 오류"],
}


def set_background(slide: Any) -> None:
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = BG


def add_textbox(slide: Any, x: float, y: float, w: float, h: float, value: str, size: int = 18, bold: bool = False, color: RGBColor = DARK, align: Any = None) -> Any:
    shape = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    frame = shape.text_frame
    frame.clear()
    frame.word_wrap = True
    paragraph = frame.paragraphs[0]
    if align is not None:
        paragraph.alignment = align
    run = paragraph.add_run()
    run.text = str(value or "")
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    return shape


def add_bullets(slide: Any, x: float, y: float, w: float, h: float, items: Sequence[str], size: int = 14, color: RGBColor = GRAY) -> Any:
    shape = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    frame = shape.text_frame
    frame.clear()
    frame.word_wrap = True
    frame.auto_size = MSO_AUTO_SIZE.NONE
    values = list(items) or ["확인필요"]
    for index, item in enumerate(values):
        paragraph = frame.paragraphs[0] if index == 0 else frame.add_paragraph()
        paragraph.text = str(item)
        paragraph.font.size = Pt(size)
        paragraph.font.color.rgb = color
        paragraph.level = 0
        paragraph.space_after = Pt(4)
    return shape


def add_section_title(slide: Any, title: str, subtitle: str = "") -> None:
    add_textbox(slide, 0.55, 0.28, 12.1, 0.46, title, size=25, bold=True, color=DARK)
    if subtitle:
        add_textbox(slide, 0.58, 0.78, 11.9, 0.28, subtitle, size=11, color=GRAY)


def add_footer(slide: Any, text_value: str) -> None:
    add_textbox(slide, 0.55, 7.15, 12.1, 0.18, text_value, size=8, color=GRAY, align=PP_ALIGN.RIGHT)


def add_title_slide(prs: Presentation, title: str, subtitle: str, company: str = "") -> None:
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_background(slide)
    add_textbox(slide, 0.85, 1.45, 11.5, 0.95, title, size=34, bold=True, color=DARK)
    add_textbox(slide, 0.88, 2.52, 11.2, 0.45, subtitle, size=16, color=GRAY)
    if company:
        add_textbox(slide, 0.88, 3.15, 11.2, 0.35, company, size=14, bold=True, color=BLUE)
    add_textbox(slide, 0.88, 6.78, 11.0, 0.25, datetime.now().strftime("Generated %Y-%m-%d %H:%M:%S"), size=10, color=GRAY)


def add_summary_slide(prs: Presentation, analysis: Dict[str, Any], manual_type: str) -> None:
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_background(slide)
    add_section_title(slide, f"{manual_type} 개요", "Workspace 정적 분석과 화면 캡처 결과를 기반으로 자동 생성")
    summary = analysis.get("summary", {}) or {}
    left = [f"{key}: {value}" for key, value in list(summary.items())[:10]]
    resource_counts: Dict[str, int] = {}
    for row in analysis.get("resources", {}).get("inventory", []):
        resource_type = row.get("resource_type", "")
        resource_counts[resource_type] = resource_counts.get(resource_type, 0) + 1
    right = [f"{resource}: {resource_counts.get(resource, 0)}건 탐지" for resource in RESOURCE_ORDER]
    add_textbox(slide, 0.75, 1.25, 5.7, 0.3, "분석 요약", size=15, bold=True, color=BLUE)
    add_bullets(slide, 0.92, 1.62, 5.4, 4.8, left, size=13)
    add_textbox(slide, 6.75, 1.25, 5.7, 0.3, "운영 리소스", size=15, bold=True, color=TEAL)
    add_bullets(slide, 6.92, 1.62, 5.3, 4.8, right, size=13)
    add_footer(slide, f"Workspace: {analysis.get('workspace', {}).get('root', '')}")


def add_auto_configuration_slide(prs: Presentation, analysis: Dict[str, Any]) -> None:
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_background(slide)
    auto = analysis.get("auto_configuration", {}) or {}
    services = auto.get("detected_services", {}) or {}
    choices = auto.get("user_choices", {}) or {}
    add_section_title(slide, "Windows 자동 설정 결과", "RUN.bat가 Workspace 설정을 탐지하여 config.auto.yaml과 로컬 자격정보 오버레이를 생성")

    frontend_items = [
        f"자동 생성: {auto.get('generated', False)}",
        f"설정 로드: {len(auto.get('loaded_config_files', []) or [])}개 파일",
        f"React: {(services.get('react') or {}).get('base_url') or '미탐지'}",
        f"Spring Boot: {(services.get('spring_boot') or {}).get('base_url') or '미탐지'}",
        f"Vert.x: {(services.get('vertx') or {}).get('base_url') or '미탐지'}",
        f"화면 캡처: {choices.get('screenshots', False)}",
    ]
    redis = services.get("redis", {}) or {}
    data_items = [
        f"Oracle: {(services.get('oracle') or {}).get('dsn') or '미탐지'}",
        f"Redis mode: {redis.get('mode') or '미탐지'}",
        f"Redis nodes: {', '.join(redis.get('nodes', []) or []) or redis.get('url') or '미탐지'}",
        f"Elasticsearch: {(services.get('elasticsearch') or {}).get('url') or '미탐지'}",
        f"Kafka: {', '.join((services.get('kafka') or {}).get('bootstrap_servers', []) or []) or '미탐지'}",
        f"런타임 점검: {choices.get('runtime_probe', False)}",
    ]
    ops_items = [
        f"Grafana: {(services.get('grafana') or {}).get('url') or '미탐지'}",
        f"Prometheus: {(services.get('prometheus') or {}).get('url') or '미탐지'}",
        f"Loki: {(services.get('loki') or {}).get('url') or '미탐지'}",
        f"운영화면 캡처: {choices.get('resource_screenshots', False)}",
        "비밀번호·토큰: credentials.local.yaml 분리",
        "문서/JSON: 민감정보 자동 마스킹",
    ]

    add_textbox(slide, 0.62, 1.20, 3.92, 0.30, "Frontend / Backend", size=14, bold=True, color=BLUE)
    add_bullets(slide, 0.78, 1.58, 3.70, 4.82, frontend_items, size=10)
    add_textbox(slide, 4.72, 1.20, 3.92, 0.30, "Data / Messaging", size=14, bold=True, color=TEAL)
    add_bullets(slide, 4.88, 1.58, 3.70, 4.82, data_items, size=9)
    add_textbox(slide, 8.82, 1.20, 3.90, 0.30, "Observability / Security", size=14, bold=True, color=BLUE)
    add_bullets(slide, 8.98, 1.58, 3.58, 4.82, ops_items, size=10)
    add_footer(slide, "주소·노드는 소스/설정 근거로 자동 채움. 연결 불가 또는 동적 값은 확인필요로 유지.")


def add_index_slides(prs: Presentation, title: str, rows: Sequence[str], per_slide: int = 22) -> None:
    values = list(rows) or ["대상 화면 없음"]
    pages = math.ceil(len(values) / per_slide)
    for page_no in range(pages):
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        set_background(slide)
        suffix = f" ({page_no + 1}/{pages})" if pages > 1 else ""
        add_section_title(slide, title + suffix)
        add_bullets(slide, 0.85, 1.12, 11.55, 5.85, values[page_no * per_slide:(page_no + 1) * per_slide], size=13)


def add_picture_fit(slide: Any, image_path: str, x: float, y: float, w: float, h: float) -> None:
    path = Path(image_path)
    if not path.exists():
        return
    if Image is None:
        slide.shapes.add_picture(str(path), Inches(x), Inches(y), width=Inches(w), height=Inches(h))
        return
    try:
        with Image.open(path) as image:
            img_w, img_h = image.size
        box_ratio = w / h
        img_ratio = img_w / img_h
        if img_ratio >= box_ratio:
            out_w = w
            out_h = w / img_ratio
            out_x = x
            out_y = y + (h - out_h) / 2
        else:
            out_h = h
            out_w = h * img_ratio
            out_y = y
            out_x = x + (w - out_w) / 2
        slide.shapes.add_picture(str(path), Inches(out_x), Inches(out_y), width=Inches(out_w), height=Inches(out_h))
    except Exception:
        slide.shapes.add_picture(str(path), Inches(x), Inches(y), width=Inches(w), height=Inches(h))


def add_screen_slide(prs: Presentation, page: Dict[str, Any], page_no: int) -> None:
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_background(slide)
    title = page.get("title") or page.get("id") or "화면"
    add_textbox(slide, 0.45, 0.23, 10.9, 0.42, f"{page_no}. {title}", size=23, bold=True, color=DARK)
    tags = page.get("tags", []) or ["확인필요"]
    add_textbox(slide, 0.48, 0.72, 11.9, 0.25, "  ".join(f"#{tag}" for tag in tags[:12]), size=10, bold=True, color=BLUE)
    component = page.get("react_component") or "확인필요"
    roles = ", ".join(page.get("roles", []) or []) or "공통/확인필요"
    add_textbox(slide, 0.55, 1.05, 4.25, 0.62, page.get("content", "확인필요"), size=10, color=GRAY)
    add_textbox(slide, 0.55, 1.75, 4.2, 0.22, "사용/운영 절차", size=12, bold=True, color=TEAL)
    add_bullets(slide, 0.70, 2.02, 4.0, 1.18, [str(item) for item in (page.get("steps", []) or [])[:5]], size=9)
    api_items = []
    for row in (page.get("static_api_calls", []) or [])[:4]:
        api_items.append(f"{row.get('method')} {row.get('path')} → {row.get('backend_framework') or '미매핑'} {row.get('backend_component') or ''}.{row.get('backend_handler') or ''} [{row.get('status') or ''}]")
    for row in (page.get("network_requests", []) or []):
        if row.get("resource_type") in {"xhr", "fetch", "websocket", "eventsource"}:
            api_items.append(f"실행: {row.get('method')} {row.get('url')} · {row.get('status')}")
        if len(api_items) >= 5:
            break
    add_textbox(slide, 0.55, 3.32, 4.2, 0.22, "연결 API / 실행 네트워크", size=12, bold=True, color=TEAL)
    add_bullets(slide, 0.70, 3.58, 4.0, 1.18, api_items or ["API 호출 미탐지 또는 담당자 확인 필요"], size=8)
    add_textbox(slide, 0.55, 4.90, 4.2, 0.22, "확인 항목", size=12, bold=True, color=TEAL)
    checks = list(page.get("checks", []) or [])[:4]
    if page.get("requires_review"):
        checks.append("담당자 검토 필요")
    errors = page.get("page_errors", []) or []
    if errors:
        checks.append(f"브라우저 오류 {len(errors)}건 확인")
    add_bullets(slide, 0.70, 5.16, 4.0, 0.95, [str(item) for item in checks], size=8)
    source = page.get("source_path") or ""
    source_line = page.get("source_line") or ""
    add_textbox(slide, 0.55, 6.25, 4.2, 0.70, f"React: {component} · 권한: {roles}\nRoute/URL: {page.get('url') or page.get('path') or ''}\nSource: {source}:{source_line}", size=7, color=GRAY)

    image_path = page.get("screenshot_path")
    if image_path and Path(str(image_path)).exists():
        add_picture_fit(slide, str(image_path), 5.03, 1.08, 7.78, 5.92)
    else:
        error = page.get("screenshot_error") or page.get("screenshot_status") or "캡처 이미지 없음"
        add_textbox(slide, 5.30, 2.75, 7.1, 1.1, f"화면 캡처 확인 필요\n{error}", size=17, bold=True, color=RED, align=PP_ALIGN.CENTER)


def add_stack_slide(prs: Presentation, analysis: Dict[str, Any]) -> None:
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_background(slide)
    stack = analysis.get("stack", {}) or {}
    add_section_title(slide, "시스템 기술스택", "React Frontend와 Spring Boot · Vert.x Backend 자동 탐지 결과")
    frontend = stack.get("frontend", {}) or {}
    backend = stack.get("backend", {}) or {}
    frontend_items = [f"Framework: {frontend.get('framework') or '확인필요'}"]
    frontend_items += [f"{row.get('framework')} · {row.get('package')} {row.get('version')}" for row in frontend.get("frameworks", [])[:12]]
    backend_items = [f"Framework: {name}" for name in backend.get("frameworks", [])]
    backend_items += [f"{row.get('coordinate')} {row.get('version')}" for row in backend.get("dependencies", [])[:12]]
    module_items = [f"{row.get('module_name')} · {', '.join(row.get('roles', []))}" for row in stack.get("module_roles", [])[:18]]
    add_textbox(slide, 0.68, 1.18, 3.75, 0.28, "React Frontend", size=14, bold=True, color=BLUE)
    add_bullets(slide, 0.83, 1.55, 3.6, 4.85, frontend_items, size=10)
    add_textbox(slide, 4.67, 1.18, 3.75, 0.28, "Backend Framework", size=14, bold=True, color=TEAL)
    add_bullets(slide, 4.82, 1.55, 3.6, 4.85, backend_items or ["Backend 확인필요"], size=10)
    add_textbox(slide, 8.66, 1.18, 3.75, 0.28, "Module Role", size=14, bold=True, color=BLUE)
    add_bullets(slide, 8.81, 1.55, 3.55, 4.85, module_items or ["Module role 확인필요"], size=9)
    add_footer(slide, f"Spring+Vert.x 공존: {stack.get('coexistence', {}).get('spring_and_vertx', False)}")


def add_frontend_backend_flow_slide(prs: Presentation, analysis: Dict[str, Any]) -> None:
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_background(slide)
    add_section_title(slide, "React → Spring Boot / Vert.x 처리 흐름", "화면 Route, API 호출, Backend Endpoint 및 Vert.x EventBus 연결")
    links = analysis.get("frontend", {}).get("route_api_links", []) or []
    matched = [row for row in links if row.get("api_call_id")]
    flow_items = [f"{row.get('route_path')} · {row.get('screen_component')} → {row.get('api_method')} {row.get('api_path')} → {row.get('backend_framework') or '미매핑'}:{row.get('backend_component')}.{row.get('backend_handler')} [{row.get('status')}]" for row in matched[:18]]
    event_items = [f"{row.get('producer') or '?'} --{row.get('producer_operation')} {row.get('address')}--> {row.get('consumer') or '?'} [{row.get('status')}]" for row in analysis.get("vertx", {}).get("event_bus_links", [])[:14]]
    internal_items = [f"{row.get('caller_framework')}:{row.get('caller_component')} → {row.get('http_method')} {row.get('call_path')} → {row.get('backend_framework')}:{row.get('backend_component')} [{row.get('status')}]" for row in analysis.get("backend", {}).get("internal_http_mappings", [])[:8]]
    add_textbox(slide, 0.70, 1.18, 7.1, 0.28, "화면·API·Backend 매핑", size=14, bold=True, color=BLUE)
    add_bullets(slide, 0.86, 1.53, 6.9, 5.15, flow_items or ["React API와 Backend Endpoint 자동 매핑 결과 없음"], size=8)
    add_textbox(slide, 8.02, 1.18, 4.55, 0.28, "Backend 내부 연결", size=14, bold=True, color=TEAL)
    add_bullets(slide, 8.17, 1.53, 4.3, 1.85, internal_items or ["내부 HTTP 호출 미탐지"], size=8)
    add_textbox(slide, 8.02, 3.60, 4.55, 0.28, "Vert.x EventBus", size=14, bold=True, color=TEAL)
    add_bullets(slide, 8.17, 3.95, 4.3, 2.45, event_items or ["EventBus 연결 미탐지"], size=8)
    add_footer(slide, "MATCHED/AMBIGUOUS/UNMATCHED 결과는 인터페이스명세서.xlsx에서 근거 파일과 함께 확인")


def add_spring_boot_slide(prs: Presentation, analysis: Dict[str, Any]) -> None:
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_background(slide)
    add_section_title(slide, "Spring Boot 운영 구조", "Application · Annotation/Functional API · Security · Scheduler/Listener")
    endpoints = [row for row in analysis.get("backend", {}).get("endpoints", []) if row.get("framework") == "SPRING_BOOT"]
    endpoint_items = [f"{row.get('http_method')} {row.get('path')} · {row.get('component')}.{row.get('handler')} ({row.get('route_style')})" for row in endpoints[:18]]
    security_items = [f"{row.get('path')} · {row.get('rule')} · {', '.join(row.get('roles', []) or [])}" for row in analysis.get("spring", {}).get("security_rules", [])[:12]]
    jobs = [f"Scheduled · {row.get('class')}.{row.get('method')} · {row.get('schedule')}" for row in analysis.get("spring", {}).get("scheduled_jobs", [])[:8]]
    jobs += [f"{row.get('listener_type')} · {row.get('class')}.{row.get('method')} · {row.get('detail')}" for row in analysis.get("spring", {}).get("event_listeners", [])[:8]]
    add_textbox(slide, 0.70, 1.18, 5.95, 0.28, f"HTTP API ({len(endpoints)}건)", size=14, bold=True, color=BLUE)
    add_bullets(slide, 0.86, 1.53, 5.75, 4.95, endpoint_items or ["Spring Endpoint 확인필요"], size=8)
    add_textbox(slide, 6.82, 1.18, 5.7, 0.28, "Security Rule", size=14, bold=True, color=TEAL)
    add_bullets(slide, 6.98, 1.53, 5.45, 2.10, security_items or ["Security rule 미탐지"], size=8)
    add_textbox(slide, 6.82, 3.90, 5.7, 0.28, "Scheduler / Listener", size=14, bold=True, color=TEAL)
    add_bullets(slide, 6.98, 4.25, 5.45, 2.15, jobs or ["Scheduler/Listener 미탐지"], size=8)


def add_vertx_slide(prs: Presentation, analysis: Dict[str, Any]) -> None:
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_background(slide)
    add_section_title(slide, "Vert.x 운영 구조", "Verticle 배포 · HTTP Server/Router · Handler · 비동기 Client")
    verticle_items = [f"{row.get('class')} · {row.get('base_type')} · worker={row.get('worker')}" for row in analysis.get("vertx", {}).get("verticles", [])[:12]]
    deploy_items = [f"{row.get('deployer')} → {row.get('verticle')} · {row.get('options')}" for row in analysis.get("vertx", {}).get("deployments", [])[:10]]
    server_items = [f"{row.get('source_component')} · {row.get('host')}:{row.get('port')} · handler={row.get('request_handler')}" for row in analysis.get("vertx", {}).get("http_servers", [])[:8]]
    route_items = [f"{row.get('http_method')} {row.get('mounted_path') or row.get('path')} · {row.get('source_component')}.{row.get('handler')}" for row in analysis.get("vertx", {}).get("routes", [])[:18]]
    add_textbox(slide, 0.70, 1.18, 4.0, 0.28, "Verticle / Deployment", size=14, bold=True, color=BLUE)
    add_bullets(slide, 0.86, 1.53, 3.85, 2.35, verticle_items + deploy_items or ["Verticle 미탐지"], size=8)
    add_textbox(slide, 0.70, 4.10, 4.0, 0.28, "HTTP Server", size=14, bold=True, color=BLUE)
    add_bullets(slide, 0.86, 4.45, 3.85, 1.75, server_items or ["HTTP Server 설정 확인필요"], size=8)
    add_textbox(slide, 4.98, 1.18, 7.55, 0.28, "Router / Handler", size=14, bold=True, color=TEAL)
    add_bullets(slide, 5.14, 1.53, 7.25, 4.95, route_items or ["Vert.x Route 미탐지"], size=8)


def add_eventbus_slide(prs: Presentation, analysis: Dict[str, Any]) -> None:
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_background(slide)
    add_section_title(slide, "Vert.x EventBus 명세", "send · publish · request · consumer 및 Service Proxy 연결")
    raw_items = [f"{row.get('direction')} · {row.get('operation')} · {row.get('address')} · {row.get('source_component')}" for row in analysis.get("vertx", {}).get("event_bus", [])[:20]]
    link_items = [f"{row.get('producer') or '?'} → {row.get('address')} → {row.get('consumer') or '?'} · {row.get('status')} / {row.get('confidence')}" for row in analysis.get("vertx", {}).get("event_bus_links", [])[:20]]
    add_textbox(slide, 0.70, 1.18, 5.95, 0.28, "생산/소비 선언", size=14, bold=True, color=BLUE)
    add_bullets(slide, 0.86, 1.53, 5.7, 4.95, raw_items or ["EventBus 선언 미탐지"], size=8)
    add_textbox(slide, 6.82, 1.18, 5.7, 0.28, "Producer → Consumer 매핑", size=14, bold=True, color=TEAL)
    add_bullets(slide, 6.98, 1.53, 5.45, 4.95, link_items or ["EventBus 연결 미탐지"], size=8)



def add_runtime_status_slide(prs: Presentation, analysis: Dict[str, Any]) -> None:
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_background(slide)
    add_section_title(slide, "운영 리소스 런타임 점검", "config.yaml에서 runtime_probe.enabled=true인 경우에만 읽기 전용으로 확인")
    results = (((analysis.get("resources") or {}).get("runtime_probe") or {}).get("results") or [])
    by_type = {row.get("resource_type"): row for row in results}
    for index, resource in enumerate(RESOURCE_ORDER):
        row = index // 4
        col = index % 4
        x = 0.65 + col * 3.12
        y = 1.35 + row * 2.55
        width = 2.85
        result = by_type.get(resource, {})
        status = result.get("status", "미실행")
        status_color = GREEN if status == "UP" else RED if status == "DOWN" else ORANGE
        add_textbox(slide, x, y, width, 0.3, resource, size=14, bold=True, color=BLUE)
        add_textbox(slide, x, y + 0.42, width, 0.35, status, size=17, bold=True, color=status_color)
        add_textbox(slide, x, y + 0.84, width, 0.95, f"Target: {result.get('target','')}\nLatency: {result.get('latency_ms','')} ms\n{result.get('error','')}", size=8, color=GRAY)
    add_footer(slide, "Secrets are masked. Runtime checks do not write or mutate target resources.")


def resource_interface_items(analysis: Dict[str, Any], resource: str) -> List[str]:
    items = []
    for row in analysis.get("resources", {}).get("interfaces", []):
        if row.get("resource_type") != resource:
            continue
        items.append(f"{row.get('direction')} · {row.get('source_component')} · {row.get('operation')} → {row.get('target')}")
    return items


def add_resource_slides(prs: Presentation, analysis: Dict[str, Any]) -> None:
    inventory = analysis.get("resources", {}).get("inventory", [])
    for resource in RESOURCE_ORDER:
        detected = [row for row in inventory if row.get("resource_type") == resource]
        interfaces = resource_interface_items(analysis, resource)
        if not detected and not interfaces:
            continue
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        set_background(slide)
        add_section_title(slide, f"{resource} 분석", f"자동 탐지 {len(detected)}건 · 코드/설정 인터페이스 {len(interfaces)}건")
        add_textbox(slide, 0.72, 1.20, 5.9, 0.28, "탐지된 연결/자산", size=14, bold=True, color=BLUE)
        detection_items = [f"{row.get('role')} · {row.get('name')} · {row.get('target')}" for row in detected[:18]]
        add_bullets(slide, 0.88, 1.56, 5.7, 4.65, detection_items or ["탐지 근거 확인필요"], size=10)
        add_textbox(slide, 6.75, 1.20, 5.8, 0.28, "운영 점검 항목", size=14, bold=True, color=TEAL)
        add_bullets(slide, 6.92, 1.56, 5.5, 1.65, RESOURCE_CHECKS.get(resource, []), size=11)
        add_textbox(slide, 6.75, 3.48, 5.8, 0.28, "인터페이스 흐름", size=14, bold=True, color=TEAL)
        add_bullets(slide, 6.92, 3.84, 5.5, 2.55, interfaces[:12] or ["코드 인터페이스 확인필요"], size=9)
        add_footer(slide, "상세 근거는 인터페이스명세서.xlsx 및 아키텍쳐정의서.xlsx 참조")


def add_observability_slides(prs: Presentation, analysis: Dict[str, Any]) -> None:
    resources = analysis.get("resources", {})
    grafana = resources.get("grafana", {}) or {}
    prometheus = resources.get("prometheus", {}) or {}
    loki = resources.get("loki", {}) or {}
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_background(slide)
    add_section_title(slide, "관측 스택 구성", "Grafana · Prometheus · Loki 정적 구성 및 Runtime API 결과")
    grafana_items = [f"Dashboard: {row.get('title')} ({row.get('uid')})" for row in grafana.get("dashboards", [])[:8]]
    grafana_items += [f"Datasource: {row.get('name')} / {row.get('type')}" for row in grafana.get("datasources", [])[:6]]
    prometheus_items = [f"Scrape: {row.get('job_name')} → {row.get('target')} {row.get('path')}" for row in prometheus.get("scrape_configs", [])[:8]]
    prometheus_items += [f"Rule: {row.get('name')} ({row.get('type')})" for row in prometheus.get("rules", [])[:6]]
    loki_items = [f"Promtail Job: {row.get('job_name')} / stages={row.get('pipeline_stage_count')}" for row in loki.get("jobs", [])[:8]]
    loki_items += [f"LogQL: {row.get('query')}" for row in loki.get("grafana_queries", [])[:4]]
    add_textbox(slide, 0.72, 1.18, 3.85, 0.28, "Grafana", size=14, bold=True, color=BLUE)
    add_bullets(slide, 0.85, 1.53, 3.75, 4.95, grafana_items or ["Dashboard/Datasource 확인필요"], size=9)
    add_textbox(slide, 4.75, 1.18, 3.85, 0.28, "Prometheus", size=14, bold=True, color=BLUE)
    add_bullets(slide, 4.88, 1.53, 3.75, 4.95, prometheus_items or ["Scrape/Rule 확인필요"], size=9)
    add_textbox(slide, 8.78, 1.18, 3.85, 0.28, "Loki", size=14, bold=True, color=BLUE)
    add_bullets(slide, 8.91, 1.53, 3.75, 4.95, loki_items or ["Promtail/LogQL 확인필요"], size=9)


def add_api_db_slides(prs: Presentation, analysis: Dict[str, Any]) -> None:
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_background(slide)
    add_section_title(slide, "통합 API / Oracle 운영 점검", "Spring Boot와 Vert.x Endpoint 및 Oracle 접근 사용처")
    endpoints = analysis.get("backend", {}).get("endpoints", [])[:22]
    endpoint_items = [f"{row.get('framework')} · {row.get('http_method')} {row.get('path')} · {row.get('component')}.{row.get('handler')}" for row in endpoints]
    oracle = analysis.get("resources", {}).get("oracle", {}) or {}
    sql_items = [f"{row.get('operation')} {row.get('schema')}.{row.get('table_name')} · {row.get('statement_id') or row.get('source_path')}" for row in oracle.get("sql_references", [])[:14]]
    sql_items += [f"VERTX SQL · {row.get('source_component')} · {row.get('operation')} {row.get('target')}" for row in analysis.get("vertx", {}).get("sql_clients", [])[:8]]
    add_textbox(slide, 0.72, 1.17, 6.0, 0.28, "Spring Boot / Vert.x API", size=14, bold=True, color=BLUE)
    add_bullets(slide, 0.88, 1.53, 5.8, 4.95, endpoint_items or ["Backend API 확인필요"], size=8)
    add_textbox(slide, 6.88, 1.17, 5.65, 0.28, "Oracle SQL 사용처", size=14, bold=True, color=TEAL)
    add_bullets(slide, 7.04, 1.53, 5.35, 4.95, sql_items or ["SQL 사용처 확인필요"], size=8)


def load_json_pages(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    try:
        return json.loads(path.read_text(encoding="utf-8")).get("pages", [])
    except Exception:
        return []


def load_manual_pages(base_dir: Path, cfg: Dict[str, Any], output_root: Path) -> List[Dict[str, Any]]:
    pages: List[Dict[str, Any]] = []
    screenshot_cfg = cfg.get("screenshots", {}) or {}
    screenshot_dir = resolve_path(base_dir, screenshot_cfg.get("output_dir", str(output_root / "screenshots")))
    pages.extend(load_json_pages(screenshot_dir / "manual_pages.generated.json"))
    if not pages:
        try:
            import yaml
            page_file = resolve_path(base_dir, screenshot_cfg.get("manual_pages_file", "examples/manual_pages.example.yaml"))
            if page_file.exists():
                pages.extend((yaml.safe_load(page_file.read_text(encoding="utf-8")) or {}).get("pages", []))
        except Exception:
            pass
    resource_cfg = cfg.get("resource_screenshots", {}) or {}
    resource_dir = resolve_path(base_dir, resource_cfg.get("output_dir", str(output_root / "resource-screenshots")))
    pages.extend(load_json_pages(resource_dir / "resource_pages.generated.json"))
    return pages


def build_presentation(
    title: str, subtitle: str, pages: List[Dict[str, Any]], analysis: Dict[str, Any],
    manual_type: str, include_operator: bool, company: str,
) -> Presentation:
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    add_title_slide(prs, title, subtitle, company)
    add_summary_slide(prs, analysis, manual_type)
    if include_operator:
        add_auto_configuration_slide(prs, analysis)
    add_stack_slide(prs, analysis)
    add_frontend_backend_flow_slide(prs, analysis)
    if include_operator:
        add_spring_boot_slide(prs, analysis)
        add_vertx_slide(prs, analysis)
        add_eventbus_slide(prs, analysis)
        add_runtime_status_slide(prs, analysis)
        add_resource_slides(prs, analysis)
        add_observability_slides(prs, analysis)
        add_api_db_slides(prs, analysis)
    add_index_slides(prs, "화면 목록", [f"{index + 1}. {page.get('title') or page.get('id')} · {', '.join(page.get('tags', []))}" for index, page in enumerate(pages)])
    for index, page in enumerate(pages, start=1):
        add_screen_slide(prs, page, index)
    return prs


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate user/operator manual PowerPoint files.")
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    cfg = load_config(args.config)
    base_dir = Path(cfg["_base_dir"])
    output_root = resolve_path(base_dir, cfg.get("output", {}).get("dir", "output"))
    analysis_path = output_root / "analysis" / "workspace_analysis.json"
    if not analysis_path.exists():
        raise FileNotFoundError(f"analysis json not found: {analysis_path}. run analyze_workspace.py first.")
    analysis = json.loads(analysis_path.read_text(encoding="utf-8"))
    pages = load_manual_pages(base_dir, cfg, output_root)
    ppt_dir = ensure_dir(resolve_path(base_dir, cfg.get("ppt", {}).get("output_dir", str(output_root / "ppt"))))
    prefix = cfg.get("ppt", {}).get("title_prefix") or analysis.get("workspace", {}).get("name", "SYSTEM")
    company = cfg.get("ppt", {}).get("company_name", "")

    user_pages = [page for page in pages if page.get("audience", "user") in {"user", "all"}]
    operator_pages = [page for page in pages if page.get("audience", "user") in {"operator", "all"}]

    user_presentation = build_presentation(
        f"{prefix} 사용자메뉴얼", "React 화면 캡처 · 태그 · 업무 절차 · API 연계 기반 사용자 매뉴얼", user_pages, analysis, "사용자메뉴얼", False, company,
    )
    user_path = ppt_dir / "사용자메뉴얼.pptx"
    user_presentation.save(user_path)
    print(f"ppt written: {user_path}")

    operator_presentation = build_presentation(
        f"{prefix} 운영자메뉴얼", "React · Spring Boot · Vert.x 및 Oracle · Redis · Elasticsearch · Kafka · Grafana · Prometheus · Loki 운영 절차",
        operator_pages, analysis, "운영자메뉴얼", True, company,
    )
    operator_path = ppt_dir / "운영자메뉴얼.pptx"
    operator_presentation.save(operator_path)
    print(f"ppt written: {operator_path}")


if __name__ == "__main__":
    main()
