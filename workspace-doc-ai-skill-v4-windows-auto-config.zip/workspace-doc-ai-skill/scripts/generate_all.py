from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def run_step(script: Path, config: str, optional: bool = False) -> bool:
    command = [sys.executable, str(script), "--config", config]
    print("\n$ " + " ".join(command))
    completed = subprocess.run(command, check=False)
    if completed.returncode != 0:
        if optional:
            print(f"optional step warning: {script.name} returned {completed.returncode}")
            return False
        raise subprocess.CalledProcessError(completed.returncode, command)
    return True


def resolve_config(args: argparse.Namespace, scripts: Path) -> Path:
    if args.config:
        path = Path(args.config).expanduser().resolve()
        if not path.exists():
            raise FileNotFoundError(f"config file not found: {path}")
        return path

    package_root = scripts.parent
    generated = package_root / "generated" / "config.auto.yaml"
    if generated.exists() and not args.reconfigure:
        return generated.resolve()

    from auto_configure import configure

    config_path, _, _ = configure(
        workspace=args.workspace or "",
        non_interactive=bool(args.non_interactive),
        static_only=bool(args.static_only),
    )
    return config_path.resolve()


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate all workspace documentation outputs.")
    parser.add_argument("--config", default="", help="Config path. If omitted, auto configuration is used.")
    parser.add_argument("--workspace", default="", help="Workspace path used by automatic configuration.")
    parser.add_argument("--reconfigure", action="store_true", help="Run automatic discovery again even if generated config exists.")
    parser.add_argument("--non-interactive", action="store_true")
    parser.add_argument("--static-only", action="store_true")
    parser.add_argument("--analysis-only", action="store_true")
    parser.add_argument("--skip-runtime-probe", action="store_true")
    parser.add_argument("--skip-screenshots", action="store_true")
    args = parser.parse_args()

    scripts = Path(__file__).resolve().parent
    config_path = resolve_config(args, scripts)
    config = str(config_path)
    print(f"\nusing config: {config}")

    run_step(scripts / "analyze_workspace.py", config)
    if args.analysis_only:
        print("\nanalysis completed")
        return
    if not args.skip_runtime_probe and not args.static_only:
        run_step(scripts / "probe_runtime_resources.py", config, optional=True)
    if not args.skip_screenshots and not args.static_only:
        run_step(scripts / "capture_manual_screens.py", config, optional=True)
        run_step(scripts / "capture_resource_screens.py", config, optional=True)
    run_step(scripts / "generate_excel_documents.py", config)
    run_step(scripts / "generate_manual_ppt.py", config)
    run_step(scripts / "validate_outputs.py", config)
    print("\nall documents generated and validated")


if __name__ == "__main__":
    main()
