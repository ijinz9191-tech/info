from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import traceback
from pathlib import Path
from typing import Any, Dict

SCRIPT_DIR = Path(__file__).resolve().parent
PACKAGE_ROOT = SCRIPT_DIR.parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from auto_configure import configure


def run(command: list[str], optional: bool = False) -> int:
    print("\n$ " + " ".join(f'"{x}"' if " " in x else x for x in command))
    completed = subprocess.run(command, cwd=str(PACKAGE_ROOT), check=False)
    if completed.returncode != 0 and not optional:
        raise subprocess.CalledProcessError(completed.returncode, command)
    if completed.returncode != 0:
        print(f"선택 단계 경고: return code={completed.returncode}")
    return completed.returncode


def ensure_playwright_browser(config: Dict[str, Any], skip: bool = False) -> None:
    if skip:
        return
    need_browser = bool((config.get("screenshots") or {}).get("enabled")) or bool((config.get("resource_screenshots") or {}).get("enabled"))
    if not need_browser:
        return
    print("\n화면 캡처용 Chromium을 확인합니다.")
    run([sys.executable, "-m", "playwright", "install", "chromium"], optional=False)


def open_output(path: Path) -> None:
    if not path.exists():
        return
    try:
        if os.name == "nt":
            os.startfile(str(path))  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
    except Exception:
        pass


def main() -> None:
    parser = argparse.ArgumentParser(description="One-click Windows launcher: auto configure, analyze, capture, and generate documents.")
    parser.add_argument("--workspace", default="")
    parser.add_argument("--non-interactive", action="store_true")
    parser.add_argument("--static-only", action="store_true")
    parser.add_argument("--runtime", action=argparse.BooleanOptionalAction, default=None)
    parser.add_argument("--screenshots", action=argparse.BooleanOptionalAction, default=None)
    parser.add_argument("--resource-screenshots", action=argparse.BooleanOptionalAction, default=None)
    parser.add_argument("--import-k8s-secrets", action=argparse.BooleanOptionalAction, default=None)
    parser.add_argument("--configure-only", action="store_true")
    parser.add_argument("--skip-browser-install", action="store_true")
    parser.add_argument("--no-open-output", action="store_true")
    parser.add_argument("--analysis-only", action="store_true")
    args = parser.parse_args()

    config_path, config, _ = configure(
        workspace=args.workspace,
        non_interactive=args.non_interactive,
        static_only=args.static_only,
        force_runtime=args.runtime,
        force_screenshots=args.screenshots,
        force_resource_screenshots=args.resource_screenshots,
        import_k8s_secrets=args.import_k8s_secrets,
    )
    if args.configure_only:
        print("\n자동 Config 생성만 완료했습니다.")
        return

    ensure_playwright_browser(config, args.skip_browser_install)
    command = [sys.executable, str(SCRIPT_DIR / "generate_all.py"), "--config", str(config_path)]
    if args.analysis_only:
        command.append("--analysis-only")
    if args.static_only:
        command.extend(["--skip-runtime-probe", "--skip-screenshots"])
    run(command)

    output_dir = Path(str((config.get("output") or {}).get("dir", "output"))).expanduser().resolve()
    print("\n============================================================")
    print("문서 생성 완료")
    print(f"출력 폴더: {output_dir}")
    print("  PPT  : 사용자메뉴얼.pptx, 운영자메뉴얼.pptx")
    print("  Excel: 인터페이스명세서, 프로그램목록, WorkBook, 테이블정의서, 아키텍쳐정의서")
    print("============================================================")
    if not args.no_open_output:
        open_output(output_dir)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n사용자가 중단했습니다.")
        raise SystemExit(130)
    except Exception as exc:
        print("\n실행 중 오류가 발생했습니다.")
        print(str(exc))
        traceback.print_exc()
        raise SystemExit(1)
