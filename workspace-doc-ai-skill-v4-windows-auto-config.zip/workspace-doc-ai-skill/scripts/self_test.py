from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import yaml


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a v4 React + Spring Boot + Vert.x + Redis Cluster documentation smoke test.")
    parser.add_argument("--work-dir", help="Directory for generated test output. A temporary directory is used by default.")
    parser.add_argument("--keep", action="store_true", help="Keep a temporary work directory after the test.")
    args = parser.parse_args()

    package_root = Path(__file__).resolve().parents[1]
    fixture = package_root / "tests" / "fixtures" / "react-spring-vertx"
    if not fixture.exists():
        raise FileNotFoundError(f"fixture not found: {fixture}")

    # v4 automatic configuration discovery checks.
    if str(package_root / "scripts") not in sys.path:
        sys.path.insert(0, str(package_root / "scripts"))
    from utils.auto_config_discovery import discover_workspace

    discovery = discover_workspace(fixture)
    discovery_failures = []
    if not discovery.services.get("react", {}).get("detected"):
        discovery_failures.append("React auto discovery failed")
    if not discovery.services.get("spring_boot", {}).get("detected"):
        discovery_failures.append("Spring Boot auto discovery failed")
    if not discovery.services.get("vertx", {}).get("detected"):
        discovery_failures.append("Vert.x auto discovery failed")
    redis_service = discovery.services.get("redis", {})
    if redis_service.get("mode") != "cluster" or len(redis_service.get("nodes", [])) < 3:
        discovery_failures.append(f"Redis Cluster auto discovery failed: {redis_service}")
    if len(discovery.services.get("kafka", {}).get("bootstrap_servers", [])) < 2:
        discovery_failures.append("Kafka bootstrap server list auto discovery failed")
    if not discovery.services.get("oracle", {}).get("dsn"):
        discovery_failures.append("Oracle DSN auto discovery failed")
    if discovery_failures:
        print("auto discovery checks failed:")
        for failure in discovery_failures:
            print("- " + failure)
        raise SystemExit(1)

    created_temp = not bool(args.work_dir)
    base = Path(args.work_dir).expanduser().resolve() if args.work_dir else Path(tempfile.mkdtemp(prefix="workspace-doc-v4-self-test-"))
    output = base / "output"
    config_path = base / "self-test-config.yaml"
    base.mkdir(parents=True, exist_ok=True)

    config = {
        "workspace": {"root": str(fixture), "name": "SELF_TEST_REACT_SPRING_VERTX"},
        "output": {"dir": str(output), "overwrite": True},
        "analysis": {
            "max_file_mb": 10,
            "max_binary_file_mb": 300,
            "inspect_jars": True,
            "max_jar_entries": 200000,
            "inspect_dependency_cache": False,
            "ignore_dirs": [".git", ".idea", ".vscode", "node_modules", "dist", "build", "target", "out", ".gradle", "coverage", ".next"],
            "ignore_file_globs": ["*.class", "*.png", "*.jpg", "*.jpeg", "*.gif", "*.ico", "*.pdf", "*.zip", "*.tar", "*.gz"],
            "common_path_keywords": ["common", "core", "shared", "base", "framework", "util", "utils", "config", "security"],
            "internal_package_roots": ["com.acme"],
        },
        "screenshots": {"enabled": False, "base_url": "http://localhost:3000", "manual_pages_file": "", "output_dir": str(output / "screenshots")},
        "resource_screenshots": {"enabled": False, "output_dir": str(output / "resource-screenshots")},
        "runtime_probe": {"enabled": False},
        "detected_services": discovery.services,
        "auto_config": {
            "generated": True,
            "generated_at_source": "self-test automatic discovery",
            "discovery_report": str(base / "discovery-report.json"),
            "user_choices": {"runtime_probe": False, "screenshots": False, "resource_screenshots": False},
        },
        "excel": {"output_dir": str(output / "excel"), "author": "Self Test"},
        "ppt": {"output_dir": str(output / "ppt"), "title_prefix": "SELF TEST", "company_name": "", "author": "Self Test"},
    }
    config_path.write_text(yaml.safe_dump(config, allow_unicode=True, sort_keys=False), encoding="utf-8")

    command = [sys.executable, str(package_root / "scripts" / "generate_all.py"), "--config", str(config_path)]
    print("$ " + " ".join(command))
    completed = subprocess.run(command, check=False)
    report_path = output / "analysis" / "validation_report.json"
    report = json.loads(report_path.read_text(encoding="utf-8")) if report_path.exists() else {}

    if completed.returncode != 0 or report.get("status") != "PASS":
        print(json.dumps(report, ensure_ascii=False, indent=2))
        raise SystemExit(completed.returncode or 1)

    analysis = json.loads((output / "analysis" / "workspace_analysis.json").read_text(encoding="utf-8"))
    if analysis.get("schema_version") != "4.0" or not (analysis.get("auto_configuration") or {}).get("generated"):
        raise SystemExit("v4 auto_configuration was not written to analysis output")

    from openpyxl import load_workbook
    from pptx import Presentation

    for workbook_name in ("WorkBook.xlsx", "아키텍쳐정의서.xlsx"):
        workbook = load_workbook(output / "excel" / workbook_name, read_only=True, data_only=False)
        if "자동설정" not in workbook.sheetnames:
            raise SystemExit(f"automatic configuration sheet missing: {workbook_name}")
        values = [
            str(cell.value or "")
            for row in workbook["자동설정"].iter_rows(min_row=1, max_row=min(workbook["자동설정"].max_row, 120))
            for cell in row
        ]
        workbook.close()
        if not any("cluster" in value.lower() for value in values) or not any("redis-1.example:6379" in value for value in values):
            raise SystemExit(f"Redis Cluster automatic configuration evidence missing: {workbook_name}")

    operator_ppt = Presentation(output / "ppt" / "운영자메뉴얼.pptx")
    slide_texts = ["\n".join(shape.text for shape in slide.shapes if hasattr(shape, "text_frame")) for slide in operator_ppt.slides]
    if not any("Windows 자동 설정 결과" in value and "Redis mode: cluster" in value for value in slide_texts):
        raise SystemExit("operator manual automatic configuration slide missing")

    summary = analysis.get("summary", {})
    expected_minimum = {
        "frontend_route_count": 2,
        "react_api_call_count": 2,
        "frontend_backend_match_count": 2,
        "spring_endpoint_count": 2,
        "vertx_route_count": 2,
        "vertx_verticle_count": 2,
        "event_bus_link_count": 2,
    }
    failures = [f"{key}: expected >= {minimum}, actual={summary.get(key, 0)}" for key, minimum in expected_minimum.items() if int(summary.get(key, 0) or 0) < minimum]
    if failures:
        print("self-test semantic checks failed:")
        for failure in failures:
            print("- " + failure)
        raise SystemExit(1)

    print("self-test PASS")
    print(json.dumps({
        **{key: summary.get(key) for key in expected_minimum},
        "auto_config_redis_mode": redis_service.get("mode"),
        "auto_config_redis_nodes": len(redis_service.get("nodes", [])),
        "auto_config_kafka_nodes": len(discovery.services.get("kafka", {}).get("bootstrap_servers", [])),
        "auto_config_excel_sheets": 2,
        "operator_manual_auto_config_slide": True,
    }, ensure_ascii=False, indent=2))
    print(f"outputs: {output}")

    if created_temp and not args.keep:
        shutil.rmtree(base, ignore_errors=True)
    elif created_temp:
        print(f"kept work directory: {base}")


if __name__ == "__main__":
    main()
