from __future__ import annotations

import argparse
import getpass
import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Tuple

import yaml

SCRIPT_DIR = Path(__file__).resolve().parent
PACKAGE_ROOT = SCRIPT_DIR.parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from utils.auto_config_discovery import DiscoveryResult, build_generated_config, discover_workspace
from utils.config_loader import deep_mask


def _bool_text(value: bool) -> str:
    return "Y" if value else "N"


def _ask_bool(prompt: str, default: bool, non_interactive: bool = False) -> bool:
    if non_interactive:
        return default
    suffix = "[Y/n]" if default else "[y/N]"
    while True:
        value = input(f"{prompt} {suffix}: ").strip().lower()
        if not value:
            return default
        if value in {"y", "yes", "예", "네", "1", "true"}:
            return True
        if value in {"n", "no", "아니오", "아니요", "0", "false"}:
            return False
        print("Y 또는 N을 입력하세요.")


def _ask_text(prompt: str, default: str = "", secret: bool = False, non_interactive: bool = False) -> str:
    if non_interactive:
        return default
    label = f"{prompt}" + (f" [{default}]" if default and not secret else "") + ": "
    value = getpass.getpass(label) if secret else input(label)
    return value.strip() or default


def _is_workspace(path: Path) -> bool:
    markers = ("settings.gradle", "settings.gradle.kts", "pom.xml", "package.json", ".git")
    return path.is_dir() and any((path / marker).exists() for marker in markers)


def _last_workspace() -> Optional[Path]:
    last = PACKAGE_ROOT / "generated" / "last-run.json"
    if not last.exists():
        return None
    try:
        value = Path(json.loads(last.read_text(encoding="utf-8")).get("workspace", "")).expanduser()
        return value.resolve() if value.exists() else None
    except Exception:
        return None


def _folder_dialog(initial: Optional[Path] = None) -> str:
    try:
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        selected = filedialog.askdirectory(
            title="분석할 React + Spring Boot + Vert.x Workspace를 선택하세요",
            initialdir=str(initial or Path.home()),
            mustexist=True,
        )
        root.destroy()
        return selected or ""
    except Exception:
        return ""


def select_workspace(explicit: str = "", non_interactive: bool = False) -> Path:
    if explicit:
        path = Path(explicit).expanduser().resolve()
        if not path.is_dir():
            raise FileNotFoundError(f"Workspace 폴더가 없습니다: {path}")
        return path

    last = _last_workspace()
    for candidate in (last, PACKAGE_ROOT.parent, Path.cwd()):
        if candidate and _is_workspace(candidate):
            if non_interactive or _ask_bool(f"Workspace로 사용할까요? {candidate}", True, False):
                return candidate.resolve()

    if non_interactive:
        raise ValueError("--non-interactive 사용 시 --workspace가 필요합니다.")
    selected = _folder_dialog(last)
    if selected:
        return Path(selected).expanduser().resolve()
    value = _ask_text("분석할 Workspace 전체 경로")
    path = Path(value).expanduser().resolve()
    if not path.is_dir():
        raise FileNotFoundError(f"Workspace 폴더가 없습니다: {path}")
    return path


def _load_template() -> Dict[str, Any]:
    template_path = PACKAGE_ROOT / "config.yaml"
    return yaml.safe_load(template_path.read_text(encoding="utf-8")) or {}


def _load_previous_choices() -> Dict[str, Any]:
    path = PACKAGE_ROOT / "generated" / "user-choices.yaml"
    if not path.exists():
        return {}
    try:
        value = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _detected_summary(discovery: DiscoveryResult) -> None:
    services = discovery.services
    redis = services.get("redis", {})
    print("\n[자동 탐지 결과]")
    print(f"  시스템명        : {discovery.system_name}")
    print(f"  React           : {_bool_text(bool(services.get('react', {}).get('detected')))}  {services.get('react', {}).get('base_url', '')}")
    print(f"  Spring Boot     : {_bool_text(bool(services.get('spring_boot', {}).get('detected')))}  {services.get('spring_boot', {}).get('base_url', '')}")
    print(f"  Vert.x          : {_bool_text(bool(services.get('vertx', {}).get('detected')))}  {services.get('vertx', {}).get('base_url', '')}")
    print(f"  Oracle          : {_bool_text(bool(services.get('oracle', {}).get('detected')))}  {services.get('oracle', {}).get('dsn', '')}")
    print(f"  Redis           : {_bool_text(bool(redis.get('detected')))}  mode={redis.get('mode', '')}, nodes={len(redis.get('nodes', []))}")
    print(f"  Elasticsearch   : {_bool_text(bool(services.get('elasticsearch', {}).get('detected')))}  {services.get('elasticsearch', {}).get('url', '')}")
    print(f"  Kafka           : {_bool_text(bool(services.get('kafka', {}).get('detected')))}  {','.join(services.get('kafka', {}).get('bootstrap_servers', []))}")
    print(f"  Grafana         : {_bool_text(bool(services.get('grafana', {}).get('detected')))}  {services.get('grafana', {}).get('url', '')}")
    print(f"  Prometheus      : {_bool_text(bool(services.get('prometheus', {}).get('detected')))}  {services.get('prometheus', {}).get('url', '')}")
    print(f"  Loki            : {_bool_text(bool(services.get('loki', {}).get('detected')))}  {services.get('loki', {}).get('url', '')}")
    print(f"  미해결 Secret   : {len(discovery.unresolved_secrets)}")


def _collect_missing_credentials(discovery: DiscoveryResult, runtime_enabled: bool, non_interactive: bool) -> None:
    if not runtime_enabled or non_interactive:
        return
    unresolved_by_resource: Dict[str, set[str]] = {}
    for row in discovery.unresolved_secrets:
        unresolved_by_resource.setdefault(str(row.get("resource", "")), set()).add(str(row.get("field", "")))

    # Oracle metadata queries normally require a user/password even when the JDBC URL
    # itself is discoverable. For other resources, only ask when the source references
    # an unresolved secret or authentication is clearly configured. Enter always skips.
    if discovery.services.get("oracle", {}).get("detected"):
        unresolved_by_resource.setdefault("oracle", set()).update({"username", "password"})
    kafka = discovery.services.get("kafka", {}) or {}
    if "sasl" in str(kafka.get("security_protocol", "")).lower() or kafka.get("sasl_mechanism"):
        unresolved_by_resource.setdefault("kafka", set()).update({"username", "password"})
    for resource, values in discovery.credentials.items():
        if values.get("username") and not values.get("password"):
            unresolved_by_resource.setdefault(resource, set()).add("password")
        if values.get("password") and not values.get("username") and resource in {"oracle", "kafka"}:
            unresolved_by_resource.setdefault(resource, set()).add("username")

    for resource, fields in unresolved_by_resource.items():
        if not discovery.services.get(resource, {}).get("detected"):
            continue
        values = discovery.credentials.setdefault(resource, {})
        print(f"\n[{resource.upper()} 인증정보] Enter를 누르면 미입력 상태로 넘어갑니다.")
        for field in sorted(fields):
            if values.get(field):
                continue
            secret = field in {"password", "token", "api_key"}
            value = _ask_text(f"{resource}.{field}", "", secret=secret, non_interactive=False)
            if value:
                values[field] = value


def _add_manual_login(config: Dict[str, Any], credentials: Dict[str, Any], enabled: bool, non_interactive: bool) -> None:
    if not enabled:
        return
    login_needed = _ask_bool("React 사용자 화면에 로그인이 필요합니까?", False, non_interactive)
    login = config.setdefault("screenshots", {}).setdefault("login", {})
    login["enabled"] = login_needed
    if not login_needed:
        return
    login["url"] = _ask_text("로그인 경로", str(login.get("url") or "/login"), non_interactive=non_interactive)
    login["username_selector"] = _ask_text("아이디 입력 selector", str(login.get("username_selector") or "input[name='username']"), non_interactive=non_interactive)
    login["password_selector"] = _ask_text("비밀번호 입력 selector", str(login.get("password_selector") or "input[name='password']"), non_interactive=non_interactive)
    login["submit_selector"] = _ask_text("로그인 버튼 selector", str(login.get("submit_selector") or "button[type='submit']"), non_interactive=non_interactive)
    username = _ask_text("화면 로그인 아이디", "", non_interactive=non_interactive)
    password = _ask_text("화면 로그인 비밀번호", "", secret=True, non_interactive=non_interactive)
    if username or password:
        credentials.setdefault("screenshots", {}).setdefault("login", {}).update({"username": username, "password": password})


def _secure_local_file(path: Path) -> None:
    try:
        os.chmod(path, 0o600)
    except Exception:
        pass
    if os.name == "nt":
        try:
            user = os.environ.get("USERNAME", "")
            if user:
                subprocess.run(["icacls", str(path), "/inheritance:r", "/grant:r", f"{user}:(R,W)"], capture_output=True, text=True, check=False)
        except Exception:
            pass


def _prune_empty(value: Any) -> Any:
    if isinstance(value, dict):
        cleaned = {k: _prune_empty(v) for k, v in value.items()}
        return {k: v for k, v in cleaned.items() if v not in ({}, [], "", None)}
    if isinstance(value, list):
        return [_prune_empty(v) for v in value if v not in ({}, [], "", None)]
    return value


def configure(
    workspace: str = "",
    non_interactive: bool = False,
    static_only: bool = False,
    force_runtime: Optional[bool] = None,
    force_screenshots: Optional[bool] = None,
    force_resource_screenshots: Optional[bool] = None,
    import_k8s_secrets: Optional[bool] = None,
) -> Tuple[Path, Dict[str, Any], DiscoveryResult]:
    workspace_path = select_workspace(workspace, non_interactive)
    previous = _load_previous_choices()

    if import_k8s_secrets is None:
        import_k8s_secrets = False if static_only else _ask_bool(
            "Workspace의 Kubernetes Secret 파일에 평문/base64 값이 있으면 로컬 자격파일로 가져올까요?",
            bool(previous.get("import_k8s_secrets", False)), non_interactive,
        )

    base_config = _load_template()
    max_discovery_files = int((base_config.get("auto_config", {}) or {}).get("max_discovery_files", 200000) or 200000)
    print(f"\nWorkspace 자동 분석 중: {workspace_path}")
    discovery = discover_workspace(
        workspace_path,
        import_k8s_secret_values=bool(import_k8s_secrets),
        max_files=max_discovery_files,
    )
    _detected_summary(discovery)

    react_detected = bool(discovery.services.get("react", {}).get("detected"))
    runtime_default = bool(previous.get("runtime_probe", False))
    screenshot_default = bool(previous.get("screenshots", react_detected))
    resource_default = bool(previous.get("resource_screenshots", False))

    runtime = False if static_only else (force_runtime if force_runtime is not None else _ask_bool(
        "Oracle/Redis Cluster/Elasticsearch/Kafka/Grafana/Prometheus/Loki에 읽기 전용으로 접속해 확인할까요?",
        runtime_default, non_interactive,
    ))
    screenshots = False if static_only else (force_screenshots if force_screenshots is not None else _ask_bool(
        "실행 중인 React 화면을 자동 캡처해 사용자·운영자 매뉴얼에 넣을까요?",
        screenshot_default, non_interactive,
    ))
    resource_screenshots = False if static_only else (force_resource_screenshots if force_resource_screenshots is not None else _ask_bool(
        "Grafana/Prometheus 운영 화면도 자동 캡처할까요?",
        resource_default, non_interactive,
    ))

    choices = {
        "runtime_probe": bool(runtime),
        "screenshots": bool(screenshots),
        "resource_screenshots": bool(resource_screenshots),
        "import_k8s_secrets": bool(import_k8s_secrets),
    }
    _collect_missing_credentials(discovery, bool(runtime), non_interactive)

    generated_config, credentials_overlay = build_generated_config(base_config, discovery, choices, PACKAGE_ROOT)
    _add_manual_login(generated_config, credentials_overlay, bool(screenshots), non_interactive)

    generated_dir = PACKAGE_ROOT / "generated"
    generated_dir.mkdir(parents=True, exist_ok=True)
    config_path = generated_dir / "config.auto.yaml"
    credentials_path = PACKAGE_ROOT / "credentials.local.yaml"
    report_path = generated_dir / "discovery-report.json"
    choices_path = generated_dir / "user-choices.yaml"
    summary_path = generated_dir / "config-summary.txt"
    last_path = generated_dir / "last-run.json"

    config_path.write_text(yaml.safe_dump(generated_config, allow_unicode=True, sort_keys=False, width=140), encoding="utf-8")
    credentials_overlay = _prune_empty(credentials_overlay)
    if credentials_overlay:
        credentials_path.write_text(yaml.safe_dump(credentials_overlay, allow_unicode=True, sort_keys=False, width=140), encoding="utf-8")
        _secure_local_file(credentials_path)
    elif not credentials_path.exists():
        credentials_path.write_text("# 자동 설정 시 인증정보가 필요한 경우 이 파일에만 저장됩니다.\n{}\n", encoding="utf-8")
        _secure_local_file(credentials_path)

    report = discovery.masked_report()
    report["generated_at"] = datetime.now().isoformat(timespec="seconds")
    report["choices"] = choices
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    choices_path.write_text(yaml.safe_dump(choices, allow_unicode=True, sort_keys=False), encoding="utf-8")
    last_path.write_text(json.dumps({"workspace": str(workspace_path), "config": str(config_path), "updated_at": datetime.now().isoformat(timespec="seconds")}, ensure_ascii=False, indent=2), encoding="utf-8")

    services = discovery.services
    summary_lines = [
        "Workspace Documentation Generator v4 - 자동 설정 결과",
        f"Workspace: {workspace_path}",
        f"System: {discovery.system_name}",
        f"Generated config: {config_path}",
        f"Output: {generated_config.get('output', {}).get('dir', '')}",
        f"React screenshot: {screenshots} ({services.get('react', {}).get('base_url', '')})",
        f"Runtime probe: {runtime}",
        f"Redis: mode={services.get('redis', {}).get('mode', '')}, nodes={','.join(services.get('redis', {}).get('nodes', []))}",
        f"Resource screenshots: {resource_screenshots}",
        "민감정보는 credentials.local.yaml에만 저장되며 생성 문서/분석 JSON에서는 마스킹됩니다.",
    ]
    summary_path.write_text("\n".join(summary_lines) + "\n", encoding="utf-8")

    print("\n[자동 설정 완료]")
    print(f"  Config      : {config_path}")
    print(f"  Credentials : {credentials_path}")
    print(f"  Report      : {report_path}")
    print(f"  Output      : {generated_config.get('output', {}).get('dir', '')}")
    return config_path, generated_config, discovery


def main() -> None:
    parser = argparse.ArgumentParser(description="Windows/CLI automatic config wizard for the workspace documentation generator.")
    parser.add_argument("--workspace", default="")
    parser.add_argument("--non-interactive", action="store_true")
    parser.add_argument("--static-only", action="store_true")
    parser.add_argument("--runtime", action=argparse.BooleanOptionalAction, default=None)
    parser.add_argument("--screenshots", action=argparse.BooleanOptionalAction, default=None)
    parser.add_argument("--resource-screenshots", action=argparse.BooleanOptionalAction, default=None)
    parser.add_argument("--import-k8s-secrets", action=argparse.BooleanOptionalAction, default=None)
    args = parser.parse_args()
    configure(
        workspace=args.workspace,
        non_interactive=args.non_interactive,
        static_only=args.static_only,
        force_runtime=args.runtime,
        force_screenshots=args.screenshots,
        force_resource_screenshots=args.resource_screenshots,
        import_k8s_secrets=args.import_k8s_secrets,
    )


if __name__ == "__main__":
    main()
