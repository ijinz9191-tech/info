from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Mapping

from .config_loader import mask_text
from .file_utils import read_text_safely

GRADLE_CONFIGS = (
    "implementation", "api", "compileOnly", "runtimeOnly", "annotationProcessor", "kapt", "ksp",
    "testImplementation", "testRuntimeOnly", "compile", "runtime", "classpath",
)
GRADLE_CONFIG_RE = "|".join(map(re.escape, GRADLE_CONFIGS))
GRADLE_DEP_RE = re.compile(
    rf"(?P<conf>{GRADLE_CONFIG_RE})\s*(?:\(?\s*)?(?:(?:platform|enforcedPlatform)\s*\(\s*)?[\'\"](?P<gav>[^\'\"]+)[\'\"]",
    re.M,
)
GRADLE_MAP_DEP_RE = re.compile(
    rf"(?P<conf>{GRADLE_CONFIG_RE})\s*\(?\s*"
    r"group\s*:\s*[\'\"](?P<group>[^\'\"]+)[\'\"]\s*,\s*"
    r"name\s*:\s*[\'\"](?P<name>[^\'\"]+)[\'\"]"
    r"(?:\s*,\s*version\s*:\s*[\'\"](?P<version>[^\'\"]+)[\'\"])?",
    re.M,
)
GRADLE_LOCAL_FILE_RE = re.compile(rf"(?P<conf>{GRADLE_CONFIG_RE})\s*(?:\(?\s*)?files\s*\((?P<args>[^)]*)\)", re.M)
GRADLE_FILETREE_RE = re.compile(rf"(?P<conf>{GRADLE_CONFIG_RE})\s*(?:\(?\s*)?fileTree\s*\((?P<args>[^)]*)\)", re.M)
GRADLE_REPO_URL_RE = re.compile(r"url\s*(?:=)?\s*(?:uri\()?\s*[\'\"]([^\'\"]+)[\'\"]", re.M)
GRADLE_INCLUDE_RE = re.compile(r"\binclude\s+(.+)")
GRADLE_PLUGIN_RE = re.compile(r"\bid\s*(?:\()?\s*[\'\"]([^\'\"]+)[\'\"]\s*\)?(?:\s+version\s+[\'\"]([^\'\"]+)[\'\"])?")


def _line(text: str, offset: int) -> int:
    return text.count("\n", 0, max(0, offset)) + 1


def parse_gav(gav: str) -> Dict[str, str]:
    parts = gav.split(":")
    if len(parts) >= 3:
        return {"group": parts[0], "artifact": parts[1], "version": ":".join(parts[2:])}
    if len(parts) == 2:
        return {"group": parts[0], "artifact": parts[1], "version": "확인필요"}
    return {"group": "확인필요", "artifact": gav, "version": "확인필요"}


def parse_gradle_file(path: Path, root: Path) -> Dict[str, Any]:
    rel = str(path.relative_to(root)).replace("\\", "/")
    text = read_text_safely(path, max_chars=3_000_000)
    deps: List[Dict[str, Any]] = []
    for m in GRADLE_DEP_RE.finditer(text):
        gav = parse_gav(m.group("gav"))
        gav.update({
            "configuration": m.group("conf"),
            "source_path": rel,
            "source_type": "gradle",
            "line": _line(text, m.start()),
            "raw": mask_text(m.group(0)),
            "platform": "platform" in m.group(0),
        })
        deps.append(gav)
    for m in GRADLE_MAP_DEP_RE.finditer(text):
        deps.append({
            "configuration": m.group("conf"),
            "group": m.group("group"),
            "artifact": m.group("name"),
            "version": m.group("version") or "확인필요",
            "source_path": rel,
            "source_type": "gradle",
            "line": _line(text, m.start()),
            "raw": mask_text(m.group(0)),
        })
    for m in GRADLE_LOCAL_FILE_RE.finditer(text):
        files = re.findall(r"[\'\"]([^\'\"]+\.jar)[\'\"]", m.group("args"), re.I)
        for file_name in files or [m.group("args").strip()]:
            deps.append({
                "configuration": m.group("conf"), "group": "local", "artifact": Path(file_name).stem,
                "version": "확인필요", "source_path": rel, "source_type": "gradle-files",
                "local_path": file_name, "line": _line(text, m.start()), "raw": mask_text(m.group(0)),
            })
    for m in GRADLE_FILETREE_RE.finditer(text):
        dir_m = re.search(r"dir\s*:\s*[\'\"]([^\'\"]+)", m.group("args"))
        include_m = re.search(r"include\s*:\s*\[?\s*[\'\"]([^\'\"]+)", m.group("args"))
        deps.append({
            "configuration": m.group("conf"), "group": "local", "artifact": include_m.group(1) if include_m else "fileTree",
            "version": "확인필요", "source_path": rel, "source_type": "gradle-fileTree",
            "local_path": dir_m.group(1) if dir_m else "확인필요", "line": _line(text, m.start()), "raw": mask_text(m.group(0)),
        })

    repos: List[Dict[str, Any]] = []
    if "mavenCentral()" in text:
        repos.append({"type": "mavenCentral", "url": "https://repo.maven.apache.org/maven2", "source_path": rel, "line": _line(text, text.index("mavenCentral()"))})
    if "google()" in text:
        repos.append({"type": "google", "url": "https://maven.google.com", "source_path": rel, "line": _line(text, text.index("google()"))})
    if "jcenter()" in text:
        repos.append({"type": "jcenter", "url": "https://jcenter.bintray.com", "source_path": rel, "line": _line(text, text.index("jcenter()"))})
    if "mavenLocal()" in text:
        repos.append({"type": "mavenLocal", "url": "~/.m2/repository", "source_path": rel, "line": _line(text, text.index("mavenLocal()"))})
    for m in GRADLE_REPO_URL_RE.finditer(text):
        repos.append({"type": "maven", "url": mask_text(m.group(1)), "source_path": rel, "line": _line(text, m.start())})

    modules: List[str] = []
    if path.name.startswith("settings.gradle"):
        for m in GRADLE_INCLUDE_RE.finditer(text):
            raw = m.group(1)
            modules.extend([x.strip().strip("'\"").replace(":", "/").strip("/") for x in raw.split(",") if x.strip()])

    plugins = [
        {"plugin_id": m.group(1), "version": m.group(2) or "확인필요", "source_path": rel, "line": _line(text, m.start())}
        for m in GRADLE_PLUGIN_RE.finditer(text)
    ]
    return {"dependencies": deps, "repositories": repos, "modules": modules, "plugins": plugins}


def ns_tag(tag: str) -> str:
    return tag.split("}")[-1]


def find_child_text(parent: ET.Element, child_name: str) -> str:
    for child in list(parent):
        if ns_tag(child.tag) == child_name:
            return (child.text or "").strip()
    return ""


def _resolve_property(value: str, props: Mapping[str, str]) -> str:
    if not value:
        return value
    for _ in range(5):
        m = re.search(r"\$\{([^}]+)}", value)
        if not m:
            break
        key = m.group(1)
        replacement = props.get(key)
        if replacement is None:
            break
        value = value[:m.start()] + replacement + value[m.end():]
    return value


def parse_pom_file(path: Path, root: Path) -> Dict[str, Any]:
    rel = str(path.relative_to(root)).replace("\\", "/")
    deps: List[Dict[str, Any]] = []
    repos: List[Dict[str, Any]] = []
    modules: List[str] = []
    plugins: List[Dict[str, Any]] = []
    try:
        tree = ET.parse(path)
        root_xml = tree.getroot()
        props: Dict[str, str] = {}
        for child in list(root_xml):
            if ns_tag(child.tag) == "properties":
                for prop in list(child):
                    props[ns_tag(prop.tag)] = (prop.text or "").strip()
        project_version = find_child_text(root_xml, "version")
        project_group = find_child_text(root_xml, "groupId")
        props.update({"project.version": project_version, "project.groupId": project_group, "pom.version": project_version})

        for dep_parent in root_xml.iter():
            if ns_tag(dep_parent.tag) != "dependency":
                continue
            group = _resolve_property(find_child_text(dep_parent, "groupId") or "확인필요", props)
            artifact = _resolve_property(find_child_text(dep_parent, "artifactId") or "확인필요", props)
            version = _resolve_property(find_child_text(dep_parent, "version") or "확인필요", props)
            scope = find_child_text(dep_parent, "scope") or "compile"
            optional = find_child_text(dep_parent, "optional") or "false"
            deps.append({
                "configuration": scope, "group": group, "artifact": artifact, "version": version,
                "optional": optional, "source_path": rel, "source_type": "maven", "line": 0,
            })
        for mod_parent in root_xml.iter():
            if ns_tag(mod_parent.tag) == "module" and mod_parent.text:
                modules.append(mod_parent.text.strip())
        for repo in root_xml.iter():
            if ns_tag(repo.tag) == "repository":
                repos.append({
                    "type": "maven", "id": find_child_text(repo, "id") or "",
                    "url": mask_text(find_child_text(repo, "url") or "확인필요"), "source_path": rel, "line": 0,
                })
        for plugin in root_xml.iter():
            if ns_tag(plugin.tag) == "plugin":
                plugins.append({
                    "plugin_id": f"{find_child_text(plugin, 'groupId') or 'org.apache.maven.plugins'}:{find_child_text(plugin, 'artifactId')}",
                    "version": _resolve_property(find_child_text(plugin, "version") or "확인필요", props),
                    "source_path": rel, "line": 0,
                })
    except Exception as exc:
        return {"dependencies": [], "repositories": [], "modules": [], "plugins": [], "error": str(exc), "source_path": rel}
    return {"dependencies": deps, "repositories": repos, "modules": modules, "plugins": plugins}


def parse_version_catalog(path: Path, root: Path) -> Dict[str, Any]:
    rel = str(path.relative_to(root)).replace("\\", "/")
    text = read_text_safely(path, max_chars=2_000_000)
    try:
        try:
            import tomllib  # type: ignore
        except Exception:
            import tomli as tomllib  # type: ignore
        obj = tomllib.loads(text)
        versions = obj.get("versions", {}) or {}
        libraries = obj.get("libraries", {}) or {}
        deps: List[Dict[str, Any]] = []
        for alias, value in libraries.items():
            if isinstance(value, str):
                gav = parse_gav(value)
            elif isinstance(value, dict):
                module = value.get("module", "")
                if module:
                    gav = parse_gav(module)
                else:
                    gav = {"group": value.get("group", ""), "artifact": value.get("name", ""), "version": "확인필요"}
                version = value.get("version")
                if isinstance(version, dict):
                    ref = version.get("ref", "")
                    gav["version"] = versions.get(ref, f"${{{ref}}}")
                elif version:
                    gav["version"] = version
                elif value.get("version.ref"):
                    ref = value.get("version.ref")
                    gav["version"] = versions.get(ref, f"${{{ref}}}")
            else:
                continue
            gav.update({"configuration": "version-catalog", "alias": alias, "source_path": rel, "source_type": "gradle-version-catalog", "line": 0})
            deps.append(gav)
        return {"dependencies": deps, "repositories": [], "modules": [], "plugins": []}
    except Exception as exc:
        # Minimal fallback for simple module = "g:a" entries.
        deps = []
        for m in re.finditer(r"^([A-Za-z0-9_.-]+)\s*=\s*\{[^\n]*(?:module\s*=\s*[\"']([^\"']+)|group\s*=\s*[\"']([^\"']+)[\"'][^\n]*name\s*=\s*[\"']([^\"']+))[^\n]*", text, re.M):
            group, artifact = "", ""
            if m.group(2):
                parsed = parse_gav(m.group(2))
                group, artifact = parsed["group"], parsed["artifact"]
            else:
                group, artifact = m.group(3) or "", m.group(4) or ""
            deps.append({"configuration": "version-catalog", "alias": m.group(1), "group": group, "artifact": artifact, "version": "확인필요", "source_path": rel, "source_type": "gradle-version-catalog", "line": _line(text, m.start())})
        return {"dependencies": deps, "repositories": [], "modules": [], "plugins": [], "warning": str(exc)}


def parse_build_file(path: Path, root: Path) -> Dict[str, Any]:
    name = path.name.lower()
    if name == "pom.xml":
        return parse_pom_file(path, root)
    if name == "libs.versions.toml":
        return parse_version_catalog(path, root)
    if "gradle" in name:
        return parse_gradle_file(path, root)
    return {"dependencies": [], "repositories": [], "modules": [], "plugins": []}


def parse_jar_name(path: Path, root: Path) -> Dict[str, Any]:
    rel = str(path.relative_to(root)).replace("\\", "/")
    stem = path.stem
    m = re.match(r"(?P<artifact>.+)-(?P<version>\d[\w\.\-+]*)$", stem)
    if m:
        artifact = m.group("artifact")
        version = m.group("version")
    else:
        artifact = stem
        version = "확인필요"
    return {
        "configuration": "local-jar", "group": "local", "artifact": artifact, "version": version,
        "source_path": rel, "source_type": "local-jar", "local_path": rel, "line": 0,
    }
