from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List

from .file_utils import read_text_safely

ROUTE_PATTERNS = [
    re.compile(r"<Route[^>]+path=\{?[\'\"]([^\'\"]+)[\'\"]", re.I),
    re.compile(r"\bpath\s*:\s*[\'\"]([^\'\"]+)[\'\"]", re.I),
    re.compile(r"\burl\s*:\s*[\'\"](/[^\'\"]+)[\'\"]", re.I),
    re.compile(r"router\.(?:get|post|put|delete|patch)\s*\(\s*[\'\"]([^\'\"]+)[\'\"]", re.I),
]
MENU_PATTERNS = [
    re.compile(r"\b(?:title|label|name|menuName)\s*:\s*[\'\"]([^\'\"]+)[\'\"]", re.I),
    re.compile(r">\s*([^<>]{2,40})\s*</(?:span|a|button|li|MenuItem|div)>", re.I),
]


def parse_frontend_file(path: Path, root: Path) -> Dict[str, Any]:
    rel = str(path.relative_to(root)).replace("\\", "/")
    text = read_text_safely(path, max_chars=500000)
    routes = []
    menus = []
    for pat in ROUTE_PATTERNS:
        for m in pat.finditer(text):
            route_path = m.group(1).strip()
            if not route_path.startswith("/"):
                continue
            routes.append({"path": route_path, "source_path": rel, "title": "", "requires_review": True})
    for pat in MENU_PATTERNS:
        for m in pat.finditer(text):
            label = re.sub(r"\s+", " ", m.group(1).strip())
            if not label or len(label) > 80:
                continue
            if any(x in label for x in ["{", "}", "=>", "function"]):
                continue
            menus.append({"label": label, "source_path": rel})
    # 중복 제거
    unique_routes = list({(x["path"], x["source_path"]): x for x in routes}.values())
    unique_menus = list({(x["label"], x["source_path"]): x for x in menus}.values())[:100]
    return {"routes": unique_routes, "menus": unique_menus}
