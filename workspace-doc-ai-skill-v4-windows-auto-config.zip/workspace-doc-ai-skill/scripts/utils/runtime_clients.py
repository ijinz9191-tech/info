from __future__ import annotations

import json
import os
import re
import socket
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple
from urllib.parse import urlparse

from .config_loader import configured_value, deep_mask, env_first, env_or_empty, mask_text, resolve_env_placeholders

try:
    import requests
except Exception:  # pragma: no cover
    requests = None


@dataclass
class ProbeResult:
    resource_type: str
    target: str
    status: str
    latency_ms: int = 0
    details: Dict[str, Any] = field(default_factory=dict)
    error: str = ""
    source: str = "CONFIG"

    def as_dict(self) -> Dict[str, Any]:
        return deep_mask({
            "resource_type": self.resource_type,
            "target": mask_text(self.target),
            "status": self.status,
            "latency_ms": self.latency_ms,
            "details": self.details,
            "error": mask_text(self.error),
            "source": self.source,
        })


def _timed(fn: Any) -> Tuple[Any, int]:
    started = time.perf_counter()
    value = fn()
    return value, int((time.perf_counter() - started) * 1000)


def _as_list(value: Any) -> List[str]:
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        rows: List[str] = []
        for item in value:
            rows.extend(_as_list(item))
        return rows
    return [x.strip() for x in re.split(r"\s*,\s*|\s*;\s*", str(value)) if x.strip()]


def _resource_config(runtime_cfg: Mapping[str, Any], name: str) -> Dict[str, Any]:
    value = runtime_cfg.get(name.lower()) or runtime_cfg.get(name.upper()) or {}
    return dict(value) if isinstance(value, dict) else {}


def _env_or_config(cfg: Mapping[str, Any], key: str, standard_envs: Sequence[str] = ()) -> str:
    # Direct values from generated config/credentials.local.yaml take precedence.
    # Environment variables remain a backwards-compatible fallback.
    return configured_value(cfg, key, standard_envs)


def _valid_discovered_target(resource_type: str, value: Any) -> bool:
    text = str(value or "").strip().strip("\"'")
    if not text or "***MASKED***" in text or "${" in text:
        return False
    if resource_type == "ORACLE":
        return text.lower().startswith("jdbc:oracle:")
    if resource_type == "REDIS":
        return text.lower().startswith(("redis://", "rediss://"))
    if resource_type in {"ELASTICSEARCH", "GRAFANA", "PROMETHEUS", "LOKI"}:
        return text.lower().startswith(("http://", "https://"))
    if resource_type == "KAFKA":
        return bool(re.fullmatch(r"[A-Za-z0-9_.-]+:\d{2,5}(?:\s*,\s*[A-Za-z0-9_.-]+:\d{2,5})*", text))
    return False


def discover_targets(analysis: Mapping[str, Any], resource_type: str) -> List[str]:
    """Return only connection-shaped static candidates; ordinary config values are never treated as endpoints."""
    targets: List[str] = []
    resources = analysis.get("resources", {}) or {}
    for row in resources.get("configurations", []) or []:
        if row.get("resource_type") != resource_type:
            continue
        endpoint = row.get("endpoint")
        if _valid_discovered_target(resource_type, endpoint):
            targets.append(str(resolve_env_placeholders(endpoint)))
            continue
        key = str(row.get("key") or "").lower()
        value = row.get("value_sample")
        connection_key = any(token in key for token in ("url", "uri", "dsn", "bootstrap", "servers"))
        if connection_key and _valid_discovered_target(resource_type, value):
            targets.append(str(resolve_env_placeholders(value)))
    for row in resources.get("assets", []) or []:
        if row.get("resource_type") == resource_type and row.get("asset_type") == "ENDPOINT_CANDIDATE":
            value = row.get("name", "")
            if _valid_discovered_target(resource_type, value):
                targets.append(str(resolve_env_placeholders(value)))
    return list(dict.fromkeys(x for x in targets if x))


def _http_auth_headers(cfg: Mapping[str, Any]) -> Tuple[Any, Dict[str, str]]:
    user = _env_or_config(cfg, "username", ())
    password = _env_or_config(cfg, "password", ())
    token = _env_or_config(cfg, "token", ())
    api_key = _env_or_config(cfg, "api_key", ())
    auth = (user, password) if user else None
    headers: Dict[str, str] = {"Accept": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    elif api_key:
        headers["Authorization"] = f"ApiKey {api_key}"
    for key, value in (cfg.get("headers") or {}).items() if isinstance(cfg.get("headers"), dict) else []:
        resolved = resolve_env_placeholders(str(value))
        if resolved:
            headers[str(key)] = resolved
    return auth, headers


def _http_get(base_url: str, path: str, cfg: Mapping[str, Any], timeout: float, verify_tls: bool) -> Tuple[int, Any, Dict[str, str]]:
    if requests is None:
        raise RuntimeError("requests package is not installed")
    auth, headers = _http_auth_headers(cfg)
    url = base_url.rstrip("/") + "/" + path.lstrip("/")
    response = requests.get(url, timeout=timeout, verify=verify_tls, auth=auth, headers=headers)
    content_type = response.headers.get("content-type", "")
    if "json" in content_type:
        try:
            data: Any = response.json()
        except Exception:
            data = {"text": response.text[:2000]}
    else:
        try:
            data = response.json()
        except Exception:
            data = {"text": response.text[:2000]}
    return response.status_code, data, dict(response.headers)


def probe_oracle(cfg: Mapping[str, Any], timeout: float, max_rows: int) -> ProbeResult:
    dsn = _env_or_config(cfg, "dsn", ("ORACLE_DSN", "SPRING_DATASOURCE_URL"))
    user = _env_or_config(cfg, "username", ("ORACLE_USER", "ORACLE_USERNAME", "SPRING_DATASOURCE_USERNAME"))
    password = _env_or_config(cfg, "password", ("ORACLE_PASSWORD", "SPRING_DATASOURCE_PASSWORD"))
    if dsn.startswith("jdbc:oracle:thin:@//"):
        dsn = dsn.split("jdbc:oracle:thin:@//", 1)[1]
    elif dsn.startswith("jdbc:oracle:thin:@"):
        legacy = dsn.split("jdbc:oracle:thin:@", 1)[1]
        parts = legacy.split(":")
        dsn = f"{parts[0]}:{parts[1]}/{parts[2]}" if len(parts) >= 3 else legacy
    if not dsn:
        return ProbeResult("ORACLE", "", "SKIPPED", error="Oracle DSN not found")
    try:
        import oracledb  # type: ignore

        def work() -> Dict[str, Any]:
            connection = oracledb.connect(user=user, password=password, dsn=dsn, tcp_connect_timeout=timeout)
            details: Dict[str, Any] = {"tables": [], "columns": [], "constraints": [], "sequences": [], "programs": []}
            try:
                with connection.cursor() as cursor:
                    cursor.execute("SELECT 1 FROM DUAL")
                    details["ping"] = cursor.fetchone()[0]
                    cursor.execute("SELECT SYS_CONTEXT('USERENV','CURRENT_SCHEMA'), SYS_CONTEXT('USERENV','DB_NAME') FROM DUAL")
                    schema, db_name = cursor.fetchone()
                    details["current_schema"] = schema
                    details["db_name"] = db_name
                    if bool(cfg.get("include_schema_metadata", True)):
                        queries = {
                            "tables": "SELECT TABLE_NAME, COMMENTS FROM USER_TAB_COMMENTS WHERE TABLE_TYPE='TABLE' ORDER BY TABLE_NAME",
                            "columns": "SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, DATA_LENGTH, DATA_PRECISION, DATA_SCALE, NULLABLE, DATA_DEFAULT, COLUMN_ID FROM USER_TAB_COLUMNS ORDER BY TABLE_NAME, COLUMN_ID",
                            "constraints": "SELECT CONSTRAINT_NAME, CONSTRAINT_TYPE, TABLE_NAME, R_CONSTRAINT_NAME, STATUS FROM USER_CONSTRAINTS ORDER BY TABLE_NAME, CONSTRAINT_NAME",
                            "sequences": "SELECT SEQUENCE_NAME, MIN_VALUE, MAX_VALUE, INCREMENT_BY, LAST_NUMBER, CACHE_SIZE FROM USER_SEQUENCES ORDER BY SEQUENCE_NAME",
                            "programs": "SELECT OBJECT_NAME, OBJECT_TYPE, STATUS FROM USER_OBJECTS WHERE OBJECT_TYPE IN ('PACKAGE','PACKAGE BODY','PROCEDURE','FUNCTION','TRIGGER','VIEW','MATERIALIZED VIEW','SYNONYM') ORDER BY OBJECT_TYPE, OBJECT_NAME",
                        }
                        for key, sql in queries.items():
                            try:
                                cursor.execute(sql)
                                columns = [d[0].lower() for d in cursor.description]
                                rows = [dict(zip(columns, row)) for row in cursor.fetchmany(max_rows)]
                                details[key] = rows
                            except Exception as exc:
                                details[f"{key}_warning"] = str(exc)
            finally:
                connection.close()
            return details

        details, latency = _timed(work)
        return ProbeResult("ORACLE", dsn, "UP", latency, details)
    except Exception as exc:
        return ProbeResult("ORACLE", dsn, "DOWN", error=str(exc))


def _normalise_redis_nodes(values: Any, default_port: int = 6379) -> List[str]:
    nodes: List[str] = []
    for raw in _as_list(values):
        text = str(raw).strip().strip("\"'")
        if not text:
            continue
        if text.startswith(("redis://", "rediss://")):
            parsed = urlparse(text)
            if parsed.hostname:
                nodes.append(f"{parsed.hostname}:{parsed.port or default_port}")
            continue
        if ":" not in text:
            text = f"{text}:{default_port}"
        nodes.append(text)
    return list(dict.fromkeys(nodes))


def _cluster_node_record(node: Any) -> Dict[str, Any]:
    return {
        "name": str(getattr(node, "name", "") or ""),
        "host": str(getattr(node, "host", "") or ""),
        "port": int(getattr(node, "port", 0) or 0),
        "server_type": str(getattr(node, "server_type", "") or ""),
    }


def _parse_cluster_nodes_text(value: Any, max_rows: int) -> List[Dict[str, Any]]:
    if isinstance(value, dict):
        rows = []
        for node_id, row in list(value.items())[:max_rows]:
            if isinstance(row, dict):
                rows.append({"node_id": node_id, **row})
            else:
                rows.append({"node_id": node_id, "detail": str(row)})
        return rows
    rows: List[Dict[str, Any]] = []
    for line in str(value or "").splitlines()[:max_rows]:
        parts = line.split()
        if len(parts) < 3:
            continue
        endpoint = parts[1].split("@", 1)[0]
        rows.append({
            "node_id": parts[0],
            "endpoint": endpoint,
            "flags": parts[2],
            "master_id": parts[3] if len(parts) > 3 else "",
            "link_state": parts[7] if len(parts) > 7 else "",
            "slots": parts[8:] if len(parts) > 8 else [],
        })
    return rows


def _probe_redis_cluster(cfg: Mapping[str, Any], timeout: float, max_rows: int, nodes: List[str], username: str, password: str) -> Tuple[str, Dict[str, Any]]:
    from redis.cluster import ClusterNode, RedisCluster  # type: ignore

    startup_nodes = []
    for value in nodes:
        host, sep, port_text = value.rpartition(":")
        if not sep or not port_text.isdigit():
            continue
        startup_nodes.append(ClusterNode(host, int(port_text)))
    if not startup_nodes:
        raise ValueError("Redis Cluster startup node가 없습니다.")

    kwargs: Dict[str, Any] = {
        "startup_nodes": startup_nodes,
        "username": username or None,
        "password": password or None,
        "decode_responses": True,
        "socket_timeout": timeout,
        "socket_connect_timeout": timeout,
        "require_full_coverage": bool(cfg.get("require_full_coverage", False)),
        "ssl": bool(cfg.get("ssl", False)),
    }
    if bool(cfg.get("read_from_replicas", False)):
        kwargs["read_from_replicas"] = True
    client = RedisCluster(**kwargs)
    details: Dict[str, Any] = {"mode": "cluster", "ping": bool(client.ping()), "startup_nodes": nodes}
    try:
        discovered_nodes = [_cluster_node_record(node) for node in client.get_nodes()]
        details["topology"] = discovered_nodes[:max_rows]
        details["master_count"] = sum(1 for row in discovered_nodes if str(row.get("server_type", "")).lower() in {"primary", "master"})
        details["replica_count"] = sum(1 for row in discovered_nodes if str(row.get("server_type", "")).lower() in {"replica", "slave"})
    except Exception as exc:
        details["topology_warning"] = str(exc)
    if bool(cfg.get("collect_cluster_nodes", True)):
        try:
            raw_nodes = client.execute_command("CLUSTER", "NODES")
            details["cluster_nodes"] = _parse_cluster_nodes_text(raw_nodes, max_rows)
        except Exception as exc:
            details["cluster_nodes_warning"] = str(exc)
    try:
        details["cluster_info"] = client.cluster_info()
    except Exception as exc:
        try:
            raw = client.execute_command("CLUSTER", "INFO")
            parsed = {}
            for line in str(raw).splitlines():
                if ":" in line:
                    key, value = line.split(":", 1)
                    parsed[key] = value
            details["cluster_info"] = parsed
        except Exception:
            details["cluster_info_warning"] = str(exc)
    if bool(cfg.get("collect_cluster_slots", True)):
        try:
            slots = client.cluster_slots()
            if isinstance(slots, dict):
                details["cluster_slots"] = [
                    {"slot_range": list(slot_range) if isinstance(slot_range, tuple) else str(slot_range), "nodes": value}
                    for slot_range, value in list(slots.items())[:max_rows]
                ]
            else:
                details["cluster_slots"] = slots
        except Exception as exc:
            details["cluster_slots_warning"] = str(exc)
    try:
        info = client.info(section="server")
        if isinstance(info, dict):
            details["node_server_info"] = list(info.items())[:max_rows]
    except Exception as exc:
        details["server_info_warning"] = str(exc)
    if bool(cfg.get("scan_keys", False)):
        keys: List[str] = []
        for key in client.scan_iter(match=str(cfg.get("key_pattern", "*")), count=100):
            keys.append(str(key))
            if len(keys) >= max_rows:
                break
        details["key_names"] = keys
    try:
        client.close()
    except Exception:
        pass
    return ",".join(nodes), details


def _probe_redis_sentinel(cfg: Mapping[str, Any], timeout: float, max_rows: int, nodes: List[str], username: str, password: str) -> Tuple[str, Dict[str, Any]]:
    from redis.sentinel import Sentinel  # type: ignore

    endpoints: List[Tuple[str, int]] = []
    for value in nodes:
        host, sep, port_text = value.rpartition(":")
        if sep and port_text.isdigit():
            endpoints.append((host, int(port_text)))
    master_name = str(cfg.get("sentinel_master") or "mymaster")
    if not endpoints:
        raise ValueError("Redis Sentinel node가 없습니다.")
    sentinel = Sentinel(endpoints, socket_timeout=timeout, username=username or None, password=password or None)
    master = sentinel.master_for(master_name, username=username or None, password=password or None, socket_timeout=timeout, decode_responses=True)
    details: Dict[str, Any] = {"mode": "sentinel", "ping": bool(master.ping()), "sentinel_nodes": nodes, "master_name": master_name}
    try:
        details["master_address"] = sentinel.discover_master(master_name)
        details["replicas"] = sentinel.discover_slaves(master_name)[:max_rows]
    except Exception as exc:
        details["sentinel_topology_warning"] = str(exc)
    try:
        details["server"] = {k: v for k, v in master.info("server").items() if k in {"redis_version", "redis_mode", "role"}}
    except Exception as exc:
        details["server_warning"] = str(exc)
    if bool(cfg.get("scan_keys", False)):
        keys = []
        for key in master.scan_iter(match=str(cfg.get("key_pattern", "*")), count=100):
            keys.append(str(key))
            if len(keys) >= max_rows:
                break
        details["key_names"] = keys
    try:
        master.close()
    except Exception:
        pass
    return ",".join(nodes), details


def _probe_redis_standalone(cfg: Mapping[str, Any], timeout: float, max_rows: int, url: str, username: str, password: str) -> Tuple[str, Dict[str, Any]]:
    import redis  # type: ignore

    client = redis.Redis.from_url(url, username=username or None, password=password or None, socket_timeout=timeout, socket_connect_timeout=timeout, decode_responses=True)
    details: Dict[str, Any] = {"mode": "standalone", "ping": bool(client.ping())}
    for section in ("server", "replication", "memory", "stats", "keyspace", "cluster"):
        try:
            info = client.info(section=section)
            keep = {
                key: value for key, value in info.items()
                if key in {
                    "redis_version", "redis_mode", "role", "connected_slaves", "used_memory", "used_memory_human",
                    "maxmemory", "maxmemory_human", "total_connections_received", "instantaneous_ops_per_sec",
                    "cluster_enabled", "db0", "db1", "db2", "db3", "master_host", "master_port",
                } or key.startswith("db")
            }
            details[section] = keep
        except Exception as exc:
            details[f"{section}_warning"] = str(exc)
    try:
        details["dbsize"] = client.dbsize()
    except Exception:
        pass
    if bool(cfg.get("scan_keys", False)):
        keys = []
        for key in client.scan_iter(match=str(cfg.get("key_pattern", "*")), count=100):
            keys.append(str(key))
            if len(keys) >= max_rows:
                break
        details["key_names"] = keys
    try:
        client.close()
    except Exception:
        pass
    return url, details


def probe_redis(cfg: Mapping[str, Any], timeout: float, max_rows: int) -> ProbeResult:
    url = _env_or_config(cfg, "url", ("REDIS_URL", "SPRING_DATA_REDIS_URL", "SPRING_REDIS_URL"))
    host = _env_or_config(cfg, "host", ("REDIS_HOST", "SPRING_DATA_REDIS_HOST", "SPRING_REDIS_HOST"))
    port = _env_or_config(cfg, "port", ("REDIS_PORT", "SPRING_DATA_REDIS_PORT", "SPRING_REDIS_PORT")) or "6379"
    nodes_value: Any = cfg.get("nodes") or _env_or_config(cfg, "nodes", ("REDIS_CLUSTER_NODES",))
    sentinel_value: Any = cfg.get("sentinel_nodes") or _env_or_config(cfg, "sentinel_nodes", ("REDIS_SENTINEL_NODES",))
    password = _env_or_config(cfg, "password", ("REDIS_PASSWORD", "SPRING_DATA_REDIS_PASSWORD", "SPRING_REDIS_PASSWORD"))
    username = _env_or_config(cfg, "username", ("REDIS_USERNAME",))
    nodes = _normalise_redis_nodes(nodes_value)
    sentinel_nodes = _normalise_redis_nodes(sentinel_value, 26379)
    mode = str(cfg.get("mode") or "auto").strip().lower()
    if mode == "auto":
        mode = "cluster" if len(nodes) > 1 or bool(nodes and not url and not host) else "sentinel" if sentinel_nodes else "standalone"
    if mode == "cluster" and not nodes and url:
        nodes = _normalise_redis_nodes(url)
    if mode == "standalone" and not url and host:
        scheme = "rediss" if bool(cfg.get("ssl")) else "redis"
        url = f"{scheme}://{host}:{port}/{cfg.get('db', 0)}"

    target = ",".join(nodes or sentinel_nodes) if mode in {"cluster", "sentinel"} else url
    if not target:
        return ProbeResult("REDIS", "", "SKIPPED", error=f"Redis {mode} connection target not found")
    try:
        def work() -> Tuple[str, Dict[str, Any]]:
            if mode == "cluster":
                return _probe_redis_cluster(cfg, timeout, max_rows, nodes, username, password)
            if mode == "sentinel":
                return _probe_redis_sentinel(cfg, timeout, max_rows, sentinel_nodes, username, password)
            return _probe_redis_standalone(cfg, timeout, max_rows, url, username, password)

        (actual_target, details), latency = _timed(work)
        return ProbeResult("REDIS", actual_target, "UP", latency, details)
    except Exception as exc:
        return ProbeResult("REDIS", target, "DOWN", error=str(exc))


def probe_elasticsearch(cfg: Mapping[str, Any], timeout: float, max_rows: int, verify_tls: bool) -> ProbeResult:
    url = _env_or_config(cfg, "url", ("ELASTICSEARCH_URL", "SPRING_ELASTICSEARCH_URIS"))
    if not url:
        return ProbeResult("ELASTICSEARCH", "", "SKIPPED", error="Elasticsearch URL not found")
    url = _as_list(url)[0]
    try:
        def work() -> Dict[str, Any]:
            details: Dict[str, Any] = {}
            code, root, _ = _http_get(url, "/", cfg, timeout, verify_tls)
            details["http_status"] = code
            details["cluster_name"] = root.get("cluster_name") if isinstance(root, dict) else ""
            details["version"] = ((root.get("version") or {}).get("number") if isinstance(root, dict) else "")
            for name, path in (
                ("cluster_health", "/_cluster/health"),
                ("indices", f"/_cat/indices?format=json&h=health,status,index,uuid,pri,rep,docs.count,store.size&s=index&bytes=b"),
                ("aliases", "/_cat/aliases?format=json&h=alias,index,filter,routing.index,routing.search&s=alias"),
            ):
                try:
                    status, data, _ = _http_get(url, path, cfg, timeout, verify_tls)
                    details[name] = data[:max_rows] if isinstance(data, list) else data
                    details[f"{name}_http_status"] = status
                except Exception as exc:
                    details[f"{name}_warning"] = str(exc)
            return details

        details, latency = _timed(work)
        code = int(details.get("http_status", 500))
        status = "UP" if 200 <= code < 400 else "PARTIAL" if code in {401, 403} else "DOWN"
        if status == "PARTIAL":
            details["authorization_required"] = True
        return ProbeResult("ELASTICSEARCH", url, status, latency, details)
    except Exception as exc:
        return ProbeResult("ELASTICSEARCH", url, "DOWN", error=str(exc))


def _kafka_socket_check(bootstrap_servers: Sequence[str], timeout: float) -> Dict[str, Any]:
    reachable = []
    errors = []
    for server in bootstrap_servers:
        host, _, port_text = server.rpartition(":")
        if not host or not port_text.isdigit():
            errors.append({"server": server, "error": "invalid host:port"})
            continue
        try:
            with socket.create_connection((host, int(port_text)), timeout=timeout):
                reachable.append(server)
        except Exception as exc:
            errors.append({"server": server, "error": str(exc)})
    return {"reachable_brokers": reachable, "socket_errors": errors}


def probe_kafka(cfg: Mapping[str, Any], timeout: float, max_rows: int) -> ProbeResult:
    # Generated configuration stores bootstrap_servers as a YAML list. Preserve the
    # list here instead of stringifying it through configured_value(). Environment
    # variables remain a compatible fallback for legacy/manual executions.
    bootstrap = cfg.get("bootstrap_servers") or _env_or_config(
        cfg, "bootstrap_servers", ("KAFKA_BOOTSTRAP_SERVERS", "SPRING_KAFKA_BOOTSTRAP_SERVERS")
    )
    servers = _as_list(bootstrap)
    if not servers:
        return ProbeResult("KAFKA", "", "SKIPPED", error="Kafka bootstrap servers not found")
    target = ",".join(servers)
    try:
        def work() -> Dict[str, Any]:
            details = _kafka_socket_check(servers, timeout)
            try:
                from kafka import KafkaAdminClient  # type: ignore
                kwargs: Dict[str, Any] = {
                    "bootstrap_servers": servers,
                    "client_id": "workspace-doc-readonly-probe",
                    "request_timeout_ms": int(timeout * 1000),
                    "api_version_auto_timeout_ms": int(timeout * 1000),
                }
                for key in ("security_protocol", "sasl_mechanism", "ssl_cafile", "ssl_certfile", "ssl_keyfile"):
                    value = _env_or_config(cfg, key, ())
                    if value:
                        kwargs[key] = value
                user = _env_or_config(cfg, "username", ("KAFKA_USERNAME",))
                password = _env_or_config(cfg, "password", ("KAFKA_PASSWORD",))
                if user:
                    kwargs["sasl_plain_username"] = user
                    kwargs["sasl_plain_password"] = password
                admin = KafkaAdminClient(**kwargs)
                topics = sorted(admin.list_topics())[:max_rows]
                details["topics"] = topics
                details["topic_count"] = len(topics)
                try:
                    groups = admin.list_consumer_groups()
                    details["consumer_groups"] = [str(x) for x in groups[:max_rows]]
                except Exception as exc:
                    details["consumer_groups_warning"] = str(exc)
                admin.close()
            except Exception as exc:
                details["admin_client_warning"] = str(exc)
            return details

        details, latency = _timed(work)
        status = "UP" if details.get("reachable_brokers") else "DOWN"
        return ProbeResult("KAFKA", target, status, latency, details)
    except Exception as exc:
        return ProbeResult("KAFKA", target, "DOWN", error=str(exc))


def probe_grafana(cfg: Mapping[str, Any], timeout: float, max_rows: int, verify_tls: bool) -> ProbeResult:
    url = _env_or_config(cfg, "url", ("GRAFANA_URL",))
    if not url:
        return ProbeResult("GRAFANA", "", "SKIPPED", error="Grafana URL not found")
    try:
        def work() -> Dict[str, Any]:
            details: Dict[str, Any] = {}
            code, health, _ = _http_get(url, "/api/health", cfg, timeout, verify_tls)
            details["http_status"] = code
            details["health"] = health
            for name, path in (("datasources", "/api/datasources"), ("dashboards", "/api/search?type=dash-db"), ("folders", "/api/folders"), ("alert_rules", "/api/v1/provisioning/alert-rules")):
                try:
                    status, data, _ = _http_get(url, path, cfg, timeout, verify_tls)
                    details[name] = data[:max_rows] if isinstance(data, list) else data
                    details[f"{name}_http_status"] = status
                except Exception as exc:
                    details[f"{name}_warning"] = str(exc)
            return details

        details, latency = _timed(work)
        code = int(details.get("http_status", 500))
        status = "UP" if 200 <= code < 400 else "PARTIAL" if code in {401, 403} else "DOWN"
        if status == "PARTIAL":
            details["authorization_required"] = True
        return ProbeResult("GRAFANA", url, status, latency, details)
    except Exception as exc:
        return ProbeResult("GRAFANA", url, "DOWN", error=str(exc))


def probe_prometheus(cfg: Mapping[str, Any], timeout: float, max_rows: int, verify_tls: bool) -> ProbeResult:
    url = _env_or_config(cfg, "url", ("PROMETHEUS_URL",))
    if not url:
        return ProbeResult("PROMETHEUS", "", "SKIPPED", error="Prometheus URL not found")
    try:
        def work() -> Dict[str, Any]:
            details: Dict[str, Any] = {}
            ready_status, ready, _ = _http_get(url, "/-/ready", cfg, timeout, verify_tls)
            details["ready_http_status"] = ready_status
            details["ready"] = ready
            for name, path in (("buildinfo", "/api/v1/status/buildinfo"), ("runtimeinfo", "/api/v1/status/runtimeinfo"), ("targets", "/api/v1/targets?state=active"), ("rules", "/api/v1/rules")):
                try:
                    status, data, _ = _http_get(url, path, cfg, timeout, verify_tls)
                    if name == "targets" and isinstance(data, dict):
                        active = ((data.get("data") or {}).get("activeTargets") or [])[:max_rows]
                        data = {"status": data.get("status"), "data": {"activeTargets": active}}
                    details[name] = data
                    details[f"{name}_http_status"] = status
                except Exception as exc:
                    details[f"{name}_warning"] = str(exc)
            return details

        details, latency = _timed(work)
        status = "UP" if int(details.get("ready_http_status", 500)) < 400 else "DOWN"
        return ProbeResult("PROMETHEUS", url, status, latency, details)
    except Exception as exc:
        return ProbeResult("PROMETHEUS", url, "DOWN", error=str(exc))


def probe_loki(cfg: Mapping[str, Any], timeout: float, max_rows: int, verify_tls: bool) -> ProbeResult:
    url = _env_or_config(cfg, "url", ("LOKI_URL",))
    if not url:
        return ProbeResult("LOKI", "", "SKIPPED", error="Loki URL not found")
    try:
        def work() -> Dict[str, Any]:
            details: Dict[str, Any] = {}
            ready_status, ready, _ = _http_get(url, "/ready", cfg, timeout, verify_tls)
            details["ready_http_status"] = ready_status
            details["ready"] = ready
            for name, path in (("buildinfo", "/loki/api/v1/status/buildinfo"), ("labels", "/loki/api/v1/labels"), ("series", "/loki/api/v1/series?match[]={job=~\".+\"}&start=0")):
                try:
                    status, data, _ = _http_get(url, path, cfg, timeout, verify_tls)
                    if name == "series" and isinstance(data, dict) and isinstance(data.get("data"), list):
                        data["data"] = data["data"][:max_rows]
                    details[name] = data
                    details[f"{name}_http_status"] = status
                except Exception as exc:
                    details[f"{name}_warning"] = str(exc)
            return details

        details, latency = _timed(work)
        status = "UP" if int(details.get("ready_http_status", 500)) < 400 else "DOWN"
        return ProbeResult("LOKI", url, status, latency, details)
    except Exception as exc:
        return ProbeResult("LOKI", url, "DOWN", error=str(exc))


PROBE_FUNCTIONS = {
    "ORACLE": probe_oracle,
    "REDIS": probe_redis,
    "ELASTICSEARCH": probe_elasticsearch,
    "KAFKA": probe_kafka,
    "GRAFANA": probe_grafana,
    "PROMETHEUS": probe_prometheus,
    "LOKI": probe_loki,
}
