from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence, Tuple

from .config_loader import mask_text
from .file_utils import read_text_safely


def _line(text: str, offset: int) -> int:
    return text.count("\n", 0, max(0, offset)) + 1


def _rel(path: Path, root: Path) -> str:
    return str(path.relative_to(root)).replace("\\", "/")


def _dedupe(rows: Iterable[Dict[str, Any]], keys: Sequence[str]) -> List[Dict[str, Any]]:
    result: Dict[Tuple[Any, ...], Dict[str, Any]] = {}
    for row in rows:
        result[tuple(row.get(key) for key in keys)] = row
    return list(result.values())


def _class_at(text: str, offset: int, fallback: str) -> str:
    matches = list(re.finditer(r"\b(?:class|interface|record|object)\s+([A-Za-z_$][\w$]*)", text[:offset]))
    return matches[-1].group(1) if matches else fallback


def _next_method(text: str, offset: int) -> str:
    snippet = text[offset: offset + 1200]
    patterns = (
        re.compile(r"\b(?:public|protected|private|internal|open|override|suspend|static|final|\s)+[A-Za-z_$][\w$<>,.?\[\] ]*\s+([A-Za-z_$][\w$]*)\s*\("),
        re.compile(r"\bfun\s+([A-Za-z_$][\w$]*)\s*\("),
    )
    for pattern in patterns:
        match = pattern.search(snippet)
        if match:
            return match.group(1)
    return "확인필요"


def _clean(value: str) -> str:
    value = str(value or "").strip().strip("\"'`")
    return mask_text(re.sub(r"\s+", " ", value))


def parse_spring_file(path: Path, root: Path) -> Dict[str, Any]:
    rel = _rel(path, root)
    text = read_text_safely(path, max_chars=5_000_000)
    lower = text.lower()
    is_spring = any(token in lower for token in (
        "org.springframework", "@springbootapplication", "@restcontroller", "@controller",
        "routerfunction", "@configurationproperties", "securityfilterchain",
    ))
    if not is_spring:
        return {
            "is_spring": False, "applications": [], "functional_routes": [], "security_rules": [],
            "configuration_properties": [], "scheduled_jobs": [], "event_listeners": [],
            "clients": [], "actuator_endpoints": [], "profiles": [], "transactions": [],
        }

    applications: List[Dict[str, Any]] = []
    functional_routes: List[Dict[str, Any]] = []
    security_rules: List[Dict[str, Any]] = []
    configuration_properties: List[Dict[str, Any]] = []
    scheduled_jobs: List[Dict[str, Any]] = []
    event_listeners: List[Dict[str, Any]] = []
    clients: List[Dict[str, Any]] = []
    actuator_endpoints: List[Dict[str, Any]] = []
    profiles: List[Dict[str, Any]] = []
    transactions: List[Dict[str, Any]] = []

    for match in re.finditer(r"@SpringBootApplication(?:\s*\([^)]*\))?", text, re.I | re.S):
        applications.append({
            "application_class": _class_at(text, match.start() + len(match.group(0)) + 500, path.stem),
            "source_path": rel, "line": _line(text, match.start()),
            "evidence": mask_text(match.group(0)),
        })

    # Spring WebFlux/RouterFunction Java and Kotlin DSL.
    route_patterns = (
        re.compile(r"\.(?P<method>GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s*\(\s*[\"'](?P<path>[^\"']+)[\"']\s*,\s*(?P<handler>[^\)\n]+)", re.I),
        re.compile(r"(?:RouterFunctions\.)?route\s*\(\s*(?:RequestPredicates\.)?(?P<method>GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s*\(\s*[\"'](?P<path>[^\"']+)[\"']\s*\)\s*,\s*(?P<handler>[^\)\n]+)", re.I),
        re.compile(r"\b(?P<method>GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s*\(\s*[\"'](?P<path>[^\"']+)[\"']\s*,\s*(?P<handler>[^\)\n]+)\)", re.I),
    )
    for pattern in route_patterns:
        for match in pattern.finditer(text):
            functional_routes.append({
                "framework": "SPRING_BOOT", "controller": _class_at(text, match.start(), path.stem),
                "method_name": _clean(match.group("handler")), "http_method": match.group("method").upper(),
                "path": match.group("path"), "request_params": [], "response_type": "ServerResponse/확인필요",
                "route_style": "FUNCTIONAL", "source_path": rel, "line": _line(text, match.start()),
                "annotation": "RouterFunction", "evidence": mask_text(match.group(0)[:500]),
            })

    # SecurityFilterChain DSL / legacy WebSecurityConfigurer.
    matcher_pattern = re.compile(
        r"\.(?:requestMatchers|antMatchers|mvcMatchers)\s*\((?P<paths>[^)]*)\)"
        r"(?P<tail>.{0,240}?)(?:\.permitAll\s*\(\)|\.authenticated\s*\(\)|\.denyAll\s*\(\)|\.hasRole\s*\([^)]*\)|\.hasAuthority\s*\([^)]*\)|\.hasAnyRole\s*\([^)]*\)|\.hasAnyAuthority\s*\([^)]*\))",
        re.I | re.S,
    )
    for match in matcher_pattern.finditer(text):
        tail = match.group("tail") or ""
        action_match = re.search(r"\.(permitAll|authenticated|denyAll|hasRole|hasAuthority|hasAnyRole|hasAnyAuthority)\s*\(([^)]*)\)", tail, re.I | re.S)
        action = action_match.group(1) if action_match else "확인필요"
        roles = re.findall(r"[\"']([^\"']+)[\"']", action_match.group(2) if action_match else "")
        paths = re.findall(r"[\"']([^\"']+)[\"']", match.group("paths")) or [_clean(match.group("paths"))]
        for route_path in paths:
            security_rules.append({
                "path": route_path, "rule": action, "roles": roles,
                "source_component": _class_at(text, match.start(), path.stem),
                "source_path": rel, "line": _line(text, match.start()),
                "evidence": mask_text(match.group(0)[:600]),
            })

    for annotation in ("PreAuthorize", "PostAuthorize", "Secured", "RolesAllowed"):
        for match in re.finditer(rf"@{annotation}\s*\((?P<expr>.*?)\)", text, re.I | re.S):
            security_rules.append({
                "path": "METHOD", "rule": annotation, "roles": re.findall(r"[\"']([^\"']+)[\"']", match.group("expr")),
                "expression": _clean(match.group("expr")), "method": _next_method(text, match.end()),
                "source_component": _class_at(text, match.start(), path.stem),
                "source_path": rel, "line": _line(text, match.start()),
                "evidence": mask_text(match.group(0)[:500]),
            })

    for match in re.finditer(r"@ConfigurationProperties\s*\((.*?)\)", text, re.I | re.S):
        raw = match.group(1)
        prefix_match = re.search(r"\b(?:prefix|value)\s*=\s*[\"']([^\"']+)", raw)
        if not prefix_match:
            prefix_match = re.search(r"[\"']([^\"']+)[\"']", raw)
        configuration_properties.append({
            "prefix": prefix_match.group(1) if prefix_match else "확인필요",
            "class": _class_at(text, match.end() + 500, path.stem), "source_path": rel,
            "line": _line(text, match.start()), "source_type": "@ConfigurationProperties",
        })
    for match in re.finditer(r"@Value\s*\(\s*[\"']\$\{([^}:]+)(?::[^}]*)?\}[\"']\s*\)", text, re.I):
        configuration_properties.append({
            "prefix": match.group(1), "class": _class_at(text, match.start(), path.stem),
            "source_path": rel, "line": _line(text, match.start()), "source_type": "@Value",
        })

    for match in re.finditer(r"@Scheduled\s*\((.*?)\)", text, re.I | re.S):
        scheduled_jobs.append({
            "class": _class_at(text, match.start(), path.stem), "method": _next_method(text, match.end()),
            "schedule": _clean(match.group(1)), "source_path": rel, "line": _line(text, match.start()),
        })
    for annotation in ("EventListener", "TransactionalEventListener", "KafkaListener", "JmsListener", "RabbitListener"):
        for match in re.finditer(rf"@{annotation}(?:\s*\((.*?)\))?", text, re.I | re.S):
            event_listeners.append({
                "listener_type": annotation, "class": _class_at(text, match.start(), path.stem),
                "method": _next_method(text, match.end()), "detail": _clean(match.group(1) or ""),
                "source_path": rel, "line": _line(text, match.start()),
            })

    client_patterns = (
        ("RestTemplate", "GET", re.compile(r"\.(?:getForObject|getForEntity)\s*\(\s*([^,\)]+)", re.I)),
        ("RestTemplate", "POST", re.compile(r"\.postFor(?:Object|Entity|Location)\s*\(\s*([^,\)]+)", re.I)),
        ("RestTemplate", "EXCHANGE", re.compile(r"\.exchange\s*\(\s*([^,\)]+)", re.I)),
        ("WebClient", "GET", re.compile(r"\.get\s*\(\s*\)\s*\.uri\s*\(\s*([^,\)]+)", re.I)),
        ("WebClient", "POST", re.compile(r"\.post\s*\(\s*\)\s*\.uri\s*\(\s*([^,\)]+)", re.I)),
        ("WebClient", "PUT", re.compile(r"\.put\s*\(\s*\)\s*\.uri\s*\(\s*([^,\)]+)", re.I)),
        ("WebClient", "DELETE", re.compile(r"\.delete\s*\(\s*\)\s*\.uri\s*\(\s*([^,\)]+)", re.I)),
        ("RestClient", "GET", re.compile(r"\.get\s*\(\s*\)\s*\.uri\s*\(\s*([^,\)]+)", re.I)),
    )
    client_id = 0
    for client_type, method, pattern in client_patterns:
        for match in pattern.finditer(text):
            client_id += 1
            clients.append({
                "call_id": f"SPRING-{rel}:{client_id}", "framework": "SPRING_BOOT", "client_type": client_type,
                "http_method": method, "path": _clean(match.group(1)),
                "source_component": _class_at(text, match.start(), path.stem),
                "source_path": rel, "line": _line(text, match.start()),
                "evidence": mask_text(match.group(0)[:500]),
            })

    for match in re.finditer(r"@Endpoint\s*\((.*?)\)", text, re.I | re.S):
        raw = match.group(1)
        id_match = re.search(r"\bid\s*=\s*[\"']([^\"']+)", raw)
        actuator_endpoints.append({
            "id": id_match.group(1) if id_match else "확인필요",
            "class": _class_at(text, match.end() + 500, path.stem),
            "source_path": rel, "line": _line(text, match.start()),
        })
    for match in re.finditer(r"@Profile\s*\((.*?)\)", text, re.I | re.S):
        profiles.append({
            "profiles": re.findall(r"[\"']([^\"']+)[\"']", match.group(1)),
            "class": _class_at(text, match.start(), path.stem), "source_path": rel,
            "line": _line(text, match.start()),
        })
    for match in re.finditer(r"@Transactional(?:\s*\((.*?)\))?", text, re.I | re.S):
        transactions.append({
            "class": _class_at(text, match.start(), path.stem), "method": _next_method(text, match.end()),
            "detail": _clean(match.group(1) or ""), "source_path": rel, "line": _line(text, match.start()),
        })

    return {
        "is_spring": True,
        "applications": _dedupe(applications, ("application_class", "source_path", "line")),
        "functional_routes": _dedupe(functional_routes, ("http_method", "path", "source_path", "line")),
        "security_rules": _dedupe(security_rules, ("path", "rule", "source_path", "line")),
        "configuration_properties": _dedupe(configuration_properties, ("prefix", "class", "source_path", "line")),
        "scheduled_jobs": _dedupe(scheduled_jobs, ("class", "method", "source_path", "line")),
        "event_listeners": _dedupe(event_listeners, ("listener_type", "class", "method", "source_path", "line")),
        "clients": _dedupe(clients, ("call_id",)),
        "actuator_endpoints": _dedupe(actuator_endpoints, ("id", "class", "source_path", "line")),
        "profiles": _dedupe(profiles, ("class", "source_path", "line")),
        "transactions": _dedupe(transactions, ("class", "method", "source_path", "line")),
    }
