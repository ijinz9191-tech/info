from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from .file_utils import read_text_safely

CREATE_TABLE_RE = re.compile(
    r"CREATE\s+(?:GLOBAL\s+TEMPORARY\s+)?TABLE\s+(?P<name>[\w\.\`\"\[\]$#]+)\s*\((?P<body>.*?)\)\s*(?:TABLESPACE\s+\S+)?\s*;",
    re.I | re.S,
)
FK_RE = re.compile(
    r"(?:CONSTRAINT\s+(?P<constraint>[\w\"$#]+)\s+)?FOREIGN\s+KEY\s*\((?P<cols>[^)]+)\)\s+REFERENCES\s+(?P<table>[\w\.\`\"\[\]$#]+)\s*\((?P<refcols>[^)]+)\)",
    re.I,
)
PK_RE = re.compile(r"(?:CONSTRAINT\s+(?P<constraint>[\w\"$#]+)\s+)?PRIMARY\s+KEY\s*\((?P<cols>[^)]+)\)", re.I)
UNIQUE_RE = re.compile(r"(?:CONSTRAINT\s+(?P<constraint>[\w\"$#]+)\s+)?UNIQUE\s*\((?P<cols>[^)]+)\)", re.I)
COMMENT_TABLE_RE = re.compile(r"COMMENT\s+ON\s+TABLE\s+([\w\.\"$#]+)\s+IS\s+'((?:''|[^'])*)'", re.I | re.S)
COMMENT_COLUMN_RE = re.compile(r"COMMENT\s+ON\s+COLUMN\s+([\w\.\"$#]+)\.([\w\"$#]+)\s+IS\s+'((?:''|[^'])*)'", re.I | re.S)
SEQUENCE_RE = re.compile(r"CREATE\s+SEQUENCE\s+([\w\.\"$#]+)(.*?);", re.I | re.S)
INDEX_RE = re.compile(r"CREATE\s+(UNIQUE\s+)?INDEX\s+([\w\.\"$#]+)\s+ON\s+([\w\.\"$#]+)\s*\(([^)]+)\)", re.I | re.S)
VIEW_RE = re.compile(r"CREATE\s+(?:OR\s+REPLACE\s+)?(?:FORCE\s+)?VIEW\s+([\w\.\"$#]+)\s+AS\s+(.*?);", re.I | re.S)
PROGRAM_RE = re.compile(r"CREATE\s+(?:OR\s+REPLACE\s+)?(?:EDITIONABLE\s+|NONEDITIONABLE\s+)?(PACKAGE(?:\s+BODY)?|PROCEDURE|FUNCTION|TRIGGER)\s+([\w\.\"$#]+)", re.I)
SYNONYM_RE = re.compile(r"CREATE\s+(?:OR\s+REPLACE\s+)?(?:PUBLIC\s+)?SYNONYM\s+([\w\.\"$#]+)\s+FOR\s+([\w\.\"$#@]+)", re.I)

SQL_REF_PATTERNS: Sequence[Tuple[str, re.Pattern[str]]] = (
    ("READ", re.compile(r"\b(?:FROM|JOIN)\s+([A-Za-z0-9_$#\.\"`]+)", re.I)),
    ("INSERT", re.compile(r"\bINSERT\s+INTO\s+([A-Za-z0-9_$#\.\"`]+)", re.I)),
    ("UPDATE", re.compile(r"\bUPDATE\s+([A-Za-z0-9_$#\.\"`]+)", re.I)),
    ("DELETE", re.compile(r"\bDELETE\s+FROM\s+([A-Za-z0-9_$#\.\"`]+)", re.I)),
    ("UPSERT", re.compile(r"\bMERGE\s+INTO\s+([A-Za-z0-9_$#\.\"`]+)", re.I)),
)


def _line(text: str, offset: int) -> int:
    return text.count("\n", 0, max(0, offset)) + 1


def clean_name(name: str) -> str:
    return name.strip().strip('`"[]')


def split_qualified_name(name: str) -> Tuple[str, str]:
    clean = clean_name(name)
    if "." in clean:
        schema, obj = clean.rsplit(".", 1)
        return clean_name(schema), clean_name(obj)
    return "", clean


def split_sql_columns(body: str) -> List[str]:
    result: List[str] = []
    buf: List[str] = []
    depth = 0
    in_string = False
    i = 0
    while i < len(body):
        ch = body[i]
        if ch == "'":
            if in_string and i + 1 < len(body) and body[i + 1] == "'":
                buf.extend([ch, body[i + 1]])
                i += 2
                continue
            in_string = not in_string
        elif not in_string:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth = max(0, depth - 1)
            elif ch == "," and depth == 0:
                item = "".join(buf).strip()
                if item:
                    result.append(item)
                buf = []
                i += 1
                continue
        buf.append(ch)
        i += 1
    item = "".join(buf).strip()
    if item:
        result.append(item)
    return result


def _parse_column_definition(part: str) -> Optional[Dict[str, Any]]:
    tokens = re.findall(r'"[^"]+"|\S+', part.strip())
    if len(tokens) < 2:
        return None
    col_name = clean_name(tokens[0])
    # Oracle types can have precision/length and TIMESTAMP WITH TIME ZONE.
    type_tokens = [tokens[1]]
    if len(tokens) > 2 and tokens[2].upper() in {"WITH", "WITHOUT"}:
        type_tokens.extend(tokens[2:5])
    data_type = " ".join(type_tokens).rstrip(",")
    upper = part.upper()
    nullable = "N" if "NOT NULL" in upper else "Y"
    default = ""
    dm = re.search(r"\bDEFAULT\s+(.+?)(?=\s+(?:NOT\s+NULL|NULL|CONSTRAINT|PRIMARY\s+KEY|UNIQUE|REFERENCES)\b|$)", part, re.I | re.S)
    if dm:
        default = dm.group(1).strip()
    return {"column_name": col_name, "data_type": data_type, "nullable": nullable, "default": default}


def extract_sql_references(sql: str, source_path: str, statement_id: str = "") -> List[Dict[str, Any]]:
    refs: List[Dict[str, Any]] = []
    for operation, pattern in SQL_REF_PATTERNS:
        for match in pattern.finditer(sql):
            schema, table = split_qualified_name(match.group(1))
            if table.upper() in {"SELECT", "DUAL", "VALUES", "SET"}:
                continue
            refs.append({
                "operation": operation,
                "schema": schema,
                "table_name": table,
                "statement_id": statement_id,
                "source_path": source_path,
                "line": _line(sql, match.start()),
            })
    seen = set()
    out = []
    for ref in refs:
        key = (ref["operation"], ref["schema"], ref["table_name"], ref["statement_id"], ref["source_path"])
        if key not in seen:
            seen.add(key)
            out.append(ref)
    return out


def parse_sql_file(path: Path, root: Path) -> Dict[str, Any]:
    rel = str(path.relative_to(root)).replace("\\", "/")
    text = read_text_safely(path, max_chars=10_000_000)
    tables: List[Dict[str, Any]] = []
    columns: List[Dict[str, Any]] = []
    relations: List[Dict[str, Any]] = []
    comments: List[Dict[str, Any]] = []
    sequences: List[Dict[str, Any]] = []
    indexes: List[Dict[str, Any]] = []
    views: List[Dict[str, Any]] = []
    programs: List[Dict[str, Any]] = []
    synonyms: List[Dict[str, Any]] = []

    table_comment_map: Dict[Tuple[str, str], str] = {}
    column_comment_map: Dict[Tuple[str, str, str], str] = {}
    for m in COMMENT_TABLE_RE.finditer(text):
        schema, table = split_qualified_name(m.group(1))
        comment = m.group(2).replace("''", "'")
        table_comment_map[(schema, table)] = comment
        comments.append({"object_type": "TABLE", "schema": schema, "table_name": table, "column_name": "", "comment": comment, "source_path": rel, "line": _line(text, m.start())})
    for m in COMMENT_COLUMN_RE.finditer(text):
        full_table = m.group(1)
        schema, table = split_qualified_name(full_table)
        column = clean_name(m.group(2))
        comment = m.group(3).replace("''", "'")
        column_comment_map[(schema, table, column)] = comment
        comments.append({"object_type": "COLUMN", "schema": schema, "table_name": table, "column_name": column, "comment": comment, "source_path": rel, "line": _line(text, m.start())})

    for tm in CREATE_TABLE_RE.finditer(text):
        schema_name, table_name = split_qualified_name(tm.group("name"))
        tables.append({
            "schema": schema_name, "table_name": table_name, "comment": table_comment_map.get((schema_name, table_name), ""),
            "source_path": rel, "source_type": "sql", "line": _line(text, tm.start()),
        })
        for part in split_sql_columns(tm.group("body")):
            part_clean = part.strip()
            if not part_clean:
                continue
            upper = part_clean.upper()
            if upper.startswith(("CONSTRAINT", "PRIMARY KEY", "FOREIGN KEY", "UNIQUE", "KEY", "INDEX", "CHECK")):
                pk = PK_RE.search(part_clean)
                if pk:
                    for col in pk.group("cols").split(","):
                        relations.append({"type": "PK", "constraint_name": clean_name(pk.group("constraint") or ""), "schema": schema_name, "table_name": table_name, "column_name": clean_name(col), "source_path": rel, "line": _line(text, tm.start())})
                fk = FK_RE.search(part_clean)
                if fk:
                    ref_schema, ref_table = split_qualified_name(fk.group("table"))
                    relations.append({
                        "type": "FK", "constraint_name": clean_name(fk.group("constraint") or ""), "schema": schema_name,
                        "table_name": table_name, "column_name": ",".join(clean_name(c) for c in fk.group("cols").split(",")),
                        "ref_schema": ref_schema, "ref_table": ref_table,
                        "ref_column": ",".join(clean_name(c) for c in fk.group("refcols").split(",")),
                        "source_path": rel, "line": _line(text, tm.start()),
                    })
                uq = UNIQUE_RE.search(part_clean)
                if uq:
                    for col in uq.group("cols").split(","):
                        relations.append({"type": "UNIQUE", "constraint_name": clean_name(uq.group("constraint") or ""), "schema": schema_name, "table_name": table_name, "column_name": clean_name(col), "source_path": rel, "line": _line(text, tm.start())})
                continue
            parsed = _parse_column_definition(part_clean)
            if parsed:
                parsed.update({
                    "schema": schema_name, "table_name": table_name,
                    "comment": column_comment_map.get((schema_name, table_name, parsed["column_name"]), ""),
                    "source_path": rel, "source_type": "sql", "line": _line(text, tm.start()),
                })
                columns.append(parsed)
                if "PRIMARY KEY" in upper:
                    relations.append({"type": "PK", "constraint_name": "", "schema": schema_name, "table_name": table_name, "column_name": parsed["column_name"], "source_path": rel, "line": _line(text, tm.start())})
                if "UNIQUE" in upper:
                    relations.append({"type": "UNIQUE", "constraint_name": "", "schema": schema_name, "table_name": table_name, "column_name": parsed["column_name"], "source_path": rel, "line": _line(text, tm.start())})

    for m in SEQUENCE_RE.finditer(text):
        schema, name = split_qualified_name(m.group(1))
        options = m.group(2)
        start = re.search(r"START\s+WITH\s+(\S+)", options, re.I)
        increment = re.search(r"INCREMENT\s+BY\s+(\S+)", options, re.I)
        sequences.append({"schema": schema, "sequence_name": name, "start_with": start.group(1) if start else "", "increment_by": increment.group(1) if increment else "", "source_path": rel, "line": _line(text, m.start())})
    for m in INDEX_RE.finditer(text):
        idx_schema, idx_name = split_qualified_name(m.group(2))
        table_schema, table_name = split_qualified_name(m.group(3))
        indexes.append({"schema": idx_schema or table_schema, "index_name": idx_name, "table_name": table_name, "columns": m.group(4).strip(), "unique": bool(m.group(1)), "source_path": rel, "line": _line(text, m.start())})
    for m in VIEW_RE.finditer(text):
        schema, name = split_qualified_name(m.group(1))
        views.append({"schema": schema, "view_name": name, "query_sample": re.sub(r"\s+", " ", m.group(2)).strip()[:2000], "source_path": rel, "line": _line(text, m.start())})
    for m in PROGRAM_RE.finditer(text):
        schema, name = split_qualified_name(m.group(2))
        programs.append({"schema": schema, "object_name": name, "object_type": m.group(1).upper(), "source_path": rel, "line": _line(text, m.start())})
    for m in SYNONYM_RE.finditer(text):
        schema, name = split_qualified_name(m.group(1))
        target_schema, target = split_qualified_name(m.group(2).split("@", 1)[0])
        synonyms.append({"schema": schema, "synonym_name": name, "target_schema": target_schema, "target_object": target, "db_link": m.group(2).split("@", 1)[1] if "@" in m.group(2) else "", "source_path": rel, "line": _line(text, m.start())})

    return {
        "tables": tables, "columns": columns, "relations": relations, "comments": comments,
        "sequences": sequences, "indexes": indexes, "views": views, "programs": programs,
        "synonyms": synonyms, "sql_references": extract_sql_references(text, rel),
    }


def parse_mybatis_mapper(path: Path, root: Path) -> Dict[str, Any]:
    rel = str(path.relative_to(root)).replace("\\", "/")
    text = read_text_safely(path, max_chars=8_000_000)
    result: List[Dict[str, Any]] = []
    references: List[Dict[str, Any]] = []
    try:
        xml = ET.fromstring(text)
        namespace = xml.attrib.get("namespace", "")
        for child in list(xml):
            tag = child.tag.split("}")[-1]
            if tag in {"select", "insert", "update", "delete"}:
                statement_text = " ".join("".join(child.itertext()).split())
                statement_id = child.attrib.get("id", "")
                result.append({
                    "namespace": namespace, "sql_type": tag.upper(), "id": statement_id,
                    "parameter_type": child.attrib.get("parameterType", ""),
                    "result_type": child.attrib.get("resultType", "") or child.attrib.get("resultMap", ""),
                    "database_id": child.attrib.get("databaseId", ""), "sql_sample": statement_text[:3000],
                    "source_path": rel, "line": 0,
                })
                references.extend(extract_sql_references(statement_text, rel, f"{namespace}.{statement_id}"))
    except Exception:
        ns_m = re.search(r"<mapper[^>]+namespace=[\'\"]([^\'\"]+)[\'\"]", text)
        namespace = ns_m.group(1) if ns_m else ""
        for m in re.finditer(r"<(select|insert|update|delete)[^>]+id=[\'\"]([^\'\"]+)[\'\"][^>]*>(.*?)</\1>", text, re.I | re.S):
            statement_text = re.sub(r"<[^>]+>", " ", m.group(3))
            statement_text = " ".join(statement_text.split())
            result.append({"namespace": namespace, "sql_type": m.group(1).upper(), "id": m.group(2), "sql_sample": statement_text[:3000], "source_path": rel, "line": _line(text, m.start())})
            references.extend(extract_sql_references(statement_text, rel, f"{namespace}.{m.group(2)}"))
    return {"mappers": result, "sql_references": references}
