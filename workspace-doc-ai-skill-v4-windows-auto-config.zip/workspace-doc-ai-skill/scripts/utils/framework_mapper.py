from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence, Tuple
from urllib.parse import urlparse


def _dedupe(rows: Iterable[Dict[str, Any]], keys: Sequence[str]) -> List[Dict[str, Any]]:
    result: Dict[Tuple[Any, ...], Dict[str, Any]] = {}
    for row in rows:
        result[tuple(row.get(key) for key in keys)] = row
    return list(result.values())


def normalize_api_path(value: Any) -> str:
    raw = str(value or "").strip().strip("\"'`")
    if not raw:
        return ""
    raw = raw.replace("\\/", "/")
    parsed = urlparse(raw) if re.match(r"^[a-z]+://", raw, re.I) else None
    if parsed and parsed.scheme:
        raw = parsed.path or "/"
    raw = re.sub(r"\?.*$", "", raw)
    raw = re.sub(r"#.*$", "", raw)
    raw = re.sub(r"\$\{[^}]+\}", "{*}", raw)
    raw = re.sub(r"\{[^}/]+\}", "{*}", raw)
    raw = re.sub(r":[A-Za-z_][A-Za-z0-9_]*", "{*}", raw)
    raw = re.sub(r"\+\s*[A-Za-z_$][\w$]*(?:\.[\w$]+)*", "{*}", raw)
    raw = re.sub(r"\b\d+\b", "{*}", raw)
    raw = re.sub(r"^\$\{[^}]+\}", "", raw)
    raw = re.sub(r"^[A-Za-z_$][\w$]*(?:\.[\w$]+)*\s*\+", "", raw)
    raw = raw.strip()
    if raw and not raw.startswith("/") and ("/" in raw or raw in {"*"}):
        raw = "/" + raw
    raw = re.sub(r"/{2,}", "/", raw)
    if len(raw) > 1:
        raw = raw.rstrip("/")
    return raw


def _segments(path: str) -> List[str]:
    return [x for x in path.strip("/").split("/") if x]


def _pattern_match(left: str, right: str) -> bool:
    a, b = _segments(left), _segments(right)
    if len(a) != len(b):
        return False
    for x, y in zip(a, b):
        if x == "{*}" or y == "{*}":
            continue
        if x != y:
            return False
    return True


def _match_score(call_method: str, call_path: str, endpoint_method: str, endpoint_path: str) -> Tuple[int, str]:
    method = str(call_method or "").upper()
    target_method = str(endpoint_method or "ANY").upper()
    if method and target_method not in {"ANY", method} and method not in {"HTTP", "REQUEST"}:
        return 0, "METHOD_MISMATCH"
    method_score = 25 if method == target_method else 10
    cp = normalize_api_path(call_path)
    ep = normalize_api_path(endpoint_path)
    if not cp or not ep or cp == "확인필요" or ep == "확인필요":
        return 0, "UNKNOWN"
    if cp == ep:
        return method_score + 75, "EXACT"
    if _pattern_match(cp, ep):
        return method_score + 65, "PATTERN"
    # Base path differences are common when proxy/baseURL is configured.
    if cp.endswith(ep) or ep.endswith(cp):
        shorter = min(len(_segments(cp)), len(_segments(ep)))
        if shorter >= 2:
            return method_score + 48, "SUFFIX"
    call_segments, endpoint_segments = _segments(cp), _segments(ep)
    if call_segments and endpoint_segments and call_segments[-1] == endpoint_segments[-1]:
        common = sum(1 for x, y in zip(reversed(call_segments), reversed(endpoint_segments)) if x == y or "{*}" in {x, y})
        if common >= 2:
            return method_score + 35 + common, "PARTIAL"
    return 0, "UNMATCHED"


def build_backend_endpoints(
    spring_annotation_endpoints: Sequence[Dict[str, Any]], spring_functional_routes: Sequence[Dict[str, Any]],
    vertx_routes: Sequence[Dict[str, Any]], module_resolver,
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    index = 0
    for endpoint in list(spring_annotation_endpoints) + list(spring_functional_routes):
        index += 1
        row = dict(endpoint)
        row["endpoint_id"] = f"SPRING-ENDPOINT-{index}"
        row["framework"] = "SPRING_BOOT"
        row["route_style"] = row.get("route_style") or "ANNOTATION"
        row["component"] = row.get("controller", "")
        row["handler"] = row.get("method_name", "")
        row["module"] = row.get("module") or module_resolver(row.get("source_path", ""))
        row["normalized_path"] = normalize_api_path(row.get("path"))
        rows.append(row)
    for route in vertx_routes:
        index += 1
        actual_path = route.get("mounted_path") or route.get("path")
        rows.append({
            "endpoint_id": f"VERTX-ENDPOINT-{index}", "framework": "VERTX", "route_style": "ROUTER",
            "component": route.get("source_component", ""), "handler": route.get("handler", ""),
            "controller": route.get("source_component", ""), "method_name": route.get("handler", ""),
            "http_method": route.get("http_method", "ANY"), "path": actual_path,
            "normalized_path": normalize_api_path(actual_path), "request_params": [],
            "response_type": ", ".join(route.get("produces", []) or []) or "RoutingContext response",
            "consumes": route.get("consumes", []), "produces": route.get("produces", []),
            "module": module_resolver(route.get("source_path", "")),
            "source_path": route.get("source_path", ""), "line": route.get("line", 0),
            "evidence": route.get("evidence", ""),
        })
    return _dedupe(rows, ("framework", "http_method", "path", "component", "handler", "source_path", "line"))


def match_calls_to_endpoints(
    calls: Sequence[Dict[str, Any]], endpoints: Sequence[Dict[str, Any]], caller_framework: str,
) -> List[Dict[str, Any]]:
    mappings: List[Dict[str, Any]] = []
    for call in calls:
        scored = []
        for endpoint in endpoints:
            score, match_type = _match_score(
                call.get("http_method", ""), call.get("path", ""),
                endpoint.get("http_method", ""), endpoint.get("path", ""),
            )
            if score > 0:
                scored.append((score, match_type, endpoint))
        scored.sort(key=lambda item: (-item[0], item[2].get("framework", ""), item[2].get("path", "")))
        if not scored:
            mappings.append({
                "call_id": call.get("call_id", ""), "caller_framework": caller_framework,
                "caller_component": call.get("caller_component") or call.get("source_component", ""),
                "http_method": call.get("http_method", ""), "call_path": call.get("path", ""),
                "normalized_call_path": normalize_api_path(call.get("path")),
                "status": "UNMATCHED", "match_type": "UNMATCHED", "confidence": "LOW",
                "backend_framework": "", "backend_component": "", "backend_handler": "",
                "backend_method": "", "backend_path": "", "endpoint_id": "",
                "source_path": call.get("source_path", ""), "line": call.get("line", 0),
            })
            continue
        best_score = scored[0][0]
        best = [item for item in scored if item[0] == best_score]
        status = "AMBIGUOUS" if len(best) > 1 else "MATCHED"
        for score, match_type, endpoint in best[:10]:
            confidence = "HIGH" if score >= 90 else "MEDIUM" if score >= 65 else "LOW"
            mappings.append({
                "call_id": call.get("call_id", ""), "caller_framework": caller_framework,
                "caller_component": call.get("caller_component") or call.get("source_component", ""),
                "http_method": call.get("http_method", ""), "call_path": call.get("path", ""),
                "normalized_call_path": normalize_api_path(call.get("path")),
                "status": status, "match_type": match_type, "score": score, "confidence": confidence,
                "backend_framework": endpoint.get("framework", ""),
                "backend_component": endpoint.get("component", ""), "backend_handler": endpoint.get("handler", ""),
                "backend_method": endpoint.get("http_method", ""), "backend_path": endpoint.get("path", ""),
                "endpoint_id": endpoint.get("endpoint_id", ""),
                "backend_source_path": endpoint.get("source_path", ""), "backend_line": endpoint.get("line", 0),
                "source_path": call.get("source_path", ""), "line": call.get("line", 0),
            })
    return mappings


def build_route_api_links(
    routes: Sequence[Dict[str, Any]], calls: Sequence[Dict[str, Any]], mappings: Sequence[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    mapping_by_call: Dict[str, List[Dict[str, Any]]] = {}
    for mapping in mappings:
        mapping_by_call.setdefault(mapping.get("call_id", ""), []).append(mapping)
    rows: List[Dict[str, Any]] = []
    for route in routes:
        component = route.get("component", "")
        route_file = route.get("source_path", "")
        linked_calls = [
            call for call in calls
            if (component and component != "확인필요" and call.get("caller_component") == component)
            or (route_file and call.get("source_path") == route_file)
        ]
        if not linked_calls:
            rows.append({
                "route_path": route.get("path", ""), "screen_component": component,
                "api_call_id": "", "api_method": "", "api_path": "", "backend_framework": "",
                "backend_component": "", "backend_handler": "", "backend_path": "",
                "status": "NO_API_CALL_DETECTED", "confidence": "LOW",
                "source_path": route.get("source_path", ""), "line": route.get("line", 0),
            })
            continue
        for call in linked_calls:
            candidates = mapping_by_call.get(call.get("call_id", ""), []) or [{}]
            for mapping in candidates:
                rows.append({
                    "route_path": route.get("path", ""), "screen_component": component,
                    "api_call_id": call.get("call_id", ""), "api_method": call.get("http_method", ""),
                    "api_path": call.get("path", ""), "backend_framework": mapping.get("backend_framework", ""),
                    "backend_component": mapping.get("backend_component", ""), "backend_handler": mapping.get("backend_handler", ""),
                    "backend_path": mapping.get("backend_path", ""), "endpoint_id": mapping.get("endpoint_id", ""),
                    "status": mapping.get("status", "UNMATCHED"),
                    "match_type": mapping.get("match_type", ""), "confidence": mapping.get("confidence", "LOW"),
                    "source_path": route.get("source_path", ""), "line": route.get("line", 0),
                    "api_source_path": call.get("source_path", ""), "api_line": call.get("line", 0),
                    "backend_source_path": mapping.get("backend_source_path", ""), "backend_line": mapping.get("backend_line", 0),
                })
    return _dedupe(rows, ("route_path", "screen_component", "api_call_id", "endpoint_id", "backend_path"))


def match_event_bus(event_bus_rows: Sequence[Dict[str, Any]], service_proxies: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    consumers = [row for row in event_bus_rows if row.get("direction") == "INBOUND"]
    producers = [row for row in event_bus_rows if row.get("direction") == "OUTBOUND"]
    # ServiceBinder registrations are consumers; generated proxies are producers.
    for proxy in service_proxies:
        converted = {
            "operation": "SERVICE_REGISTER" if proxy.get("kind") == "REGISTER" else "SERVICE_PROXY",
            "direction": "INBOUND" if proxy.get("kind") == "REGISTER" else "OUTBOUND",
            "address": proxy.get("address", ""), "source_component": proxy.get("source_component", ""),
            "source_path": proxy.get("source_path", ""), "line": proxy.get("line", 0),
        }
        (consumers if converted["direction"] == "INBOUND" else producers).append(converted)
    rows: List[Dict[str, Any]] = []
    for producer in producers:
        address = str(producer.get("address", ""))
        matches = [consumer for consumer in consumers if consumer.get("address") == address and address not in {"", "확인필요"}]
        if not matches:
            rows.append({
                "address": address, "producer": producer.get("source_component", ""),
                "producer_operation": producer.get("operation", ""), "consumer": "",
                "consumer_operation": "", "status": "UNMATCHED_CONSUMER", "confidence": "LOW",
                "source_path": producer.get("source_path", ""), "line": producer.get("line", 0),
            })
            continue
        for consumer in matches:
            rows.append({
                "address": address, "producer": producer.get("source_component", ""),
                "producer_operation": producer.get("operation", ""), "consumer": consumer.get("source_component", ""),
                "consumer_operation": consumer.get("operation", ""), "status": "MATCHED", "confidence": "HIGH",
                "source_path": producer.get("source_path", ""), "line": producer.get("line", 0),
                "consumer_source_path": consumer.get("source_path", ""), "consumer_line": consumer.get("line", 0),
            })
    for consumer in consumers:
        if not any(row.get("address") == consumer.get("address") and row.get("consumer") == consumer.get("source_component") for row in rows):
            rows.append({
                "address": consumer.get("address", ""), "producer": "", "producer_operation": "",
                "consumer": consumer.get("source_component", ""), "consumer_operation": consumer.get("operation", ""),
                "status": "UNMATCHED_PRODUCER", "confidence": "LOW",
                "source_path": consumer.get("source_path", ""), "line": consumer.get("line", 0),
            })
    return _dedupe(rows, ("address", "producer", "producer_operation", "consumer", "consumer_operation", "status"))


def classify_module_roles(
    modules: List[Dict[str, Any]], react_manifests: Sequence[Dict[str, Any]], react_components: Sequence[Dict[str, Any]],
    spring_apps: Sequence[Dict[str, Any]], spring_components: Sequence[Dict[str, Any]], verticles: Sequence[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    non_root_paths = [str(row.get("module_path", "")).rstrip("/") for row in modules if row.get("module_path") not in {"", "."}]

    def belongs(source_path: str, module_path: str) -> bool:
        source_path = str(source_path or "").lstrip("/")
        if module_path == ".":
            # The root module owns files not already owned by a nested module.
            return not any(source_path == child or source_path.startswith(child + "/") for child in non_root_paths)
        module_path = str(module_path or "").strip("/")
        return source_path == module_path or source_path.startswith(module_path + "/")

    for module in modules:
        module_path = module.get("module_path", ".")
        roles = []
        if any(belongs(row.get("source_path", ""), module_path) for row in react_manifests) or any(belongs(row.get("source_path", ""), module_path) for row in react_components):
            roles.append("REACT_FRONTEND")
        if any(belongs(row.get("source_path", ""), module_path) for row in spring_apps) or any(belongs(row.get("source_path", ""), module_path) for row in spring_components):
            roles.append("SPRING_BOOT_BACKEND")
        if any(belongs(row.get("source_path", ""), module_path) for row in verticles):
            roles.append("VERTX_BACKEND")
        lower = f"{module.get('module_name','')} {module_path}".lower()
        if not roles and any(token in lower for token in ("common", "shared", "core", "library", "framework")):
            roles.append("COMMON_LIBRARY")
        if not roles:
            roles.append("GENERAL")
        module["roles"] = roles
        module["primary_role"] = "+".join(roles)
    return modules


def build_stack_summary(
    react_frameworks: Sequence[Dict[str, Any]], dependencies: Sequence[Dict[str, Any]],
    spring_apps: Sequence[Dict[str, Any]], verticles: Sequence[Dict[str, Any]], modules: Sequence[Dict[str, Any]],
) -> Dict[str, Any]:
    backend_deps = []
    for dep in dependencies:
        gav = f"{dep.get('group','')}:{dep.get('artifact','')}".lower()
        if any(token in gav for token in ("spring-boot", "vertx-", "vertx.")):
            backend_deps.append({
                "coordinate": f"{dep.get('group','')}:{dep.get('artifact','')}",
                "version": dep.get("version", ""), "source_path": dep.get("source_path", ""),
            })
    frontend = {
        "framework": "REACT" if react_frameworks else "확인필요",
        "frameworks": list(react_frameworks),
        "detected": bool(react_frameworks),
    }
    backend_frameworks = []
    if spring_apps or any("spring-boot" in row.get("coordinate", "") for row in backend_deps):
        backend_frameworks.append("SPRING_BOOT")
    if verticles or any("vertx" in row.get("coordinate", "") for row in backend_deps):
        backend_frameworks.append("VERTX")
    return {
        "frontend": frontend,
        "backend": {"frameworks": backend_frameworks, "dependencies": backend_deps},
        "module_roles": [
            {"module_name": row.get("module_name"), "module_path": row.get("module_path"), "roles": row.get("roles", [])}
            for row in modules
        ],
        "coexistence": {
            "spring_and_vertx": "SPRING_BOOT" in backend_frameworks and "VERTX" in backend_frameworks,
            "react_to_multiple_backends": bool(react_frameworks) and len(backend_frameworks) > 1,
        },
    }


def build_framework_edges(
    route_api_links: Sequence[Dict[str, Any]], event_bus_links: Sequence[Dict[str, Any]],
    backend_internal_links: Sequence[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for link in route_api_links:
        if not link.get("api_call_id"):
            continue
        rows.append({
            "edge_type": "REACT_API_BACKEND", "source": f"REACT:{link.get('screen_component') or link.get('route_path')}",
            "target": f"{link.get('backend_framework')}:{link.get('backend_component')}.{link.get('backend_handler')}",
            "operation": f"{link.get('api_method')} {link.get('api_path')}",
            "status": link.get("status"), "confidence": link.get("confidence"),
            "source_path": link.get("source_path", ""), "line": link.get("line", 0),
        })
    for link in event_bus_links:
        rows.append({
            "edge_type": "VERTX_EVENT_BUS", "source": f"VERTX:{link.get('producer') or 'UNKNOWN_PRODUCER'}",
            "target": f"VERTX:{link.get('consumer') or 'UNKNOWN_CONSUMER'}",
            "operation": f"{link.get('producer_operation')} {link.get('address')}",
            "status": link.get("status"), "confidence": link.get("confidence"),
            "source_path": link.get("source_path", ""), "line": link.get("line", 0),
        })
    for link in backend_internal_links:
        if link.get("status") not in {"MATCHED", "AMBIGUOUS"}:
            continue
        rows.append({
            "edge_type": "BACKEND_HTTP_CALL", "source": f"{link.get('caller_framework')}:{link.get('caller_component')}",
            "target": f"{link.get('backend_framework')}:{link.get('backend_component')}.{link.get('backend_handler')}",
            "operation": f"{link.get('http_method')} {link.get('call_path')}",
            "status": link.get("status"), "confidence": link.get("confidence"),
            "source_path": link.get("source_path", ""), "line": link.get("line", 0),
        })
    return _dedupe(rows, ("edge_type", "source", "target", "operation", "source_path", "line"))


def build_mermaid_overview(stack: Dict[str, Any], route_api_links: Sequence[Dict[str, Any]], event_bus_links: Sequence[Dict[str, Any]]) -> str:
    lines = ["flowchart LR", "  U[User] --> R[React UI]"]
    backend_frameworks = stack.get("backend", {}).get("frameworks", [])
    if "SPRING_BOOT" in backend_frameworks:
        lines.append("  R -->|HTTP API| S[Spring Boot]")
    if "VERTX" in backend_frameworks:
        lines.append("  R -->|HTTP API| V[Vert.x]")
    if "SPRING_BOOT" in backend_frameworks and "VERTX" in backend_frameworks:
        lines.append("  S -. HTTP/Event integration .-> V")
    resources = ["Oracle", "Redis", "Elasticsearch", "Kafka"]
    for idx, resource in enumerate(resources, start=1):
        node = f"D{idx}"
        lines.append(f"  S -.-> {node}[{resource}]")
        if "VERTX" in backend_frameworks:
            lines.append(f"  V -.-> {node}")
    if any(row.get("status") == "MATCHED" for row in event_bus_links):
        lines.append("  V -->|EventBus| V")
    lines.append("  S --> P[Prometheus]")
    if "VERTX" in backend_frameworks:
        lines.append("  V --> P")
    lines.extend(["  P --> G[Grafana]", "  S --> L[Loki]", "  V --> L", "  L --> G"])
    return "\n".join(lines) + "\n"
