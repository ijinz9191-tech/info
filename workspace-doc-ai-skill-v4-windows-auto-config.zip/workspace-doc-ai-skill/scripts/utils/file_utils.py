from __future__ import annotations

import fnmatch
import hashlib
import os
from pathlib import Path
from typing import Dict, Iterable, Iterator, Optional

TEXT_EXTENSIONS = {
    ".java", ".kt", ".groovy", ".gradle", ".kts", ".xml", ".sql", ".yml", ".yaml", ".properties",
    ".json", ".md", ".txt", ".js", ".jsx", ".ts", ".tsx", ".vue", ".html", ".css", ".scss",
    ".sh", ".bash", ".zsh", ".bat", ".cmd", ".ps1", ".conf", ".ini", ".toml", ".tf", ".hcl",
    ".env", ".csv", ".graphql", ".proto", "",
}


def sha1_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha1()
    with path.open("rb") as stream:
        while True:
            chunk = stream.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def is_ignored_file(rel: str, ignore_globs: Iterable[str]) -> bool:
    name = Path(rel).name
    return any(fnmatch.fnmatch(name, pattern) or fnmatch.fnmatch(rel, pattern) for pattern in ignore_globs)


def iter_workspace_files(
    root: Path,
    ignore_dirs: Iterable[str],
    ignore_globs: Iterable[str],
    max_file_mb: int,
    max_binary_file_mb: int = 200,
) -> Iterator[Path]:
    ignore_dir_set = set(ignore_dirs or [])
    max_text_bytes = max_file_mb * 1024 * 1024
    max_binary_bytes = max_binary_file_mb * 1024 * 1024
    for current, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = [
            directory for directory in dirs
            if directory not in ignore_dir_set and (not directory.startswith(".") or directory in {".mvn", ".github"})
        ]
        current_path = Path(current)
        for file_name in files:
            path = current_path / file_name
            rel = str(path.relative_to(root)).replace("\\", "/")
            if is_ignored_file(rel, ignore_globs or []):
                continue
            try:
                size = path.stat().st_size
            except OSError:
                continue
            limit = max_binary_bytes if path.suffix.lower() in {".jar", ".war", ".ear"} else max_text_bytes
            if size > limit:
                continue
            yield path


def read_text_safely(path: Path, max_chars: Optional[int] = None) -> str:
    encodings = ["utf-8", "utf-8-sig", "cp949", "euc-kr", "latin-1"]
    data = path.read_bytes()
    if max_chars is not None:
        data = data[: max_chars * 4]
    for encoding in encodings:
        try:
            text = data.decode(encoding)
            return text[:max_chars] if max_chars is not None else text
        except UnicodeDecodeError:
            continue
    text = data.decode("utf-8", errors="ignore")
    return text[:max_chars] if max_chars is not None else text


def classify_file(path: Path) -> str:
    name = path.name.lower()
    ext = path.suffix.lower()
    if name == "pom.xml":
        return "maven-build"
    if name == "package.json":
        return "frontend-manifest"
    if name.startswith("tsconfig") and ext == ".json":
        return "frontend-config"
    if name in {"vite.config.js", "vite.config.ts", "vite.config.mjs", "webpack.config.js", "webpack.config.ts", "craco.config.js"}:
        return "frontend-config"
    if name in {"package-lock.json", "pnpm-lock.yaml", "yarn.lock", "bun.lockb"}:
        return "frontend-lock"
    if name in {"build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts", "libs.versions.toml"}:
        return "gradle-build"
    if ext in {".java", ".kt", ".groovy"}:
        return "jvm-source"
    if ext == ".sql" or name.endswith((".ddl", ".dml", ".pls", ".pkb", ".pks")):
        return "sql"
    if ext == ".xml" and ("mapper" in name or "mybatis" in str(path).lower()):
        return "mybatis-mapper"
    if ext in {".jar", ".war", ".ear"}:
        return "local-jar"
    if ext in {".js", ".jsx", ".ts", ".tsx", ".vue", ".html"}:
        return "frontend"
    if name in {"dockerfile", "containerfile"} or ext in {".tf", ".hcl"}:
        return "infrastructure"
    if ext in {".yml", ".yaml", ".json", ".properties", ".conf", ".ini", ".toml", ".env", ".xml"} or name.startswith(".env"):
        return "config"
    if ext in {".sh", ".bash", ".zsh", ".bat", ".cmd", ".ps1"}:
        return "script"
    if ext in {".md", ".txt"}:
        return "document"
    return "other"


def file_record(root: Path, path: Path) -> Dict[str, object]:
    stat = path.stat()
    rel = str(path.relative_to(root)).replace("\\", "/")
    ext = path.suffix.lower()
    kind = classify_file(path)
    record: Dict[str, object] = {
        "path": rel,
        "name": path.name,
        "extension": ext,
        "size_bytes": stat.st_size,
        "kind": kind,
        "modified_time": int(stat.st_mtime),
    }
    if ext in TEXT_EXTENSIONS or kind == "local-jar":
        try:
            record["sha1"] = sha1_file(path)
        except Exception as exc:
            record["sha1_error"] = str(exc)
    return record
