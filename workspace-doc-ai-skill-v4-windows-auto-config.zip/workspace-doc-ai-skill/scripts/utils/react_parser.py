from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence, Tuple

from .config_loader import mask_text
from .file_utils import read_text_safely

REACT_SOURCE_EXTENSIONS = {".js", ".jsx", ".ts", ".tsx"}


def _line(text: str, offset: int) -> int:
    return text.count("\n", 0, max(0, offset)) + 1


def _rel(path: Path, root: Path) -> str:
    return str(path.relative_to(root)).replace("\\", "/")


def _dedupe(rows: Iterable[Dict[str, Any]], keys: Sequence[str]) -> List[Dict[str, Any]]:
    result: Dict[Tuple[Any, ...], Dict[str, Any]] = {}
    for row in rows:
        result[tuple(row.get(key) for key in keys)] = row
    return list(result.values())


def _clean_js_value(value: str) -> str:
    value = str(value or "").strip().rstrip(",")
    if value.startswith(("\"", "'", "`")) and value[-1:] == value[:1]:
        value = value[1:-1]
    value = re.sub(r"\s+", " ", value).strip()
    return mask_text(value)


def _attr(raw: str, name: str) -> str:
    patterns = [
        re.compile(rf"\b{re.escape(name)}\s*=\s*\"([^\"]*)\"", re.I | re.S),
        re.compile(rf"\b{re.escape(name)}\s*=\s*'([^']*)'", re.I | re.S),
        re.compile(rf"\b{re.escape(name)}\s*=\s*\{{\s*([^}}]+?)\s*\}}", re.I | re.S),
    ]
    for pattern in patterns:
        match = pattern.search(raw or "")
        if match:
            return _clean_js_value(match.group(1))
    return ""


def _first_arg(raw: str) -> str:
    value = str(raw or "").strip()
    if not value:
        return ""
    quote = value[0] if value[0] in {"\"", "'", "`"} else ""
    if quote:
        escaped = False
        for index in range(1, len(value)):
            ch = value[index]
            if escaped:
                escaped = False
                continue
            if ch == "\\":
                escaped = True
                continue
            if ch == quote:
                return value[: index + 1]
        return value
    depth = 0
    for index, ch in enumerate(value):
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth = max(0, depth - 1)
        elif ch == "," and depth == 0:
            return value[:index]
    return value


def _extract_roles(raw: str) -> List[str]:
    role_source = " ".join([
        _attr(raw, "roles"), _attr(raw, "role"), _attr(raw, "authority"),
        _attr(raw, "permissions"), _attr(raw, "permission"),
    ])
    quoted = re.findall(r"[\"']([^\"']+)[\"']", role_source)
    if quoted:
        return sorted(set(x.strip() for x in quoted if x.strip()))
    tokens = [x.strip() for x in re.split(r"[,|\s]+", role_source.strip("[]{}")) if x.strip()]
    return sorted(set(tokens))[:20]


def _component_from_element(raw: str) -> str:
    for name in ("element", "component", "Component"):
        value = _attr(raw, name)
        if not value:
            continue
        match = re.search(r"<\s*([A-Z][A-Za-z0-9_.$]*)", value)
        if match:
            return match.group(1).split(".")[-1]
        match = re.search(r"\b([A-Z][A-Za-z0-9_$]*)\b", value)
        if match:
            return match.group(1)
    lazy = _attr(raw, "lazy")
    if lazy:
        match = re.search(r"import\s*\(\s*[\"']([^\"']+)", lazy)
        if match:
            return Path(match.group(1)).name
    return "확인필요"


def _iter_jsx_open_tags(text: str, tag_name: str) -> Iterable[Tuple[int, str, str]]:
    """Yield complete JSX opening tags while respecting braces and quoted strings."""
    start_pattern = re.compile(rf"<{re.escape(tag_name)}\b", re.I)
    for match in start_pattern.finditer(text):
        index = match.end()
        brace_depth = 0
        quote = ""
        escaped = False
        while index < len(text):
            ch = text[index]
            if quote:
                if escaped:
                    escaped = False
                elif ch == "\\":
                    escaped = True
                elif ch == quote:
                    quote = ""
            else:
                if ch in {"\"", "'", "`"}:
                    quote = ch
                elif ch == "{":
                    brace_depth += 1
                elif ch == "}":
                    brace_depth = max(0, brace_depth - 1)
                elif ch == ">" and brace_depth == 0:
                    raw = text[match.start(): index + 1]
                    attrs = text[match.end(): index]
                    yield match.start(), attrs, raw
                    break
            index += 1


def parse_package_json(path: Path, root: Path) -> Dict[str, Any]:
    rel = _rel(path, root)
    try:
        obj = json.loads(read_text_safely(path, max_chars=4_000_000))
    except Exception as exc:
        return {
            "manifest": {"source_path": rel, "error": str(exc)},
            "packages": [], "scripts": [], "frameworks": [], "workspaces": [],
        }
    dependencies = obj.get("dependencies") or {}
    dev_dependencies = obj.get("devDependencies") or {}
    peer_dependencies = obj.get("peerDependencies") or {}
    optional_dependencies = obj.get("optionalDependencies") or {}
    package_rows: List[Dict[str, Any]] = []
    for scope, values in (
        ("dependencies", dependencies), ("devDependencies", dev_dependencies),
        ("peerDependencies", peer_dependencies), ("optionalDependencies", optional_dependencies),
    ):
        if not isinstance(values, dict):
            continue
        for name, version in values.items():
            package_rows.append({
                "name": name, "version": str(version), "scope": scope,
                "source_path": rel, "line": 0,
            })
    scripts = [
        {"name": name, "command": mask_text(str(command)), "source_path": rel, "line": 0}
        for name, command in (obj.get("scripts") or {}).items()
    ] if isinstance(obj.get("scripts"), dict) else []
    combined = {**dev_dependencies, **dependencies, **peer_dependencies}
    framework_hints = {
        "REACT": ("react",),
        "REACT_DOM": ("react-dom",),
        "REACT_ROUTER": ("react-router", "react-router-dom"),
        "VITE": ("vite", "@vitejs/plugin-react", "@vitejs/plugin-react-swc"),
        "CRA": ("react-scripts",),
        "NEXT_REACT": ("next",),
        "AXIOS": ("axios",),
        "REACT_QUERY": ("@tanstack/react-query", "react-query"),
        "REDUX": ("@reduxjs/toolkit", "react-redux", "redux"),
        "ZUSTAND": ("zustand",),
        "MUI": ("@mui/material",),
        "ANT_DESIGN": ("antd",),
    }
    frameworks: List[Dict[str, Any]] = []
    for framework, names in framework_hints.items():
        for name in names:
            if name in combined:
                frameworks.append({
                    "framework": framework, "package": name, "version": str(combined[name]),
                    "source_path": rel, "line": 0,
                })
    raw_workspaces = obj.get("workspaces") or []
    if isinstance(raw_workspaces, dict):
        raw_workspaces = raw_workspaces.get("packages") or []
    workspaces = [
        {"path_pattern": str(value), "source_path": rel, "line": 0}
        for value in raw_workspaces if isinstance(raw_workspaces, list)
    ]
    manifest = {
        "name": obj.get("name", path.parent.name),
        "version": obj.get("version", ""),
        "package_access": "NON_PUBLIC" if obj.get("private", False) else "PUBLIC",
        "type": obj.get("type", ""),
        "package_manager": obj.get("packageManager", ""),
        "proxy": mask_text(str(obj.get("proxy", ""))),
        "homepage": mask_text(str(obj.get("homepage", ""))),
        "source_path": rel,
        "line": 0,
    }
    return {
        "manifest": manifest,
        "packages": package_rows,
        "scripts": scripts,
        "frameworks": frameworks,
        "workspaces": workspaces,
    }


def parse_tsconfig(path: Path, root: Path) -> Dict[str, Any]:
    rel = _rel(path, root)
    text = read_text_safely(path, max_chars=2_000_000)
    # Strip common JSONC comments conservatively.
    cleaned = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    cleaned = re.sub(r"(^|\s)//.*?$", r"\1", cleaned, flags=re.M)
    try:
        obj = json.loads(cleaned)
    except Exception:
        return {"aliases": [], "compiler_options": [], "source_path": rel}
    options = obj.get("compilerOptions") or {}
    aliases = []
    for alias, targets in (options.get("paths") or {}).items():
        aliases.append({
            "alias": alias,
            "targets": targets if isinstance(targets, list) else [targets],
            "base_url": options.get("baseUrl", ""),
            "source_path": rel,
            "line": 0,
        })
    compiler_options = []
    for key in ("jsx", "module", "target", "moduleResolution", "baseUrl", "strict"):
        if key in options:
            compiler_options.append({"key": key, "value": options.get(key), "source_path": rel, "line": 0})
    return {"aliases": aliases, "compiler_options": compiler_options, "source_path": rel}


def parse_react_file(path: Path, root: Path) -> Dict[str, Any]:
    rel = _rel(path, root)
    text = read_text_safely(path, max_chars=5_000_000)
    components: List[Dict[str, Any]] = []
    routes: List[Dict[str, Any]] = []
    menus: List[Dict[str, Any]] = []
    hooks: List[Dict[str, Any]] = []
    stores: List[Dict[str, Any]] = []
    api_clients: List[Dict[str, Any]] = []
    api_calls: List[Dict[str, Any]] = []
    env_refs: List[Dict[str, Any]] = []
    imports: List[Dict[str, Any]] = []

    import_pattern = re.compile(
        r"^\s*import\s+(?P<what>.+?)\s+from\s+[\"'](?P<module>[^\"']+)[\"']\s*;?",
        re.M,
    )
    for match in import_pattern.finditer(text):
        imports.append({
            "imported": re.sub(r"\s+", " ", match.group("what")).strip(),
            "module": match.group("module"), "source_path": rel, "line": _line(text, match.start()),
        })

    component_patterns = (
        ("FUNCTION", re.compile(r"(?:export\s+(?:default\s+)?)?(?:async\s+)?function\s+([A-Z][A-Za-z0-9_$]*)\s*\(", re.M)),
        ("ARROW", re.compile(r"(?:export\s+)?(?:const|let)\s+([A-Z][A-Za-z0-9_$]*)\s*(?::[^=\n]+)?=\s*(?:React\.)?(?:memo|forwardRef)?\s*\(?\s*(?:\([^)]*\)|[A-Za-z_$][\w$]*)\s*=>", re.M)),
        ("CLASS", re.compile(r"(?:export\s+(?:default\s+)?)?class\s+([A-Z][A-Za-z0-9_$]*)\s+extends\s+(?:React\.)?(?:PureComponent|Component)", re.M)),
    )
    component_spans: List[Dict[str, Any]] = []
    for component_type, pattern in component_patterns:
        for match in pattern.finditer(text):
            name = match.group(1)
            row = {
                "name": name, "component_type": component_type,
                "exported": bool(re.search(r"\bexport\b", match.group(0))),
                "source_path": rel, "line": _line(text, match.start()),
            }
            components.append(row)
            component_spans.append({"name": name, "start": match.start()})

    def component_at(offset: int) -> str:
        candidates = [row for row in component_spans if row["start"] <= offset]
        return candidates[-1]["name"] if candidates else path.stem

    # React Router JSX routes. A scanner is used because element={<Page/>} contains '>'.
    for tag_offset, attrs, raw_tag in _iter_jsx_open_tags(text, "Route"):
        route_path = _attr(attrs, "path")
        is_index = bool(re.search(r"\bindex\b", attrs))
        if not route_path and not is_index:
            continue
        title = _attr(attrs, "title") or _attr(attrs, "name")
        component = _component_from_element(attrs)
        roles = _extract_roles(attrs)
        routes.append({
            "path": route_path or "(index)", "title": title, "component": component,
            "route_type": "JSX_ROUTE", "router": "react-router",
            "roles": roles, "protected": bool(roles or re.search(r"Protected|Private|Auth", attrs, re.I)),
            "layout": "", "source_component": component_at(tag_offset),
            "source_path": rel, "line": _line(text, tag_offset),
            "requires_review": not bool(route_path and component != "확인필요"),
            "evidence": mask_text(raw_tag[:700]),
        })

    # React Router object routes and createBrowserRouter/useRoutes entries.
    object_route_pattern = re.compile(
        r"\bpath\s*:\s*(?P<path>`[^`]+`|\"[^\"]+\"|'[^']+'|[^,}\n]+)"
        r"(?P<tail>.{0,650}?)(?=(?:\bpath\s*:)|(?:\}\s*,)|(?:\]\s*\))|$)",
        re.I | re.S,
    )
    for match in object_route_pattern.finditer(text):
        raw_path = _clean_js_value(match.group("path"))
        if not raw_path or (not raw_path.startswith("/") and raw_path not in {"*", "(index)"}):
            continue
        tail = match.group("tail") or ""
        component = "확인필요"
        for pattern in (
            r"\belement\s*:\s*<\s*([A-Z][A-Za-z0-9_.$]*)",
            r"\b(?:Component|component)\s*:\s*([A-Z][A-Za-z0-9_.$]*)",
            r"\blazy\s*:\s*.*?import\s*\(\s*[\"']([^\"']+)",
        ):
            cm = re.search(pattern, tail, re.S)
            if cm:
                component = Path(cm.group(1)).name if "/" in cm.group(1) else cm.group(1).split(".")[-1]
                break
        title_match = re.search(r"\b(?:title|name|label)\s*:\s*[\"']([^\"']+)", tail)
        roles = []
        role_match = re.search(r"\b(?:roles|permissions)\s*:\s*(\[[^\]]+\]|[\"'][^\"']+[\"'])", tail, re.S)
        if role_match:
            roles = _extract_roles("roles={" + role_match.group(1) + "}")
        routes.append({
            "path": raw_path, "title": title_match.group(1) if title_match else "",
            "component": component, "route_type": "OBJECT_ROUTE", "router": "react-router",
            "roles": roles, "protected": bool(roles or re.search(r"Protected|Private|Auth", tail, re.I)),
            "layout": "", "source_component": component_at(match.start()),
            "source_path": rel, "line": _line(text, match.start()),
            "requires_review": component == "확인필요",
            "evidence": mask_text((match.group(0) or "")[:700]),
        })

    # Links / navigation menus.
    link_pattern = re.compile(
        r"<(?:NavLink|Link)\b(?P<attrs>[^>]*)>(?P<label>.*?)</(?:NavLink|Link)>",
        re.I | re.S,
    )
    for match in link_pattern.finditer(text):
        path_value = _attr(match.group("attrs"), "to") or _attr(match.group("attrs"), "href")
        label = re.sub(r"<[^>]+>", " ", match.group("label"))
        label = re.sub(r"\{[^}]+\}", " ", label)
        label = re.sub(r"\s+", " ", label).strip()
        if path_value:
            menus.append({
                "label": label or "확인필요", "path": path_value,
                "source_component": component_at(match.start()), "source_path": rel,
                "line": _line(text, match.start()), "menu_type": "LINK",
            })
    menu_object_pattern = re.compile(
        r"\b(?:label|title|name|menuName)\s*:\s*[\"'](?P<label>[^\"']+)[\"']"
        r"(?P<tail>.{0,260}?)\b(?:path|to|url|href)\s*:\s*[\"'](?P<path>/[^\"']*)[\"']",
        re.I | re.S,
    )
    for match in menu_object_pattern.finditer(text):
        menus.append({
            "label": match.group("label").strip(), "path": match.group("path").strip(),
            "source_component": component_at(match.start()), "source_path": rel,
            "line": _line(text, match.start()), "menu_type": "OBJECT",
        })

    # Axios clients and base URLs.
    axios_client_pattern = re.compile(
        r"(?:const|let|var)\s+(?P<name>[A-Za-z_$][\w$]*)\s*=\s*axios\.create\s*\(\s*\{(?P<body>.*?)\}\s*\)",
        re.I | re.S,
    )
    known_clients = {"axios"}
    for match in axios_client_pattern.finditer(text):
        body = match.group("body") or ""
        base_match = re.search(r"\bbaseURL\s*:\s*([^,\n}]+)", body, re.I)
        client_name = match.group("name")
        known_clients.add(client_name)
        api_clients.append({
            "name": client_name, "client_type": "AXIOS", "base_url": _clean_js_value(base_match.group(1)) if base_match else "",
            "source_component": component_at(match.start()), "source_path": rel,
            "line": _line(text, match.start()), "evidence": mask_text(match.group(0)[:600]),
        })

    # API calls. Broad identifiers are only accepted when they look like a client.
    call_pattern = re.compile(
        r"(?P<client>[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\.(?P<method>get|post|put|patch|delete|head|options)\s*\(\s*(?P<args>[^\n;]{1,900})",
        re.I,
    )
    likely_client_names = {"api", "client", "http", "httpClient", "request", "rest", "axios", "axiosInstance"}
    api_call_id = 0
    for match in call_pattern.finditer(text):
        client = match.group("client")
        simple_client = client.split(".")[-1]
        if client not in known_clients and simple_client not in likely_client_names and not re.search(r"api|client|http|request", simple_client, re.I):
            continue
        raw_arg = _first_arg(match.group("args"))
        target = _clean_js_value(raw_arg)
        if not target:
            continue
        api_call_id += 1
        api_calls.append({
            "call_id": f"REACT-{rel}:{api_call_id}", "protocol": "HTTP",
            "client": client, "http_method": match.group("method").upper(), "path": target,
            "dynamic": bool(re.search(r"\$\{|\+|\bparams\b|\bconfig\b", raw_arg)),
            "caller_component": component_at(match.start()), "hook": "",
            "source_path": rel, "line": _line(text, match.start()),
            "evidence": mask_text(match.group(0)[:500]),
        })

    fetch_pattern = re.compile(r"\bfetch\s*\(\s*(?P<url>`[^`]+`|\"[^\"]+\"|'[^']+'|[^,\n\)]+)(?P<options>\s*,\s*\{.*?\})?\s*\)", re.I | re.S)
    for match in fetch_pattern.finditer(text):
        options = match.group("options") or ""
        method_match = re.search(r"\bmethod\s*:\s*[\"']([A-Za-z]+)", options, re.I)
        api_call_id += 1
        raw_url = match.group("url")
        api_calls.append({
            "call_id": f"REACT-{rel}:{api_call_id}", "protocol": "HTTP",
            "client": "fetch", "http_method": (method_match.group(1).upper() if method_match else "GET"),
            "path": _clean_js_value(raw_url),
            "dynamic": bool(re.search(r"\$\{|\+|\bparams\b|\bconfig\b", raw_url)),
            "caller_component": component_at(match.start()), "hook": "",
            "source_path": rel, "line": _line(text, match.start()),
            "evidence": mask_text(match.group(0)[:500]),
        })

    axios_config_pattern = re.compile(r"\baxios\s*\(\s*\{(?P<body>.*?)\}\s*\)", re.I | re.S)
    for match in axios_config_pattern.finditer(text):
        body = match.group("body") or ""
        url_match = re.search(r"\burl\s*:\s*([^,\n}]+)", body, re.I)
        if not url_match:
            continue
        method_match = re.search(r"\bmethod\s*:\s*[\"']([A-Za-z]+)", body, re.I)
        api_call_id += 1
        raw_url = url_match.group(1)
        api_calls.append({
            "call_id": f"REACT-{rel}:{api_call_id}", "protocol": "HTTP",
            "client": "axios", "http_method": method_match.group(1).upper() if method_match else "GET",
            "path": _clean_js_value(raw_url), "dynamic": bool(re.search(r"\$\{|\+", raw_url)),
            "caller_component": component_at(match.start()), "hook": "",
            "source_path": rel, "line": _line(text, match.start()), "evidence": mask_text(match.group(0)[:500]),
        })

    for protocol, pattern in (
        ("WEBSOCKET", re.compile(r"new\s+WebSocket\s*\(\s*([^\)]+)", re.I)),
        ("SSE", re.compile(r"new\s+EventSource\s*\(\s*([^\)]+)", re.I)),
    ):
        for match in pattern.finditer(text):
            api_call_id += 1
            api_calls.append({
                "call_id": f"REACT-{rel}:{api_call_id}", "protocol": protocol,
                "client": protocol, "http_method": protocol, "path": _clean_js_value(_first_arg(match.group(1))),
                "dynamic": True, "caller_component": component_at(match.start()), "hook": "",
                "source_path": rel, "line": _line(text, match.start()), "evidence": mask_text(match.group(0)[:500]),
            })

    # Hooks and state management.
    hook_definition_pattern = re.compile(r"(?:export\s+)?(?:function|const)\s+(use[A-Z][A-Za-z0-9_$]*)\b", re.M)
    for match in hook_definition_pattern.finditer(text):
        hooks.append({
            "hook": match.group(1), "kind": "CUSTOM_HOOK", "owner_component": component_at(match.start()),
            "source_path": rel, "line": _line(text, match.start()),
        })
    hook_usage_pattern = re.compile(r"\b(useState|useEffect|useMemo|useCallback|useContext|useReducer|useRef|useQuery|useMutation|useInfiniteQuery|useSelector|useDispatch|useNavigate)\s*\(")
    for match in hook_usage_pattern.finditer(text):
        hooks.append({
            "hook": match.group(1), "kind": "HOOK_USAGE", "owner_component": component_at(match.start()),
            "source_path": rel, "line": _line(text, match.start()),
        })
    for match in re.finditer(r"createSlice\s*\(\s*\{(?P<body>.*?)\}\s*\)", text, re.I | re.S):
        name_match = re.search(r"\bname\s*:\s*[\"']([^\"']+)", match.group("body"))
        stores.append({
            "store_type": "REDUX_SLICE", "name": name_match.group(1) if name_match else "확인필요",
            "source_component": component_at(match.start()), "source_path": rel, "line": _line(text, match.start()),
        })
    for match in re.finditer(r"(?:const|export\s+const)\s+(use[A-Za-z0-9_$]*Store)\s*=\s*create\s*\(", text):
        stores.append({
            "store_type": "ZUSTAND", "name": match.group(1), "source_component": component_at(match.start()),
            "source_path": rel, "line": _line(text, match.start()),
        })
    for match in re.finditer(r"(?:const|export\s+const)\s+([A-Za-z0-9_$]*Context)\s*=\s*(?:React\.)?createContext\s*\(", text):
        stores.append({
            "store_type": "CONTEXT", "name": match.group(1), "source_component": component_at(match.start()),
            "source_path": rel, "line": _line(text, match.start()),
        })

    for pattern, prefix in (
        (re.compile(r"\bimport\.meta\.env\.([A-Za-z_][A-Za-z0-9_]*)"), "import.meta.env"),
        (re.compile(r"\bprocess\.env\.([A-Za-z_][A-Za-z0-9_]*)"), "process.env"),
        (re.compile(r"\bwindow\.__ENV__\.([A-Za-z_][A-Za-z0-9_]*)"), "window.__ENV__"),
    ):
        for match in pattern.finditer(text):
            env_refs.append({
                "key": match.group(1), "access": prefix, "source_component": component_at(match.start()),
                "source_path": rel, "line": _line(text, match.start()),
            })

    # Attach nearest custom/query hook usage to API calls where possible.
    hook_spans = sorted(
        [{"hook": row["hook"], "line": row["line"]} for row in hooks if row.get("kind") in {"CUSTOM_HOOK", "HOOK_USAGE"}],
        key=lambda row: row["line"],
    )
    for call in api_calls:
        prior = [row for row in hook_spans if row["line"] <= call["line"] and call["line"] - row["line"] <= 40]
        if prior:
            call["hook"] = prior[-1]["hook"]

    is_react = bool(
        re.search(r"from\s+[\"']react[\"']|from\s+[\"']react-router|React\.|<Route\b|createRoot\s*\(", text)
        or any(item.get("module", "").startswith("react") for item in imports)
        or (path.suffix.lower() in {".jsx", ".tsx"} and (components or re.search(r"<[A-Za-z][A-Za-z0-9.:-]*(?:\s|/?>)", text)))
    )
    return {
        "is_react": is_react,
        "components": _dedupe(components, ("name", "source_path", "line")),
        "routes": _dedupe(routes, ("path", "component", "source_path", "line")),
        "menus": _dedupe(menus, ("label", "path", "source_path", "line")),
        "hooks": _dedupe(hooks, ("hook", "kind", "owner_component", "source_path", "line")),
        "stores": _dedupe(stores, ("store_type", "name", "source_path", "line")),
        "api_clients": _dedupe(api_clients, ("name", "base_url", "source_path", "line")),
        "api_calls": _dedupe(api_calls, ("call_id",)),
        "env_refs": _dedupe(env_refs, ("key", "access", "source_path", "line")),
        "imports": _dedupe(imports, ("imported", "module", "source_path", "line")),
    }
