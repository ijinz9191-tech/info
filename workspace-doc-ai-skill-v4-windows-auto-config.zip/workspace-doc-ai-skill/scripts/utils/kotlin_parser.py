from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List

from .file_utils import read_text_safely
from .java_parser import (
    COMPONENT_ANNOTATIONS,
    MAPPING_ANNOTATIONS,
    normalize_path,
    parse_annotations,
    parse_named_annotation_arg,
    split_params,
)

PACKAGE_RE = re.compile(r"^\s*package\s+([\w.]+)", re.M)
IMPORT_RE = re.compile(r"^\s*import\s+([\w.*]+)", re.M)
CLASS_RE = re.compile(
    r"(?P<ann>(?:\s*@[A-Za-z_][\w.]*(?:\([^\n]*\))?\s*)*)"
    r"(?P<mods>(?:(?:public|private|protected|internal|open|abstract|sealed|data|enum|annotation|value|inner)\s+)*)"
    r"(?P<kind>class|interface|object)\s+(?P<name>[A-Za-z_][\w]*)"
    r"(?:\s*\((?P<ctor>[^)]*)\))?"
    r"(?:\s*:\s*(?P<supers>[^\{\n]+))?",
    re.M,
)
FUN_RE = re.compile(
    r"(?P<ann>(?:\s*@[A-Za-z_][\w.]*(?:\([^\n]*\))?\s*)*)"
    r"(?P<mods>(?:(?:public|private|protected|internal|open|override|suspend|inline|operator|infix|tailrec)\s+)*)"
    r"fun\s+(?:<[^>]+>\s*)?(?P<name>[A-Za-z_][\w]*)\s*\((?P<params>[^)]*)\)\s*(?::\s*(?P<ret>[^=\{\n]+))?",
    re.M,
)


def _line(text: str, offset: int) -> int:
    return text.count("\n", 0, max(0, offset)) + 1


def _parse_kt_params(raw: str) -> List[Dict[str, str]]:
    result = []
    for item in split_params(raw or ""):
        annotations = parse_annotations(item)
        clean = re.sub(r"@[A-Za-z_][\w.]*\s*(?:\([^)]*\))?\s*", "", item)
        clean = re.sub(r"\b(?:val|var|crossinline|noinline|vararg)\s+", "", clean).strip()
        if ":" in clean:
            name, typ = clean.split(":", 1)
            result.append({"name": name.strip(), "type": typ.split("=", 1)[0].strip(), "annotations": [a["name"] for a in annotations]})
        else:
            result.append({"name": clean, "type": "확인필요", "annotations": [a["name"] for a in annotations]})
    return result


def parse_kotlin_file(path: Path, root: Path) -> Dict[str, Any]:
    rel = str(path.relative_to(root)).replace("\\", "/")
    text = read_text_safely(path, max_chars=5_000_000)
    pkg_match = PACKAGE_RE.search(text)
    package = pkg_match.group(1) if pkg_match else ""
    imports = IMPORT_RE.findall(text)
    result: Dict[str, Any] = {
        "path": rel, "language": "kotlin", "package": package, "imports": imports,
        "classes": [], "methods": [], "endpoints": [], "injections": [], "beans": [],
        "entities": [], "feign_clients": [], "uses": [],
    }
    use_keywords = {
        "RestTemplate": "REST_CLIENT", "WebClient": "WEB_CLIENT", "KafkaTemplate": "KAFKA",
        "@KafkaListener": "KAFKA", "RedisTemplate": "REDIS", "RedissonClient": "REDIS",
        "JdbcTemplate": "JDBC", "EntityManager": "JPA", "ElasticsearchOperations": "ELASTICSEARCH",
        "ElasticsearchClient": "ELASTICSEARCH", "MeterRegistry": "PROMETHEUS", "Loki": "LOKI",
    }
    result["uses"] = sorted({value for keyword, value in use_keywords.items() if keyword in text})

    class_spans = []
    class_base_path = ""
    for match in CLASS_RE.finditer(text):
        annotations = parse_annotations(match.group("ann") or "")
        name = match.group("name")
        supers = [re.sub(r"\(.*", "", x).strip() for x in (match.group("supers") or "").split(",") if x.strip()]
        kind = match.group("kind")
        component_type = next((COMPONENT_ANNOTATIONS[a["name"]] for a in annotations if a["name"] in COMPONENT_ANNOTATIONS), "KOTLIN_TYPE")
        result["classes"].append({
            "name": name, "fqn": f"{package}.{name}" if package else name, "kind": kind,
            "component_type": component_type, "extends": supers[:1] if kind != "interface" else [],
            "implements": supers[1:] if kind != "interface" else supers,
            "annotations": [a["name"] for a in annotations], "raw_annotations": [a["raw"] for a in annotations],
            "source_path": rel, "line": _line(text, match.start()),
        })
        class_spans.append({"name": name, "start": match.start()})
        if not class_base_path:
            mapping = next((a for a in annotations if a["name"] == "RequestMapping"), None)
            class_base_path = parse_named_annotation_arg(mapping["raw"]) if mapping else ""
        for param in _parse_kt_params(match.group("ctor") or ""):
            # Primary constructor properties are Spring constructor injection candidates.
            result["injections"].append({
                "class": name, "injection_type": "PRIMARY_CONSTRUCTOR", "target_type": param["type"],
                "field_name": param["name"], "parameter_name": param["name"], "qualifier": "",
                "annotation": ",".join(param.get("annotations", [])), "source_path": rel, "line": _line(text, match.start()),
            })
        if any(a["name"] == "FeignClient" for a in annotations):
            ann = next(a for a in annotations if a["name"] == "FeignClient")
            result["feign_clients"].append({
                "name": parse_named_annotation_arg(ann["raw"], ("name", "value")),
                "url": parse_named_annotation_arg(ann["raw"], ("url",)), "path": parse_named_annotation_arg(ann["raw"], ("path",)),
                "context_id": parse_named_annotation_arg(ann["raw"], ("contextId",)), "raw": ann["raw"],
                "source_path": rel, "line": _line(text, match.start()),
            })

    def class_at(offset: int) -> str:
        candidates = [x for x in class_spans if x["start"] <= offset]
        return candidates[-1]["name"] if candidates else path.stem

    for match in FUN_RE.finditer(text):
        annotations = parse_annotations(match.group("ann") or "")
        method = {
            "class": class_at(match.start()), "name": match.group("name"),
            "return_type": (match.group("ret") or "Unit").strip(),
            "visibility": next((x for x in (match.group("mods") or "").split() if x in {"public", "private", "protected", "internal"}), "public"),
            "modifiers": (match.group("mods") or "").split(), "params": _parse_kt_params(match.group("params") or ""),
            "annotations": [a["name"] for a in annotations], "raw_annotations": [a["raw"] for a in annotations],
            "source_path": rel, "line": _line(text, match.start()),
        }
        result["methods"].append(method)
        for annotation in annotations:
            if annotation["name"] in MAPPING_ANNOTATIONS:
                result["endpoints"].append({
                    "controller": method["class"], "method_name": method["name"], "http_method": MAPPING_ANNOTATIONS[annotation["name"]],
                    "path": normalize_path(class_base_path, parse_named_annotation_arg(annotation["raw"])),
                    "request_params": method["params"], "response_type": method["return_type"], "source_path": rel,
                    "line": method["line"], "annotation": annotation["raw"],
                })
        if "Bean" in method["annotations"]:
            result["beans"].append({
                "configuration_class": method["class"], "bean_name": method["name"], "return_type": method["return_type"],
                "method_name": method["name"], "source_path": rel, "line": method["line"],
            })

    # Basic Kotlin JPA entity/column extraction.
    entity_classes = [c for c in result["classes"] if "Entity" in c.get("annotations", [])]
    for cls in entity_classes:
        table_match = re.search(r"@Table\s*\((.*?)\)", text, re.S)
        table_name = parse_named_annotation_arg(table_match.group(1), ("name", "value")) if table_match else cls["name"]
        schema = parse_named_annotation_arg(table_match.group(1), ("schema",)) if table_match else ""
        columns = []
        for match in re.finditer(r"(?P<ann>(?:\s*@[A-Za-z_][\w.]*\([^\n]*\)\s*)*)\s*(?:val|var)\s+(?P<name>[A-Za-z_][\w]*)\s*:\s*(?P<type>[^,\n\)]+)", text):
            annotations = parse_annotations(match.group("ann") or "")
            column_ann = next((a for a in annotations if a["name"] in {"Column", "JoinColumn"}), None)
            column_name = parse_named_annotation_arg(column_ann["raw"], ("name", "value")) if column_ann else match.group("name")
            columns.append({
                "field_name": match.group("name"), "java_type": match.group("type").strip(), "column_name": column_name,
                "is_id": any(a["name"] in {"Id", "EmbeddedId"} for a in annotations),
                "annotations": [a["name"] for a in annotations], "line": _line(text, match.start()),
            })
        result["entities"].append({
            "is_entity": True, "schema": schema, "table_name": table_name, "columns": columns,
            "class": cls["name"], "package": package, "source_path": rel, "line": cls["line"],
        })
    return result
