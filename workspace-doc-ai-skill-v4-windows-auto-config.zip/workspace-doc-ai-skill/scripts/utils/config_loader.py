from __future__ import annotations

import os
import re
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, MutableMapping, Union

import yaml

SENSITIVE_KEYS = (
    "password", "passwd", "pwd", "secret", "token", "credential", "private", "apikey", "api_key",
    "access_key", "secret_key", "authorization", "bearer", "client_secret", "keystore_password", "truststore_password",
)

SENSITIVE_VALUE_PATTERNS = (
    re.compile(r"(?i)(password|passwd|pwd|secret|token|api[_-]?key|client[_-]?secret)\s*[:=]\s*([^\s,;]+)"),
    re.compile(r"(?i)(authorization\s*[:=]\s*bearer\s+)([^\s,;]+)"),
    re.compile(r"(?i)(https?://[^:/\s]+:)([^@/\s]+)(@)"),
    re.compile(r"(?i)(rediss?://[^:/\s]+:)([^@/\s]+)(@)"),
)

ENV_PLACEHOLDER_RE = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::([^}]*))?}")


def deep_merge(base: Mapping[str, Any] | None, overlay: Mapping[str, Any] | None) -> Dict[str, Any]:
    """Recursively merge mapping values. Overlay lists/scalars replace base values."""
    result: Dict[str, Any] = deepcopy(dict(base or {}))
    for key, value in dict(overlay or {}).items():
        if isinstance(value, Mapping) and isinstance(result.get(key), Mapping):
            result[key] = deep_merge(result.get(key), value)
        else:
            result[key] = deepcopy(value)
    return result


def _load_yaml(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as stream:
        value = yaml.safe_load(stream) or {}
    if not isinstance(value, dict):
        raise ValueError(f"config root must be a mapping: {path}")
    return value


def _include_paths(cfg: Mapping[str, Any], config_path: Path) -> list[Path]:
    raw: list[Any] = []
    includes = cfg.get("include_files", [])
    if isinstance(includes, (str, Path)):
        raw.append(includes)
    elif isinstance(includes, list):
        raw.extend(includes)
    credentials = cfg.get("credentials_file")
    if credentials:
        raw.append(credentials)

    paths: list[Path] = []
    for value in raw:
        if not value:
            continue
        path = Path(str(value)).expanduser()
        if not path.is_absolute():
            path = config_path.parent / path
        path = path.resolve()
        if path not in paths:
            paths.append(path)
    return paths


def load_config(config_path: Union[str, Path]) -> Dict[str, Any]:
    """
    Load the primary config and optional local overlay files.

    The generated Windows config uses this precedence:
      template/primary config < include_files in order < credentials_file

    A missing credentials file is allowed so the package can still perform static analysis.
    """
    path = Path(config_path).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(f"config file not found: {path}")

    primary = _load_yaml(path)
    merged: Dict[str, Any] = dict(primary)
    loaded_files = [str(path)]
    for include_path in _include_paths(primary, path):
        if not include_path.exists():
            continue
        merged = deep_merge(merged, _load_yaml(include_path))
        loaded_files.append(str(include_path))

    # Internal metadata always reflects the primary config location. Relative paths in
    # generated config are intentionally resolved from this directory.
    merged["_config_path"] = str(path)
    merged["_base_dir"] = str(path.parent)
    merged["_loaded_config_files"] = loaded_files
    return merged


def resolve_path(base_dir: Union[str, Path], maybe_path: Union[str, Path]) -> Path:
    p = Path(str(maybe_path)).expanduser()
    if p.is_absolute():
        return p
    return Path(base_dir).expanduser().resolve() / p


def ensure_dir(path: Union[str, Path]) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def is_sensitive_key(key: str) -> bool:
    key_lower = str(key).lower()
    return any(s in key_lower for s in SENSITIVE_KEYS)


def mask_value(key: str, value: Any) -> Any:
    if is_sensitive_key(key) and value not in (None, ""):
        return "***MASKED***"
    if isinstance(value, str):
        return mask_text(value)
    return value


def mask_text(value: str) -> str:
    text = str(value or "")
    for pattern in SENSITIVE_VALUE_PATTERNS:
        if pattern.groups == 2:
            text = pattern.sub(lambda m: f"{m.group(1)}=***MASKED***", text)
        else:
            text = pattern.sub(lambda m: f"{m.group(1)}***MASKED***{m.group(3)}", text)
    return text


def deep_mask(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: deep_mask(mask_value(k, v)) for k, v in obj.items()}
    if isinstance(obj, list):
        return [deep_mask(v) for v in obj]
    if isinstance(obj, tuple):
        return tuple(deep_mask(v) for v in obj)
    if isinstance(obj, str):
        return mask_text(obj)
    return obj


def env_or_empty(name: str) -> str:
    return os.environ.get(name, "") if name else ""


def env_first(names: Iterable[str]) -> str:
    for name in names:
        value = env_or_empty(name)
        if value:
            return value
    return ""


def resolve_env_placeholders(value: Any, allow_default: bool = True) -> Any:
    if not isinstance(value, str):
        return value

    def repl(match: re.Match[str]) -> str:
        env_name = match.group(1)
        default = match.group(2) or ""
        return os.environ.get(env_name, default if allow_default else "")

    return ENV_PLACEHOLDER_RE.sub(repl, value)


def configured_value(cfg: Mapping[str, Any], key: str, standard_envs: Iterable[str] = ()) -> str:
    """Resolve direct local-config value first, then named/standard environment variables."""
    value = cfg.get(key)
    if value not in (None, ""):
        resolved = resolve_env_placeholders(value)
        if resolved not in (None, ""):
            return str(resolved)
    env_name = str(cfg.get(f"{key}_env", "") or "")
    if env_name and env_or_empty(env_name):
        return env_or_empty(env_name)
    return env_first(standard_envs)


def enabled_value(value: Any, auto_condition: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    text = str(value).strip().lower()
    if text == "auto":
        return auto_condition
    return text in {"1", "true", "yes", "y", "on", "enabled"}
