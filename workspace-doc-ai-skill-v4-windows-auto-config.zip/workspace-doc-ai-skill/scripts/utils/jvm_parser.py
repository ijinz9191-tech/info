from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

from .java_parser import parse_java_file
from .kotlin_parser import parse_kotlin_file


def parse_jvm_file(path: Path, root: Path) -> Dict[str, Any]:
    suffix = path.suffix.lower()
    if suffix == ".kt":
        return parse_kotlin_file(path, root)
    result = parse_java_file(path, root)
    if suffix == ".groovy":
        result["language"] = "groovy-best-effort"
    return result
