from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence, Tuple

from .config_loader import mask_text
from .file_utils import read_text_safely


def _line(text: str, offset: int) -> int:
    return text.count("\n", 0, max(0, offset)) + 1


def _rel(path: Path, root: Path) -> str:
    return str(path.relative_to(root)).replace("\\", "/")


def _dedupe(rows: Iterable[Dict[str, Any]], keys: Sequence[str]) -> List[Dict[str, Any]]:
    result: Dict[Tuple[Any, ...], Dict[str, Any]] = {}
    for row in rows:
        result[tuple(row.get(key) for key in keys)] = row
    return list(result.values())


def _clean(value: str) -> str:
    value = str(value or "").strip().rstrip(",;")
    if value.startswith(("\"", "'", "`")) and value[-1:] == value[:1]:
        value = value[1:-1]
    return mask_text(re.sub(r"\s+", " ", value).strip())


def _class_at(text: str, offset: int, fallback: str) -> str:
    matches = list(re.finditer(r"\b(?:class|object)\s+([A-Za-z_$][\w$]*)", text[:offset]))
    return matches[-1].group(1) if matches else fallback


def _first_arg(value: str) -> str:
    value = str(value or "").strip()
    if not value:
        return ""
    if value[0] in {"\"", "'", "`"}:
        quote = value[0]
        escaped = False
        for index in range(1, len(value)):
            if escaped:
                escaped = False
                continue
            if value[index] == "\\":
                escaped = True
            elif value[index] == quote:
                return value[: index + 1]
        return value
    depth = 0
    for index, ch in enumerate(value):
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth = max(0, depth - 1)
        elif ch == "," and depth == 0:
            return value[:index]
    return value


def parse_vertx_file(path: Path, root: Path) -> Dict[str, Any]:
    rel = _rel(path, root)
    text = read_text_safely(path, max_chars=5_000_000)
    lower = text.lower()
    is_vertx = any(token in lower for token in (
        "io.vertx", "abstractverticle", "router.router", "vertx.eventbus", "routingcontext",
        "createhttpserver", "servicebinder", "serviceproxybuilder",
    ))
    empty = {
        "is_vertx": False, "verticles": [], "deployments": [], "http_servers": [], "routes": [],
        "handlers": [], "event_bus": [], "event_bus_codecs": [], "service_proxies": [],
        "web_clients": [], "config_keys": [], "shared_data": [], "timers": [], "sql_clients": [],
        "redis_clients": [], "kafka_clients": [], "metrics": [], "subrouter_mounts": [],
    }
    if not is_vertx:
        return empty

    verticles: List[Dict[str, Any]] = []
    deployments: List[Dict[str, Any]] = []
    http_servers: List[Dict[str, Any]] = []
    routes: List[Dict[str, Any]] = []
    handlers: List[Dict[str, Any]] = []
    event_bus: List[Dict[str, Any]] = []
    event_bus_codecs: List[Dict[str, Any]] = []
    service_proxies: List[Dict[str, Any]] = []
    web_clients: List[Dict[str, Any]] = []
    config_keys: List[Dict[str, Any]] = []
    shared_data: List[Dict[str, Any]] = []
    timers: List[Dict[str, Any]] = []
    sql_clients: List[Dict[str, Any]] = []
    redis_clients: List[Dict[str, Any]] = []
    kafka_clients: List[Dict[str, Any]] = []
    metrics: List[Dict[str, Any]] = []
    mounts: List[Dict[str, Any]] = []

    verticle_pattern = re.compile(
        r"\bclass\s+(?P<name>[A-Za-z_$][\w$]*)[^\n{]*(?:extends\s+(?P<base>AbstractVerticle|CoroutineVerticle)|implements\s+(?P<intf>Verticle))",
        re.I,
    )
    for match in verticle_pattern.finditer(text):
        verticles.append({
            "class": match.group("name"), "base_type": match.group("base") or match.group("intf") or "Verticle",
            "worker": bool(re.search(r"setWorker\s*\(\s*true", text[max(0, match.start()-1000):match.start()+3000], re.I)),
            "source_path": rel, "line": _line(text, match.start()),
        })

    deploy_pattern = re.compile(r"\bdeployVerticle\s*\(\s*(?P<target>new\s+[A-Za-z_$][\w$]*\s*\([^)]*\)|[\"'][^\"']+[\"']|[A-Za-z_$][\w$.:]*)\s*(?:,\s*(?P<options>[^\)]+))?\)", re.I | re.S)
    for match in deploy_pattern.finditer(text):
        target = _clean(match.group("target"))
        class_match = re.search(r"new\s+([A-Za-z_$][\w$]*)", target)
        deployments.append({
            "deployer": _class_at(text, match.start(), path.stem),
            "verticle": class_match.group(1) if class_match else target,
            "options": _clean(match.group("options") or ""),
            "source_path": rel, "line": _line(text, match.start()),
            "evidence": mask_text(match.group(0)[:500]),
        })

    for match in re.finditer(r"(?P<router>[A-Za-z_$][\w$]*)\.mountSubRouter\s*\(\s*(?P<prefix>[^,]+)\s*,\s*(?P<sub>[A-Za-z_$][\w$]*)\s*\)", text, re.I):
        mounts.append({
            "router": match.group("router"), "prefix": _clean(match.group("prefix")), "subrouter": match.group("sub"),
            "source_component": _class_at(text, match.start(), path.stem),
            "source_path": rel, "line": _line(text, match.start()),
        })

    route_id = 0
    direct_route_pattern = re.compile(
        r"(?P<router>[A-Za-z_$][\w$]*)\.(?P<method>get|post|put|patch|delete|head|options)\s*\(\s*(?P<path>`[^`]+`|\"[^\"]+\"|'[^']+'|[^\)]+)\s*\)"
        r"(?P<chain>.{0,900}?)(?=;|\n\s*(?:[A-Za-z_$][\w$]*\.)?(?:get|post|put|patch|delete|head|options|route|mountSubRouter)\s*\(|$)",
        re.I | re.S,
    )
    for match in direct_route_pattern.finditer(text):
        route_id += 1
        chain = match.group("chain") or ""
        handler_match = re.search(r"\.handler\s*\(\s*([^\)]+)\)", chain, re.I | re.S)
        failure_match = re.search(r"\.failureHandler\s*\(\s*([^\)]+)\)", chain, re.I | re.S)
        consumes = re.findall(r"\.consumes\s*\(\s*[\"']([^\"']+)", chain, re.I)
        produces = re.findall(r"\.produces\s*\(\s*[\"']([^\"']+)", chain, re.I)
        routes.append({
            "route_id": f"VERTX-{rel}:{route_id}", "framework": "VERTX",
            "router_variable": match.group("router"), "http_method": match.group("method").upper(),
            "path": _clean(match.group("path")), "handler": _clean(handler_match.group(1)) if handler_match else "확인필요",
            "failure_handler": _clean(failure_match.group(1)) if failure_match else "",
            "consumes": consumes, "produces": produces,
            "source_component": _class_at(text, match.start(), path.stem),
            "source_path": rel, "line": _line(text, match.start()),
            "evidence": mask_text(match.group(0)[:900]),
        })

    route_http_method_pattern = re.compile(
        r"(?P<router>[A-Za-z_$][\w$]*)\.route\s*\(\s*HttpMethod\.(?P<method>[A-Z]+)\s*,\s*(?P<path>[^\)]+)\)"
        r"(?P<chain>.{0,700}?)(?=;|\n\s*(?:[A-Za-z_$][\w$]*\.)?route\s*\(|$)", re.I | re.S,
    )
    for match in route_http_method_pattern.finditer(text):
        route_id += 1
        handler_match = re.search(r"\.handler\s*\(\s*([^\)]+)\)", match.group("chain") or "", re.I | re.S)
        routes.append({
            "route_id": f"VERTX-{rel}:{route_id}", "framework": "VERTX",
            "router_variable": match.group("router"), "http_method": match.group("method").upper(),
            "path": _clean(match.group("path")), "handler": _clean(handler_match.group(1)) if handler_match else "확인필요",
            "failure_handler": "", "consumes": [], "produces": [],
            "source_component": _class_at(text, match.start(), path.stem),
            "source_path": rel, "line": _line(text, match.start()),
            "evidence": mask_text(match.group(0)[:800]),
        })

    route_method_chain_pattern = re.compile(
        r"(?P<router>[A-Za-z_$][\w$]*)\.route\s*\(\s*(?P<path>[^\)]*)\)\s*\.method\s*\(\s*HttpMethod\.(?P<method>[A-Z]+)\s*\)"
        r"(?P<chain>.{0,700}?)(?=;|\n\s*(?:[A-Za-z_$][\w$]*\.)?route\s*\(|$)", re.I | re.S,
    )
    for match in route_method_chain_pattern.finditer(text):
        route_id += 1
        handler_match = re.search(r"\.handler\s*\(\s*([^\)]+)\)", match.group("chain") or "", re.I | re.S)
        routes.append({
            "route_id": f"VERTX-{rel}:{route_id}", "framework": "VERTX",
            "router_variable": match.group("router"), "http_method": match.group("method").upper(),
            "path": _clean(match.group("path") or "*") or "*", "handler": _clean(handler_match.group(1)) if handler_match else "확인필요",
            "failure_handler": "", "consumes": [], "produces": [],
            "source_component": _class_at(text, match.start(), path.stem),
            "source_path": rel, "line": _line(text, match.start()),
            "evidence": mask_text(match.group(0)[:800]),
        })

    # Apply mount prefixes when a route belongs to a mounted subrouter.
    prefixed_routes: List[Dict[str, Any]] = []
    for route in routes:
        candidates = [m for m in mounts if m.get("subrouter") == route.get("router_variable")]
        if not candidates:
            continue
        for mount in candidates:
            prefix = mount.get("prefix", "").rstrip("/")
            child = str(route.get("path", "")).lstrip("/")
            clone = dict(route)
            clone["mounted_path"] = (prefix + "/" + child).replace("//", "/")
            clone["mount_source_path"] = mount.get("source_path")
            prefixed_routes.append(clone)
    routes.extend(prefixed_routes)

    handler_pattern = re.compile(
        r"(?:public|private|protected|internal|static|final|suspend|\s)*(?:void|Future<[^>]+>|Uni<[^>]+>|[A-Za-z_$][\w$<>,.? ]*)\s+"
        r"(?P<name>[A-Za-z_$][\w$]*)\s*\(\s*(?:RoutingContext|io\.vertx\.ext\.web\.RoutingContext)\s+(?P<param>[A-Za-z_$][\w$]*)",
        re.I,
    )
    for match in handler_pattern.finditer(text):
        handlers.append({
            "class": _class_at(text, match.start(), path.stem), "handler": match.group("name"),
            "context_parameter": match.group("param"), "source_path": rel, "line": _line(text, match.start()),
        })

    # HTTP server creation/listen settings.
    for match in re.finditer(r"createHttpServer\s*\((?P<options>[^)]*)\)(?P<chain>.{0,1500}?)\.listen\s*\(\s*(?P<listen>[^\)]+)\)", text, re.I | re.S):
        listen_args = [_clean(x) for x in match.group("listen").split(",")]
        http_servers.append({
            "source_component": _class_at(text, match.start(), path.stem),
            "port": listen_args[0] if listen_args else "확인필요",
            "host": listen_args[1] if len(listen_args) > 1 else "",
            "options": _clean(match.group("options")),
            "request_handler": _clean((re.search(r"\.requestHandler\s*\(\s*([^\)]+)", match.group("chain"), re.I | re.S) or ["", ""])[1]),
            "source_path": rel, "line": _line(text, match.start()),
        })

    event_id = 0
    event_patterns = (
        ("CONSUME", "INBOUND", re.compile(r"(?:eventBus\s*\(\s*\)|eventBus|vertx\.eventBus\s*\(\s*\))\.(?:consumer|localConsumer)\s*\(\s*([^,\)]+)", re.I)),
        ("SEND", "OUTBOUND", re.compile(r"(?:eventBus\s*\(\s*\)|eventBus|vertx\.eventBus\s*\(\s*\))\.send\s*\(\s*([^,\)]+)", re.I)),
        ("PUBLISH", "OUTBOUND", re.compile(r"(?:eventBus\s*\(\s*\)|eventBus|vertx\.eventBus\s*\(\s*\))\.publish\s*\(\s*([^,\)]+)", re.I)),
        ("REQUEST", "OUTBOUND", re.compile(r"(?:eventBus\s*\(\s*\)|eventBus|vertx\.eventBus\s*\(\s*\))\.request\s*\(\s*([^,\)]+)", re.I)),
        ("MESSAGE_PRODUCER", "OUTBOUND", re.compile(r"\.sender\s*\(\s*([^\)]+)\)|\.publisher\s*\(\s*([^\)]+)\)", re.I)),
    )
    for operation, direction, pattern in event_patterns:
        for match in pattern.finditer(text):
            event_id += 1
            raw = next((group for group in match.groups() if group), "")
            event_bus.append({
                "event_id": f"EVENTBUS-{rel}:{event_id}", "operation": operation, "direction": direction,
                "address": _clean(_first_arg(raw)), "source_component": _class_at(text, match.start(), path.stem),
                "source_path": rel, "line": _line(text, match.start()), "evidence": mask_text(match.group(0)[:500]),
            })

    for match in re.finditer(r"register(?:Default|Codec)?Codec\s*\(\s*([^,\)]+)\s*,\s*([^\)]+)\)", text, re.I):
        event_bus_codecs.append({
            "message_type": _clean(match.group(1)), "codec": _clean(match.group(2)),
            "source_component": _class_at(text, match.start(), path.stem),
            "source_path": rel, "line": _line(text, match.start()),
        })

    service_patterns = (
        ("REGISTER", re.compile(r"new\s+ServiceBinder\s*\([^)]*\)(?P<chain>.{0,900}?)\.register\s*\(\s*([^,]+)\s*,\s*([^\)]+)\)", re.I | re.S)),
        ("PROXY", re.compile(r"new\s+ServiceProxyBuilder\s*\([^)]*\)(?P<chain>.{0,700}?)\.build\s*\(\s*([^\)]+)\)", re.I | re.S)),
    )
    for kind, pattern in service_patterns:
        for match in pattern.finditer(text):
            chain = match.groupdict().get("chain") or ""
            address_match = re.search(r"\.setAddress\s*\(\s*([^\)]+)\)", chain, re.I)
            service_proxies.append({
                "kind": kind, "address": _clean(address_match.group(1)) if address_match else "확인필요",
                "service": _clean(match.groups()[-1]), "source_component": _class_at(text, match.start(), path.stem),
                "source_path": rel, "line": _line(text, match.start()), "evidence": mask_text(match.group(0)[:800]),
            })

    web_call_id = 0
    web_patterns = (
        ("GET", re.compile(r"\.(?:getAbs|get)\s*\(\s*(?P<args>[^\)]+)\)", re.I)),
        ("POST", re.compile(r"\.(?:postAbs|post)\s*\(\s*(?P<args>[^\)]+)\)", re.I)),
        ("PUT", re.compile(r"\.(?:putAbs|put)\s*\(\s*(?P<args>[^\)]+)\)", re.I)),
        ("DELETE", re.compile(r"\.(?:deleteAbs|delete)\s*\(\s*(?P<args>[^\)]+)\)", re.I)),
        ("REQUEST", re.compile(r"\.request\s*\(\s*HttpMethod\.(?P<http>[A-Z]+)\s*,\s*(?P<args>[^\)]+)\)", re.I)),
    )
    for method, pattern in web_patterns:
        for match in pattern.finditer(text):
            prefix = text[max(0, match.start()-150):match.start()].lower()
            if not any(token in prefix for token in ("webclient", "httpclient", "client", "request")):
                continue
            web_call_id += 1
            actual_method = match.groupdict().get("http") or method
            args = match.group("args")
            parts = [x.strip() for x in args.split(",")]
            target = parts[-1] if len(parts) >= 3 else parts[0]
            web_clients.append({
                "call_id": f"VERTX-HTTP-{rel}:{web_call_id}", "framework": "VERTX", "client_type": "Vert.x WebClient/HttpClient",
                "http_method": actual_method.upper(), "path": _clean(_first_arg(target)),
                "source_component": _class_at(text, match.start(), path.stem),
                "source_path": rel, "line": _line(text, match.start()), "evidence": mask_text(match.group(0)[:500]),
            })

    for match in re.finditer(r"(?:config\s*\(\s*\)|config|json)\.(?:getString|getInteger|getLong|getBoolean|getJsonObject|getJsonArray)\s*\(\s*([^,\)]+)", text, re.I):
        config_keys.append({
            "key": _clean(match.group(1)), "source_component": _class_at(text, match.start(), path.stem),
            "source_path": rel, "line": _line(text, match.start()),
        })
    for match in re.finditer(r"(?:getLocalMap|getAsyncMap|getClusterWideMap)\s*\(\s*([^,\)]+)", text, re.I):
        shared_data.append({
            "map_type": re.search(r"(getLocalMap|getAsyncMap|getClusterWideMap)", match.group(0), re.I).group(1),
            "name": _clean(match.group(1)), "source_component": _class_at(text, match.start(), path.stem),
            "source_path": rel, "line": _line(text, match.start()),
        })
    for operation, pattern in (
        ("PERIODIC", re.compile(r"setPeriodic\s*\(\s*([^,\)]+)", re.I)),
        ("TIMER", re.compile(r"setTimer\s*\(\s*([^,\)]+)", re.I)),
    ):
        for match in pattern.finditer(text):
            timers.append({
                "timer_type": operation, "delay": _clean(match.group(1)),
                "source_component": _class_at(text, match.start(), path.stem),
                "source_path": rel, "line": _line(text, match.start()),
            })

    sql_patterns = (
        ("ORACLE_POOL", re.compile(r"OracleBuilder\.pool\s*\((.*?)\)", re.I | re.S)),
        ("JDBC_POOL", re.compile(r"JDBCPool\.(?:pool|client)\s*\((.*?)\)", re.I | re.S)),
        ("SQL_POOL", re.compile(r"Pool\.pool\s*\((.*?)\)", re.I | re.S)),
        ("PREPARED_QUERY", re.compile(r"\.preparedQuery\s*\(\s*([^\)]+)\)", re.I)),
        ("QUERY", re.compile(r"(?<!prepared)\.query\s*\(\s*([^\)]+)\)", re.I)),
    )
    for operation, pattern in sql_patterns:
        for match in pattern.finditer(text):
            sql_clients.append({
                "operation": operation, "target": _clean((match.group(1) or "")[:1000]),
                "source_component": _class_at(text, match.start(), path.stem),
                "source_path": rel, "line": _line(text, match.start()),
            })
    for match in re.finditer(r"Redis\.createClient\s*\((.*?)\)|RedisAPI\.api\s*\((.*?)\)", text, re.I | re.S):
        redis_clients.append({
            "operation": "CREATE_CLIENT", "target": _clean(next((x for x in match.groups() if x), "")),
            "source_component": _class_at(text, match.start(), path.stem),
            "source_path": rel, "line": _line(text, match.start()),
        })
    for match in re.finditer(r"KafkaConsumer\.create\s*\((.*?)\)|KafkaProducer\.create\s*\((.*?)\)", text, re.I | re.S):
        kafka_clients.append({
            "client_type": "CONSUMER" if "KafkaConsumer" in match.group(0) else "PRODUCER",
            "config": _clean(next((x for x in match.groups() if x), "")),
            "source_component": _class_at(text, match.start(), path.stem),
            "source_path": rel, "line": _line(text, match.start()),
        })
    for match in re.finditer(r"\.subscribe\s*\(\s*([^\)]+)\)|\.send\s*\(\s*([^\)]+)\)", text, re.I):
        prefix = text[max(0, match.start()-180):match.start()].lower()
        if "kafka" not in prefix:
            continue
        kafka_clients.append({
            "client_type": "CONSUME" if "subscribe" in match.group(0).lower() else "PRODUCE",
            "config": _clean(next((x for x in match.groups() if x), "")),
            "source_component": _class_at(text, match.start(), path.stem),
            "source_path": rel, "line": _line(text, match.start()),
        })

    for match in re.finditer(r"VertxPrometheusOptions|MicrometerMetricsOptions|setPrometheusOptions|setMetricsOptions", text, re.I):
        metrics.append({
            "feature": match.group(0), "source_component": _class_at(text, match.start(), path.stem),
            "source_path": rel, "line": _line(text, match.start()),
        })

    result = {
        "is_vertx": True,
        "verticles": _dedupe(verticles, ("class", "source_path", "line")),
        "deployments": _dedupe(deployments, ("deployer", "verticle", "source_path", "line")),
        "http_servers": _dedupe(http_servers, ("source_component", "port", "host", "source_path", "line")),
        "routes": _dedupe(routes, ("http_method", "path", "handler", "source_path", "line", "mounted_path")),
        "handlers": _dedupe(handlers, ("class", "handler", "source_path", "line")),
        "event_bus": _dedupe(event_bus, ("event_id",)),
        "event_bus_codecs": _dedupe(event_bus_codecs, ("message_type", "codec", "source_path", "line")),
        "service_proxies": _dedupe(service_proxies, ("kind", "address", "service", "source_path", "line")),
        "web_clients": _dedupe(web_clients, ("call_id",)),
        "config_keys": _dedupe(config_keys, ("key", "source_path", "line")),
        "shared_data": _dedupe(shared_data, ("map_type", "name", "source_path", "line")),
        "timers": _dedupe(timers, ("timer_type", "delay", "source_path", "line")),
        "sql_clients": _dedupe(sql_clients, ("operation", "target", "source_path", "line")),
        "redis_clients": _dedupe(redis_clients, ("operation", "target", "source_path", "line")),
        "kafka_clients": _dedupe(kafka_clients, ("client_type", "config", "source_path", "line")),
        "metrics": _dedupe(metrics, ("feature", "source_path", "line")),
        "subrouter_mounts": _dedupe(mounts, ("router", "prefix", "subrouter", "source_path", "line")),
    }
    return result
