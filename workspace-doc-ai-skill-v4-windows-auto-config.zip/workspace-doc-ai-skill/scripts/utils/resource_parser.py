from __future__ import annotations

import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence, Tuple

try:
    import yaml
except Exception:  # pragma: no cover - optional fallback
    yaml = None

from .config_loader import mask_text, mask_value
from .file_utils import read_text_safely

RESOURCE_TYPES = ("ORACLE", "REDIS", "ELASTICSEARCH", "KAFKA", "GRAFANA", "PROMETHEUS", "LOKI")

RESOURCE_HINTS: Dict[str, Sequence[str]] = {
    "ORACLE": (
        "jdbc:oracle", "oracle.jdbc", "ojdbc", "oracle.ucp", "oracle.net", "tnsnames", "simplejdbccall",
        "from dual", "nextval", "spring.datasource", "datasource.url",
    ),
    "REDIS": (
        "redis://", "rediss://", "spring.redis", "spring.data.redis", "redistemplate", "stringredistemplate",
        "redisson", "@cacheable", "@cacheput", "@cacheevict", "@redishash", "redismessage",
    ),
    "ELASTICSEARCH": (
        "elasticsearch", "spring.elasticsearch", "spring.data.elasticsearch", "resthighlevelclient",
        "elasticsearchoperations", "elasticsearchclient", "@document", "_cluster/health", "_cat/indices",
    ),
    "KAFKA": (
        "spring.kafka", "bootstrap.servers", "kafkatemplate", "@kafkalistener", "producerrecord", "consumerrecord",
        "kafka-clients", "kafka-streams", "schema.registry", "confluent",
    ),
    "GRAFANA": (
        "grafana", "grafana.ini", "/api/dashboards", "/api/datasources", "dashboardproviders", "grafana.com",
    ),
    "PROMETHEUS": (
        "prometheus", "micrometer-registry-prometheus", "meterregistry", "counter.builder", "timer.builder",
        "servicemonitor", "podmonitor", "prometheusrule", "/api/v1/targets", "remote_write",
    ),
    "LOKI": (
        "loki", "promtail", "loki4j", "logql", "/loki/api/v1", "clients:", "positions:", "pipeline_stages",
    ),
}

URL_PATTERNS: Dict[str, re.Pattern[str]] = {
    "ORACLE": re.compile(r"jdbc:oracle:[^\s\"'<>]+", re.I),
    "REDIS": re.compile(r"rediss?://[^\s\"'<>]+", re.I),
    "ELASTICSEARCH": re.compile(r"https?://[^\s\"'<>]*(?:9200|elasticsearch|elastic)[^\s\"'<>]*", re.I),
    "KAFKA": re.compile(r"(?:[A-Za-z0-9_.-]+:\d{2,5})(?:\s*,\s*[A-Za-z0-9_.-]+:\d{2,5})+|[A-Za-z0-9_.-]+:9092", re.I),
    "GRAFANA": re.compile(r"https?://[^\s\"'<>]*(?:3000|grafana)[^\s\"'<>]*", re.I),
    "PROMETHEUS": re.compile(r"https?://[^\s\"'<>]*(?:9090|prometheus)[^\s\"'<>]*", re.I),
    "LOKI": re.compile(r"https?://[^\s\"'<>]*(?:3100|loki)[^\s\"'<>]*", re.I),
}

SQL_TABLE_PATTERNS: Sequence[Tuple[str, re.Pattern[str]]] = (
    ("READ", re.compile(r"\b(?:FROM|JOIN)\s+([A-Za-z0-9_$#\.\"`]+)", re.I)),
    ("INSERT", re.compile(r"\bINSERT\s+INTO\s+([A-Za-z0-9_$#\.\"`]+)", re.I)),
    ("UPDATE", re.compile(r"\bUPDATE\s+([A-Za-z0-9_$#\.\"`]+)", re.I)),
    ("DELETE", re.compile(r"\bDELETE\s+FROM\s+([A-Za-z0-9_$#\.\"`]+)", re.I)),
    ("UPSERT", re.compile(r"\bMERGE\s+INTO\s+([A-Za-z0-9_$#\.\"`]+)", re.I)),
)


def _line(text: str, offset: int) -> int:
    return text.count("\n", 0, max(0, offset)) + 1


def _rel(path: Path, root: Path) -> str:
    return str(path.relative_to(root)).replace("\\", "/")


def _clean_token(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip().strip("\"'")
    return mask_text(text)


def _dedupe(rows: Iterable[Dict[str, Any]], keys: Sequence[str]) -> List[Dict[str, Any]]:
    out: Dict[Tuple[Any, ...], Dict[str, Any]] = {}
    for row in rows:
        key = tuple(row.get(k) for k in keys)
        out[key] = row
    return list(out.values())


def _flatten(data: Any, prefix: str = "") -> Iterable[Tuple[str, Any]]:
    if isinstance(data, dict):
        for key, value in data.items():
            next_key = f"{prefix}.{key}" if prefix else str(key)
            yield from _flatten(value, next_key)
    elif isinstance(data, list):
        for idx, value in enumerate(data):
            next_key = f"{prefix}[{idx}]"
            yield from _flatten(value, next_key)
    else:
        yield prefix, data


def _key_line_map(text: str) -> Dict[str, int]:
    result: Dict[str, int] = {}
    for i, raw in enumerate(text.splitlines(), start=1):
        stripped = raw.strip()
        if not stripped or stripped.startswith(("#", "//")):
            continue
        m = re.match(r"[\-\s]*([A-Za-z0-9_.\-]+)\s*[:=]", stripped)
        if m and m.group(1) not in result:
            result[m.group(1)] = i
    return result


def extract_config_entries(path: Path, root: Path) -> List[Dict[str, Any]]:
    """Return flattened configuration entries with masked values and best-effort line numbers."""
    rel = _rel(path, root)
    text = read_text_safely(path, max_chars=2_000_000)
    suffix = path.suffix.lower()
    entries: List[Dict[str, Any]] = []
    line_map = _key_line_map(text)

    parsed = False
    if suffix in {".yml", ".yaml"} and yaml is not None and "{{" not in text:
        try:
            for doc in yaml.safe_load_all(text):
                if doc is None:
                    continue
                for key, value in _flatten(doc):
                    leaf = re.sub(r"\[\d+\]$", "", key.split(".")[-1])
                    entries.append({
                        "key": key,
                        "value_sample": mask_value(key, _clean_token(value)),
                        "line": line_map.get(leaf, 0),
                        "source_path": rel,
                        "format": "yaml",
                    })
            parsed = True
        except Exception:
            parsed = False
    elif suffix == ".json":
        try:
            obj = json.loads(text)
            for key, value in _flatten(obj):
                leaf = re.sub(r"\[\d+\]$", "", key.split(".")[-1])
                entries.append({
                    "key": key,
                    "value_sample": mask_value(key, _clean_token(value)),
                    "line": line_map.get(leaf, 0),
                    "source_path": rel,
                    "format": "json",
                })
            parsed = True
        except Exception:
            parsed = False
    elif suffix in {".properties", ".conf", ".ini", ".env"} or path.name.lower().startswith(".env"):
        for i, raw in enumerate(text.splitlines(), start=1):
            line = raw.strip()
            if not line or line.startswith(("#", ";")) or "=" not in line:
                continue
            key, value = line.split("=", 1)
            entries.append({
                "key": key.strip(),
                "value_sample": mask_value(key, _clean_token(value)),
                "line": i,
                "source_path": rel,
                "format": "properties",
            })
        parsed = True

    if not parsed:
        # Handles Helm templates, shell exports, XML snippets and malformed YAML.
        for i, raw in enumerate(text.splitlines(), start=1):
            line = raw.strip()
            if not line or line.startswith(("#", "//", "<!--")):
                continue
            m = re.match(r"(?:export\s+)?([A-Za-z_][A-Za-z0-9_.\-]*)\s*[:=]\s*(.*)$", line)
            if m:
                key, value = m.group(1), m.group(2).rstrip(",")
                entries.append({
                    "key": key,
                    "value_sample": mask_value(key, _clean_token(value)),
                    "line": i,
                    "source_path": rel,
                    "format": "line",
                })
    return _dedupe(entries, ("key", "value_sample", "source_path", "line"))[:5000]


def detect_resource_config(entries: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for entry in entries:
        source = f"{entry.get('key', '')} {entry.get('value_sample', '')}".lower()
        for resource_type, hints in RESOURCE_HINTS.items():
            if any(h in source for h in hints):
                value = str(entry.get("value_sample", ""))
                endpoint = ""
                match = URL_PATTERNS[resource_type].search(value)
                if match:
                    endpoint = mask_text(match.group(0))
                rows.append({
                    "resource_type": resource_type,
                    "key": entry.get("key", ""),
                    "value_sample": entry.get("value_sample", ""),
                    "endpoint": endpoint,
                    "source_path": entry.get("source_path", ""),
                    "line": entry.get("line", 0),
                    "detection": "CONFIG",
                    "confidence": "HIGH" if endpoint or resource_type.lower() in source else "MEDIUM",
                })
    return _dedupe(rows, ("resource_type", "key", "value_sample", "source_path", "line"))


def _component_name(text: str, path: Path, offset: int) -> str:
    prefix = text[:offset]
    classes = list(re.finditer(r"\b(?:class|interface|record|object)\s+([A-Za-z_$][\w$]*)", prefix))
    return classes[-1].group(1) if classes else path.stem


def _add_interface(
    rows: List[Dict[str, Any]], resource_type: str, direction: str, operation: str, target: str,
    api: str, path: Path, root: Path, text: str, offset: int, detail: str = "", confidence: str = "HIGH",
) -> None:
    rows.append({
        "resource_type": resource_type,
        "direction": direction,
        "source_component": _component_name(text, path, offset),
        "operation": operation,
        "target": _clean_token(target) or "확인필요",
        "client_api": api,
        "detail": mask_text(detail),
        "source_path": _rel(path, root),
        "line": _line(text, offset),
        "confidence": confidence,
    })


def _annotation_value(raw: str, names: Sequence[str]) -> str:
    for name in names:
        m = re.search(rf"\b{name}\s*=\s*(?:\{{\s*)?([^,)}}]+)", raw, re.I)
        if m:
            return _clean_token(m.group(1))
    q = re.search(r"\"([^\"]+)\"", raw)
    return _clean_token(q.group(1)) if q else ""


def analyze_code_integrations(path: Path, root: Path) -> Dict[str, List[Dict[str, Any]]]:
    rel = _rel(path, root)
    text = read_text_safely(path, max_chars=3_000_000)
    interfaces: List[Dict[str, Any]] = []
    assets: List[Dict[str, Any]] = []

    # Oracle / JDBC SQL tables and procedures.
    if any(x in text.lower() for x in ("jdbc", "@query", "select ", "insert ", "update ", "delete ", "merge ", "@procedure", "simplejdbccall")):
        for op, pat in SQL_TABLE_PATTERNS:
            for m in pat.finditer(text):
                target = m.group(1).strip('`"')
                if target.lower() in {"select", "values", "set", "dual"}:
                    continue
                _add_interface(interfaces, "ORACLE", "OUTBOUND", op, target, "SQL/JDBC/JPA/MyBatis", path, root, text, m.start(), m.group(0), "MEDIUM")
        procedure_patterns = (
            re.compile(r"@Procedure\s*\(([^)]*)\)", re.I | re.S),
            re.compile(r"withProcedureName\s*\(\s*[\"']([^\"']+)", re.I),
            re.compile(r"\b(?:CALL|EXEC(?:UTE)?)\s+([A-Za-z0-9_$#\.]+)", re.I),
        )
        for pat in procedure_patterns:
            for m in pat.finditer(text):
                raw = m.group(1)
                target = _annotation_value(raw, ("procedureName", "value")) if "=" in raw else _clean_token(raw)
                _add_interface(interfaces, "ORACLE", "OUTBOUND", "CALL_PROCEDURE", target, "Stored Procedure", path, root, text, m.start(), m.group(0))
        for m in re.finditer(r"\b([A-Za-z0-9_$#\.]+)\.NEXTVAL\b", text, re.I):
            _add_interface(interfaces, "ORACLE", "OUTBOUND", "NEXTVAL", m.group(1), "Oracle Sequence", path, root, text, m.start())

    # Redis cache/data/lock/pub-sub.
    for ann, op in (("Cacheable", "CACHE_READ"), ("CachePut", "CACHE_WRITE"), ("CacheEvict", "CACHE_EVICT")):
        pat = re.compile(rf"@{ann}\s*\((.*?)\)", re.I | re.S)
        for m in pat.finditer(text):
            target = _annotation_value(m.group(1), ("cacheNames", "value"))
            _add_interface(interfaces, "REDIS", "OUTBOUND", op, target, f"@{ann}", path, root, text, m.start(), m.group(0))
    for m in re.finditer(r"@RedisHash\s*\(\s*[\"']([^\"']+)", text, re.I):
        _add_interface(interfaces, "REDIS", "OUTBOUND", "HASH_PERSIST", m.group(1), "@RedisHash", path, root, text, m.start())
    redis_calls = (
        ("GET", re.compile(r"opsForValue\s*\(\s*\)\s*\.get\s*\(([^,\)]+)", re.I)),
        ("SET", re.compile(r"opsForValue\s*\(\s*\)\s*\.set\s*\(([^,\)]+)", re.I)),
        ("HASH", re.compile(r"opsForHash\s*\(\s*\)\s*\.(?:get|put|entries|delete)\s*\(([^,\)]+)", re.I)),
        ("DELETE", re.compile(r"(?:redisTemplate|stringRedisTemplate)\.delete\s*\(([^\)]+)", re.I)),
        ("PUBLISH", re.compile(r"convertAndSend\s*\(([^,\)]+)", re.I)),
        ("LOCK", re.compile(r"getLock\s*\(([^\)]+)", re.I)),
    )
    for op, pat in redis_calls:
        for m in pat.finditer(text):
            _add_interface(interfaces, "REDIS", "OUTBOUND", op, m.group(1), "RedisTemplate/Redisson", path, root, text, m.start(), m.group(0), "MEDIUM")
    for m in re.finditer(r"(?:ChannelTopic|PatternTopic)\s*\(\s*[\"']([^\"']+)", text, re.I):
        _add_interface(interfaces, "REDIS", "BIDIRECTIONAL", "PUBSUB_TOPIC", m.group(1), "Redis Topic", path, root, text, m.start())

    # Elasticsearch indices, documents and repositories.
    for m in re.finditer(r"@Document\s*\((.*?)\)", text, re.I | re.S):
        target = _annotation_value(m.group(1), ("indexName", "value"))
        _add_interface(interfaces, "ELASTICSEARCH", "OUTBOUND", "INDEX_MAPPING", target, "@Document", path, root, text, m.start(), m.group(0))
        assets.append({"resource_type": "ELASTICSEARCH", "asset_type": "INDEX", "name": target or "확인필요", "source_path": rel, "line": _line(text, m.start()), "detail": "Spring Data @Document"})
    for m in re.finditer(r"extends\s+(?:Reactive)?ElasticsearchRepository\s*<\s*([^,>]+)", text, re.I):
        _add_interface(interfaces, "ELASTICSEARCH", "OUTBOUND", "REPOSITORY", m.group(1), "ElasticsearchRepository", path, root, text, m.start())
    es_patterns = (
        ("SEARCH", re.compile(r"(?:SearchRequest|withIndex|IndexCoordinates\.of)\s*\(\s*[\"']([^\"']+)", re.I)),
        ("INDEX", re.compile(r"(?:IndexRequest|DeleteIndexRequest|CreateIndexRequest)\s*\(\s*[\"']([^\"']+)", re.I)),
        ("INDEX", re.compile(r"\.index\s*\(\s*[\"']([^\"']+)", re.I)),
    )
    for op, pat in es_patterns:
        for m in pat.finditer(text):
            _add_interface(interfaces, "ELASTICSEARCH", "OUTBOUND", op, m.group(1), "Elasticsearch Client", path, root, text, m.start())

    # Kafka producers, consumers and streams.
    for m in re.finditer(r"@KafkaListener\s*\((.*?)\)", text, re.I | re.S):
        raw = m.group(1)
        topics_raw = _annotation_value(raw, ("topics", "topicPattern"))
        group_id = _annotation_value(raw, ("groupId",))
        _add_interface(interfaces, "KAFKA", "INBOUND", "CONSUME", topics_raw, "@KafkaListener", path, root, text, m.start(), f"groupId={group_id}")
    kafka_patterns = (
        ("PRODUCE", re.compile(r"(?:kafkaTemplate|KafkaTemplate[^;\n]*)\.send\s*\(\s*([^,\)]+)", re.I)),
        ("PRODUCE", re.compile(r"new\s+ProducerRecord\s*<[^>]*>?\s*\(\s*([^,\)]+)", re.I)),
        ("STREAM_SOURCE", re.compile(r"\.stream\s*\(\s*([^,\)]+)", re.I)),
        ("STREAM_SINK", re.compile(r"\.to\s*\(\s*([^,\)]+)", re.I)),
        ("REPLY", re.compile(r"@SendTo\s*\(\s*([^\)]+)", re.I)),
    )
    for op, pat in kafka_patterns:
        for m in pat.finditer(text):
            direction = "INBOUND" if op == "STREAM_SOURCE" else "OUTBOUND"
            _add_interface(interfaces, "KAFKA", direction, op, m.group(1), "Kafka API", path, root, text, m.start(), m.group(0), "MEDIUM")

    # Prometheus/Micrometer metric definitions.
    metric_patterns = (
        ("COUNTER", re.compile(r"(?:Counter\.builder|\.counter)\s*\(\s*[\"']([^\"']+)", re.I)),
        ("TIMER", re.compile(r"(?:Timer\.builder|\.timer)\s*\(\s*[\"']([^\"']+)", re.I)),
        ("GAUGE", re.compile(r"Gauge\.builder\s*\(\s*[\"']([^\"']+)", re.I)),
        ("SUMMARY", re.compile(r"DistributionSummary\.builder\s*\(\s*[\"']([^\"']+)", re.I)),
        ("TIMED", re.compile(r"@Timed\s*\((.*?)\)", re.I | re.S)),
        ("COUNTED", re.compile(r"@Counted\s*\((.*?)\)", re.I | re.S)),
    )
    for metric_type, pat in metric_patterns:
        for m in pat.finditer(text):
            target = _annotation_value(m.group(1), ("value",)) if metric_type in {"TIMED", "COUNTED"} else _clean_token(m.group(1))
            _add_interface(interfaces, "PROMETHEUS", "OUTBOUND", "EMIT_METRIC", target, f"Micrometer {metric_type}", path, root, text, m.start())
            assets.append({"resource_type": "PROMETHEUS", "asset_type": "METRIC", "name": target or "확인필요", "source_path": rel, "line": _line(text, m.start()), "detail": metric_type})

    # Loki logging client / appender hints.
    loki_patterns = (
        ("PUSH_LOG", re.compile(r"(?:Loki4jAppender|LokiAppender|loki-logback-appender)", re.I)),
        ("LOKI_QUERY", re.compile(r"\{[A-Za-z_][^\n{}]{0,200}(?:=|=~|!=|!~)[^\n{}]{0,200}\}\s*(?:\|[^\n]+)?", re.I)),
    )
    for op, pat in loki_patterns:
        for m in pat.finditer(text):
            target = "Loki" if op == "PUSH_LOG" else m.group(0)[:200]
            _add_interface(interfaces, "LOKI", "OUTBOUND" if op == "PUSH_LOG" else "INBOUND", op, target, "Logging/LogQL", path, root, text, m.start(), m.group(0), "MEDIUM")

    # Generic detected endpoints in source/config templates.
    for resource_type, pat in URL_PATTERNS.items():
        for m in pat.finditer(text):
            assets.append({
                "resource_type": resource_type,
                "asset_type": "ENDPOINT_CANDIDATE",
                "name": mask_text(m.group(0)),
                "source_path": rel,
                "line": _line(text, m.start()),
                "detail": "source text",
            })

    return {
        "interfaces": _dedupe(interfaces, ("resource_type", "direction", "operation", "target", "source_path", "line")),
        "assets": _dedupe(assets, ("resource_type", "asset_type", "name", "source_path", "line")),
    }


def parse_grafana_dashboard(path: Path, root: Path) -> Dict[str, List[Dict[str, Any]]]:
    rel = _rel(path, root)
    try:
        obj = json.loads(read_text_safely(path, max_chars=8_000_000))
    except Exception:
        return {"dashboards": [], "panels": [], "datasources": [], "queries": []}
    dash = obj.get("dashboard", obj) if isinstance(obj, dict) else {}
    if not isinstance(dash, dict) or not ("panels" in dash or "templating" in dash or "title" in dash):
        return {"dashboards": [], "panels": [], "datasources": [], "queries": []}

    dashboard = {
        "title": dash.get("title", path.stem),
        "uid": dash.get("uid", ""),
        "tags": dash.get("tags", []),
        "schema_version": dash.get("schemaVersion", ""),
        "source_path": rel,
    }
    panels: List[Dict[str, Any]] = []
    datasources: List[Dict[str, Any]] = []
    queries: List[Dict[str, Any]] = []

    def walk(items: Any) -> None:
        if not isinstance(items, list):
            return
        for panel in items:
            if not isinstance(panel, dict):
                continue
            ds = panel.get("datasource")
            ds_type = ds.get("type", "") if isinstance(ds, dict) else ""
            ds_uid = ds.get("uid", "") if isinstance(ds, dict) else (ds or "")
            panels.append({
                "dashboard_title": dashboard["title"],
                "dashboard_uid": dashboard["uid"],
                "panel_id": panel.get("id", ""),
                "panel_title": panel.get("title", ""),
                "panel_type": panel.get("type", ""),
                "datasource_type": ds_type,
                "datasource_uid": ds_uid,
                "source_path": rel,
            })
            if ds_type or ds_uid:
                datasources.append({"type": ds_type, "uid": ds_uid, "name": ds_uid, "source_path": rel, "detection": "DASHBOARD"})
            for target in panel.get("targets", []) or []:
                if not isinstance(target, dict):
                    continue
                expr = target.get("expr") or target.get("query") or target.get("rawSql") or target.get("queryText") or ""
                target_ds = target.get("datasource")
                target_type = target_ds.get("type", "") if isinstance(target_ds, dict) else ds_type
                queries.append({
                    "dashboard_title": dashboard["title"],
                    "panel_title": panel.get("title", ""),
                    "ref_id": target.get("refId", ""),
                    "datasource_type": target_type,
                    "query": mask_text(str(expr))[:4000],
                    "source_path": rel,
                })
            walk(panel.get("panels"))

    walk(dash.get("panels"))
    templating = ((dash.get("templating") or {}).get("list") or []) if isinstance(dash.get("templating"), dict) else []
    for item in templating:
        if isinstance(item, dict) and item.get("datasource"):
            datasources.append({"type": item.get("type", "variable"), "uid": str(item.get("datasource", "")), "name": item.get("name", ""), "source_path": rel, "detection": "TEMPLATING"})
    return {
        "dashboards": [dashboard],
        "panels": panels,
        "datasources": _dedupe(datasources, ("type", "uid", "name", "source_path")),
        "queries": queries,
    }


def _yaml_documents(text: str) -> List[Any]:
    if yaml is None or "{{" in text:
        return []
    try:
        return [x for x in yaml.safe_load_all(text) if x is not None]
    except Exception:
        return []


def parse_infrastructure_file(path: Path, root: Path) -> Dict[str, List[Dict[str, Any]]]:
    rel = _rel(path, root)
    text = read_text_safely(path, max_chars=8_000_000)
    lower = text.lower()
    resources: List[Dict[str, Any]] = []
    deployments: List[Dict[str, Any]] = []
    scrape_configs: List[Dict[str, Any]] = []
    rules: List[Dict[str, Any]] = []
    loki_jobs: List[Dict[str, Any]] = []
    datasources: List[Dict[str, Any]] = []

    docs = _yaml_documents(text) if path.suffix.lower() in {".yml", ".yaml"} else []
    for doc in docs:
        if not isinstance(doc, dict):
            continue
        kind = str(doc.get("kind", ""))
        meta = doc.get("metadata") or {}
        spec = doc.get("spec") or {}
        if kind:
            resources.append({
                "kind": kind,
                "name": meta.get("name", ""),
                "namespace": meta.get("namespace", ""),
                "source_path": rel,
                "resource_type": (
                    "PROMETHEUS" if kind in {"ServiceMonitor", "PodMonitor", "PrometheusRule", "Prometheus"}
                    else "GRAFANA" if "Grafana" in kind
                    else "LOKI" if kind in {"LokiStack", "Loki", "Promtail"}
                    else "KUBERNETES"
                ),
            })
        if kind in {"Deployment", "StatefulSet", "DaemonSet", "Job", "CronJob"}:
            template = spec.get("template", {}) if kind != "CronJob" else (((spec.get("jobTemplate") or {}).get("spec") or {}).get("template") or {})
            pod_spec = template.get("spec") or {}
            for container in (pod_spec.get("containers") or []) + (pod_spec.get("initContainers") or []):
                if not isinstance(container, dict):
                    continue
                deployments.append({
                    "kind": kind,
                    "workload": meta.get("name", ""),
                    "namespace": meta.get("namespace", ""),
                    "container": container.get("name", ""),
                    "image": container.get("image", ""),
                    "ports": [p.get("containerPort") for p in container.get("ports", []) if isinstance(p, dict)],
                    "env_names": [e.get("name") for e in container.get("env", []) if isinstance(e, dict)],
                    "source_path": rel,
                })
        if kind in {"ServiceMonitor", "PodMonitor"}:
            for endpoint in spec.get("endpoints", []) or []:
                if isinstance(endpoint, dict):
                    scrape_configs.append({
                        "type": kind,
                        "job_name": meta.get("name", ""),
                        "namespace": meta.get("namespace", ""),
                        "target": endpoint.get("port") or endpoint.get("targetPort") or "",
                        "path": endpoint.get("path", "/metrics"),
                        "interval": endpoint.get("interval", ""),
                        "source_path": rel,
                    })
        if kind == "PrometheusRule":
            for group in spec.get("groups", []) or []:
                if not isinstance(group, dict):
                    continue
                for rule in group.get("rules", []) or []:
                    if isinstance(rule, dict):
                        rules.append({
                            "group": group.get("name", ""),
                            "name": rule.get("alert") or rule.get("record") or "",
                            "type": "ALERT" if rule.get("alert") else "RECORD",
                            "expr": mask_text(str(rule.get("expr", ""))),
                            "for": rule.get("for", ""),
                            "source_path": rel,
                        })

        # Distinguish Prometheus scrape jobs from Promtail/Alloy jobs. Both use `scrape_configs`.
        scrape_jobs = doc.get("scrape_configs", []) or []
        is_loki_document = bool(doc.get("clients") or doc.get("positions")) or any(
            isinstance(job, dict) and any(key in job for key in ("pipeline_stages", "journal", "docker_sd_configs"))
            for job in scrape_jobs
        )
        if not is_loki_document:
            for job in scrape_jobs:
                if not isinstance(job, dict):
                    continue
                targets: List[str] = []
                for static in job.get("static_configs", []) or []:
                    if isinstance(static, dict):
                        targets.extend([str(x) for x in static.get("targets", []) or []])
                scrape_configs.append({
                    "type": "prometheus.yml",
                    "job_name": job.get("job_name", ""),
                    "namespace": "",
                    "target": ", ".join(targets),
                    "path": job.get("metrics_path", "/metrics"),
                    "interval": job.get("scrape_interval", ""),
                    "source_path": rel,
                })

        # Loki/Promtail/Alloy configuration.
        clients = doc.get("clients") or []
        if isinstance(clients, list):
            for client in clients:
                if isinstance(client, dict) and client.get("url"):
                    resources.append({"kind": "LokiClient", "name": mask_text(str(client.get("url"))), "namespace": "", "source_path": rel, "resource_type": "LOKI"})
        for job in doc.get("scrape_configs", []) or []:
            if not isinstance(job, dict):
                continue
            if "pipeline_stages" in job or "journal" in job or "docker_sd_configs" in job:
                loki_jobs.append({
                    "job_name": job.get("job_name", ""),
                    "pipeline_stage_count": len(job.get("pipeline_stages", []) or []),
                    "source_path": rel,
                })

        # Grafana provisioning datasource files.
        for ds in doc.get("datasources", []) or []:
            if isinstance(ds, dict):
                datasources.append({
                    "type": ds.get("type", ""),
                    "uid": ds.get("uid", ""),
                    "name": ds.get("name", ""),
                    "url": mask_text(str(ds.get("url", ""))),
                    "access": ds.get("access", ""),
                    "source_path": rel,
                    "detection": "PROVISIONING",
                })

    # Helm/template fallback detections.
    for m in re.finditer(r"\bkind\s*:\s*(ServiceMonitor|PodMonitor|PrometheusRule|Deployment|StatefulSet|DaemonSet|Service|Ingress)\b", text, re.I):
        resources.append({"kind": m.group(1), "name": "확인필요", "namespace": "", "source_path": rel, "resource_type": "PROMETHEUS" if "monitor" in m.group(1).lower() or "prometheus" in m.group(1).lower() else "KUBERNETES", "line": _line(text, m.start())})

    if "scrape_configs" in lower and not scrape_configs and not loki_jobs:
        for m in re.finditer(r"job_name\s*:\s*[\"']?([^\"'\n#]+)", text, re.I):
            scrape_configs.append({"type": "text", "job_name": m.group(1).strip(), "target": "확인필요", "path": "/metrics", "source_path": rel, "line": _line(text, m.start())})
    if "pipeline_stages" in lower and not loki_jobs:
        for m in re.finditer(r"job_name\s*:\s*[\"']?([^\"'\n#]+)", text, re.I):
            loki_jobs.append({"job_name": m.group(1).strip(), "pipeline_stage_count": "확인필요", "source_path": rel, "line": _line(text, m.start())})

    return {
        "manifests": _dedupe(resources, ("kind", "name", "namespace", "source_path")),
        "deployments": _dedupe(deployments, ("kind", "workload", "container", "source_path")),
        "prometheus_scrapes": _dedupe(scrape_configs, ("type", "job_name", "target", "source_path")),
        "prometheus_rules": _dedupe(rules, ("group", "name", "source_path")),
        "loki_jobs": _dedupe(loki_jobs, ("job_name", "source_path")),
        "grafana_datasources": _dedupe(datasources, ("type", "uid", "name", "source_path")),
    }


def build_resource_inventory(
    configs: Sequence[Dict[str, Any]], interfaces: Sequence[Dict[str, Any]], assets: Sequence[Dict[str, Any]],
    manifests: Sequence[Dict[str, Any]], dependencies: Sequence[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for c in configs:
        rows.append({
            "resource_type": c.get("resource_type"),
            "name": c.get("key"),
            "role": "CONFIGURATION",
            "target": c.get("endpoint") or c.get("value_sample"),
            "detection": c.get("detection", "CONFIG"),
            "confidence": c.get("confidence", "MEDIUM"),
            "source_path": c.get("source_path", ""),
            "line": c.get("line", 0),
        })
    for i in interfaces:
        rows.append({
            "resource_type": i.get("resource_type"),
            "name": i.get("target"),
            "role": i.get("operation"),
            "target": i.get("target"),
            "detection": "CODE_INTERFACE",
            "confidence": i.get("confidence", "MEDIUM"),
            "source_path": i.get("source_path", ""),
            "line": i.get("line", 0),
        })
    for a in assets:
        rows.append({
            "resource_type": a.get("resource_type"),
            "name": a.get("name"),
            "role": a.get("asset_type"),
            "target": a.get("name"),
            "detection": "ASSET",
            "confidence": "HIGH",
            "source_path": a.get("source_path", ""),
            "line": a.get("line", 0),
        })
    for m in manifests:
        rtype = m.get("resource_type")
        if rtype in RESOURCE_TYPES:
            rows.append({
                "resource_type": rtype,
                "name": m.get("name"),
                "role": m.get("kind"),
                "target": m.get("namespace", ""),
                "detection": "MANIFEST",
                "confidence": "HIGH",
                "source_path": m.get("source_path", ""),
                "line": m.get("line", 0),
            })
    dep_map = {
        "oracle": "ORACLE", "ojdbc": "ORACLE", "redis": "REDIS", "redisson": "REDIS",
        "elasticsearch": "ELASTICSEARCH", "kafka": "KAFKA", "prometheus": "PROMETHEUS",
        "micrometer": "PROMETHEUS", "loki": "LOKI", "grafana": "GRAFANA",
    }
    for dep in dependencies:
        gav = f"{dep.get('group', '')}:{dep.get('artifact', '')}".lower()
        for hint, resource_type in dep_map.items():
            if hint in gav:
                rows.append({
                    "resource_type": resource_type,
                    "name": f"{dep.get('group', '')}:{dep.get('artifact', '')}",
                    "role": "LIBRARY",
                    "target": dep.get("version", ""),
                    "detection": "DEPENDENCY",
                    "confidence": "HIGH",
                    "source_path": dep.get("source_path", ""),
                    "line": dep.get("line", 0),
                })
                break
    return _dedupe(rows, ("resource_type", "name", "role", "target", "source_path", "line"))


def build_resource_topology(interfaces: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for item in interfaces:
        target = f"{item.get('resource_type')}:{item.get('target')}"
        if item.get("direction") == "INBOUND":
            source, dest = target, item.get("source_component")
        else:
            source, dest = item.get("source_component"), target
        rows.append({
            "edge_type": "RESOURCE_INTERFACE",
            "resource_type": item.get("resource_type"),
            "source": source,
            "target": dest,
            "operation": item.get("operation"),
            "source_path": item.get("source_path"),
            "line": item.get("line", 0),
            "confidence": item.get("confidence", "MEDIUM"),
        })
    return _dedupe(rows, ("resource_type", "source", "target", "operation", "source_path", "line"))
