from __future__ import annotations

import base64
import json
import os
import re
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Mapping, MutableMapping, Optional, Sequence, Tuple
from urllib.parse import unquote, urlparse, urlsplit, urlunsplit

import yaml

from .config_loader import deep_mask, deep_merge, is_sensitive_key, mask_text
from .file_utils import read_text_safely

DEFAULT_IGNORE_DIRS = {
    ".git", ".idea", ".vscode", ".gradle", ".mvn", ".venv", "venv", "node_modules",
    "dist", "build", "target", "out", "coverage", ".next", ".nuxt", ".cache", "output", "workspace-doc-output",
}

CONFIG_NAMES = {
    "application.yml", "application.yaml", "application.properties", "bootstrap.yml", "bootstrap.yaml",
    "bootstrap.properties", "config.yml", "config.yaml", "config.json", "vertx-config.json", "vertx.json",
    "redisson.yml", "redisson.yaml", "redisson.json", "docker-compose.yml", "docker-compose.yaml",
    "prometheus.yml", "prometheus.yaml", "promtail.yml", "promtail.yaml", "grafana.ini",
}

CONFIG_SUFFIXES = {".yml", ".yaml", ".properties", ".json", ".conf", ".ini", ".toml", ".env", ".xml"}

ENV_RE = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::([^}]*))?}")
HOST_PORT_RE = re.compile(r"(?<![A-Za-z0-9_.-])([A-Za-z0-9_.-]+):(\d{2,5})(?!\d)")
HTTP_URL_RE = re.compile(r"https?://[^\s\"'<>\]\[{},]+", re.I)
REDIS_URL_RE = re.compile(r"rediss?://[^\s\"'<>\]\[{},]+", re.I)
ORACLE_URL_RE = re.compile(r"jdbc:oracle:[^\s\"'<>\]\[{},]+", re.I)


@dataclass
class ConfigEntry:
    key: str
    value: Any
    source_path: str
    line: int = 0
    profile: str = ""
    format: str = ""

    def text(self) -> str:
        if isinstance(self.value, (dict, list)):
            try:
                return json.dumps(self.value, ensure_ascii=False)
            except Exception:
                return str(self.value)
        return str(self.value or "")


@dataclass
class DiscoveryResult:
    workspace_root: Path
    system_name: str
    entries: List[ConfigEntry] = field(default_factory=list)
    evidence: List[Dict[str, Any]] = field(default_factory=list)
    modules: List[Dict[str, Any]] = field(default_factory=list)
    services: Dict[str, Any] = field(default_factory=dict)
    credentials: Dict[str, Any] = field(default_factory=dict)
    unresolved_secrets: List[Dict[str, Any]] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def masked_report(self) -> Dict[str, Any]:
        return deep_mask({
            "workspace_root": str(self.workspace_root),
            "system_name": self.system_name,
            "services": self.services,
            "credentials": self.credentials,
            "unresolved_secrets": self.unresolved_secrets,
            "modules": self.modules,
            "evidence": self.evidence,
            "warnings": self.warnings,
        })


def _rel(path: Path, root: Path) -> str:
    try:
        return str(path.relative_to(root)).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def _iter_files(root: Path, max_files: int = 200000) -> Iterator[Path]:
    count = 0
    for current, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = [d for d in dirs if d not in DEFAULT_IGNORE_DIRS and not (d.startswith(".") and d not in {".github"})]
        for name in files:
            path = Path(current) / name
            try:
                if path.stat().st_size > 12 * 1024 * 1024:
                    continue
            except OSError:
                continue
            count += 1
            if count > max_files:
                return
            yield path


def _flatten(value: Any, prefix: str = "") -> Iterator[Tuple[str, Any]]:
    if isinstance(value, Mapping):
        for key, child in value.items():
            next_key = f"{prefix}.{key}" if prefix else str(key)
            yield from _flatten(child, next_key)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            next_key = f"{prefix}[{index}]"
            yield from _flatten(child, next_key)
    else:
        yield prefix, value


def _line_for_key(text: str, leaf: str) -> int:
    if not leaf:
        return 0
    token = re.sub(r"\[\d+\]$", "", leaf)
    pattern = re.compile(rf"^\s*(?:[-]\s*)?{re.escape(token)}\s*[:=]", re.I)
    for index, raw in enumerate(text.splitlines(), start=1):
        if pattern.search(raw):
            return index
    return 0


def _profile_from_name(path: Path) -> str:
    name = path.name
    m = re.match(r"(?:application|bootstrap)-([^.]+)\.(?:ya?ml|properties)$", name, re.I)
    return m.group(1) if m else ""


def _parse_properties(text: str, rel: str, profile: str, fmt: str = "properties") -> List[ConfigEntry]:
    entries: List[ConfigEntry] = []
    pending = ""
    pending_line = 0
    for index, raw in enumerate(text.splitlines(), start=1):
        line = raw.rstrip()
        if not line.strip() or line.lstrip().startswith(("#", ";", "//")):
            continue
        if pending:
            line = pending + line.lstrip()
            index = pending_line
            pending = ""
        if line.endswith("\\"):
            pending = line[:-1]
            pending_line = index
            continue
        m = re.match(r"\s*(?:export\s+)?([^:=\s]+)\s*[:=]\s*(.*)$", line)
        if not m:
            continue
        entries.append(ConfigEntry(m.group(1).strip(), m.group(2).strip().strip("\"'"), rel, index, profile, fmt))
    return entries


def _parse_yaml_json(path: Path, text: str, rel: str, profile: str) -> List[ConfigEntry]:
    entries: List[ConfigEntry] = []
    try:
        docs: List[Any]
        if path.suffix.lower() == ".json":
            docs = [json.loads(text)]
        else:
            docs = list(yaml.safe_load_all(text))
        for doc in docs:
            if doc is None:
                continue
            for key, value in _flatten(doc):
                leaf = key.split(".")[-1]
                entries.append(ConfigEntry(key, value, rel, _line_for_key(text, leaf), profile, path.suffix.lower().lstrip(".")))
    except Exception:
        entries.extend(_parse_properties(text, rel, profile, "line"))
    return entries


def parse_config_file(path: Path, root: Path) -> List[ConfigEntry]:
    rel = _rel(path, root)
    text = read_text_safely(path, max_chars=2_000_000)
    profile = _profile_from_name(path)
    name = path.name.lower()
    suffix = path.suffix.lower()
    if suffix in {".yml", ".yaml", ".json"}:
        return _parse_yaml_json(path, text, rel, profile)
    if suffix in {".properties", ".env", ".conf", ".ini", ".toml"} or name.startswith(".env"):
        return _parse_properties(text, rel, profile, suffix.lstrip(".") or "env")
    if suffix == ".xml":
        # XML property elements and Maven/Spring resource filters.
        entries: List[ConfigEntry] = []
        for index, raw in enumerate(text.splitlines(), start=1):
            for m in re.finditer(r"<([A-Za-z_][\w.-]*)>([^<>]+)</\1>", raw):
                entries.append(ConfigEntry(m.group(1), m.group(2).strip(), rel, index, profile, "xml"))
            for m in re.finditer(r"<property\s+name=[\"']([^\"']+)[\"']\s+value=[\"']([^\"']*)[\"']", raw, re.I):
                entries.append(ConfigEntry(m.group(1), m.group(2), rel, index, profile, "xml"))
        return entries
    return []


def _candidate_config_file(path: Path) -> bool:
    name = path.name.lower()
    rel_lower = str(path).lower().replace("\\", "/")
    if name in CONFIG_NAMES or name.startswith(("application-", "bootstrap-", ".env")):
        return True
    if path.suffix.lower() in CONFIG_SUFFIXES:
        return any(token in rel_lower for token in (
            "/config/", "/resources/", "/deploy/", "/helm/", "/k8s/", "/kubernetes/", "/observability/",
            "/grafana/", "/prometheus/", "/loki/", "/docker/", "/charts/",
        ))
    return False


def _resolve_placeholder(value: Any, property_map: Mapping[str, Any]) -> Tuple[Any, List[str]]:
    if not isinstance(value, str):
        return value, []
    unresolved: List[str] = []

    def repl(match: re.Match[str]) -> str:
        name = match.group(1)
        default = match.group(2)
        if name in os.environ:
            return os.environ[name]
        if name in property_map and property_map[name] not in (None, ""):
            return str(property_map[name])
        if default not in (None, ""):
            return str(default)
        unresolved.append(name)
        return match.group(0)

    return ENV_RE.sub(repl, value), unresolved


def _entry_map(entries: Sequence[ConfigEntry]) -> Dict[str, Any]:
    result: Dict[str, Any] = {}
    # Base/application values first, explicit profiles later. This is best-effort; all evidence remains in report.
    ordered = sorted(entries, key=lambda e: (1 if e.profile else 0, e.source_path, e.line))
    for entry in ordered:
        result[entry.key] = entry.value
    return result


def _values(entries: Sequence[ConfigEntry], include: Sequence[str], exclude: Sequence[str] = ()) -> List[ConfigEntry]:
    rows: List[ConfigEntry] = []
    for entry in entries:
        key = entry.key.lower()
        if all(token.lower() in key for token in include) and not any(token.lower() in key for token in exclude):
            rows.append(entry)
    return rows


def _first(entries: Sequence[ConfigEntry], key_patterns: Sequence[Sequence[str]], exclude: Sequence[str] = ()) -> Optional[ConfigEntry]:
    for pattern in key_patterns:
        rows = _values(entries, pattern, exclude)
        if rows:
            # Prefer application/explicit runtime configs over examples/templates/tests.
            rows.sort(key=lambda e: (
                1 if any(x in e.source_path.lower() for x in ("example", "sample", "test", "template")) else 0,
                0 if "application" in Path(e.source_path).name.lower() else 1,
                e.source_path,
                e.line,
            ))
            return rows[0]
    return None


def _literal_secret(value: Any, property_map: Mapping[str, Any]) -> Tuple[str, List[str]]:
    resolved, unresolved = _resolve_placeholder(value, property_map)
    text = str(resolved or "").strip().strip("\"'")
    if not text or unresolved or text.startswith(("${", "{{", "<")):
        return "", unresolved
    return text, []


def _clean_url(value: Any) -> str:
    """Return a connection URL without embedded username/password information."""
    text = str(value or "").strip().strip("\"'").rstrip(",;])}")
    if text.lower().startswith(("http://", "https://", "redis://", "rediss://")):
        try:
            parsed = urlsplit(text)
            if parsed.hostname:
                host = parsed.hostname
                if ":" in host and not host.startswith("["):
                    host = f"[{host}]"
                netloc = host + (f":{parsed.port}" if parsed.port else "")
                return urlunsplit((parsed.scheme, netloc, parsed.path, parsed.query, parsed.fragment))
        except Exception:
            pass
    # Rare Oracle URLs may embed credentials as jdbc:oracle:thin:user/pass@//host.
    text = re.sub(r"(?i)^(jdbc:oracle:[^:]+:)[^/@:]+/[^@]+@", r"\1@", text)
    return text


def _url_credentials(value: Any) -> Tuple[str, str]:
    text = str(value or "").strip().strip("\"'")
    if not text.lower().startswith(("http://", "https://", "redis://", "rediss://")):
        return "", ""
    try:
        parsed = urlsplit(text)
        return unquote(parsed.username or ""), unquote(parsed.password or "")
    except Exception:
        return "", ""


def _split_csv(value: Any) -> List[str]:
    if value is None:
        return []
    if isinstance(value, list):
        result: List[str] = []
        for item in value:
            result.extend(_split_csv(item))
        return result
    text = str(value).strip().strip("[]")
    if not text:
        return []
    parts = re.split(r"\s*,\s*|\s+", text)
    return [p.strip().strip("\"'") for p in parts if p.strip().strip("\"'")]


def _normalise_host_port(value: str, default_port: int = 6379) -> str:
    text = str(value or "").strip().strip("\"'")
    if text.startswith(("redis://", "rediss://")):
        parsed = urlparse(text)
        return f"{parsed.hostname}:{parsed.port or default_port}" if parsed.hostname else ""
    text = text.rstrip("/")
    if ":" in text and text.rsplit(":", 1)[1].isdigit():
        return text
    return f"{text}:{default_port}" if text else ""


def _find_all_urls(files: Sequence[Path], root: Path, patterns: Sequence[re.Pattern[str]], limit: int = 500) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for path in files:
        if path.suffix.lower() not in CONFIG_SUFFIXES | {".java", ".kt", ".groovy", ".js", ".jsx", ".ts", ".tsx", ".ps1", ".bat", ".cmd", ".sh"}:
            continue
        try:
            text = read_text_safely(path, max_chars=1_000_000)
        except Exception:
            continue
        for pattern in patterns:
            for match in pattern.finditer(text):
                rows.append({
                    "value": match.group(0).rstrip(",;])}"),
                    "source_path": _rel(path, root),
                    "line": text.count("\n", 0, match.start()) + 1,
                })
                if len(rows) >= limit:
                    return rows
    return rows


def _detect_system_name(root: Path, files: Sequence[Path]) -> str:
    for path in files:
        name = path.name.lower()
        try:
            text = read_text_safely(path, max_chars=500_000)
        except Exception:
            continue
        if name in {"settings.gradle", "settings.gradle.kts"}:
            m = re.search(r"rootProject\.name\s*=\s*[\"']([^\"']+)", text)
            if m:
                return m.group(1)
        if name == "pom.xml":
            m = re.search(r"<artifactId>\s*([^<]+)\s*</artifactId>", text)
            if m:
                return m.group(1).strip()
        if name == "package.json":
            try:
                obj = json.loads(text)
                value = obj.get("name")
                if value:
                    return str(value)
            except Exception:
                pass
    return root.name or "TARGET_SYSTEM"


def _detect_modules(root: Path, files: Sequence[Path]) -> List[Dict[str, Any]]:
    rows: Dict[str, Dict[str, Any]] = {}
    for path in files:
        name = path.name.lower()
        if name not in {"pom.xml", "build.gradle", "build.gradle.kts", "package.json"}:
            continue
        module_path = _rel(path.parent, root) or "."
        row = rows.setdefault(module_path, {"path": module_path, "types": [], "manifests": []})
        row["manifests"].append(_rel(path, root))
        try:
            text = read_text_safely(path, max_chars=600_000)
        except Exception:
            text = ""
        if name == "package.json":
            try:
                obj = json.loads(text)
                deps = {**(obj.get("dependencies") or {}), **(obj.get("devDependencies") or {})}
                if "react" in deps:
                    row["types"].append("REACT")
                row["package_name"] = obj.get("name", "")
            except Exception:
                pass
        else:
            lower = text.lower()
            if "spring-boot" in lower or "org.springframework.boot" in lower:
                row["types"].append("SPRING_BOOT")
            if "vertx" in lower:
                row["types"].append("VERTX")
            row["types"].append("MAVEN" if name == "pom.xml" else "GRADLE")
        row["types"] = sorted(set(row["types"]))
    return sorted(rows.values(), key=lambda x: x["path"])


def _detect_react(root: Path, files: Sequence[Path], entries: Sequence[ConfigEntry]) -> Dict[str, Any]:
    packages: List[Dict[str, Any]] = []
    for path in files:
        if path.name.lower() != "package.json":
            continue
        try:
            obj = json.loads(read_text_safely(path, max_chars=1_000_000))
        except Exception:
            continue
        deps = {**(obj.get("dependencies") or {}), **(obj.get("devDependencies") or {})}
        if "react" not in deps:
            continue
        scripts = obj.get("scripts") or {}
        packages.append({"path": _rel(path, root), "dir": _rel(path.parent, root), "name": obj.get("name", ""), "deps": deps, "scripts": scripts, "proxy": obj.get("proxy", "")})
    if not packages:
        return {"detected": False, "base_url": "", "port": 0, "packages": []}
    package = packages[0]
    port = 0
    for entry in entries:
        key = entry.key.upper().replace(".", "_")
        if key in {"PORT", "VITE_PORT", "REACT_APP_PORT", "DEV_SERVER_PORT"}:
            try:
                port = int(str(entry.value))
                break
            except Exception:
                pass
    if not port:
        for value in (package.get("scripts") or {}).values():
            m = re.search(r"(?:--port\s+|--port=)(\d{2,5})", str(value))
            if m:
                port = int(m.group(1))
                break
    if not port:
        port = 5173 if "vite" in package.get("deps", {}) else 3000
    host = "localhost"
    for entry in entries:
        key = entry.key.upper().replace(".", "_")
        if key in {"HOST", "VITE_HOST", "DEV_SERVER_HOST"} and str(entry.value).strip() not in {"0.0.0.0", "::"}:
            host = str(entry.value).strip()
            break
    return {
        "detected": True,
        "base_url": f"http://{host}:{port}",
        "port": port,
        "packages": [{k: v for k, v in row.items() if k != "deps"} for row in packages],
        "proxy_targets": [str(p.get("proxy")) for p in packages if p.get("proxy")],
    }


def _detect_spring(entries: Sequence[ConfigEntry], modules: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    detected = any("SPRING_BOOT" in row.get("types", []) for row in modules)
    port_entry = _first(entries, [("server", "port")], exclude=("management",))
    context_entry = _first(entries, [("server", "servlet", "context-path"), ("server", "context-path")])
    management_entry = _first(entries, [("management", "server", "port")])
    try:
        port = int(str(port_entry.value)) if port_entry else 8080
    except Exception:
        port = 8080
    context_path = str(context_entry.value).strip() if context_entry else ""
    return {
        "detected": detected or bool(port_entry),
        "port": port,
        "base_url": f"http://localhost:{port}{('/' + context_path.strip('/')) if context_path else ''}",
        "context_path": context_path,
        "management_port": int(str(management_entry.value)) if management_entry and str(management_entry.value).isdigit() else port,
    }


def _detect_vertx(root: Path, files: Sequence[Path], entries: Sequence[ConfigEntry], modules: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    detected = any("VERTX" in row.get("types", []) for row in modules)
    candidates: List[Tuple[int, str, int]] = []
    for entry in entries:
        key = entry.key.lower()
        if "vertx" in key and any(token in key for token in ("port", "listen")) or key in {"http.port", "httpserver.port", "web.port"}:
            if str(entry.value).isdigit():
                candidates.append((0, entry.source_path, int(str(entry.value))))
    for path in files:
        if path.suffix.lower() not in {".java", ".kt", ".groovy"}:
            continue
        try:
            text = read_text_safely(path, max_chars=1_000_000)
        except Exception:
            continue
        if "vertx" not in text.lower():
            continue
        detected = True
        for match in re.finditer(r"\.listen\s*\(\s*(\d{2,5})", text):
            candidates.append((1, _rel(path, root), int(match.group(1))))
    port = candidates[0][2] if candidates else 8090
    return {"detected": detected, "port": port, "base_url": f"http://localhost:{port}", "evidence": [{"source_path": x[1], "port": x[2]} for x in candidates[:20]]}


def _credential_field(entries: Sequence[ConfigEntry], property_map: Mapping[str, Any], patterns: Sequence[Sequence[str]], resource: str, field_name: str) -> Tuple[str, List[Dict[str, Any]]]:
    entry = _first(entries, patterns)
    if not entry:
        return "", []
    value, unresolved = _literal_secret(entry.value, property_map)
    unresolved_rows = [{"resource": resource, "field": field_name, "reference": name, "source_path": entry.source_path, "line": entry.line} for name in unresolved]
    return value, unresolved_rows


def _detect_oracle(entries: Sequence[ConfigEntry], property_map: Mapping[str, Any], raw_urls: Sequence[Dict[str, Any]]) -> Tuple[Dict[str, Any], Dict[str, Any], List[Dict[str, Any]]]:
    url_entry = _first(entries, [
        ("spring", "datasource", "url"), ("datasource", "url"), ("jdbc", "url"), ("oracle", "url"), ("oracle", "dsn"),
    ])
    dsn = ""
    evidence: List[Dict[str, Any]] = []
    if url_entry:
        resolved, _ = _resolve_placeholder(url_entry.value, property_map)
        if "oracle" in str(resolved).lower():
            dsn = _clean_url(resolved)
            evidence.append({"key": url_entry.key, "source_path": url_entry.source_path, "line": url_entry.line})
    if not dsn:
        row = next((x for x in raw_urls if str(x.get("value", "")).lower().startswith("jdbc:oracle:")), None)
        if row:
            dsn = row["value"]
            evidence.append(row)
    username, unresolved_user = _credential_field(entries, property_map, [("datasource", "username"), ("oracle", "username"), ("oracle", "user")], "oracle", "username")
    password, unresolved_password = _credential_field(entries, property_map, [("datasource", "password"), ("oracle", "password")], "oracle", "password")
    service = {"detected": bool(dsn), "dsn": dsn, "evidence": evidence}
    creds = {k: v for k, v in {"username": username, "password": password}.items() if v}
    return service, creds, unresolved_user + unresolved_password


def _redis_node_entries(entries: Sequence[ConfigEntry]) -> List[ConfigEntry]:
    rows: List[ConfigEntry] = []
    for entry in entries:
        key = entry.key.lower()
        if any(token in key for token in (
            "redis.cluster.nodes", "redis.cluster.node", "cluster.servers", "clusterserversconfig.nodeaddresses",
            "clusterserversconfig.nodeaddress", "redis.endpoints", "redis.addresses",
        )):
            rows.append(entry)
    return rows


def _detect_redis(entries: Sequence[ConfigEntry], property_map: Mapping[str, Any], raw_urls: Sequence[Dict[str, Any]]) -> Tuple[Dict[str, Any], Dict[str, Any], List[Dict[str, Any]]]:
    nodes: List[str] = []
    evidence: List[Dict[str, Any]] = []
    for entry in _redis_node_entries(entries):
        resolved, _ = _resolve_placeholder(entry.value, property_map)
        for value in _split_csv(resolved):
            node = _normalise_host_port(value)
            if node:
                nodes.append(node)
        evidence.append({"key": entry.key, "source_path": entry.source_path, "line": entry.line})

    url_entry = _first(entries, [("redis", "url"), ("redis", "uri"), ("redisson", "address")])
    url = ""
    raw_url = ""
    if url_entry:
        resolved, _ = _resolve_placeholder(url_entry.value, property_map)
        if str(resolved).lower().startswith(("redis://", "rediss://")):
            raw_url = str(resolved)
            url = _clean_url(resolved)
            evidence.append({"key": url_entry.key, "source_path": url_entry.source_path, "line": url_entry.line})
    if not url:
        row = next((x for x in raw_urls if str(x.get("value", "")).lower().startswith(("redis://", "rediss://"))), None)
        if row:
            raw_url = str(row["value"])
            url = _clean_url(raw_url)
            evidence.append({**row, "value": url})

    host_entry = _first(entries, [("redis", "host")], exclude=("cluster", "sentinel"))
    port_entry = _first(entries, [("redis", "port")], exclude=("cluster", "sentinel"))
    host = str(host_entry.value).strip() if host_entry else ""
    try:
        port = int(str(port_entry.value)) if port_entry else 6379
    except Exception:
        port = 6379

    sentinel_nodes: List[str] = []
    for entry in entries:
        key = entry.key.lower()
        if "redis" in key and "sentinel" in key and "node" in key:
            resolved, _ = _resolve_placeholder(entry.value, property_map)
            sentinel_nodes.extend(_normalise_host_port(v, 26379) for v in _split_csv(resolved))
    sentinel_nodes = [x for x in sentinel_nodes if x]
    master_entry = _first(entries, [("redis", "sentinel", "master")])
    sentinel_master = str(master_entry.value).strip() if master_entry else ""

    mode = "cluster" if nodes else "sentinel" if sentinel_nodes else "standalone"
    if not nodes and mode == "standalone" and not url and host:
        nodes = [f"{host}:{port}"]
    ssl_entry = _first(entries, [("redis", "ssl"), ("redisson", "ssl")])
    ssl = bool(str(ssl_entry.value).lower() in {"true", "1", "yes", "on"}) if ssl_entry else url.lower().startswith("rediss://")

    username, unresolved_user = _credential_field(entries, property_map, [("redis", "username")], "redis", "username")
    password, unresolved_password = _credential_field(entries, property_map, [("redis", "password")], "redis", "password")
    embedded_user, embedded_password = _url_credentials(raw_url)
    username = username or embedded_user
    password = password or embedded_password
    service = {
        "detected": bool(url or nodes or sentinel_nodes), "mode": mode, "url": url, "nodes": list(dict.fromkeys(nodes)),
        "sentinel_nodes": list(dict.fromkeys(sentinel_nodes)), "sentinel_master": sentinel_master,
        "host": host, "port": port, "ssl": ssl, "evidence": evidence,
    }
    creds = {k: v for k, v in {"username": username, "password": password}.items() if v}
    return service, creds, unresolved_user + unresolved_password


def _detect_http_resource(name: str, entries: Sequence[ConfigEntry], property_map: Mapping[str, Any], raw_urls: Sequence[Dict[str, Any]], key_patterns: Sequence[Sequence[str]], url_tokens: Sequence[str], default_port: int) -> Tuple[Dict[str, Any], Dict[str, Any], List[Dict[str, Any]]]:
    entry = _first(entries, key_patterns)
    url = ""
    raw_url = ""
    evidence: List[Dict[str, Any]] = []
    if entry:
        resolved, _ = _resolve_placeholder(entry.value, property_map)
        values = _split_csv(resolved)
        candidate = values[0] if values else str(resolved)
        if candidate.startswith(("http://", "https://")):
            raw_url = candidate
            url = _clean_url(candidate)
            evidence.append({"key": entry.key, "source_path": entry.source_path, "line": entry.line})
    if not url:
        def matches(row: Dict[str, Any]) -> bool:
            value = str(row.get("value", "")).lower()
            parsed = urlparse(value) if value.startswith(("http://", "https://")) else None
            return any(token in value for token in url_tokens) or bool(parsed and parsed.port == default_port)
        row = next((x for x in raw_urls if matches(x)), None)
        if row:
            raw_url = str(row["value"])
            url = _clean_url(raw_url)
            evidence.append({**row, "value": url})
    username, unresolved_user = _credential_field(entries, property_map, [(name, "username"), (name, "user")], name, "username")
    password, unresolved_password = _credential_field(entries, property_map, [(name, "password")], name, "password")
    embedded_user, embedded_password = _url_credentials(raw_url)
    username = username or embedded_user
    password = password or embedded_password
    token, unresolved_token = _credential_field(entries, property_map, [(name, "token"), (name, "api-key"), (name, "apikey")], name, "token")
    service = {"detected": bool(url), "url": url, "evidence": evidence}
    creds = {k: v for k, v in {"username": username, "password": password, "token": token}.items() if v}
    return service, creds, unresolved_user + unresolved_password + unresolved_token


def _detect_kafka(entries: Sequence[ConfigEntry], property_map: Mapping[str, Any], all_text_urls: Sequence[Dict[str, Any]]) -> Tuple[Dict[str, Any], Dict[str, Any], List[Dict[str, Any]]]:
    matching: List[ConfigEntry] = []
    for pattern in (("kafka", "bootstrap-servers"), ("kafka", "bootstrap.servers"), ("bootstrap", "servers")):
        matching = _values(entries, pattern)
        if matching:
            break
    servers: List[str] = []
    evidence: List[Dict[str, Any]] = []
    for entry in matching:
        resolved, _ = _resolve_placeholder(entry.value, property_map)
        servers.extend(x for x in _split_csv(resolved) if HOST_PORT_RE.fullmatch(x))
        evidence.append({"key": entry.key, "source_path": entry.source_path, "line": entry.line})
    if not servers:
        for row in all_text_urls:
            value = str(row.get("value", ""))
            if ":9092" in value and not value.startswith(("http://", "https://", "redis://", "rediss://")):
                servers.extend(_split_csv(value))
                evidence.append(row)
                break
    protocol_entry = _first(entries, [("kafka", "security", "protocol"), ("security", "protocol")])
    mechanism_entry = _first(entries, [("kafka", "sasl", "mechanism"), ("sasl", "mechanism")])
    username, unresolved_user = _credential_field(entries, property_map, [("kafka", "sasl", "username"), ("kafka", "username")], "kafka", "username")
    password, unresolved_password = _credential_field(entries, property_map, [("kafka", "sasl", "password"), ("kafka", "password")], "kafka", "password")
    service = {
        "detected": bool(servers), "bootstrap_servers": list(dict.fromkeys(servers)),
        "security_protocol": str(protocol_entry.value) if protocol_entry else "",
        "sasl_mechanism": str(mechanism_entry.value) if mechanism_entry else "",
        "evidence": evidence,
    }
    creds = {k: v for k, v in {"username": username, "password": password}.items() if v}
    return service, creds, unresolved_user + unresolved_password


def _extract_k8s_secret_candidates(files: Sequence[Path], root: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for path in files:
        if path.suffix.lower() not in {".yml", ".yaml", ".json"}:
            continue
        try:
            text = read_text_safely(path, max_chars=3_000_000)
            docs = [json.loads(text)] if path.suffix.lower() == ".json" else list(yaml.safe_load_all(text))
        except Exception:
            continue
        for doc in docs:
            if not isinstance(doc, dict) or str(doc.get("kind", "")).lower() != "secret":
                continue
            metadata = doc.get("metadata") or {}
            for section, encoded in (("stringData", False), ("data", True)):
                values = doc.get(section) or {}
                if not isinstance(values, dict):
                    continue
                for key, value in values.items():
                    decoded = ""
                    if encoded:
                        try:
                            decoded = base64.b64decode(str(value)).decode("utf-8")
                        except Exception:
                            decoded = ""
                    else:
                        decoded = str(value)
                    rows.append({
                        "secret_name": metadata.get("name", ""), "namespace": metadata.get("namespace", ""),
                        "key": key, "value": decoded, "source_path": _rel(path, root), "encoded": encoded,
                    })
    return rows


def discover_workspace(root: Path, import_k8s_secret_values: bool = False, max_files: int = 200000) -> DiscoveryResult:
    root = root.expanduser().resolve()
    if not root.exists() or not root.is_dir():
        raise FileNotFoundError(f"workspace directory not found: {root}")

    files = list(_iter_files(root, max_files=max_files))
    system_name = _detect_system_name(root, files)
    modules = _detect_modules(root, files)
    entries: List[ConfigEntry] = []
    for path in files:
        if _candidate_config_file(path):
            try:
                entries.extend(parse_config_file(path, root))
            except Exception:
                continue

    property_map = _entry_map(entries)
    raw_urls = _find_all_urls(files, root, (ORACLE_URL_RE, REDIS_URL_RE, HTTP_URL_RE, HOST_PORT_RE), limit=2000)
    result = DiscoveryResult(root, system_name, entries=entries, modules=modules)
    result.services["react"] = _detect_react(root, files, entries)
    result.services["spring_boot"] = _detect_spring(entries, modules)
    result.services["vertx"] = _detect_vertx(root, files, entries, modules)

    oracle, oracle_creds, unresolved = _detect_oracle(entries, property_map, raw_urls)
    result.services["oracle"] = oracle
    result.credentials["oracle"] = oracle_creds
    result.unresolved_secrets.extend(unresolved)

    redis, redis_creds, unresolved = _detect_redis(entries, property_map, raw_urls)
    result.services["redis"] = redis
    result.credentials["redis"] = redis_creds
    result.unresolved_secrets.extend(unresolved)

    elasticsearch, es_creds, unresolved = _detect_http_resource(
        "elasticsearch", entries, property_map, raw_urls,
        [("spring", "elasticsearch", "uris"), ("spring", "data", "elasticsearch", "uris"), ("elasticsearch", "url"), ("elasticsearch", "uris")],
        ("elasticsearch", "elastic", ":9200"), 9200,
    )
    result.services["elasticsearch"] = elasticsearch
    result.credentials["elasticsearch"] = es_creds
    result.unresolved_secrets.extend(unresolved)

    kafka, kafka_creds, unresolved = _detect_kafka(entries, property_map, raw_urls)
    result.services["kafka"] = kafka
    result.credentials["kafka"] = kafka_creds
    result.unresolved_secrets.extend(unresolved)

    for name, patterns, tokens, port in (
        ("grafana", [("grafana", "url"), ("grafana", "endpoint")], ("grafana", ":3000"), 3000),
        ("prometheus", [("prometheus", "url"), ("prometheus", "endpoint")], ("prometheus", ":9090"), 9090),
        ("loki", [("loki", "url"), ("loki", "endpoint"), ("clients", "url")], ("loki", ":3100"), 3100),
    ):
        service, creds, unresolved = _detect_http_resource(name, entries, property_map, raw_urls, patterns, tokens, port)
        # Loki push path should be reduced to the base endpoint for readiness/API calls.
        if name == "loki" and service.get("url"):
            service["url"] = re.sub(r"/loki/api/v1/push/?$", "", str(service["url"]))
        result.services[name] = service
        result.credentials[name] = creds
        result.unresolved_secrets.extend(unresolved)

    # Local Kubernetes Secret manifests can optionally fill missing credential values.
    secret_candidates = _extract_k8s_secret_candidates(files, root)
    result.evidence.extend([{**row, "value": "***MASKED***"} for row in secret_candidates])
    if import_k8s_secret_values:
        for row in secret_candidates:
            key = str(row.get("key", "")).lower()
            value = str(row.get("value", ""))
            if not value:
                continue
            resource = next((name for name in ("oracle", "redis", "elasticsearch", "kafka", "grafana", "prometheus", "loki") if name in key or name in str(row.get("secret_name", "")).lower()), "")
            if not resource:
                continue
            target = result.credentials.setdefault(resource, {})
            if "password" in key or key in {"pass", "pwd"}:
                target.setdefault("password", value)
            elif "username" in key or key == "user":
                target.setdefault("username", value)
            elif "token" in key or "api_key" in key or "apikey" in key:
                target.setdefault("token", value)

    result.evidence.extend([
        {"key": entry.key, "value": "***MASKED***" if is_sensitive_key(entry.key) else mask_text(entry.text()), "source_path": entry.source_path, "line": entry.line, "profile": entry.profile}
        for entry in entries[:20000]
    ])
    if len(files) >= max_files:
        result.warnings.append(f"file scan reached max_files={max_files}; discovery may be partial")
    return result


def build_generated_config(base_config: Mapping[str, Any], discovery: DiscoveryResult, choices: Mapping[str, Any], package_root: Path) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    services = discovery.services
    output_dir = str((discovery.workspace_root / "workspace-doc-output").resolve())
    credentials_path = str((package_root / "credentials.local.yaml").resolve())

    generated: Dict[str, Any] = deep_merge(base_config, {
        "version": "4.0.0",
        "credentials_file": credentials_path,
        "workspace": {"root": str(discovery.workspace_root), "name": discovery.system_name},
        "output": {"dir": output_dir, "overwrite": True},
        "screenshots": {
            "enabled": bool(choices.get("screenshots", False) and services.get("react", {}).get("detected")),
            "base_url": services.get("react", {}).get("base_url") or "http://localhost:3000",
            "manual_pages_file": "",
            "output_dir": str(Path(output_dir) / "screenshots"),
        },
        "resource_screenshots": {
            "enabled": bool(choices.get("resource_screenshots", False)),
            "allow_discovered_endpoints": True,
            "output_dir": str(Path(output_dir) / "resource-screenshots"),
            "grafana_url": services.get("grafana", {}).get("url", ""),
            "prometheus_url": services.get("prometheus", {}).get("url", ""),
            "loki_url": services.get("loki", {}).get("url", ""),
        },
        "runtime_probe": {
            "enabled": bool(choices.get("runtime_probe", False)),
            "allow_discovered_endpoints": True,
            "oracle": {"enabled": "auto", "dsn": services.get("oracle", {}).get("dsn", ""), "include_schema_metadata": True},
            "redis": {
                "enabled": "auto", "mode": services.get("redis", {}).get("mode", "auto"),
                "url": services.get("redis", {}).get("url", ""), "nodes": services.get("redis", {}).get("nodes", []),
                "host": services.get("redis", {}).get("host", ""), "port": services.get("redis", {}).get("port", 6379),
                "sentinel_nodes": services.get("redis", {}).get("sentinel_nodes", []),
                "sentinel_master": services.get("redis", {}).get("sentinel_master", ""),
                "ssl": bool(services.get("redis", {}).get("ssl", False)), "scan_keys": False,
                "collect_cluster_nodes": True, "collect_cluster_slots": True,
            },
            "elasticsearch": {"enabled": "auto", "url": services.get("elasticsearch", {}).get("url", "")},
            "kafka": {
                "enabled": "auto", "bootstrap_servers": services.get("kafka", {}).get("bootstrap_servers", []),
                "security_protocol": services.get("kafka", {}).get("security_protocol", ""),
                "sasl_mechanism": services.get("kafka", {}).get("sasl_mechanism", ""),
            },
            "grafana": {"enabled": "auto", "url": services.get("grafana", {}).get("url", "")},
            "prometheus": {"enabled": "auto", "url": services.get("prometheus", {}).get("url", "")},
            "loki": {"enabled": "auto", "url": services.get("loki", {}).get("url", "")},
        },
        "excel": {"output_dir": str(Path(output_dir) / "excel")},
        "ppt": {"output_dir": str(Path(output_dir) / "ppt"), "title_prefix": discovery.system_name},
        "detected_services": services,
        "auto_config": {
            "generated": True, "generated_at_source": "workspace static discovery",
            "discovery_report": str((package_root / "generated" / "discovery-report.json").resolve()),
            "user_choices": dict(choices),
        },
    })

    credentials_overlay: Dict[str, Any] = {"runtime_probe": {}, "screenshots": {"login": {}}, "resource_screenshots": {"auth_profiles": {}}}
    for resource in ("oracle", "redis", "elasticsearch", "kafka", "grafana", "prometheus", "loki"):
        values = discovery.credentials.get(resource) or {}
        if values:
            credentials_overlay["runtime_probe"][resource] = dict(values)
            if resource in {"grafana", "prometheus", "loki"}:
                credentials_overlay["resource_screenshots"]["auth_profiles"][resource] = {
                    k: v for k, v in values.items() if k in {"username", "password", "token"}
                }
    return generated, credentials_overlay
