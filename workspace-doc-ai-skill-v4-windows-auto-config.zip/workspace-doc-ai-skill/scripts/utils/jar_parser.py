from __future__ import annotations

import configparser
import io
import re
import zipfile
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence
from urllib.parse import urljoin

from .config_loader import mask_text


def _rel(path: Path, root: Path) -> str:
    try:
        return str(path.relative_to(root)).replace("\\", "/")
    except Exception:
        return str(path)


def _parse_properties(text: str) -> Dict[str, str]:
    result: Dict[str, str] = {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith(("#", "!")) or "=" not in line:
            continue
        key, value = line.split("=", 1)
        result[key.strip()] = value.strip()
    return result


def _parse_manifest(text: str) -> Dict[str, str]:
    unfolded: List[str] = []
    for raw in text.splitlines():
        if raw.startswith(" ") and unfolded:
            unfolded[-1] += raw[1:]
        else:
            unfolded.append(raw)
    result: Dict[str, str] = {}
    for line in unfolded:
        if ":" in line:
            key, value = line.split(":", 1)
            result[key.strip()] = mask_text(value.strip())
    return result


def inspect_jar(path: Path, root: Path, max_entries: int = 200_000, package_limit: int = 300) -> Dict[str, Any]:
    result: Dict[str, Any] = {
        "source_path": _rel(path, root),
        "file_name": path.name,
        "manifest": {},
        "maven_coordinates": [],
        "class_count": 0,
        "packages": [],
        "service_providers": [],
        "spring_auto_configurations": [],
        "errors": [],
    }
    try:
        with zipfile.ZipFile(path) as zf:
            names = zf.namelist()[:max_entries]
            packages = set()
            auto_configs = set()
            for name in names:
                if name.endswith(".class") and not name.startswith("META-INF/versions/"):
                    result["class_count"] += 1
                    if "/" in name:
                        packages.add(name.rsplit("/", 1)[0].replace("/", "."))
                if name.upper() == "META-INF/MANIFEST.MF":
                    try:
                        result["manifest"] = _parse_manifest(zf.read(name).decode("utf-8", errors="replace"))
                    except Exception as exc:
                        result["errors"].append(f"manifest: {exc}")
                if re.match(r"META-INF/maven/[^/]+/[^/]+/pom\.properties$", name):
                    try:
                        props = _parse_properties(zf.read(name).decode("utf-8", errors="replace"))
                        result["maven_coordinates"].append({
                            "group": props.get("groupId", ""),
                            "artifact": props.get("artifactId", ""),
                            "version": props.get("version", ""),
                            "entry": name,
                        })
                    except Exception as exc:
                        result["errors"].append(f"pom.properties {name}: {exc}")
                if name.startswith("META-INF/services/") and not name.endswith("/"):
                    try:
                        providers = [x.strip() for x in zf.read(name).decode("utf-8", errors="replace").splitlines() if x.strip() and not x.strip().startswith("#")]
                        result["service_providers"].append({
                            "service_interface": name.split("META-INF/services/", 1)[1],
                            "providers": providers,
                            "entry": name,
                        })
                    except Exception as exc:
                        result["errors"].append(f"service {name}: {exc}")
                if name in {
                    "META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports",
                    "META-INF/spring.factories",
                }:
                    try:
                        content = zf.read(name).decode("utf-8", errors="replace")
                        for line in content.replace("\\\n", "").splitlines():
                            line = line.strip()
                            if not line or line.startswith("#"):
                                continue
                            if "=" in line:
                                _, line = line.split("=", 1)
                            for item in line.split(","):
                                item = item.strip()
                                if item and "." in item:
                                    auto_configs.add(item)
                    except Exception as exc:
                        result["errors"].append(f"spring metadata {name}: {exc}")
            result["packages"] = sorted(packages)[:package_limit]
            result["spring_auto_configurations"] = sorted(auto_configs)
    except Exception as exc:
        result["errors"].append(str(exc))
    return result


def repository_download_candidates(dependency: Dict[str, Any], repositories: Sequence[Dict[str, Any]]) -> List[str]:
    group = str(dependency.get("group", ""))
    artifact = str(dependency.get("artifact", ""))
    version = str(dependency.get("version", ""))
    if not group or not artifact or not version or any(x in version for x in ("${", "$", "확인필요", "+")):
        return []
    rel = f"{group.replace('.', '/')}/{artifact}/{version}/{artifact}-{version}.jar"
    urls: List[str] = []
    for repo in repositories:
        base = str(repo.get("url", ""))
        if not base or "확인필요" in base:
            continue
        urls.append(mask_text(urljoin(base.rstrip("/") + "/", rel)))
    return sorted(set(urls))


def find_cached_artifact(dependency: Dict[str, Any], roots: Iterable[Path], max_matches: int = 10) -> List[str]:
    group = str(dependency.get("group", ""))
    artifact = str(dependency.get("artifact", ""))
    version = str(dependency.get("version", ""))
    if not artifact or not version or "확인필요" in version:
        return []
    matches: List[str] = []
    for root in roots:
        root = root.expanduser()
        if not root.exists():
            continue
        # Maven repository layout.
        if group:
            maven_dir = root / group.replace(".", "/") / artifact / version
            if maven_dir.exists():
                for jar in maven_dir.glob(f"{artifact}-{version}*.jar"):
                    matches.append(str(jar))
                    if len(matches) >= max_matches:
                        return matches
        # Gradle modules-2 layout or user-provided broad cache root.
        gradle_dir = root / group / artifact / version if group else root / artifact / version
        if gradle_dir.exists():
            for jar in gradle_dir.rglob(f"{artifact}-{version}*.jar"):
                matches.append(str(jar))
                if len(matches) >= max_matches:
                    return matches
    return matches


def enrich_dependency_acquisition(
    dependencies: Sequence[Dict[str, Any]], repositories: Sequence[Dict[str, Any]],
    cache_roots: Optional[Sequence[Path]] = None,
) -> List[Dict[str, Any]]:
    result: List[Dict[str, Any]] = []
    for dependency in dependencies:
        row = dict(dependency)
        row["download_candidates"] = repository_download_candidates(row, repositories)
        row["cached_files"] = find_cached_artifact(row, cache_roots or []) if cache_roots else []
        if row.get("source_type") == "local-jar":
            row["acquisition_method"] = "WORKSPACE_LOCAL_JAR"
        elif row.get("cached_files"):
            row["acquisition_method"] = "LOCAL_DEPENDENCY_CACHE"
        elif row.get("download_candidates"):
            row["acquisition_method"] = "MAVEN_REPOSITORY"
        else:
            row["acquisition_method"] = "BUILD_TOOL_RESOLUTION_REVIEW"
        result.append(row)
    return result
