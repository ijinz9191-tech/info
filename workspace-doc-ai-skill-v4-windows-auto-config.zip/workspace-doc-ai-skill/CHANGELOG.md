# CHANGELOG

## 4.0.0

### Windows 원클릭 실행

- Python 3.11 확인, `.venv` 생성, dependency 설치를 수행하는 `RUN.bat`
- Config만 생성하는 `CONFIGURE_ONLY.bat`
- 외부 접속 없는 `RUN_STATIC_ONLY.bat`
- 로컬 설정 초기화용 `RESET_LOCAL_CONFIG.bat`
- 사내망 `wheelhouse` 오프라인 설치 지원

### 자동 Config 생성

- Workspace 폴더 선택 UI와 이전 Workspace 재사용
- React `package.json/.env`, Spring `application*.yml/properties`, Vert.x config/code 자동 탐지
- Helm/Kubernetes/Docker Compose/Grafana/Prometheus/Loki 설정 근거 병합
- Oracle DSN, Redis mode/nodes, Elasticsearch URL, Kafka brokers, 운영 URL 자동 입력
- `generated/config.auto.yaml`, discovery report, summary, user choices 자동 생성
- WorkBook·아키텍쳐정의서 `자동설정` 시트와 운영자 매뉴얼 자동 설정 슬라이드 생성
- URL 내 embedded credential을 주소와 `credentials.local.yaml`로 자동 분리
- 미확인 값만 질문하는 interactive/non-interactive 모드

### 인증정보 분리

- 환경변수 직접 설정 없이 `credentials.local.yaml` overlay 사용
- Git 제외 및 Windows ACL 제한 시도
- 생성 JSON/Excel/PPT의 민감정보 마스킹 유지
- Kubernetes Secret 값 가져오기 explicit opt-in

### Redis Cluster

- Standalone/Sentinel/Cluster 자동 판별
- Spring cluster nodes, Redisson clusterServersConfig, Vert.x Redis endpoint 탐지
- RedisCluster startup nodes 연결
- master/replica topology, CLUSTER INFO/NODES/SLOTS 수집
- key value 미조회, SCAN 기본 비활성

### 검증

- 자동 Config에서 Redis Cluster 3개 node와 Kafka 2개 broker 탐지 검증
- Windows launcher와 동일한 자동 설정→PPT/Excel 생성 경로 검증
- 5개 Excel, 2개 PPT, JSON Schema 및 validation report PASS

## 3.0.0

### React 분석 확장

- `package.json`, NPM dependency/script/workspace 분석
- React/Vite/CRA/Next React 기술 스택 탐지
- React Router JSX/객체형 Route, menu/link, component, hook, state library 분석
- Axios/fetch/WebSocket/SSE 호출과 환경변수 분석
- Route → Component → API 호출 연결
- React API → Spring Boot/Vert.x endpoint 자동 매핑
- SPA direct/hash/history 이동과 Route 자동 화면 목록 지원
- 화면 캡처 중 DOM, XHR/fetch, WebSocket/EventSource, console/page error 수집
- 화면별 click/fill/select/press/wait/sleep 자동 동작 지원

### Spring Boot 분석 확장

- annotation API 및 WebFlux functional route
- application/component/security/configuration property
- scheduled job, event/Kafka listener
- RestTemplate/WebClient/RestClient 외부·내부 호출
- profile, transaction, Actuator 후보
- Spring Boot ↔ Vert.x 내부 HTTP 매핑

### Vert.x 분석 추가

- Verticle/AbstractVerticle, deployment, HTTP server
- Router/Route/Handler/subRouter
- EventBus send/publish/request/consumer 및 producer-consumer topology
- codec/service proxy, WebClient/HttpClient
- Config/SharedData/timer
- Vert.x Oracle/Redis/Kafka/Micrometer client

### 문서 확장

- 인터페이스명세서에 React API, 화면-API-backend, Spring, Vert.x, EventBus 시트 추가
- 프로그램목록에 React package/component/hook 및 Spring/Vert.x 프로그램 시트 추가
- WorkBook에 기술 스택, 프레임워크 모듈, API 매핑, EventBus topology 추가
- 테이블정의서에 Spring/Vert.x DB 접근 컴포넌트 추가
- 아키텍쳐정의서에 Frontend/Spring Boot/Vert.x, 공존 구조, Mermaid 추가
- 사용자/운영자 PPT에 화면 API 연결, 기술 스택, Spring Boot, Vert.x, EventBus 설명 추가
- v3 필수 시트와 PPT 최소 슬라이드 검증 강화

## 2.0.0

- Oracle, Redis, Elasticsearch, Kafka, Grafana, Prometheus, Loki 탐지
- 선택적 읽기 전용 Runtime probe
- JAR 내부 구조 및 source import 연결
- 운영 화면 캡처와 5개 Excel/2개 PPT 자동 검증

## 1.0.0

- Workspace 기본 정적 분석
- PowerPoint 사용자/운영자 매뉴얼
- Excel 인터페이스/프로그램/Work Book/테이블/아키텍처 문서 생성
