package com.acme.api;
import org.springframework.context.annotation.*;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
@Configuration
public class SecurityConfig {
 @Bean SecurityFilterChain security(HttpSecurity http) throws Exception { http.authorizeHttpRequests(a->a.requestMatchers("/api/users").hasAnyRole("USER","ADMIN").requestMatchers("/actuator/**").permitAll().anyRequest().authenticated()); return http.build(); }
}
