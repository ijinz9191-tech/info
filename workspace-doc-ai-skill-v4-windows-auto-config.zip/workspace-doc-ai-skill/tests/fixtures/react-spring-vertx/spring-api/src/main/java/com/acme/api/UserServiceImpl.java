package com.acme.api;
import org.springframework.stereotype.Service;
@Service
public class UserServiceImpl implements UserService { public String list(){return "[]";} }
