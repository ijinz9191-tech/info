package com.acme.api;
import jakarta.persistence.*;
@Entity @Table(name="TB_USER", schema="APP")
public class UserEntity { @Id @Column(name="USER_ID") Long id; @Column(name="USER_NAME") String name; }
