package com.acme.api;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
@RestController
@RequestMapping("/api")
public class UserController {
 private final UserService userService;
 public UserController(UserService userService){this.userService=userService;}
 @GetMapping("/users") public String users(){return userService.list();}
 @GetMapping("/bridge-events") public String bridge(){return new RestTemplate().getForObject("http://vertx-service:8090/api/events",String.class);}
}
