package com.acme.api;
public interface UserService { String list(); }
