package com.acme.api;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
@Component class Jobs { @Scheduled(cron="0 */5 * * * *") void sync(){} @KafkaListener(topics="user-events",groupId="sample") void consume(String msg){} }
