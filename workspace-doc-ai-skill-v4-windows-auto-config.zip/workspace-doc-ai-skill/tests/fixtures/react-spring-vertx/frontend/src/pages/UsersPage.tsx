import axios from 'axios';
import {useEffect,useState} from 'react';
export function UsersPage(){
 const [users,setUsers]=useState([]);
 useEffect(()=>{axios.get('/api/users').then(r=>setUsers(r.data));},[]);
 return <main><h1>사용자 목록</h1><button>새로고침</button><table><thead><tr><th>ID</th><th>이름</th></tr></thead></table></main>;
}
