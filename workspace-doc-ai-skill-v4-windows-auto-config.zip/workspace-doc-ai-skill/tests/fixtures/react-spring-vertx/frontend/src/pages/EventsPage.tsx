export function EventsPage(){
 async function load(){const r=await fetch('/api/events',{method:'GET'});return r.json();}
 return <main><h1>이벤트 현황</h1><button onClick={load}>조회</button></main>;
}
