import {Routes, Route, Link} from 'react-router-dom';
import {UsersPage} from './pages/UsersPage';
import {EventsPage} from './pages/EventsPage';
export function AppRoutes(){return <><nav><Link to="/users">사용자</Link><Link to="/events">이벤트</Link></nav><Routes>
<Route path="/users" element={<UsersPage/>} roles={['USER','ADMIN']} />
<Route path="/events" element={<EventsPage/>} roles={['OPS']} />
</Routes></>}
