package com.acme.common; public final class TraceUtil { public static String id(){return "x";} }
