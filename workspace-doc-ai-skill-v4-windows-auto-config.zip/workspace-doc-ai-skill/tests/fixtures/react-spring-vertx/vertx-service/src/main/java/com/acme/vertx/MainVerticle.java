package com.acme.vertx;
import io.vertx.core.*;
import io.vertx.ext.web.*;
import io.vertx.ext.web.client.WebClient;
public class MainVerticle extends AbstractVerticle {
 public void start(){
   Router router=Router.router(vertx);
   router.get("/api/events").produces("application/json").handler(this::events);
   router.post("/api/events").handler(this::createEvent);
   vertx.createHttpServer().requestHandler(router).listen(8090);
   vertx.eventBus().consumer("events.process", msg -> System.out.println(msg.body()));
   vertx.eventBus().send("audit.write", "started");
   WebClient client=WebClient.create(vertx);
   client.getAbs("http://spring-api:8080/api/users").send();
 }
 private void events(RoutingContext ctx){ vertx.eventBus().request("events.process","list"); ctx.response().end("[]"); }
 private void createEvent(RoutingContext ctx){ vertx.eventBus().publish("events.created",ctx.body().asString()); ctx.response().setStatusCode(201).end(); }
}
