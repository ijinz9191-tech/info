package com.acme.vertx;
import io.vertx.core.Vertx;
import io.vertx.oracleclient.OracleBuilder;
import io.vertx.redis.client.Redis;
import io.vertx.kafka.client.producer.KafkaProducer;
class ResourceClients { void init(Vertx vertx){ OracleBuilder.pool(); Redis.createClient(vertx,"redis://redis.example:6379"); KafkaProducer.create(vertx,new java.util.HashMap<>()); } }
