package com.acme.vertx;
import io.vertx.core.AbstractVerticle;
public class AuditVerticle extends AbstractVerticle { public void start(){ vertx.eventBus().consumer("audit.write", msg -> System.out.println(msg.body())); } }
