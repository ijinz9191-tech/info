# Workspace Documentation Generator AI Skill v4

Windows에서 **React 화면 + Spring Boot + Vert.x 백엔드 + Oracle + Redis Cluster + Elasticsearch + Kafka + Grafana + Prometheus + Loki**가 포함된 Workspace를 자동 분석하고 다음 문서를 만든다.

```text
PowerPoint
  사용자메뉴얼.pptx
  운영자메뉴얼.pptx

Excel
  인터페이스명세서.xlsx
  프로그램목록.xlsx
  WorkBook.xlsx
  테이블정의서.xlsx
  아키텍쳐정의서.xlsx
```

v4에서는 사용자가 `config.yaml`이나 Windows 환경변수를 직접 작성할 필요가 없다. **Python 3.11 설치 후 `RUN.bat`를 실행하고 Workspace 폴더만 선택**하면 소스와 배포 설정에서 필요한 값을 찾아 `generated/config.auto.yaml`을 자동 생성한다.

---

## 1. 사용자가 해줄 것

### 필수

1. Windows에 **Python 3.11 이상 64-bit**를 설치한다.
2. 압축을 해제한다.
3. `RUN.bat`를 더블클릭한다.
4. 분석할 Workspace 폴더를 선택한다.

### 선택

실제 화면과 운영 리소스까지 확인하려는 경우 다음 시스템을 실행하거나 접근 가능한 상태로 둔다.

- React 개발/운영 화면
- Spring Boot 및 Vert.x 서비스
- Oracle
- Redis Cluster
- Elasticsearch
- Kafka
- Grafana
- Prometheus
- Loki

실제 접속은 `RUN.bat`가 물어볼 때 사용자가 동의한 경우에만 시도한다. 외부 시스템 접속 없이 소스만 분석하려면 `RUN_STATIC_ONLY.bat`를 실행한다.

---

## 2. 가장 쉬운 실행 방법

```bat
RUN.bat
```

첫 실행 때 자동으로 다음을 수행한다.

```text
Python 3.11 확인
→ .venv 생성
→ 필수 패키지 설치
→ Workspace 폴더 선택
→ 소스/설정/배포 파일 자동 탐지
→ generated/config.auto.yaml 생성
→ credentials.local.yaml 분리 생성
→ Workspace 전체 분석
→ 선택적 Runtime 읽기 전용 점검
→ 선택적 React/Grafana/Prometheus 화면 캡처
→ Excel 5개 생성
→ PowerPoint 2개 생성
→ 산출물 재열기 및 구조 검증
→ 출력 폴더 열기
```

### 자동 설정만 다시 만들기

```bat
CONFIGURE_ONLY.bat
```

### 외부 접속과 화면 캡처 없이 실행

```bat
RUN_STATIC_ONLY.bat
```

### 이전 자동 설정 초기화

```bat
RESET_LOCAL_CONFIG.bat
```

---

## 3. Python 버전

권장 버전:

```text
Python 3.11.x 64-bit
```

확인:

```bat
python --version
```

또는:

```bat
py -3.11 --version
```

`RUN.bat`는 먼저 `py -3.11`을 찾고, 없으면 PATH의 `python`이 3.11 이상인지 확인한다.

---

## 4. 자동 Config 탐지 범위

자동 설정기는 Workspace 전체에서 다음 파일을 찾아 서로 합친다.

### React

- `package.json`
- `.env`, `.env.local`, `.env.development`, `.env.production`
- Vite/CRA/React script
- React Router
- proxy
- 개발 서버 port
- API base URL

### Spring Boot

- `application.yml`, `application.yaml`, `application.properties`
- profile별 `application-*.yml/properties`
- `bootstrap.yml/properties`
- `server.port`, context path, management port
- datasource, Redis, Elasticsearch, Kafka 설정
- `@Value`, `@ConfigurationProperties`

### Vert.x

- Vert.x JSON/YAML/HOCON 형태 설정
- `createHttpServer`, `.listen(port)`
- Router와 Route
- EventBus address
- Vert.x Redis endpoint
- Vert.x Oracle/Kafka/HTTP client

### 배포 및 운영

- Helm values/templates
- Kubernetes Deployment, Service, ConfigMap, Secret 참조
- Docker Compose
- Prometheus 설정
- Grafana dashboard/provisioning
- Loki/Promtail 설정
- CI/CD와 실행 script

자동 탐지 결과는 다음에 기록된다.

```text
generated/config.auto.yaml
generated/discovery-report.json
generated/config-summary.txt
generated/user-choices.yaml
```

`discovery-report.json`에는 어떤 파일과 줄에서 설정을 찾았는지 근거가 남는다. 비밀번호·토큰은 마스킹된다. 같은 내용은 `WorkBook.xlsx`와 `아키텍쳐정의서.xlsx`의 **자동설정** 시트, `운영자메뉴얼.pptx`의 **Windows 자동 설정 결과** 슬라이드에도 반영된다.

---

## 5. 인증정보와 환경변수

Windows 환경변수를 직접 설정하지 않아도 된다.

자동 설정기는 다음 원칙으로 인증정보를 처리한다.

1. 소스에 `${ORACLE_PASSWORD}`처럼 참조만 있으면 Runtime 점검을 선택했을 때만 값을 묻는다.
2. 입력한 값은 `credentials.local.yaml`에만 저장한다.
3. `generated/config.auto.yaml`, 분석 JSON, PPT, Excel에는 비밀번호와 토큰을 넣지 않는다.
4. `credentials.local.yaml`은 `.gitignore` 대상이다.
5. Windows에서는 가능한 범위에서 현재 사용자만 읽고 쓸 수 있도록 ACL을 제한한다.
6. Kubernetes Secret 파일의 값을 가져오는 기능은 사용자가 명시적으로 허용할 때만 동작한다.

자동 생성되는 구조:

```text
workspace-doc-ai-skill/
  generated/
    config.auto.yaml
    discovery-report.json
    config-summary.txt
    user-choices.yaml
  credentials.local.yaml        Git 제외, 인증정보 전용
```

기존 환경변수 방식도 호환되지만 필수는 아니다.

---

## 6. Redis Cluster 지원

v4는 다음 Redis 연결 방식을 자동 구분한다.

```text
standalone
sentinel
cluster
```

Cluster 판단 근거 예시:

```yaml
spring:
  data:
    redis:
      cluster:
        nodes:
          - redis-1.example:6379
          - redis-2.example:6379
          - redis-3.example:6379
```

Redisson:

```yaml
clusterServersConfig:
  nodeAddresses:
    - redis://redis-1.example:6379
    - redis://redis-2.example:6379
```

Vert.x:

```json
{
  "vertx": {
    "redis": {
      "endpoints": [
        "redis://redis-1.example:6379",
        "redis://redis-2.example:6379"
      ]
    }
  }
}
```

자동 생성 Config 예시:

```yaml
runtime_probe:
  redis:
    enabled: auto
    mode: cluster
    nodes:
      - redis-1.example:6379
      - redis-2.example:6379
      - redis-3.example:6379
    username: ""
    password: ""
    ssl: false
    collect_cluster_nodes: true
    collect_cluster_slots: true
    scan_keys: false
```

Runtime 점검에서 읽는 내용:

- PING
- startup node
- master/replica topology
- `CLUSTER INFO`
- `CLUSTER NODES`
- slot 분배
- cluster state
- 제한된 server 정보

기본적으로 하지 않는 내용:

- Redis value 조회
- 임의 key 조회
- key 삭제/수정
- failover나 cluster 변경
- `SCAN`은 기본 비활성

---

## 7. React 화면 자동 캡처

자동 설정기는 React 패키지와 port를 찾아 base URL 후보를 만든다.

예:

```text
Vite       → http://localhost:5173
CRA        → http://localhost:3000
PORT=4000  → http://localhost:4000
```

실제 화면을 매뉴얼에 넣으려면 React 앱이 실행 중이어야 한다. `RUN.bat`에서 화면 캡처를 선택하면 Playwright Chromium을 자동 설치하고 다음을 수행한다.

- React Router 화면 목록 자동 구성
- direct/hash/SPA navigation 자동 시도
- 화면 PNG 캡처
- 제목, heading, button, input, link, table, dialog 수집
- XHR, fetch, WebSocket, EventSource 수집
- 실패한 네트워크 요청과 console/page error 수집
- 화면의 API를 Spring Boot 또는 Vert.x endpoint와 연결

로그인이 필요하면 최초 설정 때 다음 값만 묻는다.

- 로그인 경로
- 아이디/비밀번호 selector
- 로그인 버튼 selector
- 로컬 로그인 계정

계정은 `credentials.local.yaml`에만 저장된다.

---

## 8. 분석 범위

### React

- React/Vite/CRA/Next React 탐지
- JSX Route와 객체형 Route
- Component, custom Hook
- Redux, Zustand, Context, React Query
- Axios, fetch, WebSocket, SSE
- Route → Component → API 호출
- 화면 권한/보호 Route 후보

### Spring Boot

- Controller, Service, Repository, Mapper
- Annotation API, WebFlux functional route
- Interface와 구현체
- 생성자/필드 주입
- `@Bean`, `@Configuration`
- Security matcher와 method security
- Scheduler, event listener, Kafka listener
- RestTemplate, WebClient, RestClient, Feign
- JPA, JDBC, MyBatis
- Redis, Elasticsearch, Kafka, Micrometer

### Vert.x

- Verticle, AbstractVerticle, worker 후보
- deployVerticle
- HTTP server와 port
- Router, Route, Handler
- subRouter
- EventBus send/publish/request/consumer
- producer-consumer topology
- WebClient/HttpClient
- Oracle SQL client
- Redis client
- Kafka producer/consumer
- Micrometer

### 공통 모듈과 JAR

- Maven/Gradle 멀티모듈
- NPM workspace/dependency
- common/core/shared 모듈
- repository/GAV/configuration
- local JAR
- 선택적 `.m2`/Gradle cache 경로
- manifest, package, SPI, Spring AutoConfiguration
- source import와 JAR package 연결

### 데이터·메시징·관측

- Oracle Table/Column/PK/FK/Index/Sequence/View/Synonym/PLSQL
- SQL CRUD 사용처
- Redis key/TTL/cache/lock/pub-sub
- Elasticsearch index/alias/search/bulk/delete
- Kafka topic/group/producer/consumer/stream
- Grafana dashboard/panel/datasource/query/alert
- Prometheus scrape/target/rule/metric
- Loki/Promtail job/pipeline/LogQL/appender

---

## 9. 프레임워크 간 연결

다음 연결을 자동 추적한다.

```text
React Route
  → React Component
  → Axios/fetch/WebSocket
  → Spring Boot API 또는 Vert.x Route
  → Service/Handler/EventBus
  → Oracle/Redis Cluster/Elasticsearch/Kafka
  → Prometheus/Grafana/Loki
```

Vert.x EventBus 예:

```text
MainVerticle --send audit.write--> AuditVerticle
MainVerticle --request user.lookup--> UserQueryVerticle
Publisher --publish cache.changed--> 복수 Consumer
```

정확히 연결되지 않는 경우 임의로 선택하지 않고 다음 상태를 남긴다.

```text
MATCHED
AMBIGUOUS
UNMATCHED_PRODUCER
UNMATCHED_CONSUMER
DYNAMIC
확인필요
```

---

## 10. 생성 산출물

기본 출력 폴더:

```text
<Workspace>/workspace-doc-output/
```

구조:

```text
workspace-doc-output/
  analysis/
    workspace_analysis.json
    workspace_summary.md
    runtime_probe.json
    validation_report.json
  screenshots/
    manual_pages.generated.json
    *.png
  resource-screenshots/
    resource_pages.generated.json
    *.png
  excel/
    인터페이스명세서.xlsx
    프로그램목록.xlsx
    WorkBook.xlsx
    테이블정의서.xlsx
    아키텍쳐정의서.xlsx
  ppt/
    사용자메뉴얼.pptx
    운영자메뉴얼.pptx
```

### 사용자메뉴얼.pptx

- React 화면 이미지
- Route와 Component
- 화면 태그
- 대상 역할
- 화면 설명과 조작 순서
- 주요 DOM 요소
- 정적/실제 API 호출
- Spring Boot/Vert.x 연결
- 캡처 실패 사유

### 운영자메뉴얼.pptx

- React·Spring Boot·Vert.x 구조
- API와 Security
- Verticle/Route/EventBus
- Oracle/Redis Cluster/Elasticsearch/Kafka
- Grafana/Prometheus/Loki
- Kubernetes/배포 구조
- Runtime 점검
- 운영 검토 항목

### Excel 5종

`인터페이스명세서.xlsx`:

- React API 호출
- React-Backend 매핑
- Spring API/Security/외부호출
- Vert.x HTTP/EventBus/외부호출
- Oracle/Redis/Elasticsearch/Kafka/관측 연계
- Interface-Impl/Injection/Bean/JAR/NPM

`프로그램목록.xlsx`:

- 모듈, 파일, 클래스, 메서드
- React Component/Hook/Route
- Spring Component
- Verticle/Handler
- 공통소스와 배포 workload

`WorkBook.xlsx`:

- 분석 요약
- 구현 흐름
- 프레임워크 연결
- JAR 가져오기
- 변경 영향도
- 검토 항목

`테이블정의서.xlsx`:

- Oracle 정의
- Entity/MyBatis/SQL 사용처
- Spring/Vert.x DB 접근 Component

`아키텍쳐정의서.xlsx`:

- 시스템/모듈/프레임워크 구조
- Frontend-Backend 연결
- EventBus topology
- 리소스/배포/관측 구조
- Mermaid 아키텍처
- 리스크와 확인필요

---

## 11. CLI와 무인 실행

질문 없이 정적 분석:

```bat
RUN.bat --workspace "D:\workspace\my-system" --non-interactive --static-only
```

질문 없이 Runtime과 화면을 모두 끈 Config 생성:

```bat
.venv\Scripts\python.exe scripts\auto_configure.py ^
  --workspace "D:\workspace\my-system" ^
  --non-interactive ^
  --static-only
```

기존 자동 Config로 문서 재생성:

```bat
.venv\Scripts\python.exe scripts\generate_all.py
```

자동 Config 다시 탐지:

```bat
.venv\Scripts\python.exe scripts\generate_all.py ^
  --workspace "D:\workspace\my-system" ^
  --reconfigure
```

분석만:

```bat
.venv\Scripts\python.exe scripts\generate_all.py --analysis-only
```

---

## 12. 사내망·인터넷 차단 환경

첫 설치에는 Python 패키지가 필요하다. 사내 PyPI를 사용하거나 패키지의 `wheelhouse` 폴더에 wheel 파일을 넣으면 `RUN.bat`가 오프라인 설치를 우선한다.

```text
workspace-doc-ai-skill/
  wheelhouse/
    PyYAML-....whl
    openpyxl-....whl
    python_pptx-....whl
    playwright-....whl
    ...
```

`wheelhouse`가 있으면 다음 방식으로 설치한다.

```bat
pip install --no-index --find-links wheelhouse -r requirements.txt
```

Playwright Chromium도 인터넷 차단 환경에서는 사전 배포된 브라우저 또는 사내 미러가 필요할 수 있다. 화면 캡처를 선택하지 않으면 Chromium 설치 없이 정적 분석과 문서 생성이 가능하다.

---

## 13. 안전한 Runtime 점검

- Oracle: `SELECT 1 FROM DUAL`, 현재 schema/DB, USER_* metadata
- Redis Cluster: PING, cluster topology/info/nodes/slots
- Elasticsearch: root, cluster health, index/alias metadata
- Kafka: broker socket, topic, consumer-group metadata
- Grafana: health, datasource, dashboard, folder, alert metadata
- Prometheus: ready, build/runtime info, target, rule
- Loki: ready, build info, label/series metadata

변경·삭제·메시지 소비·Redis value 조회는 수행하지 않는다.

---

## 14. Self Test

```bat
.venv\Scripts\python.exe scripts\self_test.py
```

검증 항목:

- React Route 및 API
- Spring Boot endpoint
- Vert.x route와 Verticle
- EventBus 연결
- Redis Cluster 자동 탐지
- 5개 Excel 생성/열기/필수 시트
- 2개 PPT 생성/열기/최소 슬라이드
- JSON Schema
- validation report PASS

---

## 15. 주요 파일

```text
RUN.bat                         Windows 원클릭 실행
CONFIGURE_ONLY.bat              자동 Config만 생성
RUN_STATIC_ONLY.bat             외부 접속 없는 정적 실행
RESET_LOCAL_CONFIG.bat          로컬 설정 초기화

scripts/auto_configure.py       질문형/무인 자동 설정
scripts/windows_launcher.py     Config→브라우저→문서 생성 연결
scripts/analyze_workspace.py    Workspace 전체 정적 분석
scripts/probe_runtime_resources.py
scripts/capture_manual_screens.py
scripts/capture_resource_screens.py
scripts/generate_excel_documents.py
scripts/generate_manual_ppt.py
scripts/validate_outputs.py
scripts/self_test.py

scripts/utils/auto_config_discovery.py
scripts/utils/runtime_clients.py
scripts/utils/react_parser.py
scripts/utils/spring_parser.py
scripts/utils/vertx_parser.py
scripts/utils/framework_mapper.py
scripts/utils/resource_parser.py
scripts/utils/db_parser.py
scripts/utils/dependency_parser.py
scripts/utils/jar_parser.py
```
