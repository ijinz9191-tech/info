# Self Test v4

패키지에는 React + Spring Boot + Vert.x + Oracle + Redis Cluster + Elasticsearch + Kafka + Grafana dashboard + Prometheus + Loki 예제 Workspace가 포함되어 있다.

```bat
.venv\Scripts\python.exe scripts\self_test.py
```

생성 결과를 유지하려면:

```bat
.venv\Scripts\python.exe scripts\self_test.py --keep
```

지정 경로에 생성하려면:

```bat
.venv\Scripts\python.exe scripts\self_test.py --work-dir C:\temp\workspace-doc-self-test
```

Self test는 다음을 확인한다.

- 자동 Config React 탐지
- 자동 Config Spring Boot 탐지
- 자동 Config Vert.x 탐지
- Oracle DSN 자동 탐지
- Redis mode=`cluster` 및 node 3개 이상
- Kafka bootstrap server 2개 이상
- React Route/API 및 React→Backend 매핑
- Spring Boot endpoint
- Vert.x route/Verticle/EventBus 연결
- 5개 Excel 및 필수 시트
- WorkBook·아키텍쳐정의서 자동설정 시트
- 사용자/운영자 PPT 및 운영자 자동 설정 결과 슬라이드
- 분석/Runtime JSON Schema
- validation report PASS

실제 화면과 Runtime 리소스는 실행 환경에 의존하므로 문서 생성 self test에서는 비활성화한다. 자동 접속 코드는 별도의 mock 없이 운영 주소에 접근하지 않는다.
