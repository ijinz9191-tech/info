@echo off
cd /d "%~dp0\.."
call RUN.bat --workspace "D:\workspace\my-system" --non-interactive --static-only --no-open-output
