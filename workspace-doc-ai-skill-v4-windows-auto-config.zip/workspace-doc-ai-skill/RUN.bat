@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>&1
cd /d "%~dp0"
title Workspace Documentation Generator v4

echo ============================================================
echo  React + Spring Boot + Vert.x Workspace 문서 자동 생성기 v4
echo  Python 3.11 확인 - 자동 Config - 분석 - PPT/Excel 생성
echo ============================================================

set "PY_CMD="
py -3.11 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)" >nul 2>&1
if not errorlevel 1 set "PY_CMD=py -3.11"

if not defined PY_CMD (
  python -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)" >nul 2>&1
  if not errorlevel 1 set "PY_CMD=python"
)

if not defined PY_CMD (
  echo.
  echo [오류] Python 3.11 이상 64-bit를 설치한 뒤 다시 실행하세요.
  echo 설치 시 "Add python.exe to PATH"를 체크하거나 Python Launcher를 설치하세요.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo.
  echo [1/4] 전용 Python 가상환경을 만듭니다.
  %PY_CMD% -m venv .venv
  if errorlevel 1 goto :fail
)

set "VPY=%CD%\.venv\Scripts\python.exe"
set "BASE_STAMP=.venv\.workspace-doc-v4-base-ready"
set "RUNTIME_STAMP=.venv\.workspace-doc-v4-runtime-ready"
set "HAS_WHEELHOUSE="
set "SKIP_RUNTIME_DEPS="
for %%A in (%*) do (
  if /I "%%~A"=="--static-only" set "SKIP_RUNTIME_DEPS=1"
  if /I "%%~A"=="--configure-only" set "SKIP_RUNTIME_DEPS=1"
)
for %%F in ("wheelhouse\*.whl") do if exist "%%~fF" set "HAS_WHEELHOUSE=1"

if not exist "%BASE_STAMP%" (
  echo.
  echo [2/4] 필수 Python 패키지를 설치합니다.
  "%VPY%" -m pip install --upgrade pip
  if errorlevel 1 goto :fail

  if defined HAS_WHEELHOUSE (
    "%VPY%" -m pip install --no-index --find-links "wheelhouse" -r requirements.txt
  ) else (
    "%VPY%" -m pip install -r requirements.txt
  )
  if errorlevel 1 goto :fail
  >"%BASE_STAMP%" echo ready
)

if defined SKIP_RUNTIME_DEPS (
  echo.
  echo [3/4] 정적/설정 전용 실행이므로 런타임 점검 패키지 설치를 건너뜁니다.
) else if not exist "%RUNTIME_STAMP%" (
  echo.
  echo [3/4] Oracle, Redis Cluster, Kafka 런타임 점검 패키지를 설치합니다.
  if defined HAS_WHEELHOUSE (
    "%VPY%" -m pip install --no-index --find-links "wheelhouse" -r requirements-runtime.txt
  ) else (
    "%VPY%" -m pip install -r requirements-runtime.txt
  )
  if errorlevel 1 (
    echo [경고] 런타임 전용 패키지 설치 실패. 정적 분석과 문서 생성은 계속 가능합니다.
  ) else (
    >"%RUNTIME_STAMP%" echo ready
  )
)

echo.
echo [4/4] Workspace 자동 설정 및 문서 생성을 시작합니다.
"%VPY%" scripts\windows_launcher.py %*
if errorlevel 1 goto :fail

echo.
echo 완료되었습니다.
pause
exit /b 0

:fail
echo.
echo [실패] 위 오류 내용을 확인하세요.
echo 사내망이면 사내 PyPI 주소 또는 wheelhouse 폴더의 wheel 파일이 필요할 수 있습니다.
pause
exit /b 1
